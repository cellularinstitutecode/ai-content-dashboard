# AI Content Dashboard — Next.js app

The dashboard application. Lives in this `web/` subfolder; deploy it with `web` as the root directory (Vercel) or with the repository `Dockerfile` (Dokploy / any Docker host).

## Stack
- **Frontend + API routes:** Next.js (App Router) + Tailwind
- **AI generation:** Anthropic Claude **and** OpenAI (\`/api/generate\` — toggle in UI)
- **Scheduling proxy:** Metricool (\`/api/metricool/schedule\`) — token never leaves the server
- **Video clips proxy:** OpusClip (\`/api/opus/clip\`) — key never leaves the server
- **Drafts + Auth:** Supabase (Postgres + RLS + email auth)
- **Dashboard data:** stat counters (`/api/stats`), scheduled posts (`/api/posts`), Content Calendar (`/calendar`) and Brand Brain (`/api/brand`, `/brand`), and Schedule Templates (`/templates`, `/api/templates`)

## Setup

Step-by-step setup (accounts, database, keys, deploy, the cheapest
configuration) is in [`../SETUP.md`](../SETUP.md). Every setting is documented
in [`.env.example`](./.env.example).

## Environment variables at a glance

| Key | Required? | Where to get it |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` | yes | Supabase → Project Settings → API |
| `ANTHROPIC_API_KEY` **or** `OPENAI_API_KEY` (+ `AI_PROVIDER`) | yes (one) | console.anthropic.com / platform.openai.com |
| `METRICOOL_USER_TOKEN`, `METRICOOL_USER_ID`, `METRICOOL_BLOG_ID` (+ `NEXT_PUBLIC_` copies of the two ids) | yes | Metricool → Settings → API |
| `ALLOWED_EMAILS` (+ `NEXT_PUBLIC_ALLOWED_EMAILS`) | yes | your own sign-in email(s); empty = nobody can sign in |
| `CRON_SECRET`, `MEDIA_URL_SECRET` | yes | `openssl rand -hex 32` |
| `NEXT_PUBLIC_BRAND_NAME`, `BRAND_DESCRIPTION`, `BRAND_LOCATION`, `BRAND_HASHTAG`, `BRAND_WEBSITE`, `CONTACT_EMAIL` | recommended | your brand (Brand Brain in the app overrides) |
| `SCHEDULE_TIMEZONE` | recommended | your IANA zone, e.g. `America/New_York` (default UTC) |
| `OPUS_API_KEY`, `SEMRUSH_API_KEY`, `WORDPRESS_*`, `GOOGLE_SERVICE_ACCOUNT_JSON`, `SOURCES_*` | optional | only for those integrations |

## Local dev
\`\`\`
cd web
cp .env.example .env.local   # then fill in real values
npm install
npm run dev
\`\`\`

## How the AI toggle works
- The default provider is whatever \`AI_PROVIDER\` is set to in env.
- The dashboard UI has a **Claude / OpenAI** toggle that overrides per-request.
- Both providers return the same JSON shape: \`{ instagram, facebook, linkedin, blog }\`.
- Drafts persist a \`provider\` column so Recent Drafts shows which AI wrote each one.

## Security model
- All third-party API keys (Anthropic, OpenAI, Metricool, OpusClip, Supabase service role) live **only** in server environment variables.
- The browser never sees them — every external call goes through a server route.
- Supabase Row Level Security ensures users only see their own drafts/posts/clips.
- The auth middleware redirects unauthenticated users to \`/sign-in\` (the `/sign-in` page and Supabase auth callback are implemented).

## Recently shipped
- Brand Brain profile is now threaded into `/api/generate` — generations follow the stored voice, audience, keywords and guidelines.
- Live Metricool metrics (followers / reach / impressions / engagement) surface as extra cards in the dashboard counter row when analytics are loaded.
- `/sign-in` page with Supabase email auth and `/auth/callback` handler.
- Stat counters (Drafts / Scheduled / Upcoming / Clip jobs) wired to `/api/stats`.
- Content Calendar (`/calendar`) with a month-grid layout and drag-to-reschedule — dropping a post onto another day PATCHes `/api/posts` to move it (keeping its time of day).
- Brand Brain (`/brand`) profile editor backed by the `brand_profiles` table via `/api/brand`.
- `PATCH /api/posts` reschedules a single post's `publication_date` (used by calendar drag-and-drop).
- Schedule Templates (`/templates`) — save a reusable weekly posting cadence (providers, weekdays, time, text) via `/api/templates`.
- Apply a template with `POST /api/templates/apply` to materialize the next N weeks of scheduled posts into the `posts` table.

## Approval lives on the dashboard

Every post the app creates lands in Metricool's review queue (`draft: true`,
`autoPublish: false`). The reviewer's yes is `PATCH /api/posts { id,
action: 'approve' }` (or `'publish_now'`), which replaces the post in Metricool
with `draft: false, autoPublish: true`; Metricool then publishes at the set
time. It is the only path by which a post goes out, it is reachable only from
the Approve buttons (queue, calendar, Autopilot's "Approve & schedule"), and
our row changes only after Metricool accepted the change. Nobody needs to open
Metricool. `lib/metricool-post.ts` holds the mode flags and the replace body
(a REPLACE must carry text, networks, date and media, or the picture is
dropped); `lib/metricool.ts` does the HTTP.

## One clock, everywhere

Times a person READS come from `lib/schedule-clock.ts`; times the app WRITES
come from `lib/timezone.ts`; the Metricool handoff conversion is
`lib/metricool-time.ts`. The root layout stamps the resolved zone on
`<html data-schedule-tz>` so client components display the same clock the
server schedules with — no `NEXT_PUBLIC_` copy to drift.

Do not format a scheduled time with `toLocaleString(undefined, …)`. That renders
in the *viewer's* zone, which is how the composer came to say 9:00 AM and the
queue 7:00 AM for the same post.

## Progressive disclosure

Image Studio, Long-form to Shorts, SEO intelligence and the Research Copilot
are wrapped in `components/CollapsibleSection` and arrive folded. Their bodies
are unmounted while closed, which also stops the SEO panel spending Semrush
units on a section nobody opened. The daily job — Create, Publish, Autopilot,
Recent Drafts — stays open.

## Image verification: defects vs. opinions

The vision reviewer's findings are split by `lib/image-verdict.ts`. Text,
anatomy, logos and graphic content are **blocking** — they flag the image and
trigger a regeneration. Relevance, composition and rendering taste are
**advisory** — shown as a note count on the verified badge, never a reason to
flag. Before the split, "unclear relevance" put an amber warning on four of
five usable images.

## Semrush needs a Standard API (v3) key

Every report this app runs — and the free balance endpoint that guards spend —
is Semrush's Standard API (v3). The keys issued on Semrush's "API Keys" page
are **v4** keys, which v3 endpoints reject. With a v4 key the balance reads as
unreadable, the spend guard fails closed, and every live lookup is refused;
the app reports this as `balance_unknown` (health `code`, panel notice, status
banner) and says explicitly that adding units will not change it. A Standard
API key is a Business-plan entitlement. Do not diagnose "no keyword data" as
"out of units" until `/api/semrush?action=balance` returns a number.

## Health means capability

`/api/health` reports configuration, with one exception: the Semrush check asks
the budget guard whether a lookup would actually run, not whether the key is
set. The status banner on the dashboard reads the `code` it returns to say
*why* keyword research is paused.

## Known gaps to wire next
- Multi-account team roles.
- The Opus webhook replay guard (`seenSalts`) is per-instance, so it is
  best-effort on multi-instance serverless.

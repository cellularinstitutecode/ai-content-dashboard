// web/lib/growth-history.ts
// What has brought the brand customers, in numbers — the standing knowledge
// the assistant reasons from when it suggests what to write and where.
//
// A blank deployment has no history, so this ships EMPTY: the block below
// tells the assistant there is none rather than letting it guess. When your
// team pulls its own lead or sales history (from a CRM, the ad accounts, the
// shop), write it into GROWTH_HISTORY in a few dated lines — which channels
// and searches brought customers, and which only brought attention — and set
// GROWTH_HISTORY_AS_OF to the date it was pulled; the date is part of the fact.
// Metricool's engagement numbers (lib/workspace-snapshot.ts performanceBlock)
// say what got attention; this says what got CUSTOMERS, which is not the same
// thing, and the assistant is told both.
//
// Pure, no imports: read by the playbook, the voice session and the tests.

/** When the history below was pulled. '' while none has been recorded. */
export const GROWTH_HISTORY_AS_OF = '';

export const GROWTH_HISTORY = `# WHAT HAS BROUGHT CUSTOMERS (${GROWTH_HISTORY_AS_OF ? 'lead history as of ' + GROWTH_HISTORY_AS_OF : 'no lead history recorded yet'})

No lead or sales history has been recorded for this brand yet. Do not invent one: when choosing
what to write, where and when, reason from what has worked on the accounts (engagement), say that
this is attention rather than customers, and remember that leads are not customers — search
intent usually converts better than reach. Say whether a suggestion rests on attention
(engagement) or on customers (a history, once the team adds one here).`;

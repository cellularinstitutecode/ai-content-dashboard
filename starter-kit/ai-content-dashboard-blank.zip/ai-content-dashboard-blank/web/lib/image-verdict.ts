// web/lib/image-verdict.ts
// Turn the vision reviewer's answer into a verdict — as a pure function, so it
// can be tested without an image, a key, or a network.
//
// The reviewer runs six checks. Four of them find DEFECTS: visible text,
// warped anatomy, stray logos or watermarks, graphic medical content. Those
// must flag the image and trigger a regeneration; nothing like that may reach
// a public-facing channel. The other two are OPINIONS: "rendering quality"
// and "relevance to the topic". Those are what actually fired on the live
// deployment — "unclear relevance", "non-specific background elements" — and
// they put an amber warning on four of five perfectly usable photographs.
//
// A warning that lights up on nearly everything teaches the reviewer to stop
// reading it, including the one time it says there is text in the picture.
// So: defects are blocking, opinions are advisory, and only blocking findings
// change the status.

export type ImageVerdict = {
  status: 'approved' | 'flagged';
  score: number | null;
  /** Blocking findings — the reasons the status is 'flagged'. */
  issues: string[];
  /** Notes worth showing a person, that do not fail the image. */
  advisory: string[];
  textDetected: boolean;
  /**
   * A banned prop or a device on a person is in frame. Like text, this is a
   * picture that must never be attached to a post — see imageUnshippable.
   */
  bannedProp: boolean;
  /** Advisory 0-100: how much the picture lives in the brand's own world. Never affects status. */
  brandFit: number | null;
  /** Planner covers: how far down the frame the highest head starts, as a percentage. Null when not measured. */
  headTopPct?: number | null;
};

const TEXT_RE = /\btext\b|letter|typograph|caption|\bword|writing|lettering|number|digit|signage|\bsign\b/i;

// Findings that are defects whatever the reviewer called them. Anything that
// is not one of these — composition, mood, relevance, "generic", "stock-like",
// lighting — is a matter of taste and stays advisory.
const BLOCKING_RE = new RegExp(
  [
    // anatomy
    'finger', 'hand', 'limb', 'anatom', 'warped', 'distort', 'merged', 'extra (arm|leg|eye)', 'malformed', 'deformed', 'impossible pose',
    // marks
    'logo', 'watermark', 'trademark', 'brand mark', 'brandmark',
    // graphic medical content
    'needle', 'blood', 'wound', 'gore', 'graphic', 'distressing', 'injur', 'syringe', 'vial', 'ampoule',
    // teaching props and medicines — a brand photograph contains neither
    'model (brain|heart|spine|lung|kidney|organ|skull|torso)', '(brain|heart|spine|organ|torso) model',
    'skeleton', 'skull', 'mannequin', 'teaching (model|prop|aid)', 'anatomical (chart|poster|model)',
    '(pill|supplement|vitamin|medicine|medication|tablet|capsule) bottle', 'blister pack', 'loose (pills|tablets|capsules)',
    // devices worn by or given to a person — a conversation, never a procedure
    'blood.?pressure cuff', 'bp cuff', 'ecg', 'ekg', 'electrode', 'pulse oximeter', 'iv (line|drip|bag)', 'cannula', 'catheter',
    'glucose monitor', 'oxygen mask', 'injector pen', 'infusion',
    // outright broken renders
    'uncanny', 'artifact', 'glitch', 'corrupt',
  ].join('|'),
  'i',
);

/**
 * The props-and-devices part of BLOCKING_RE, on its own: a brand photograph
 * contains no anatomical model, no medicine, and nothing worn by or given to a
 * person. Exported so the planner's own scene briefs can be checked against
 * it — two of them used to ASK for a cuff on an arm and a dish of capsules.
 */
export const BANNED_PROP_RE = new RegExp(
  [
    'model (brain|heart|spine|lung|kidney|organ|skull|torso)', '(brain|heart|spine|organ|torso) model',
    'skeleton', 'skull', 'mannequin', 'teaching (model|prop|aid)', 'anatomical (chart|poster|model)',
    '(pill|supplement|vitamin|medicine|medication|tablet|capsule) bottle', 'blister pack', '\\bpills?\\b', '\\bcapsules?\\b', '\\btablets\\b',
    'syringe', '\\bvials?\\b', 'ampoule', '\\bneedles?\\b',
    'blood.?pressure cuff[^,;.]{0,20}\\b(on|around) (the |a |an |their |his |her )?(patient.s |person.s )?(upper )?arm', 'bp cuff', 'ecg', 'ekg', 'electrode',
    'pulse oximeter', 'iv (line|drip|bag)', 'cannula', 'catheter', 'glucose monitor', 'oxygen mask', 'injector pen', 'infusion',
    'banned prop',
  ].join('|'),
  'i',
);

/**
 * May this picture be attached to a post at all?
 *
 * Text has always been refused at the ship-point. A banned prop was not: the
 * verdict flagged the image, the pipeline kept the best flagged candidate when
 * three attempts were all flagged, and approval — and autoschedule — attached
 * it anyway. So a planner post could go out showing a syringe or a cuff on an
 * arm. Now both are the same rule, in one place. `issues` is read too, so an
 * image verified before `bannedProp` was recorded is judged the same way.
 */
export function imageUnshippable(v: { textDetected?: boolean; bannedProp?: boolean; issues?: readonly string[] } | null | undefined): boolean {
  if (!v) return false;
  if (v.textDetected === true || v.bannedProp === true) return true;
  return (v.issues || []).some((i) => /banned prop/i.test(String(i)));
}

function strings(v: unknown, cap = 8): string[] {
  return Array.isArray(v) ? v.map((i) => String(i).slice(0, 160)).filter(Boolean).slice(0, cap) : [];
}

/**
 * `requireOnTopic` is set only for weekly-planner images (lib/planner-image.ts),
 * whose subject is concrete — food for nutrition, a bedroom for sleep. For those,
 * a picture that shows something else (a generic reception desk, every time) is a
 * defect, not a matter of taste. Every other image keeps relevance advisory.
 */
export function classifyVerdict(raw: unknown, opts: { requireOnTopic?: boolean; minHeadTopPct?: number } = {}): ImageVerdict {
  const obj = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const score = typeof obj.score === 'number' && Number.isFinite(obj.score)
    ? Math.max(0, Math.min(100, Math.round(obj.score)))
    : null;
  // Brand fit is an opinion about palette, materials and camera. It rides
  // along for the human and for ranking ties; it can never flag an image.
  const brandFit = typeof obj.brandFit === 'number' && Number.isFinite(obj.brandFit)
    ? Math.max(0, Math.min(100, Math.round(obj.brandFit)))
    : null;

  // The reviewer is asked for `blocking` and `advisory` lists. An older answer
  // shape (one flat `issues` list) is sorted by content instead of trusted.
  let blocking = strings(obj.blocking);
  let advisory = strings(obj.advisory);
  if (!blocking.length && !advisory.length) {
    for (const i of strings(obj.issues)) {
      (TEXT_RE.test(i) || BLOCKING_RE.test(i) ? blocking : advisory).push(i);
    }
  }
  // A "defect" the reviewer filed under advisory is still a defect.
  const promoted = advisory.filter((i) => TEXT_RE.test(i) || BLOCKING_RE.test(i));
  if (promoted.length) {
    blocking = [...blocking, ...promoted].slice(0, 8);
    advisory = advisory.filter((i) => !promoted.includes(i));
  }

  // Weekly-planner covers carry a title in the top band: a head reaching up
  // into it is a defect (the reviewer reports where the highest head starts).
  const headTop = typeof obj.headTopPct === 'number' && Number.isFinite(obj.headTopPct) ? obj.headTopPct : null;
  if (opts.minHeadTopPct != null && headTop != null && headTop < opts.minHeadTopPct) {
    blocking = ['a head reaches into the title area (top of head at ' + Math.round(headTop) + '% from the top)', ...blocking].slice(0, 8);
  }
  // A banned prop fails the image on its own, on EVERY path — the rule used to
  // ride at the end of the on-topic paragraph, where a reviewer looking at a
  // flat lay of a model brain and a pill bottle simply sailed past it.
  if (obj.bannedProp === true) {
    blocking = ['a banned prop is in frame — an anatomical model, teaching prop, or a pill or medicine bottle', ...blocking].slice(0, 8);
  }
  if (opts.requireOnTopic && obj.onTopic === false) {
    blocking = ['off-topic — the picture does not show what this post is about', ...blocking].slice(0, 8);
  }

  // Text can never pass, whatever any other field says. Belt and braces: catch
  // a text mention in the findings even if the dedicated flag was forgotten.
  const textDetected = obj.textDetected === true || blocking.some((i) => TEXT_RE.test(i));
  if (textDetected && !blocking.some((i) => /\btext\b/i.test(i))) {
    blocking = ['visible text/letters detected — content images must be text-free', ...blocking].slice(0, 8);
  }

  // The reviewer saying "not approved" with no defect named at all is the one
  // ambiguous case; respect it, because the cost of a wrong pass is higher
  // than the cost of a wrong flag.
  const vetoWithoutReason = obj.approved === false && !blocking.length && !advisory.length;

  const flagged = textDetected || blocking.length > 0 || vetoWithoutReason;
  return {
    headTopPct: headTop,
    status: flagged ? 'flagged' : 'approved',
    score,
    issues: flagged && vetoWithoutReason && !blocking.length ? ['reviewer declined the image without naming a defect'] : blocking,
    advisory,
    textDetected,
    bannedProp: obj.bannedProp === true,
    brandFit,
  };
}

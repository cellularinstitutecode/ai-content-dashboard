import { test } from 'node:test';
import assert from 'node:assert/strict';
import { classifyDomain, serpLandscapeFrom, themesFrom, type SerpRow } from './serp-landscape.ts';

/** A top 10 for "insomnia" (us): institutions and reference works. */
const INSTITUTIONAL: SerpRow[] = [
  { domain: 'www.mayoclinic.org', url: 'https://www.mayoclinic.org/diseases-conditions/insomnia/symptoms-causes/syc-20355167' },
  { domain: 'www.hopkinsmedicine.org', url: 'https://www.hopkinsmedicine.org/health/conditions-and-diseases/insomnia' },
  { domain: 'pmc.ncbi.nlm.nih.gov', url: 'https://pmc.ncbi.nlm.nih.gov/articles/PMC0000000/' },
  { domain: 'my.clevelandclinic.org', url: 'https://my.clevelandclinic.org/health/diseases/12119-insomnia' },
  { domain: 'www.unitypoint.org', url: 'https://www.unitypoint.org/news-and-articles/insomnia' },
  { domain: 'medlineplus.gov', url: 'https://medlineplus.gov/insomnia.html' },
];

/** And a top 10 for "coffee roasting class springfield" — a completely different fight. */
const PEERS: SerpRow[] = [
  { domain: 'www.brewlab.org', url: 'https://www.brewlab.org/' },
  { domain: 'www.roast-institute.com', url: 'https://www.roast-institute.com/classes/best-coffee-roasting-class-in-springfield' },
  { domain: 'beanstudio.com', url: 'https://beanstudio.com/cost-of-coffee-roasting-class-in-springfield/' },
  { domain: 'roastservices.com', url: 'https://roastservices.com/travel-overview/coffee-farm-visit/' },
  { domain: 'kalimbaroasters.com', url: 'https://kalimbaroasters.com/licensed-coffee-roasting-course/' },
  { domain: 'www.youtube.com', url: 'https://www.youtube.com/watch?v=xxxxxxxxxxx' },
];

test('an institution, a journal, a rival business and a video are told apart', () => {
  assert.equal(classifyDomain('www.mayoclinic.org'), 'institution');
  assert.equal(classifyDomain('pmc.ncbi.nlm.nih.gov'), 'reference');
  assert.equal(classifyDomain('medlineplus.gov'), 'reference');
  assert.equal(classifyDomain('beanstudio.com'), 'peer');
  // A brand name with no telltale word is honestly 'other' — the posture below
  // must not depend on being able to name every competitor.
  assert.equal(classifyDomain('kalimbaroasters.com'), 'other');
  assert.equal(classifyDomain('www.youtube.com'), 'social');
});

test('the named lists win over the loose peer pattern', () => {
  // hopkinsMEDICINE and clevelandCLINIC both match the peer regex. If ordering
  // slipped, Johns Hopkins would be filed as a rival business and the post
  // would be told to out-specify it rather than not out-explain it.
  assert.equal(classifyDomain('www.hopkinsmedicine.org'), 'institution');
  assert.equal(classifyDomain('my.clevelandclinic.org'), 'institution');
  assert.equal(classifyDomain('roast-institute.com'), 'peer', 'contains "institute" but is a competitor');
});

test('against large institutions: do not try to out-explain them', () => {
  const out = serpLandscapeFrom('insomnia', INSTITUTIONAL);
  assert.match(out, /will not out-explain them/);
  assert.match(out, /never show one brand actually doing the thing/);
  assert.ok(!/rival businesses selling the same thing/.test(out));
});

test('against rival businesses: stop claiming, start showing', () => {
  // The opposite instruction, from the same function, on the same brand's
  // other keyword. This is the whole reason the file exists.
  const out = serpLandscapeFrom('coffee roasting class springfield', PEERS);
  assert.match(out, /rival businesses selling the same thing/);
  assert.match(out, /VERIFIABLE from this video/);
  assert.match(out, /comparing this brand against/);
  assert.ok(!/out-explain/.test(out));
});

test('unrecognisable competitors do not let two institutions outvote eight rivals', () => {
  // Most rivals carry nothing in their domains to mark them as peers. Counting
  // them neutral would have handed a page of direct competitors the "do not
  // out-explain the institution" instruction.
  const mostlyUnknown: SerpRow[] = [
    { domain: 'kalimbaroasters.com', url: 'https://kalimbaroasters.com/' },
    { domain: 'brandnamehere.com', url: 'https://brandnamehere.com/' },
    { domain: 'anotherbrand.co', url: 'https://anotherbrand.co/' },
    { domain: 'medlineplus.gov', url: 'https://medlineplus.gov/x.html' },
  ];
  assert.match(serpLandscapeFrom('x', mostlyUnknown), /rival businesses selling the same thing/);
});

test('the slugs give up what the competitors are worried about', () => {
  // A page's path is chosen to match the query it wants, which makes it an
  // unusually honest statement of what its visitors are anxious about.
  const themes = themesFrom(PEERS);
  assert.ok(themes.includes('being called the best'));
  assert.ok(themes.includes('what it costs'));
  assert.ok(themes.includes('whether it is legitimate and safe'));
  assert.ok(themes.includes('the logistics of getting there'));
});

test('a competitor is never named in the copy, whatever the landscape', () => {
  // Comparative advertising is separately regulated in many places, and an
  // advertiser naming a rival is a problem this pipeline must not be able to create.
  for (const rows of [INSTITUTIONAL, PEERS]) {
    assert.match(serpLandscapeFrom('x', rows), /NEVER name a competitor/);
    assert.match(serpLandscapeFrom('x', rows), /comparative claim/);
  }
});

test('no SERP data is a quieter post, never a failed one', () => {
  assert.equal(serpLandscapeFrom('anything', []), '');
  assert.equal(serpLandscapeFrom('', PEERS), '');
  assert.equal(serpLandscapeFrom('x', [{ domain: '', url: '' }]), '');
});

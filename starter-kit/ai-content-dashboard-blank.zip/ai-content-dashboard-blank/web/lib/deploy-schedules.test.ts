// Three schedulers, one list of jobs.
//
// deploy/dokploy-schedules.json is the full list: every background job, at its
// real frequency, run inside the container on Dokploy. vercel.json carries only
// the DAILY ones, because Vercel's free plan refuses any cron that runs more
// than once a day (and a refused cron fails the whole deployment). The rest
// run hourly from .github/workflows/scheduled-jobs.yml. If a job is added to
// one list and forgotten in another, one copy of the app quietly stops doing
// it — this says so.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const text = (p: string) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const read = (p: string) => JSON.parse(text(p));

type Cron = { path: string; schedule: string };
type Job = { name: string; path: string; cronExpression: string; command: string };

const vercelCrons = read('vercel.json').crons as Cron[];
const jobs = read('deploy/dokploy-schedules.json').schedules as Job[];
const workflow = text('../.github/workflows/scheduled-jobs.yml');

test('every Vercel cron is a Dokploy job at the same time', () => {
  for (const c of vercelCrons) {
    assert.ok(jobs.some((j) => j.path === c.path && j.cronExpression === c.schedule), c.path + ' @ ' + c.schedule + ' is not in deploy/dokploy-schedules.json');
  }
});

test('vercel.json holds daily crons only, so the free (Hobby) plan accepts the deployment', () => {
  for (const c of vercelCrons) {
    const [min, hour, ...rest] = c.schedule.split(' ');
    assert.match(min, /^\d+$/, c.path + ' runs more than once a day');
    assert.match(hour, /^\d+$/, c.path + ' runs more than once a day');
    assert.deepEqual(rest, ['*', '*', '*'], c.path + ' must run every day');
  }
});

test('every job Vercel does not run is run hourly by the GitHub workflow, and nothing else is', () => {
  const onVercel = new Set(vercelCrons.map((c) => c.path));
  const elsewhere = jobs.filter((j) => !onVercel.has(j.path)).map((j) => j.path.replace(/^\/api\//, '')).sort();
  const loop = workflow.match(/for job in ([^;]+); do/);
  assert.ok(loop, 'the workflow job loop has changed shape');
  assert.deepEqual(loop![1].trim().split(/\s+/).sort(), elsewhere);
  assert.match(workflow, /- cron: '\d+ \* \* \* \*'/, 'the workflow runs hourly');
  assert.match(workflow, /if: \$\{\{ vars\.APP_URL != '' \}\}/, 'and only once APP_URL is set');
});

test('each schedule runs cron-tick against its own path', () => {
  for (const j of jobs) {
    const route = j.path.replace(/^\/api\//, '');
    assert.equal(j.command, 'node scripts/cron-tick.mjs ' + route, j.name + ' does not call its own route');
    assert.match(j.name, /^[a-z0-9-]+$/, 'schedule names are plain slugs');
  }
});

test('cron-tick exists where the Dockerfile copies it from', () => {
  const src = readFileSync(new URL('../scripts/cron-tick.mjs', import.meta.url), 'utf8');
  assert.match(src, /authorization: 'Bearer ' \+ secret/, 'the tick must send the same header Vercel does');
  assert.match(src, /process\.exit\(res\.ok \? 0 : 1\)/, 'a non-2xx must fail the job');
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  CARD_SIZES, groundHex, inkFor, headlineSize, footerText, slidesFromPack, normalizeSlides,
  normalizeGround, normalizeSize, groundForSlide, GROUNDS,
} from './brand-card-layout.ts';
import { DEFAULT_VISUAL, contrast } from './brand-visual.ts';

test('card sizes are the formats the team posts in', () => {
  assert.deepEqual([CARD_SIZES.portrait.width, CARD_SIZES.portrait.height], [1080, 1350]);
  assert.deepEqual([CARD_SIZES.square.width, CARD_SIZES.square.height], [1080, 1080]);
});

test('every ground gets ink that reads on it, from the brand palette', () => {
  for (const g of ['paper', 'light', 'accent', 'accent2', 'dark2', 'dark'] as const) {
    const { ink, accent } = inkFor(g);
    assert.ok(contrast(groundHex(g), ink) >= 3, g + ' ink contrast (large-text AA)');
    assert.notEqual(accent.toUpperCase(), groundHex(g).toUpperCase(), g + ': the accent is never the ground colour');
  }
  // The neutral default pairs charcoal on the accent grey and on the light grey.
  assert.equal(inkFor('accent').ink, '#222222');
  assert.equal(inkFor('light').ink, '#222222');
  assert.equal(inkFor('dark').ink, '#D9D9D9');
});

test('grounds come from the profile palette by role, so a re-coloured brand re-colours its cards', () => {
  const v = { ...DEFAULT_VISUAL, palette: [
    { name: 'Ink', hex: '#101010', role: 'dark' as const },
    { name: 'Teal', hex: '#0A6B6B', role: 'accent' as const },
    { name: 'Sand', hex: '#F1E7D0', role: 'light' as const },
  ] };
  assert.equal(groundHex('accent', v), '#0A6B6B');
  assert.equal(groundHex('accent2', v), '#0A6B6B', 'a palette with one accent falls back to it');
  assert.equal(groundHex('light', v), '#F1E7D0');
  assert.equal(groundHex('dark', v), '#101010');
  assert.equal(groundHex('dark2', v), '#101010', 'a palette with one dark falls back to it');
  assert.equal(inkFor('accent', v).ink, '#F1E7D0');
  const noLight = { ...v, palette: v.palette.filter((c) => c.role !== 'light') };
  assert.equal(groundHex('light', noLight), '#D9D9D9', 'a missing role borrows the neutral default');
});

test('long headlines shrink instead of wrapping into a paragraph', () => {
  assert.ok(headlineSize('Short', 'portrait') > headlineSize('A headline of about forty characters here', 'portrait'));
  assert.ok(headlineSize('x'.repeat(100), 'portrait') >= 52);
  assert.ok(headlineSize('Short', 'landscape') < headlineSize('Short', 'portrait'), 'landscape cards set smaller');
});

test('the footer counts slides only when there is more than one', () => {
  assert.equal(footerText(1, 1), '');
  assert.equal(footerText(3, 8), '3/8');
});

test('a pack becomes the slide structure: cover, then one idea per paragraph, never the REF/AVISO/hashtag lines', () => {
  const pack = {
    instagram:
      'Sleep and focus: what the evidence says.\n\n' +
      'Peer-reviewed studies report better attention after a week of regular sleep for many adults. Every routine still starts with a consistent bedtime.\n\n' +
      'Not all naps are the same.\n\n' +
      '#sleep #focus\n' +
      'REF: Rogeri PS et al. (2021) Nutrients 14(1):52. DOI: 10.3390/nu14010052\n\n' +
      'AVISO DE PUBLICIDAD: 0000000000X00000',
  };
  const slides = slidesFromPack('Sleep and focus', pack, 8, 'Acme Studio');
  assert.equal(slides[0].headline, 'Sleep and focus');
  assert.equal(slides[0].kicker, 'Acme Studio', 'the cover carries the brand name');
  assert.equal(slides[1].headline, 'Sleep and focus: what the evidence says.');
  assert.equal(slides[2].headline, 'Peer-reviewed studies report better attention after a week of regular sleep for many adults');
  assert.match(slides[2].body || '', /^Every routine still starts/);
  assert.equal(slides[3].headline, 'Not all naps are the same.');
  assert.equal(slides.length, 4, 'hashtags, REF and AVISO are not slides');
  const all = JSON.stringify(slides);
  assert.doesNotMatch(all, /REF:|AVISO|#sleep/);
  assert.equal(slidesFromPack('t', pack, 8, '')[0].kicker, undefined, 'no name, no kicker');
  assert.ok(slidesFromPack('t', pack)[0].kicker, 'the deployment brand name by default');
});

test('a carousel is capped at eight slides', () => {
  const pack = { instagram: Array.from({ length: 20 }, (_, i) => 'Idea number ' + i + '.').join('\n\n') };
  assert.equal(slidesFromPack('t', pack).length, 8);
});

test('typed slides are cleaned and capped; a slide with no headline is dropped', () => {
  const s = normalizeSlides([{ headline: '  Hello   world ', body: 'b'.repeat(500), kicker: 'k' }, { body: 'orphan' }, 'junk', null]);
  assert.equal(s.length, 1);
  assert.equal(s[0].headline, 'Hello world');
  assert.equal(s[0].body?.length, 260);
  assert.equal(s[0].kicker, 'k');
  assert.deepEqual(normalizeSlides('nope'), []);
});

test('unknown grounds and sizes fall back to paper / portrait', () => {
  assert.equal(normalizeGround('neon'), 'paper');
  assert.equal(normalizeGround('accent'), 'accent');
  for (const g of GROUNDS) assert.equal(normalizeGround(g), g);
  assert.equal(normalizeSize('huge'), 'portrait');
  assert.equal(normalizeSize('square'), 'square');
});

test('a carousel opens on the strong colour and then alternates paper and the light colour', () => {
  assert.equal(groundForSlide('paper', 1, 5), 'accent');
  assert.equal(groundForSlide('dark', 1, 5), 'dark');
  assert.equal(groundForSlide('paper', 2, 5), 'paper');
  assert.equal(groundForSlide('paper', 3, 5), 'light');
  assert.equal(groundForSlide('paper', 1, 1), 'paper', 'a single card keeps what was asked for');
  assert.equal(groundForSlide('photo', 1, 3), 'photo');
  assert.equal(groundForSlide('photo', 2, 3), 'paper', 'only the cover carries the photograph');
});

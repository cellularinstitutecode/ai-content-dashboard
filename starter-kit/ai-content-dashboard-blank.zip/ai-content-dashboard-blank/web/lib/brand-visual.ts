// web/lib/brand-visual.ts
// The brand's VISUAL identity — palette, materials, light, photography
// direction — as data the image pipeline can read, instead of a PDF only
// people can. Brand Brain stores one of these per profile (brand_profiles.visual);
// buildImagePrompt() turns it into prompt language, the vision reviewer scores
// against it, and the brand-card compositor paints with it.
//
// Pure: no I/O, so every rule here is unit-tested. The defaults are a plain,
// brand-free neutral: a grey palette (cards need at least a dark, an accent and
// a light to pair text with ground), no materials or photography direction and
// no typeface names — so a fresh deployment carries nobody's look until its
// own brand is entered in Brand Brain.

export type BrandColor = { name: string; hex: string; role: 'dark' | 'accent' | 'light' };

export type BrandVisual = {
  /** Primary palette, darkest first. Roles decide text/background pairing on cards. */
  palette: BrandColor[];
  /** The materials and light a photograph should show — the brand's world. */
  materials: string;
  /** How the camera behaves: framing, angle, styling, expression. */
  photography: string;
  /** Things the brand's pictures never show, beyond the pipeline's own safety rules. */
  never: string[];
  /** Typeface names, for the record (the files themselves are uploaded per role in Brand Brain). */
  fonts: { headline: string; body: string };
};

const HEX = /^#[0-9a-f]{6}$/i;

export const DEFAULT_VISUAL: BrandVisual = {
  palette: [
    { name: 'Charcoal', hex: '#222222', role: 'dark' },
    { name: 'Slate', hex: '#4A4A4A', role: 'dark' },
    { name: 'Accent Grey', hex: '#8A8A8A', role: 'accent' },
    { name: 'Light Grey', hex: '#D9D9D9', role: 'light' },
  ],
  // Blank on purpose: an empty field is left out of the image brief rather
  // than filled with somebody else's world.
  materials: '',
  photography: '',
  never: [],
  // Blank = the open stand-in faces (public/fonts/standin) set the cards.
  fonts: { headline: '', body: '' },
};

/** A neutral off-white — the card ground when no palette colour is asked for. */
export const PAPER = '#F6F5F2';

function str(v: unknown, max: number): string {
  return typeof v === 'string' ? v.replace(/\s+/g, ' ').trim().slice(0, max) : '';
}

/**
 * Accept whatever Brand Brain saved (or a hand-edited JSON blob) and return a
 * complete, safe visual: bad colours dropped, a missing palette filled from the
 * neutral default, lengths capped so a profile can never blow up a prompt.
 */
export function normalizeVisual(raw: unknown): BrandVisual {
  const o = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const palette: BrandColor[] = [];
  if (Array.isArray(o.palette)) {
    for (const c of o.palette.slice(0, 8)) {
      const cc = (c && typeof c === 'object' ? c : {}) as Record<string, unknown>;
      const hex = str(cc.hex, 7).toUpperCase();
      if (!HEX.test(hex)) continue;
      const role = cc.role === 'dark' || cc.role === 'accent' || cc.role === 'light' ? cc.role : roleOf(hex);
      palette.push({ name: str(cc.name, 40) || hex, hex, role });
    }
  }
  const never = Array.isArray(o.never) ? o.never.map((n) => str(n, 120)).filter(Boolean).slice(0, 8) : [];
  const fonts = (o.fonts && typeof o.fonts === 'object' ? o.fonts : {}) as Record<string, unknown>;
  return {
    palette: palette.length >= 2 ? palette : DEFAULT_VISUAL.palette,
    materials: str(o.materials, 400),
    photography: str(o.photography, 400),
    never,
    fonts: {
      headline: str(fonts.headline, 40),
      body: str(fonts.body, 40),
    },
  };
}

/** Relative luminance (sRGB), 0 = black, 1 = white. */
export function luminance(hex: string): number {
  const h = hex.replace('#', '');
  const [r, g, b] = [0, 2, 4].map((i) => {
    const c = parseInt(h.slice(i, i + 2), 16) / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** A colour's role from its lightness when the profile did not say. */
export function roleOf(hex: string): BrandColor['role'] {
  const l = luminance(hex);
  return l > 0.5 ? 'light' : l < 0.08 ? 'dark' : 'accent';
}

/** WCAG contrast ratio between two colours. */
export function contrast(a: string, b: string): number {
  const la = luminance(a), lb = luminance(b);
  const [hi, lo] = la > lb ? [la, lb] : [lb, la];
  return (hi + 0.05) / (lo + 0.05);
}

/**
 * The palette colour to write with on a given ground: the lightest colour on a
 * dark ground, the darkest on a light one — always the pairing with the most
 * contrast, so a card is legible whatever colour it is asked for.
 */
export function textColorOn(ground: string, palette: BrandColor[] = DEFAULT_VISUAL.palette): string {
  let best = palette[0]?.hex || '#222222';
  let bestC = 0;
  for (const c of palette) {
    const cr = contrast(ground, c.hex);
    if (cr > bestC) { bestC = cr; best = c.hex; }
  }
  // The palette pairs itself (3:1 is fine for display type). Paper, white and
  // black are outside the palette and only step in when no palette colour
  // reads at all on this ground.
  if (bestC < 3) {
    for (const extra of [PAPER, '#FFFFFF', '#111111']) {
      if (contrast(ground, extra) > bestC) { best = extra; bestC = contrast(ground, extra); }
    }
  }
  return best;
}

/**
 * The palette's character in words — warm, cool or neutral; muted or vivid —
 * measured from the hexes themselves, so the brief never assumes a palette.
 */
export function paletteCharacter(palette: BrandColor[]): string {
  if (!palette.length) return '';
  let warm = 0, sat = 0;
  for (const c of palette) {
    const h = c.hex.replace('#', '');
    const [r, g, b] = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    warm += r - b;
    sat += max === 0 ? 0 : (max - min) / max;
  }
  warm /= palette.length;
  sat /= palette.length;
  const temp = warm > 18 ? 'warm' : warm < -18 ? 'cool' : 'neutral';
  const chroma = sat < 0.15 ? 'low-saturation' : sat < 0.45 ? 'muted' : 'vivid';
  return temp + ', ' + chroma;
}

/**
 * The visual identity as prompt language for the image model. Colours are
 * named AND given as hex — models follow colour words better than numbers,
 * but the numbers pin what the words mean for this brand. A blank materials
 * or photography field is left out rather than sent empty.
 */
export function visualPromptBlock(v: BrandVisual): string {
  const colours = v.palette.map((c) => `${c.name.toLowerCase()} (${c.hex})`).join(', ');
  const character = paletteCharacter(v.palette);
  return [
    `Colour world: ${colours}${character ? ' — ' + character : ''}; let these tones dominate the frame.`,
    v.materials ? `Materials and light: ${v.materials}.` : '',
    v.photography ? `Photography: ${v.photography}.` : '',
    v.never.length ? `Never: ${v.never.join('; ')}.` : '',
  ].filter(Boolean).join(' ');
}

/**
 * What the vision reviewer scores brand fit against — advisory, never a reason
 * to flag. A picture can be perfectly safe and still look like someone else's
 * brand; that is a note for the human, not a defect.
 */
export function brandFitRubric(v: BrandVisual): string {
  const colours = v.palette.map((c) => c.name).join(', ');
  const character = paletteCharacter(v.palette);
  const parts = [
    `BRAND FIT (advisory, 0-100): does the image live in this brand's world? Palette: ${colours}${character ? ' (' + character + ')' : ''}.`,
    v.materials ? `Materials/light: ${v.materials}.` : '',
    v.photography ? `Photography: ${v.photography}.` : '',
    v.materials || v.photography
      ? 'Score 90+ only when palette, materials and camera all match; 50 when neutral; under 30 when it reads as a different brand.'
      : 'Score 90+ only when the palette clearly matches; 50 when neutral; under 30 when it reads as a different brand.',
  ];
  return parts.filter(Boolean).join(' ');
}

// web/lib/brand-identity.ts
// Who this deployment publishes for — the handful of facts the code needs
// before anybody has opened Brand Brain.
//
// Every value comes from the environment and every default is blank or
// neutral, so a fresh copy of this repository carries no brand at all. Brand
// Brain (the `brand_profiles` row) is still the authority wherever a profile
// is loaded; these are only the deployment-wide fallbacks.
//
// Pure: no imports, so the test runner reads this file directly.
//
// NEXT_PUBLIC_* names are written out literally (not through a helper) because
// that is the only form Next.js inlines into the browser bundle.

function clean(v: string | undefined | null): string {
  return String(v || '').replace(/\s+/g, ' ').trim();
}

const ENV: Record<string, string | undefined> = typeof process !== 'undefined' && process.env ? process.env : {};

/** The brand's display name. Shown in the UI and given to every writer. */
export const BRAND_NAME: string =
  clean(typeof process !== 'undefined' ? process.env.NEXT_PUBLIC_BRAND_NAME : '') || clean(ENV.BRAND_NAME) || 'Your Brand';

/** One line on what the brand is or does, e.g. "a family-run bakery". Optional. */
export const BRAND_DESCRIPTION: string = clean(ENV.BRAND_DESCRIPTION);

/** Where the brand is, when that matters to the copy, e.g. "Austin, Texas". Optional. */
export const BRAND_LOCATION: string = clean(ENV.BRAND_LOCATION);

/** The brand's own hashtag, always placed first. Blank = no house tag. */
export const BRAND_HASHTAG: string = (() => {
  const t = clean(ENV.BRAND_HASHTAG).replace(/\s+/g, '');
  if (!t) return '';
  return t.startsWith('#') ? t : '#' + t;
})();

/** The brand's public website (https://…). Optional. */
export const BRAND_WEBSITE: string = clean(ENV.BRAND_WEBSITE);

/**
 * A contact address for polite API use (Crossref, PubMed and friends ask for
 * one in the User-Agent). Blank = the User-Agent simply carries none.
 */
export const CONTACT_EMAIL: string = clean(ENV.CONTACT_EMAIL);

/** The User-Agent this app identifies itself with to public research APIs. */
export const RESEARCH_USER_AGENT: string = 'ContentStudio/1' + (CONTACT_EMAIL ? ' (mailto:' + CONTACT_EMAIL + ')' : '');

/**
 * The brand described in one phrase, for a prompt: "Acme, a family-run bakery
 * in Austin, Texas". Only the parts that are set; never empty.
 */
export function describeBrand(
  over: { name?: string | null; description?: string | null; location?: string | null } = {},
): string {
  const name = clean(over.name) || BRAND_NAME;
  const desc = clean(over.description) || BRAND_DESCRIPTION;
  const loc = clean(over.location) || BRAND_LOCATION;
  return name + (desc ? ', ' + desc : '') + (loc ? (desc ? ' in ' : ', based in ') + loc : '');
}

// web/lib/library-topic.test.ts
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { GENERAL_PILLARS, REUSE_WINDOW_DAYS, pickFresh, pillarsForText, type LibraryCandidate } from './library-topic.ts';
import { BRAND_TARGET } from './palette.ts';

const cap = (subjects: string[], blockers: string[] = []) => ({ caption: 'x', subjects: subjects as never, blockers: blockers as never });
const photo = (id: string, subjects: string[], extra: Partial<LibraryCandidate> = {}): LibraryCandidate =>
  ({ id, name: id + '.png', caption: cap(subjects), stats: BRAND_TARGET, ...extra });

test('a post about muscle strength is a lifestyle post; a how-to is know-how; a recipe is food', () => {
  assert.equal(pillarsForText('Muscle strength and longevity — why staying active matters at every age')[0], 'lifestyle');
  assert.equal(pillarsForText('Five tips and common mistakes: a guide to planning your first order')[0], 'expertise');
  assert.equal(pillarsForText('Our breakfast recipe: protein, vegetables and good coffee')[0], 'food');
  assert.equal(pillarsForText('Behind the scenes of our workshop: the process and the tools')[0], 'craft');
  assert.deepEqual(pillarsForText(''), []);
  assert.deepEqual(pillarsForText('the and of'), [], 'nothing named, nothing offered');
});

test('the best pillar wins, and within it a fresh photograph beats a better one used lately', () => {
  const now = Date.parse('2026-09-30T12:00:00Z');
  const day = 24 * 60 * 60 * 1000;
  const photos = [
    photo('consult', ['conversation']),
    photo('gym-used', ['movement'], { lastUsedAt: now - 3 * day }),
    photo('gym-fresh', ['movement', 'exterior'], { lastUsedAt: now - (REUSE_WINDOW_DAYS + 1) * day }),
  ];
  const m = pickFresh(photos, ['movement', 'tips'], now);
  assert.equal(m?.id, 'gym-fresh', 'the movement photo not used in the window, even though the used one is more focused');
  assert.equal(m?.repeated, false);
  // Nothing fresh under movement: the least recently used is taken, and said to be a repeat.
  const busy = [photo('a', ['movement'], { lastUsedAt: now - 2 * day }), photo('b', ['movement'], { lastUsedAt: now - 10 * day })];
  const r = pickFresh(busy, ['movement'], now);
  assert.equal(r?.id, 'b');
  assert.equal(r?.repeated, true);
  // A pillar with nothing falls through to the next.
  assert.equal(pickFresh(photos, ['sleep', 'tips'], now)?.id, 'consult');
  assert.equal(pickFresh(photos, ['sleep'], now), null, 'no near-miss');
});

test('the cover rules and consent still refuse a photograph; an unmeasured one ranks below a measured one but is not refused', () => {
  const now = Date.now();
  const photos = [
    { ...photo('text', ['movement']), caption: cap(['movement'], ['text']) },
    { ...photo('patient', ['movement']), caption: cap(['movement'], ['identifiable-patient']) },
    photo('unmeasured', ['movement'], { stats: null }),
    photo('ok', ['movement']),
  ];
  assert.equal(pickFresh(photos, ['movement'], now)?.id, 'ok', 'the measured one first');
  assert.equal(pickFresh(photos, ['movement'], now, { exclude: ['ok'] })?.id, 'unmeasured', 'then the unmeasured one — the brand filter grades it at use');
  assert.equal(pickFresh(photos, ['movement'], now, { exclude: ['ok', 'unmeasured'] }), null, 'never a photo the cover rules refuse');
  assert.equal(pickFresh([{ ...photos[1], consentCleared: true }], ['movement'], now)?.id, 'patient', 'a release clears a recognisable customer');
});

test('a post whose words name no theme still gets a photograph of the business', () => {
  const photos = [photo('consult', ['conversation']), photo('room', ['workspace'])];
  const pillars = [...pillarsForText('Three things to know'), ...GENERAL_PILLARS];
  // Either photograph of the business serves; the more focused one (fewer themes) wins the tie.
  assert.ok(['consult', 'room'].includes(String(pickFresh(photos, pillars, Date.now())?.id)), 'a photograph of the business, not a generated picture');
  assert.equal(pickFresh([], pillars, Date.now()), null);
});

// web/lib/post-title.test.ts
//
// THE TITLE THAT WENT OUT. The composer sent the media label as the post's
// title, so YouTube and TikTok were handed, verbatim, a filename like:
//
//   Video_JordanxPartnercoxAcmeStudio_Alex.mp4
//
// Two staff names, a partner's name, a container word and a file extension, on
// a brand's public channel. lib/video-title.ts cleans a filename that CONTAINS
// its subject; this one does not contain one, and cleaning it produces
// "Jordanx Partnercox Acme Studio at Acme Studio" — worse than what it replaced.
//
// The answer was already in the pipeline: every prepared row runs a keyword
// search, reseeded from the transcript when the filename turns out to say
// nothing (lib/reseed.ts). It knows what this video is about. The title comes
// from that.
//
// Fixtures pass their own brand suffix and strip list, so the tests do not
// depend on whatever brand a deployment configures.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { looksInternal, professionalTitle, withClinic } from './post-title.ts';
import { titleCasePhrase, cleanVideoTitle } from './video-title.ts';

const src = (p: string) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
/** The staff names this fixture's files carry. */
const NO_ENV: Record<string, string | undefined> = { VIDEO_TITLE_STRIP: 'Alex,Jordan' };
const BRAND = 'Acme Studio';

test('the file that started this never reaches a title again', () => {
  const filename = 'Video_JordanxPartnercoxAcmeStudio_Alex.mp4';
  // What it used to produce, and why cleaning alone was not the fix.
  assert.match(cleanVideoTitle(filename, { suffix: BRAND, env: NO_ENV }), /Acme Studio at Acme Studio/);

  const out = professionalTitle({ supplied: filename, keyword: 'red light therapy', filename, suffix: BRAND, env: NO_ENV });
  assert.equal(out.title, 'Red Light Therapy at Acme Studio');
  assert.equal(out.source, 'keyword');
});

test('an editor’s name glued to the next word is still an editor’s name', () => {
  // "Jordanx" is why this matches on substring rather than whole word: the whole
  // -word rule in lib/video-title.ts left it in, and it was published.
  assert.equal(looksInternal('Jordanx Partnerco', NO_ENV), true);
  assert.equal(looksInternal('Reel_RedLight_Alex.mp4', NO_ENV), true);
  assert.equal(looksInternal('Red Light Therapy', NO_ENV), false);
  assert.equal(looksInternal('', NO_ENV), true, 'nothing is not a title');
  // Short entries stay whole-word, or "IV" would strike out "arrival".
  assert.equal(looksInternal('Arrival day at the studio', { VIDEO_TITLE_STRIP: 'iv' }), false);
  assert.equal(looksInternal('IV therapy day', { VIDEO_TITLE_STRIP: 'iv' }), true);
});

test('a title somebody wrote is kept in their words', () => {
  const out = professionalTitle({ supplied: 'Nuestro protocolo de oxígeno', keyword: 'oxygen therapy', suffix: BRAND, env: NO_ENV });
  assert.equal(out.title, 'Nuestro protocolo de oxígeno at Acme Studio');
  assert.equal(out.source, 'written', 'the keyword does not overrule a person');
});

test('the brand’s name is added once, never twice', () => {
  assert.equal(withClinic('Red Light Therapy', BRAND), 'Red Light Therapy at Acme Studio');
  assert.equal(withClinic('Inside Acme Studio', BRAND), 'Inside Acme Studio');
  assert.equal(withClinic('', BRAND), 'Acme Studio');
  assert.equal(withClinic('Red Light', ''), 'Red Light');
});

test('a searcher’s phrase is set like a title, not like a sentence', () => {
  assert.equal(titleCasePhrase('cold brew coffee for beginners'), 'Cold Brew Coffee for Beginners');
  assert.equal(titleCasePhrase('led lighting faq'), 'LED Lighting FAQ');
  assert.equal(titleCasePhrase('prp and dna'), 'PRP and DNA');
  assert.equal(titleCasePhrase(''), '');
});

test('the order is: a person, the research, the speaker, the file, the brand', () => {
  const env = NO_ENV;
  const suffix = BRAND;
  assert.equal(professionalTitle({ supplied: 'Written Title', keyword: 'kw', spoken: 'sp', filename: 'f.mp4', suffix, env }).source, 'written');
  assert.equal(professionalTitle({ keyword: 'red light therapy', spoken: 'sp', filename: 'f.mp4', suffix, env }).source, 'keyword');
  assert.equal(professionalTitle({ spoken: 'vagus nerve reset', filename: 'Reel_Alex.mp4', suffix, env }).source, 'spoken');
  assert.equal(professionalTitle({ filename: 'Reel_RedLightJordan_Alex.mp4', suffix, env }).source, 'filename');
  // Nothing usable anywhere: the brand's name alone is plain, and is never
  // wrong — unlike publishing the name of whoever held the camera.
  const nothing = professionalTitle({ filename: 'Reel_Alex.mp4', suffix, env });
  assert.equal(nothing.title, 'Acme Studio');
  assert.equal(nothing.source, 'clinic');
});

test('a keyword that is itself internal is refused, not published', () => {
  // Semrush has returned a partner's brand name as a "keyword" before. A title
  // is the one place that must never carry one.
  const out = professionalTitle({ keyword: 'jordan studio', filename: 'Reel_LEDSession.mp4', suffix: BRAND, env: NO_ENV });
  assert.equal(out.source, 'filename');
  assert.equal(out.title, 'LED Session at Acme Studio');
});

test('nothing absurdly long becomes a title', () => {
  const long = 'a'.repeat(200);
  assert.equal(professionalTitle({ supplied: long, suffix: BRAND, env: NO_ENV }).source, 'clinic');
});

// --- IT IS ACTUALLY USED ----------------------------------------------------

test('preparing a row titles it from the research it just ran', () => {
  const prepare = src('lib/video-prepare.ts');
  assert.match(prepare, /professionalTitle\(\{/, 'prepareVideo must build the public title');
  assert.match(prepare, /keyword: brief\.stamp\.primary/, 'from the keyword search, which is the point');
  assert.match(prepare, /title: publicTitle/, 'and the pack must carry it');
  assert.match(prepare, /saveVideoDraft\(input\.userId, publicTitle/, 'and so must the saved draft');
});

test('the composer sends the title a person can see, not the filename', () => {
  const page = src('app/page.tsx');
  assert.ok(!/title: mMediaLabel/.test(page), 'the media label is the FILENAME — it must never be the post title again');
  assert.match(page, /title: mTitle\.trim\(\) \|\| undefined/, 'the title box is what goes to Metricool');
  assert.match(page, /id="composer-title"/, 'and it has to be visible above the copy');
  // The title is WRITTEN from the video now, not looked up: "instead of the
  // keyword search I want to make sure it drafts it with AI taking into
  // consideration what was said from the copy and the transcription of the
  // video". The keyword search still runs where it belongs — server-side, when
  // a row is prepared — and still shapes the copy; it just no longer names it.
  assert.match(page, /\/api\/title/, 'with a way to write the title from the video');
});


test('which rung produced a title is recorded, and so is a model skipped for budget', () => {
  // THE REPEAT ON YOUTUBE. Four different reels went up under one and the same
  // title. The drafted title is budget-gated in lib/video-prepare.ts
  // — it is only asked for when the request has CLAIM_CHECK_MS left after
  // download, transcription, keywords, copy and the claim check — and when it
  // is skipped the next rung is the KEYWORD, which is the same phrase for every
  // video about the same subject. Nothing recorded which rung had fired, so the
  // repeat could be seen on YouTube and traced from nowhere.
  const src = (p: string) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
  const prep = src('lib/video-prepare.ts');
  assert.match(prep, /titleSkipped = 'budget';/, 'a skipped model is named as such');
  assert.match(prep, /const chosen = titleChoice\(\);/, 'the whole choice is kept, not just the string');
  assert.equal((prep.match(/titleSource: chosen\.source,/g) || []).length, 2, 'on the pack AND on the prepare result');
  assert.match(prep, /titleSource\?: string;/);
  // And the register carries it, from both doors that prepare a video.
  const sweep = src('lib/video-autopilot.ts');
  assert.equal((sweep.match(/titleSource: (?:opts\.)?prepared\.titleSource \?\? null/g) || []).length, 2, 'both prepared events');
});


test('the title is asked for BEFORE the claim check, with a budget of its own', () => {
  // THE FIX for the repeat. Last in line and borrowing CLAIM_CHECK_MS, the
  // drafted title was the first thing a slow row lost, and the keyword rung it
  // fell to is the same phrase for every video about one subject.
  const src = (p: string) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
  const prep = src('lib/video-prepare.ts');
  const title = prep.indexOf('draftedTitle = await writeTitle({');
  const ladder = prep.indexOf('// RUNG 1');
  assert.ok(title > 0 && ladder > 0);
  assert.ok(title < ladder, 'the title must be written before the claim ladder runs');
  assert.match(prep, /canWriteTitle\(remainingMs\(startedAt, budgetMs, Date\.now\(\)\)\)/, 'its own threshold');
  assert.doesNotMatch(prep.slice(title - 400, title), /canCheckClaim/, 'not the claim check\u2019s');
  const budget = src('lib/prepare-budget.ts');
  assert.match(budget, /export const TITLE_MS = 12_000;/);
  assert.match(budget, /export function canWriteTitle\(remaining: number\): boolean \{\s*return remaining >= TITLE_MS;/);
});

test('a send whose posts row could not be written is named, not forgotten', () => {
  // Metricool took the post; the row the duplicate guard reads did not get
  // written. One reportError and a silent `ok: true` is how a video ends up on
  // YouTube twice. The insert is retried, and a lost one reaches the register.
  const src = (p: string) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
  const pub = src('lib/video-publish.ts');
  assert.match(pub, /for \(let attempt = 0; attempt < 3 && !recorded; attempt\+\+\)/, 'three tries');
  assert.match(pub, /return \{ network, ok: true, metricoolPostId, recorded \};/, 'the outcome says whether the row exists');
  assert.match(pub, /recorded\?: boolean;/);
  const sweep = src('lib/video-autopilot.ts');
  assert.equal((sweep.match(/networks: sent, unrecorded,/g) || []).length, 3, 'all three queued events carry it');
  assert.equal((sweep.match(/const unrecorded = /g) || []).length, 3);
});

// web/lib/content-strategy.snapshot.test.ts
//
// The built-in example strategy, word for word, pinned against
// lib/content-strategy.ts.
//
// The literals below are the example as written, kept here separately from
// the module under test, so a change to either side is a disagreement this
// file reports. Each string ends up in a published post's brief. When you
// replace the example with your own strategy, replace these with it.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DAY_THEMES, FREQUENCY_PILLARS, WEEK, pillarById } from './content-strategy.ts';

/** The example's day pages: day, Post number, Post heading, the day's subtitle, and its angles. */
const DOCUMENT_POSTS: { day: number; post: number; heading: string; theme: string; angles: string[] }[] = [
  { day: 1, post: 1, heading: "How-to guides", theme: "Teach something useful", angles: [
    "A step-by-step guide to getting started",
    "The mistake beginners make most often, and how to avoid it",
    "How to choose the right option for your situation",
    "What to know before you begin",
    "A simple checklist for getting it right the first time"
  ] },
  { day: 1, post: 2, heading: "Product or service spotlight", theme: "Teach something useful", angles: [
    "One detail most people overlook",
    "Who this is for, and who it is not for",
    "How it works, explained in plain words",
    "What goes into making it",
    "How to get the most value from it"
  ] },
  { day: 2, post: 1, heading: "Tips and quick wins", theme: "Quick wins and what is new", angles: [
    "A two-minute tip that saves time",
    "Three small habits that make a big difference",
    "A shortcut our team uses every day",
    "A common problem and a quick fix",
    "How to do more with what you already have",
    "One thing to stop doing this week"
  ] },
  { day: 2, post: 2, heading: "Industry news and insights", theme: "Quick wins and what is new", angles: [
    "A recent change in our industry and what it means for you",
    "A trend worth watching this year",
    "What the latest numbers say, in plain words",
    "A question everyone in our field is asking right now",
    "How the way people shop for this has changed",
    "An overlooked idea from a recent report or event"
  ] },
  { day: 3, post: 1, heading: "Behind the scenes", theme: "Show how it is made", angles: [
    "A day in the life of our team",
    "How an idea becomes something we offer",
    "The tools we rely on, and why",
    "Meet someone on the team",
    "What a busy week looks like from the inside",
    "A mistake we made and what we changed"
  ] },
  { day: 3, post: 2, heading: "Ideas and inspiration", theme: "Show how it is made", angles: [
    "An idea to try this season",
    "Small ways to make an ordinary day better",
    "Where our team finds inspiration",
    "A creative use for something you already own",
    "A goal worth setting this month",
    "A book, podcast or idea that changed how we think"
  ] },
  { day: 4, post: 1, heading: "Getting started", theme: "Learn and connect", angles: [
    "Where to begin if you are completely new to this",
    "The terms worth knowing, explained simply",
    "How to tell whether you are on the right track",
    "Questions to ask before you decide",
    "How to compare your options fairly",
    "What realistic progress looks like"
  ] },
  { day: 4, post: 2, heading: "Community and values", theme: "Learn and connect", angles: [
    "What we stand for, and why it matters to us",
    "A local cause or partner we support",
    "How we try to do business responsibly",
    "Thank you to the people who make this possible",
    "A conversation we want to start with our community",
    "The story of how we started"
  ] },
  { day: 5, post: 1, heading: "FAQ and myth-busting", theme: "Questions, answered", angles: [
    "The question we hear most often, answered",
    "A common myth, and what is actually true",
    "What to expect when you work with us",
    "How long it really takes, and why",
    "Why the right choice depends on your needs",
    "How to look after it so it lasts"
  ] },
  { day: 5, post: 2, heading: "Customer stories", theme: "Questions, answered", angles: [
    "A common challenge people bring to us, and how we approach it",
    "Questions people ask before they decide to work with us",
    "How we handle it when something goes wrong",
    "Feedback that changed how we work",
    "What a great experience with us looks like",
    "How a small request became something we now offer everyone"
  ] },
  { day: 6, post: 1, heading: "How we work", theme: "Ideas for the weekend", angles: [
    "The steps behind a finished piece of work",
    "How we check quality before anything goes out",
    "Why we do it this way and not the quick way",
    "The part of the work nobody sees",
    "How our process has improved over time",
    "What we prepare before the week begins"
  ] },
  { day: 6, post: 2, heading: "Practical tips", theme: "Ideas for the weekend", angles: [
    "A weekend project worth trying",
    "How to make it last longer",
    "Easy ways to save time this week",
    "Common beginner mistakes and how to avoid them",
    "A simple routine that keeps things running smoothly",
    "What to keep on hand, and what you can skip"
  ] },
  { day: 0, post: 1, heading: "Lessons and reflections", theme: "Stories and community", angles: [
    "A lesson we learned the hard way",
    "What we would tell ourselves on day one",
    "Why slowing down can be worth it",
    "A small win worth celebrating this week",
    "What a good week looks like for us",
    "Something we changed our mind about"
  ] },
  { day: 0, post: 2, heading: "Community spotlight", theme: "Stories and community", angles: [
    "A customer or partner we are proud to work with",
    "How our community has shaped what we do",
    "An event or moment worth remembering",
    "People in our community doing great work",
    "A thank-you to someone who helped us grow",
    "How to get involved and connect with others"
  ] },
];

/** The day map: [weekday, Post 1, Post 2]. 0 = Sunday. */
const DOCUMENT_DAY_MAP: [number, string, string][] = [
  [1, "Education and how-to", "Product or service spotlight"],
  [2, "Tips and quick wins", "Industry news and insights"],
  [3, "Behind the scenes", "Ideas and inspiration"],
  [4, "Getting started", "Community and values"],
  [5, "FAQ about what we offer", "Customer stories"],
  [6, "Process and craft", "Practical tips"],
  [0, "Lessons and reflections", "Stories from the community"],
];

/** The frequency table: [pillar, days, frequency]. */
const DOCUMENT_FREQUENCY: [string, string, string][] = [
  ["Education and how-to", "Monday and Thursday", "2x weekly"],
  ["Product or service spotlight", "Monday and Friday", "2x weekly"],
  ["Tips and quick wins", "Tuesday and Saturday", "2x weekly"],
  ["Industry news and insights", "Tuesday", "1x weekly"],
  ["Behind the scenes", "Wednesday and Saturday", "2x weekly"],
  ["Ideas and inspiration", "Wednesday and Sunday", "2x weekly"],
  ["Customer stories", "Friday and Sunday", "2x weekly"],
  ["Community and values", "Thursday and Sunday", "2x weekly"],
  ["FAQ and myth-busting", "Primarily Friday; also integrated into education content", "1-2x weekly"],
];

test('all 82 angles, in order, word for word', () => {
  assert.equal(DOCUMENT_POSTS.reduce((n, p) => n + p.angles.length, 0), 82);
  for (const doc of DOCUMENT_POSTS) {
    const slot = WEEK.find((s) => s.day === doc.day && s.post === doc.post);
    assert.ok(slot, 'no slot for day ' + doc.day + ' post ' + doc.post);
    const pillar = pillarById(slot!.pillarId)!;
    assert.equal(pillar.name, doc.heading, 'the Post heading');
    assert.deepEqual(pillar.angles, doc.angles, doc.heading);
  }
});

test('the day subtitles', () => {
  for (const doc of DOCUMENT_POSTS) assert.equal(DAY_THEMES[doc.day as 0 | 1 | 2 | 3 | 4 | 5 | 6], doc.theme);
});

test('the page-2 day map, cell for cell', () => {
  for (const [day, p1, p2] of DOCUMENT_DAY_MAP) {
    assert.equal(WEEK.find((s) => s.day === day && s.post === 1)!.mapName, p1);
    assert.equal(WEEK.find((s) => s.day === day && s.post === 2)!.mapName, p2);
  }
});

test('the frequency table, row for row', () => {
  assert.deepEqual(FREQUENCY_PILLARS.map((f) => [f.name, f.days, f.frequency]), DOCUMENT_FREQUENCY);
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { greetingFor, renderSnapshot, situationOf, summarise, type RunRow } from './assistant-context.ts';

const NOW = Date.parse('2026-09-10T12:00:00Z');
const ago = (ms: number) => new Date(NOW - ms).toISOString();

test('a live claim is being worked on; a dead one is retryable', () => {
  assert.equal(situationOf({ state: 'preparing', updated_at: ago(60_000) }, NOW), 'working');
  // The case that stayed invisible: nothing is holding this claim.
  assert.equal(situationOf({ state: 'preparing', updated_at: ago(60 * 60_000) }, NOW), 'retryable');
});

test('the failure code decides who has to act', () => {
  assert.equal(situationOf({ state: 'failed', last_error_code: 'out_of_time' }, NOW), 'retryable');
  assert.equal(situationOf({ state: 'failed', last_error_code: 'named_a_person' }, NOW), 'needs_you');
  assert.equal(situationOf({ state: 'failed', last_error_code: 'transcript_not_kept' }, NOW), 'blocked');
  assert.equal(situationOf({ state: 'prepared' }, NOW), 'done');
  assert.equal(situationOf({ state: 'discovered' }, NOW), 'waiting');
});

test('problems are named, healthy rows are only counted', () => {
  const rows: RunRow[] = [
    { state: 'prepared', video_title: 'Done one' },
    { state: 'failed', video_title: 'Timed out', row_number: 180, last_error_code: 'out_of_time', last_error: 'Ran out of time.' },
    { state: 'discovered', video_title: 'Queued' },
  ];
  const s = summarise(rows, NOW);
  assert.equal(s.counts.done, 1);
  assert.equal(s.counts.waiting, 1);
  assert.equal(s.counts.retryable, 1);
  assert.equal(s.problems.length, 1);
  assert.equal(s.problems[0].title, 'Timed out');
});

test('the rows a person must act on are named before the ones we can fix', () => {
  const rows: RunRow[] = [
    { state: 'failed', video_title: 'Temporary', last_error_code: 'out_of_time' },
    { state: 'failed', video_title: 'Needs a human', last_error_code: 'no_transcript' },
    { state: 'failed', video_title: 'Migration', last_error_code: 'transcript_not_kept' },
  ];
  const s = summarise(rows, NOW);
  assert.deepEqual(s.problems.map((p) => p.title), ['Migration', 'Needs a human', 'Temporary']);
});

test('the named list is capped so a big backlog costs the same as a small one', () => {
  const rows: RunRow[] = Array.from({ length: 40 }, (_, i) => ({
    state: 'failed', video_title: 'Video ' + i, last_error_code: 'out_of_time',
  }));
  const s = summarise(rows, NOW);
  assert.equal(s.counts.retryable, 40);
  assert.equal(s.problems.length, 3);
  assert.ok(renderSnapshot(s).split('\n').length < 12);
});

test('a very long sheet title is trimmed rather than pasted whole', () => {
  const s = summarise([{ state: 'failed', video_title: 'x'.repeat(300), last_error_code: 'out_of_time' }], NOW);
  assert.ok(s.problems[0].title.length <= 60);
});

test('the failure’s own sentence is preferred over the category', () => {
  const s = summarise([{ state: 'failed', video_title: 'V', last_error_code: 'no_transcript', last_error: 'Only a few words could be heard.' }], NOW);
  assert.equal(s.problems[0].plain, 'Only a few words could be heard.');
});

test('a dependency the videos need is said first, and nothing impossible is offered', () => {
  const s = summarise([{ state: 'failed', last_error_code: 'out_of_time' }], NOW, {
    health: [{ down: 'Writing is unavailable — no AI is connected.', blocksVideos: true }],
  });
  const g = greetingFor(s);
  assert.match(g.message, /no AI is connected/);
  assert.ok(!g.chips.some((c) => /retry/i.test(c)));
});

test('something degraded ELSEWHERE does not blank the video report', () => {
  // The case this split exists for: the health probe spans three migration
  // files, and a missing Autopilot templates table used to open the chat with
  // a database warning that never mentioned a single video.
  const s = summarise([
    { state: 'failed', video_title: 'Hydrogen reel', row_number: 180, last_error_code: 'out_of_time', last_error: 'Ran out of time.' },
  ], NOW, {
    health: [{ down: 'Run supabase/autopilot.sql. Until then this breaks Autopilot.', blocksVideos: false }],
  });
  const g = greetingFor(s);
  assert.match(g.message, /Hydrogen reel/);
  assert.deepEqual(g.chips, ['Show me the video pipeline']);
  // Still said — as a footnote, and naming the actual file.
  assert.match(g.message, /Separately: .*autopilot\.sql/);
});

test('a non-blocking failure is reported on the all-clear greeting too', () => {
  const g = greetingFor(summarise([{ state: 'prepared' }], NOW, {
    health: [{ down: 'Keyword research is paused.', blocksVideos: false }],
  }));
  assert.match(g.message, /done or moving/);
  assert.match(g.message, /Separately: Keyword research is paused/);
});

test('the prompt block says which failures touch video and which do not', () => {
  const out = renderSnapshot(summarise([{ state: 'prepared' }], NOW, {
    health: [
      { down: 'The transcript store is missing.', blocksVideos: true },
      { down: 'Autopilot templates are missing.', blocksVideos: false },
    ],
  }));
  assert.match(out, /Stopping the video pipeline: The transcript store/);
  assert.match(out, /does NOT affect video.*Autopilot templates/);
});

test('the report names what is stuck and waits to be told, offering nothing', () => {
  const s = summarise([
    { state: 'failed', video_title: 'Hydrogen reel', row_number: 180, last_error_code: 'out_of_time', last_error: 'Ran out of time.' },
  ], NOW);
  const g = greetingFor(s);
  assert.match(g.message, /Hydrogen reel/);
  assert.match(g.message, /row 180/);
  // It says what it COULD do if told, and that it will not do it unasked.
  assert.match(g.message, /Say the word/);
  assert.match(g.message, /will not touch them until you do/);
  assert.ok(!g.chips.some((c) => /retry/i.test(c)), 'no Retry chip: the assistant acts on a command, not an offer');
  // The promise that must survive every rewording of this file.
  assert.match(g.message, /nothing goes to Metricool without you saying so/i);
});

test('several stuck videos still produce no offer, only the report', () => {
  const rows: RunRow[] = [
    { state: 'failed', video_title: 'A', last_error_code: 'out_of_time' },
    { state: 'failed', video_title: 'B', last_error_code: 'generation_failed' },
  ];
  const g = greetingFor(summarise(rows, NOW));
  assert.match(g.message, /2 videos are stuck on something temporary/);
  assert.deepEqual(g.chips, ['Show me the video pipeline']);
});

test('an all-clear pipeline does not invent work', () => {
  const g = greetingFor(summarise([{ state: 'prepared' }], NOW));
  assert.match(g.message, /done or moving/);
  assert.ok(!g.chips.some((c) => /retry/i.test(c)));
});

test('an account that has never swept is told that, not "all clear"', () => {
  const g = greetingFor(summarise([], NOW));
  assert.match(g.message, /Nothing has been through/);
});

test('a missing Brand Brain is surfaced, because it blocks Metricool later', () => {
  const s = summarise([{ state: 'prepared' }], NOW, { hasBrandProfile: false });
  assert.match(renderSnapshot(s), /No Brand Brain/);
});

test('overnight recovery is reported only when something actually moved', () => {
  const quiet = summarise([{ state: 'prepared' }], NOW, { recovery: { revived: 0, released: 0 } });
  assert.equal(quiet.recovery, null);
  assert.ok(!renderSnapshot(quiet).includes('Since the last pass'));

  const busy = summarise([{ state: 'prepared' }], NOW, { recovery: { revived: 2, released: 1 } });
  assert.match(renderSnapshot(busy), /Since the last pass: 2 retried/);
});

// --- the two states the assistant used to get wrong --------------------------

test('a pipeline that could not be READ is never reported as one that is fine', () => {
  // The bug this exists for: listRuns throws deliberately on a failed read, the
  // assistant caught it with .catch(() => []), and every count came back zero —
  // so the greeting said "everything is done or moving" during a database
  // outage. Saying "nothing to report" is how a broken read looks like good news.
  const s = summarise([], Date.now(), { pipelineUnreadable: true });
  const greeting = greetingFor(s);
  assert.doesNotMatch(greeting.message, /done or moving/i);
  assert.match(greeting.message, /could not read/i);
  assert.match(greeting.message, /not an empty queue/i);
  // And the prompt block must stop the model answering from the zeroes.
  const rendered = renderSnapshot(s);
  assert.match(rendered, /could not be READ/);
  assert.match(rendered, /do not know/i);
});

test('an empty pipeline still reads as empty, not as an outage', () => {
  const greeting = greetingFor(summarise([], Date.now()));
  assert.match(greeting.message, /Nothing has been through/i);
});

test('a health check that blocks video takes over the greeting', () => {
  // The headline finding: with the Drive copies folder unusable the assistant
  // opened with "Everything in the video pipeline is either done or moving"
  // while the banner on the same screen said no video could be attached.
  const s = summarise([{ state: 'prepared', video_title: 'A', updated_at: new Date().toISOString() }], Date.now(), {
    health: [{ down: 'Videos cannot be attached to posts: the copies folder is not in a Shared Drive.', stillWorks: 'Captions are still written into the sheet.', blocksVideos: true }],
  });
  const greeting = greetingFor(s);
  assert.match(greeting.message, /Shared Drive/);
  assert.doesNotMatch(greeting.message, /done or moving/i);
  // The half that stops it reading as a total outage.
  assert.match(greeting.message, /Captions are still written/);
});

test('something degraded elsewhere stays a footnote, not the headline', () => {
  const s = summarise([{ state: 'prepared', video_title: 'A', updated_at: new Date().toISOString() }], Date.now(), {
    health: [{ down: 'Keyword research is paused.', stillWorks: 'Drafts are still written.', blocksVideos: false }],
  });
  const greeting = greetingFor(s);
  assert.match(greeting.message, /done or moving/i, 'the videos really are fine');
  assert.match(greeting.message, /Separately: Keyword research is paused/);
});

test('needsHuman counts the rows only a person can move', () => {
  const now = Date.now();
  const s = summarise(
    [
      { state: 'needs_transcript', last_error_code: 'no_transcript', updated_at: new Date(now).toISOString() },
      { state: 'prepared', updated_at: new Date(now).toISOString() },
    ],
    now,
  );
  assert.equal(s.needsHuman, s.counts.needs_you + s.counts.blocked);
});

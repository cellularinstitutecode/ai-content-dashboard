// web/lib/strategy-voice.ts
// How a weekly-planner post is written, as opposed to every other post.
//
// WHY THIS EXISTS. A Brand Brain's guidelines are often written for promotion:
// "highlight what makes the product unique", "always include a clear call to
// action (Book now / Get your free quote)". Those are right for the brand's ads
// and its video posts. They are wrong for a weekly content strategy, whose aim
// is to position the brand as a useful, trustworthy source — not simply a
// business promoting what it sells. Fed both, the writer obeys the Brand
// Brain: an educational how-to post comes back as a sales pitch on every
// channel, with product hashtags and a "book now" close.
//
// So posts from slots the strategy seed wrote (strategy.seeded === SEED_MARK)
// get the strategy's own editorial direction instead of the promotional rules.
// Nothing else changes: the Draft page, the Video Library and every template a
// person wrote by hand still get the Brand Brain exactly as it is.
//
// Pure: `./x.ts` imports only, so the test runner reads this file directly.
import { PILLARS, citationPolicyForSlot, pillarById, slotByKey, type CitationPolicy, type Pillar } from './content-strategy.ts';
import { SEED_MARK } from './strategy-seed.ts';
import { UPLOAD_MARK } from './strategy-upload.ts';
import { negatedAt } from './safety-rules.ts';
import { BRAND_NAME, describeBrand } from './brand-identity.ts';

/**
 * Whether this template's posts must cite a study: the document slot's policy
 * for a seeded slot (lib/content-strategy.ts), 'if-health-claim' for an
 * uploaded strategy's slot, 'required' for everything else.
 */
export function citationPolicyFor(strategy: { seeded?: unknown; slot?: unknown } | null | undefined): CitationPolicy {
  // A slot from a dropped strategy document (lib/strategy-upload.ts) follows
  // the same rule the team chose for the weekly strategy: a REF line only when
  // the post makes a health claim.
  if (String(strategy?.seeded || '') === UPLOAD_MARK) return 'if-health-claim';
  if (!isStrategySlot(strategy)) return 'required';
  return citationPolicyForSlot(String(strategy?.slot || ''));
}

/** Is this template one of the weekly strategy's own slots? */
export function isStrategySlot(strategy: { seeded?: unknown } | null | undefined): boolean {
  return String(strategy?.seeded || '') === SEED_MARK;
}

/** Was this template created by dropping a strategy document (lib/strategy-upload.ts)? */
export function isUploadedSlot(strategy: { seeded?: unknown } | null | undefined): boolean {
  return String(strategy?.seeded || '') === UPLOAD_MARK;
}

/**
 * Does this template write in the strategy's voice — the document's angle kept
 * as the subject, its editorial direction instead of the Brand Brain's
 * promotional rules, no keyword swaps, the promotion rewrite, varied format and
 * audience, and a single image?
 *
 * The built-in weekly strategy's slots, and every slot from a dropped strategy
 * document: a dropped document IS a strategy, and must be written like one.
 * What depends on the built-in document's own slot keys (its dealt rotation,
 * day themes and frequency tags) still asks isStrategySlot and `strategy.slot`.
 */
export function usesStrategyVoice(strategy: { seeded?: unknown } | null | undefined): boolean {
  return isStrategySlot(strategy) || isUploadedSlot(strategy);
}

const DAY_KEYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'] as const;

/**
 * The week-grid position an uploaded slot takes for its format / audience /
 * closing rotation (lib/strategy-variety.ts): its day, and first or second post
 * by time of day. The dealt variety is keyed by these positions, so an uploaded
 * week changes shape each week exactly as the built-in one does.
 */
export function uploadVarietyKey(weekdays: unknown, time: unknown): string | null {
  const day = Array.isArray(weekdays) ? Number(weekdays[0]) : NaN;
  if (!Number.isInteger(day) || day < 0 || day > 6) return null;
  const hour = Number(String(time ?? '').slice(0, 2));
  return DAY_KEYS[day] + '-' + (Number.isFinite(hour) && hour >= 12 ? '2' : '1');
}

function key(s: unknown): string {
  return String(s ?? '').trim().toLowerCase().replace(/\s+/g, ' ');
}

/** The strategy pillar a template name belongs to, or null (the weekly article has none). */
export function pillarForName(name: unknown): Pillar | null {
  const k = key(name);
  return PILLARS.find((p) => key(p.name) === k) ?? null;
}

/**
 * The pillar a seeded template writes about, found through the keys the seed
 * stamped (`pillarId`, then `slot`) and only then through its name.
 *
 * By name alone, a slot somebody renamed — "Tips and quick wins (Tuesday AM)" — lost
 * its pillar in the brief and its picture, and a hand-written template that
 * happened to be called "Practical tips" gained one.
 */
export function pillarForStrategy(strategy: { pillarId?: unknown; slot?: unknown } | null | undefined, name?: unknown): Pillar | null {
  const byId = typeof strategy?.pillarId === 'string' ? pillarById(strategy.pillarId) : null;
  if (byId) return byId;
  const slot = slotByKey(strategy?.slot);
  if (slot) return pillarById(slot.pillarId);
  return pillarForName(name);
}

/**
 * The positioning line used in place of the Brand Brain mission for these
 * posts: the brand (the loaded profile's name when there is one, else
 * BRAND_NAME) as a trusted guide rather than a stream of promotions.
 */
export function strategyPositioning(name?: unknown): string {
  return describeBrand({ name: typeof name === 'string' ? name : '' }) +
    ' shares practical, honest content that helps people understand, choose and get more out of what they care about — ' +
    'explaining, showing how things work and answering real questions. It is a trusted guide, not simply a business promoting what it sells.';
}

/** The positioning line for the deployment's own brand (BRAND_NAME). */
export const STRATEGY_POSITIONING = strategyPositioning(BRAND_NAME);

/** "The content should feel" — the strategy's editorial direction, as writer rules. */
export const EDITORIAL_DIRECTION = [
  'EDITORIAL DIRECTION (the brand\'s weekly content strategy — must follow):',
  'Educational: clear, useful information the reader can understand and apply today.',
  'Personal: speak to the reader\'s own situation rather than offering a one-size-fits-all answer.',
  'Balanced: teaching supported by everyday tips, behind-the-scenes, stories and community content — not only what the brand sells.',
  'Responsible: no exaggerated claims, no guarantees, no promise of identical results for everyone — this is education, not an advertisement.',
  'Supportive: centred on helping the reader, whether or not they ever buy.',
].join(' ');

/** What these posts must NOT do — the promotional habits the Brand Brain would otherwise add. */
export const NO_PROMOTION_RULES = [
  'DO NOT turn the post into a promotion:',
  'do not pitch a named product, service or package unless this week\'s angle is about it, and even then explain it rather than sell it;',
  'do not lean on slogans or superlatives as selling points;',
  'do not use sales hooks such as "See if you are a candidate", "free consultation" or "limited-time offer";',
  'do not use promotional or product hashtags — use 3-5 hashtags about the topic itself.',
  'do not ask readers to book, call, DM or "contact us", and never attach a price, package or offer to anything;',
  'there is no source for this post: do not quote, paraphrase or describe any individual customer\'s experience;',
  'Mention the brand by name at most once, naturally, as the team sharing the advice.',
  'Close with a gentle, useful next step instead of a sales call to action — e.g. save this, share it with someone who needs it, or try it this week.',
].join(' ');

/**
 * The brand the writer sees for a strategy post.
 *
 * Name and voice are kept — they ARE the brand. Mission, audience keywords and
 * guidelines are replaced, because those are where the selling instructions
 * live. The advertising-permit (aviso) number and the visual identity are
 * kept, so the compliance gate and the images behave exactly as before.
 */
export function strategyBrand<T extends Record<string, unknown>>(
  brand: T | undefined | null,
  opts: { citation?: 'required' | 'if-health-claim' } = {},
): T {
  const b = (brand || {}) as T;
  // A post under the 'if-health-claim' policy cites a study only when it makes
  // a health claim (lib/content-strategy.ts citation policy) — and must not
  // invent one to have something to cite.
  const cite = opts.citation === 'if-health-claim'
    ? ' Keep claims responsible and evidence-based; cite one real, relevant study only if the post makes a health claim, and do not add a health claim just to cite one.'
    : ' Keep claims responsible and evidence-based; cite one real, relevant study.';
  return {
    ...b,
    mission: strategyPositioning((b as Record<string, unknown>).name),
    keywords: [],
    guidelines: EDITORIAL_DIRECTION + ' ' + NO_PROMOTION_RULES + ' Write in English.' + cite,
  } as T;
}

/** The brief for one occurrence of a strategy slot. */
export function strategyTopicPrompt(opts: {
  angle: string;
  pillarName: string;
  rule?: string;
  reviewerNote?: string;
  supportingPhrase?: string;
  /** The day page's subtitle, e.g. "Teach something useful". */
  dayTheme?: string;
  /** The frequency-table rows this slot counts as, when it is more than one. */
  alsoCovers?: string[];
  /** A pillar the table integrates into this slot without making it the subject. */
  integrated?: string[];
  /** What the related slots write this same week — ground not to repeat. */
  coveredThisWeek?: string[];
  /** Varies the brief's own example sentences from week to week (the dealt week). */
  variant?: number;
  /** This occurrence's shape, reader and close (lib/strategy-variety.ts briefs). */
  formatBrief?: string;
  audienceBrief?: string;
  closingBrief?: string;
  /** The opening line this same angle had the last time it was published. */
  previousOpening?: string;
}): string {
  const parts = [
    'Write about: ' + opts.angle + '.',
    'This is the weekly "' + opts.pillarName + '" post. Stay on this pillar and on this exact angle — the rest of the week covers the other topics.',
  ];
  if (opts.dayTheme) parts.push('The day\'s theme is "' + opts.dayTheme + '"; let the post sit inside it.');
  // "Each time a pillar returns, the angle, question, format, or audience
  // should change." The angle is dealt by the rotation; these are the rest.
  if (opts.audienceBrief) parts.push('Write it for ' + opts.audienceBrief + ' — speak to their situation, and make no assumptions about their circumstances or their results.');
  if (opts.formatBrief) parts.push(opts.formatBrief);
  if (opts.previousOpening) {
    parts.push('This angle has been published before, opening with: "' + opts.previousOpening.slice(0, 200) +
      '". Come at it from a different question or entry point this time, and do not reuse that opening.');
  }
  if (opts.alsoCovers && opts.alsoCovers.length > 1) {
    parts.push('This slot counts for both ' + opts.alsoCovers.map((n) => '"' + n + '"').join(' and ') + ' in the brand\'s weekly mix, so the post should speak to both.');
  }
  if (opts.integrated && opts.integrated.length) {
    // Varied by week, so the same connecting sentence is not handed over every
    // Monday — the one place the brief itself risked repeating its wording.
    const examples = INTEGRATED_EXAMPLES;
    const example = examples[Math.abs(Math.trunc(opts.variant ?? 0)) % examples.length];
    parts.push('Where it fits naturally, connect the angle to ' + opts.integrated.map((n) => '"' + n + '"').join(' and ') +
      ' — for example, ' + example + ' One sentence is enough; do not change the subject.');
  }
  if (opts.coveredThisWeek && opts.coveredThisWeek.length) {
    // Monday explains how to get started, Thursday how to tell whether you
    // are on the right track — the same pillar, complementary points. So:
    // build on them, do not repeat them.
    parts.push('Related posts this week cover: ' + opts.coveredThisWeek.map((a) => '"' + a + '"').join('; ') +
      '. Build on them from a different point or step in the reader\'s journey; do not repeat their points.');
  }
  parts.push(EDITORIAL_DIRECTION, NO_PROMOTION_RULES);
  // After the general rule, so the specific close for this post wins.
  if (opts.closingBrief) parts.push('For this post: ' + opts.closingBrief);
  if (opts.supportingPhrase) {
    parts.push('If it reads naturally, use the search phrase "' + opts.supportingPhrase + '" once; never force it.');
  }
  if (opts.rule) parts.push('STANDING RULE for this pillar (must follow): ' + opts.rule);
  if (opts.reviewerNote) parts.push('REVIEWER FEEDBACK (must address): ' + opts.reviewerNote);
  return parts.join(' ');
}

/** Ways to tie an integrated pillar (the example's FAQ) into a post; one per week, in turn. */
const INTEGRATED_EXAMPLES = [
  'by answering the question people most often ask at this step.',
  'by clearing up one common misunderstanding about it.',
  'by naming the one question worth asking before going further.',
];

/** A gentle next step counts as a call to action for a strategy post. */
export const SOFT_CTA_RE =
  /\b(save (this|it)|share (this|it)|tag someone|talk (it )?(through )?with (your|an?) (physician|doctor|expert|specialist|advisor)|ask (your|an?) (physician|doctor|expert|specialist|advisor)|comment|let us know|learn more|read more|what('s| is) your|what does your|how do you|try (this|it) (today|tonight|this week))\b/i;

/**
 * The brand's own named products or services that a strategy post may
 * INTRODUCE but never sell, e.g. ['Premium Plan', 'Studio Session'].
 *
 * Empty in this template, which switches the four checks that need names off
 * (a named-offer pitch, a hashtag for one, selling one, a post built around or
 * comparing them). Fill it with your own offer names to switch them on.
 */
export const PROMOTED_SERVICES: readonly string[] = [];

function escapeRe(v: string): string {
  return v.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** The services as one regex alternative, or null when none are listed. */
function serviceAlternation(services: readonly string[]): string | null {
  const names = services.map((v) => String(v || '').trim()).filter(Boolean)
    .sort((x, y) => y.length - x.length)
    .map((v) => escapeRe(v).replace(/\s+/g, '[\\s-]+'));
  return names.length ? '(?:' + names.join('|') + ')' : null;
}

/** The key two mentions of one service share: case and spacing do not count. */
function serviceKey(m: string): string {
  return m.toLowerCase().replace(/[\s-]+/g, ' ').trim();
}

const SELLING = '(?:book|booking|package|packages|pricing|price|prices|\\$\\s?\\d|discount|offer|special|promo|try our|ask about our|available now|reserve|sessions? (?:from|for|starting))';

type PromoPattern = { re: RegExp; label: string; negatable?: boolean; sentence?: RegExp };

/** A sentence that is about the brand or how it compares with anyone else. */
const COMPARISON_SCOPE = new RegExp(
  '\\b(competitors?|competition|alternatives?|other (?:brands?|companies|businesses|providers|stores|shops|options)|anyone else|destination' +
    (BRAND_NAME && BRAND_NAME !== 'Your Brand' ? '|' + escapeRe(BRAND_NAME) : '') + ')\\b',
  'i',
);

/**
 * Phrases that make an educational post read as an advert. Each one found
 * costs the draft points, forces a rewrite, and holds an auto-scheduled post.
 *
 * `negatable` patterns pass after a negation ("not everyone will get the
 * same result" is a personal-advice post's whole message, not an outcome
 * promise). `sentence` patterns are checked only inside a sentence that
 * mentions what they are about, so "walking is better than nothing" is not a
 * claim about the brand.
 */
const BASE_PATTERNS: PromoPattern[] = [
  { re: /free consultation|free quote|limited[- ]time offer/i, label: 'sales hook' },
  { re: /\bsee if you('| a)re a candidate|\bif you('| a)re a candidate/i, label: 'candidate pitch' },
  { re: /drug[- ]free|surgery[- ]free/i, label: '"drug-free / surgery-free" selling point' },
  { re: /many (patients|customers|clients|people) (feel|see|notice)/i, label: 'outcome claim' },
  // A sales close. Bare "schedule" is left alone: "weekly schedule" is common here.
  {
    re: /\bbook (a|an|your|now|today|online)\b|\bschedule (a|an|your) (free )?(consult\w*|appointment|session|visit|call|evaluation|demo)\b|\bcall us\b|\bcontact us\b|\bdm us\b|\blink in (our )?bio\b|\breach out to (us|our team)\b|\bsign up\b|\bshop now\b|\bbuy now\b|\border (now|today)\b/i,
    label: 'booking call to action',
  },
  // There is no source for a strategy post, so any customer quote is invented.
  {
    re: /\b(one of )?our (patients?|customers?|clients?) (said|says|told|tells|shared|shares|felt|reported|put it)\b|\bas (a|one) (of our )?(patients?|customers?|clients?) (put it|said|told us|shared)\b|\b(patients|customers|clients) (often |frequently |regularly )?(tell|say to) us\b|\bone (of our )?(patients?|customers?|clients?) (said|told|shared|put it|described)\b/i,
    label: 'invented testimonial',
  },
  // The everyday-scenario shape (lib/strategy-variety.ts) is a hypothetical,
  // never a result: "someone who… felt better after" is a testimonial with
  // the name taken off.
  {
    re: /\b(someone|a person|a customer|a client|a patient|a friend|a woman|a man)\b[^.!?\n]{0,100}\b(felt|feels|was|were|got|gets|became|is now|was now|ended up)\s+(?:(?:so |much |a lot |finally |far )+)?(better(?=\s*(?:[.,!;:)]|$|\s+(?:after|within|in (?:a|one|two|three|just)|by the end|than (?:before|ever))))|cured|healed|pain[- ]free|transformed|back to normal|like new|symptom[- ]free)\b/i,
    label: 'scenario outcome',
    negatable: true,
  },
  // The example's community note: specific, checkable things, never
  // superiority over anyone else.
  {
    re: /\b(best|top|#1|number one|leading|premier|ultimate|perfect)\b[^.!?\n]{0,40}\b(destination|place|brand|company|business|provider|store|shop|option|choice)\b|\bbetter than\b|\bunlike (other|any)\b|\bnowhere else\b|\bonly (place|brand|company|one)\b|\bno other (destination|place|brand|company|business)\b|\b(ideal|paradise|world[- ]class|unmatched|unrivall?ed|unbeatable|second to none)\b/i,
    label: 'superiority claim',
    negatable: true,
    sentence: COMPARISON_SCOPE,
  },
  // "Personal: the reader's own situation rather than a one-size-fits-all
  // answer." A blanket instruction to every reader is the opposite. Advice
  // to talk it through with an expert is not.
  {
    re: /\beveryone should (?!(talk|consult|ask|speak|check))\w+|\bworks for everyone\b|\bone[- ]size[- ]fits[- ]all\b|\byou must (take|do|start|try|stop|avoid|eat|buy)\b/i,
    label: 'universal prescription',
    negatable: true,
  },
  // "No exaggerated claims, no guarantees, no promise of identical results."
  {
    re: /\b(everyone|everybody|every (patient|customer|client)|all (patients|customers|clients)|anyone)\b[^.!?\n]{0,30}\b(will|can expect|is guaranteed|gets the same)\b|\breverses? (aging|ageing|disease|damage|the (effects|signs|clock))\b|\breversed (aging|ageing|disease|damage)\b|\bwill (heal|cure|fix|reverse|eliminate)\b|\b\d{2,3}\s?% (success|improvement|of (our )?(patients|customers|clients))\b/i,
    label: 'outcome promise',
    negatable: true,
  },
];

/** The patterns that need the brand's own offer names (PROMOTED_SERVICES). */
function servicePatterns(service: string): PromoPattern[] {
  const tag = service.replace(/\[\\s-\]\+/g, '');
  return [
    { re: new RegExp('#' + tag, 'i'), label: 'offer hashtag' },
    { re: new RegExp('\\b' + service + '\\b', 'i'), label: 'offer pitch' },
    // A named offer may be introduced, never sold.
    {
      re: new RegExp('\\b' + service + '\\b[^.!?\\n]{0,80}\\b' + SELLING + '|\\b' + SELLING + '[^.!?\\n]{0,80}\\b' + service + '\\b', 'i'),
      label: 'service promotion',
    },
  ];
}

function sentencesOf(text: string): string[] {
  return String(text || '').split(/(?<=[.!?])\s+|\n+/).filter((s) => s.trim());
}

function hits(p: PromoPattern, text: string): boolean {
  const scopes = p.sentence ? sentencesOf(text).filter((s) => p.sentence!.test(s)) : [text];
  for (const scope of scopes) {
    const re = new RegExp(p.re.source, p.re.flags.includes('g') ? p.re.flags : p.re.flags + 'g');
    let m: RegExpExecArray | null;
    while ((m = re.exec(scope))) {
      if (!p.negatable || !negatedAt(scope, m.index)) return true;
      if (m[0].length === 0) re.lastIndex++;
    }
  }
  return false;
}

/**
 * "Do not build the post around one of them": one named offer mentioned
 * three or more times is the post being about it.
 */
function builtAroundOneService(text: string, service: string): boolean {
  const counts = new Map<string, number>();
  const re = new RegExp('\\b' + service + '\\b', 'gi');
  for (const m of String(text || '').matchAll(re)) {
    const k = serviceKey(m[0]);
    counts.set(k, (counts.get(k) || 0) + 1);
  }
  return [...counts.values()].some((n) => n >= 3);
}

/**
 * "Do not compare them": two named offers in one sentence with a
 * comparative is the comparison.
 */
function comparesServices(text: string, service: string): boolean {
  const re = new RegExp('\\b' + service + '\\b', 'gi');
  for (const sentence of sentencesOf(text)) {
    const names = new Set([...sentence.matchAll(re)].map((m) => serviceKey(m[0])));
    if (names.size >= 2 && /\b(better|more effective|less effective|superior|inferior|stronger|weaker|than|versus|vs\.?)\b/i.test(sentence)) return true;
  }
  return false;
}

/**
 * Promotional habits found in a strategy post.
 *
 * A named offer is allowed when the week's angle itself is about it, so an
 * angle on, say, how one of them works is not penalised for naming it.
 * Selling it is never allowed. `services` defaults to PROMOTED_SERVICES.
 */
export function promotionFlags(text: string, angle = '', opts: { services?: readonly string[] } = {}): string[] {
  const found: string[] = [];
  const service = serviceAlternation(opts.services ?? PROMOTED_SERVICES);
  const patterns = service ? [...servicePatterns(service), ...BASE_PATTERNS] : BASE_PATTERNS;
  for (const p of patterns) {
    if (!hits(p, text)) continue;
    if (p.label === 'offer pitch' && p.re.test(angle)) continue;
    if (!found.includes(p.label)) found.push(p.label);
  }
  if (service && builtAroundOneService(text, service) && !found.includes('post built around one service')) found.push('post built around one service');
  if (service && comparesServices(text, service) && !found.includes('service comparison')) found.push('service comparison');
  return found;
}

/** Sales words, the brand's own name and its named offers: never a supporting phrase for an educational post. */
const OFF_LIMITS_PHRASE = new RegExp(
  '\\b(price|prices|cost|costs|cheap|discount|deals?|buy|near me|best|top' +
    (BRAND_NAME && BRAND_NAME !== 'Your Brand' ? '|' + escapeRe(BRAND_NAME) : '') +
    (serviceAlternation(PROMOTED_SERVICES) ? '|' + serviceAlternation(PROMOTED_SERVICES) : '') + ')\\b',
  'i',
);

const PHRASE_STOP = new Set([
  'about', 'after', 'also', 'before', 'being', 'between', 'does', 'doing', 'during', 'each', 'every', 'from', 'have',
  'help', 'helps', 'into', 'just', 'like', 'many', 'mean', 'means', 'more', 'most', 'much', 'only', 'other', 'same',
  'should', 'some', 'such', 'than', 'that', 'their', 'them', 'there', 'these', 'they', 'this', 'those', 'through',
  'very', 'what', 'when', 'where', 'which', 'while', 'with', 'without', 'your', 'body', 'people', 'why', 'how',
]);

function subjectWords(text: string): Set<string> {
  const out = new Set<string>();
  for (const w of String(text || '').toLowerCase().split(/[^a-z0-9áéíóúñü]+/)) {
    if (w.length >= 4 && !PHRASE_STOP.has(w)) {
      out.add(w);
      // "supplements" and "supplement", "sleeping" and "sleep": a crude stem is enough here.
      out.add(w.replace(/(ing|es|s)$/, ''));
    }
  }
  return out;
}

/**
 * The one search phrase a strategy post may use, if any.
 *
 * Research on the week's angle returns a primary keyword, related searches and
 * questions. The first that is ON the angle's subject (shares a content word
 * with it or its pillar), not commercial or transactional, and names no
 * offer, price or the brand itself, is offered to the writer — "use it
 * once if it reads naturally". Nothing else is: the phrase used to come from
 * whichever angle type the rotation landed on, and one week in four that was
 * a domain-wide product search on an educational post.
 */
export function pickSupportingPhrase(
  angle: string,
  pillarName: string,
  candidates: readonly { keyword: string; intents?: readonly string[] | null }[],
): string | undefined {
  const subject = subjectWords(angle + ' ' + pillarName);
  const angleKey = String(angle || '').trim().toLowerCase();
  for (const c of candidates) {
    const phrase = String(c?.keyword || '').trim();
    if (!phrase || phrase.toLowerCase() === angleKey) continue;
    const intents = (c.intents || []).map((i) => String(i).toLowerCase());
    if (intents.includes('commercial') || intents.includes('transactional')) continue;
    if (OFF_LIMITS_PHRASE.test(phrase) || promotionFlags(phrase, '').length) continue;
    const words = [...subjectWords(phrase)];
    if (!words.some((w) => subject.has(w))) continue;
    return phrase;
  }
  return undefined;
}

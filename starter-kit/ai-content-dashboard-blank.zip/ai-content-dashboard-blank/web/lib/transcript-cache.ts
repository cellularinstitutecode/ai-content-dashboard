// The transcript of a video, kept so it is only ever paid for once.
//
// The reels in the sheet run to 149 MB and beyond, and pulling one down from
// Drive takes most of a 60-second function before ffmpeg or the transcriber
// have started. So the full chain — download, extract, transcribe, keyword
// brief, write the copy — does not reliably fit in one invocation on this
// plan, and until now a run that overran discarded the download and the
// transcription spend with it. Pressing Prepare again bought the same timeout
// a second time, at the same cost.
//
// This makes the work RESUMABLE rather than faster: the expensive half happens
// once, and every later attempt on the same video skips it. A first attempt
// that times out is no longer wasted — it is the first half, done.
//
// Keyed on the video, not the sheet row, so the Prepare button and the
// automatic sweep share one copy. Failures here are logged and swallowed on
// purpose: a cache that cannot be reached must slow the pipeline down, never
// stop it.
import 'server-only';

import { supabaseAdmin } from '@/lib/supabase-admin';
import { reportError } from '@/lib/report';
import { transcriptFromPacks } from '@/lib/transcript-recall';

export type CachedTranscript = {
  text: string;
  source: string;
  language: string | null;
  title: string | null;
};

/** A transcript already paid for, or null. Never throws. */
export async function cachedTranscript(videoId: string): Promise<CachedTranscript | null> {
  const id = String(videoId || '').trim();
  if (!id) return null;
  const r = await supabaseAdmin()
    .from('video_transcripts')
    .select('text, source, language, title')
    .eq('video_id', id)
    .maybeSingle()
    .then((x) => x, (e: unknown) => ({ data: null, error: e as { message?: string } }));
  if (r.error) {
    // Not fatal, but not silent either: a cache that is quietly missing looks
    // exactly like a pipeline that is quietly slow and expensive.
    reportError('transcript-cache:read', r.error, { videoId: id });
    return null;
  }
  const row = r.data as { text?: string; source?: string; language?: string | null; title?: string | null } | null;
  const text = String(row?.text || '').trim();
  if (!text) return recallFromDrafts(id);
  return { text, source: String(row?.source || 'drive'), language: row?.language ?? null, title: row?.title ?? null };
}

/**
 * The transcript, found again in the draft that was written from it.
 *
 * rememberPublicCopy() once replaced a banked transcript with '' every time a
 * video's public copy was recorded — at the end of every successful Prepare.
 * The transcript was gone from this table but not from the draft: Prepare
 * saves it in the pack (lib/video-prepare.ts, saveVideoDraft). So a miss here
 * looks there before anyone pays for the download and the transcription
 * again, and re-banks what it finds. One cheap read; never throws.
 */
async function recallFromDrafts(videoId: string): Promise<CachedTranscript | null> {
  const r = await supabaseAdmin()
    .from('drafts')
    .select('pack')
    .eq('pack->>kind', 'video')
    .eq('pack->>videoId', videoId)
    .order('updated_at', { ascending: false })
    .limit(5)
    .then((x) => x, (e: unknown) => ({ data: null, error: e as { message?: string } }));
  if (r.error) {
    reportError('transcript-cache:recall', r.error, { videoId });
    return null;
  }
  const packs = ((r.data || []) as { pack?: Record<string, unknown> | null }[]).map((d) => d.pack);
  const found = transcriptFromPacks(packs);
  if (!found) return null;
  const t: CachedTranscript = { text: found.text, source: 'drive', language: found.language, title: found.title };
  // Banked again so the next read is the cheap one. cacheTranscript writes only
  // the transcript columns, so a public copy recorded on the row is kept.
  await cacheTranscript(videoId, t);
  return t;
}

/**
 * Keep a transcript for next time. Never throws — but SAYS whether it worked.
 *
 * It used to return void, and that was the whole failure. On a database where the table
 * does not exist the write comes back "relation does not exist", which was logged to a
 * server log nobody reads and then discarded; the caller carried on as though the
 * transcript were banked, the request was killed at sixty seconds a moment later, and the
 * person was told "press Prepare again — the transcript is kept". It was not kept. The
 * next press re-downloaded a hundred and fifty megabytes and died in the same place, and
 * that could repeat for ever because nothing anywhere knew the difference.
 *
 * So the caller is told, and can stop promising something that did not happen.
 */
export async function cacheTranscript(videoId: string, t: CachedTranscript): Promise<boolean> {
  const id = String(videoId || '').trim();
  const text = String(t.text || '').trim();
  if (!id || !text) return false;
  const r = await supabaseAdmin()
    .from('video_transcripts')
    .upsert({
      video_id: id,
      source: t.source || 'drive',
      language: t.language,
      title: t.title,
      text,
      chars: text.length,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'video_id' })
    .then((x) => x, (e: unknown) => ({ error: e as { message?: string } }));
  if (r.error) {
    reportError('transcript-cache:write', r.error, { videoId: id });
    return false;
  }
  return true;
}

/**
 * The public Drive copy already made for a video, if there is one.
 *
 * Metricool cannot fetch an ordinary Drive link, so a video attached to a post is copied
 * into the app's folder and that copy is opened to anyone holding the URL. It used to be
 * made once per run — re-preparing a row made another — and nothing could delete any of
 * them, so the folder filled with world-readable copies of the team's footage that
 * nothing could trace back to a row.
 *
 * Never throws: an unreachable cache must cost a duplicate copy, not the post.
 */
export async function cachedPublicCopy(videoId: string): Promise<{ id: string; url: string } | null> {
  const key = String(videoId || '').trim();
  if (!key) return null;
  const r = await supabaseAdmin()
    .from('video_transcripts')
    .select('public_copy_id, public_copy_url')
    .eq('video_id', key)
    .maybeSingle()
    .then((x) => x, (e: unknown) => ({ data: null, error: e as { message?: string } }));
  if (r.error) {
    reportError('transcript-cache:copy-read', r.error, { videoId: key });
    return null;
  }
  const row = r.data as { public_copy_id?: string | null; public_copy_url?: string | null } | null;
  const id = String(row?.public_copy_id || '').trim();
  const url = String(row?.public_copy_url || '').trim();
  return id && url ? { id, url } : null;
}

/**
 * Remember the copy, or forget it once it has been deleted.
 *
 * UPDATE first, and INSERT only when the video has no row yet. This used to be
 * one upsert carrying `text: ''` — meant as a placeholder for a video whose
 * copy is made before its transcript is cached, but an upsert MERGES, so on a
 * video that already had its transcript banked the placeholder overwrote it.
 * That ran at the end of every successful Prepare: every success erased the
 * transcript, and the next press paid the download and the transcription
 * again, past the time the request had. The transcript columns are never
 * touched here now; the placeholder row is only ever created, never merged.
 */
export async function rememberPublicCopy(videoId: string, copy: { id: string; url: string } | null): Promise<void> {
  const key = String(videoId || '').trim();
  if (!key) return;
  const admin = supabaseAdmin();
  const patch = {
    public_copy_id: copy?.id ?? null,
    public_copy_url: copy?.url ?? null,
    updated_at: new Date().toISOString(),
  };
  const updated = await admin
    .from('video_transcripts')
    .update(patch)
    .eq('video_id', key)
    .select('video_id')
    .then((x) => x, (e: unknown) => ({ data: null, error: e as { message?: string } }));
  if (updated.error) {
    reportError('transcript-cache:copy-write', updated.error, { videoId: key });
    return;
  }
  if (Array.isArray(updated.data) && updated.data.length) return;
  // No row yet: the copy was made before the transcript. A placeholder row,
  // created once — a transcript that arrives later replaces the empty text.
  const inserted = await admin
    .from('video_transcripts')
    .insert({ video_id: key, text: '', chars: 0, ...patch })
    .then((x) => x, (e: unknown) => ({ error: e as { message?: string } }));
  // A row that appeared between the two statements is fine: it has the
  // transcript, and the copy is remembered on the next call.
  if (inserted.error && !/duplicate|unique|23505/i.test(String(inserted.error.message || ''))) {
    reportError('transcript-cache:copy-insert', inserted.error, { videoId: key });
  }
}

/**
 * Forget a copy that has been deleted, found by the COPY's own id.
 *
 * The cache is keyed on the source video, not on the copy, so a caller holding only the
 * deleted file's id cannot address the row directly. Clearing it matters: leaving the id
 * behind would have the next run hand Metricool a URL for a file that no longer exists,
 * which is worse than making a fresh copy.
 */
/**
 * The SOURCE video a copy was made from, or null.
 *
 * The composer holds a copy's URL, not the video's: what came back from the
 * picker or the hand-off weeks ago. When that copy is one Metricool will not
 * take — a Drive link, any Drive link — the only way to make a better one is
 * to find the original it was made from. Keyed on the copy's id, which for a
 * Drive copy is the copied file's own id.
 */
export async function sourceOfPublicCopy(copyFileId: string): Promise<string | null> {
  const id = String(copyFileId || '').trim();
  if (!id) return null;
  const r = await supabaseAdmin()
    .from('video_transcripts')
    .select('video_id')
    .eq('public_copy_id', id)
    .limit(1)
    .maybeSingle()
    .then((x) => x, (e: unknown) => ({ data: null, error: e as { message?: string } }));
  if (r.error) {
    reportError('transcript-cache:copy-source', r.error, { copyFileId: id });
    return null;
  }
  const videoId = String((r.data as { video_id?: string | null } | null)?.video_id || '').trim();
  return videoId || null;
}

export async function forgetPublicCopy(copyFileId: string): Promise<void> {
  const id = String(copyFileId || '').trim();
  if (!id) return;
  const r = await supabaseAdmin()
    .from('video_transcripts')
    .update({ public_copy_id: null, public_copy_url: null, updated_at: new Date().toISOString() })
    .eq('public_copy_id', id)
    .then((x) => x, (e: unknown) => ({ error: e as { message?: string } }));
  if (r.error) reportError('transcript-cache:copy-forget', r.error, { copyFileId: id });
}

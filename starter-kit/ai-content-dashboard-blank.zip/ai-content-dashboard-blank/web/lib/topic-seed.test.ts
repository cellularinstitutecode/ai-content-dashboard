import { test } from 'node:test';
import assert from 'node:assert/strict';
import { pickSeed } from './topic-seed.ts';

/** The tokenising lib/video-copy.ts does before calling pickSeed. */
const w = (s: string) => s.toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/).filter(Boolean);

test('the subject wins over sheer repetition — this is row 183', () => {
  // A reel named for its subject ("MorningRitual") whose speaker dwells on a
  // detail, so "electric kettle" is said more often than "morning coffee" —
  // and the old rule therefore researched consumer kettles for a post about
  // the ritual.
  const words = w('morning ritual morning coffee routine electric kettle electric kettle temperature electric kettle base morning coffee routine');
  assert.equal(pickSeed(words), 'electric kettle', 'unanchored: repetition wins, which is the bug');
  assert.equal(pickSeed(words, w('morning ritual')), 'morning coffee', 'anchored: the subject wins');
});

test('a subject-corroborated phrase said twice beats an unrelated one said many times', () => {
  // Ruled out by construction rather than tuned: any single weighted score lets
  // raw repetition win eventually, and that is the failure being fixed.
  const words = w('electric kettle electric kettle electric kettle electric kettle electric kettle morning coffee morning coffee');
  assert.equal(pickSeed(words, w('morning ritual')), 'morning coffee');
});

test('a subject that corroborates nothing falls back to the old behaviour', () => {
  const words = w('sourdough matters sourdough again something else entirely');
  assert.equal(pickSeed(words, w('gift box')), pickSeed(words));
});

test('no subject at all is exactly the old behaviour', () => {
  const words = w('specialty coffee is specialty coffee after all');
  assert.equal(pickSeed(words), 'specialty coffee');
  assert.equal(pickSeed(words, []), 'specialty coffee');
});

test('said once is still not a theme', () => {
  // The bar the previous rule set, preserved: nothing repeated means no signal,
  // and '' tells the caller to keep the file name's subject.
  assert.equal(pickSeed(w('customer walked into shop today')), '');
  assert.equal(pickSeed([]), '');
  // Corroboration does not lower the bar. At a bar of one, every adjacent pair
  // touching a subject word qualifies and "into shop" wins on a transcript
  // that merely mentions the shop once.
  assert.equal(pickSeed(w('customer walked into shop today'), w('shop visit')), '');
});

test('a single repeated word is used when no pair repeats', () => {
  assert.equal(pickSeed(w('sourdough matters sourdough again something else entirely')), 'sourdough');
  // And the subject steers that fallback too.
  const words = w('sourdough matters sourdough again morning once morning twice');
  assert.equal(pickSeed(words, w('morning ritual')), 'morning');
});

test('a phrase that only restates the subject is skipped', () => {
  // This function is reached BECAUSE the subject returned nothing from Semrush.
  // Re-seeding on the subject spends a second lookup to fail the same way.
  const words = w('morning ritual morning ritual morning coffee routine morning coffee routine');
  assert.equal(pickSeed(words, w('morning ritual')), 'morning coffee');
});

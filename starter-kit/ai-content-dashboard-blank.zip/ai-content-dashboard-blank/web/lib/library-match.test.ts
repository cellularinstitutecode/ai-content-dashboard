import { test } from 'node:test';
import assert from 'node:assert/strict';
import { coverage, pickForPillar, type Candidate } from './library-match.ts';
import { BRAND_TARGET } from './palette.ts';
import { parseCaption } from './library-caption.ts';

const inPalette = { ...BRAND_TARGET };
const gradeable = { r: 138, g: 142, b: 150, warm: -12, sat: 30, lum: 140 };
const magenta = { r: 150, g: 90, b: 160, warm: -10, sat: 62, lum: 110 };

const cand = (id: string, subjects: string[], opts: Partial<Candidate> & { blockers?: string[] } = {}): Candidate => ({
  id,
  name: id + '.png',
  caption: parseCaption({ caption: 'a picture', subjects, blockers: opts.blockers ?? [] })!,
  stats: 'stats' in opts ? opts.stats : inPalette,
  consentCleared: opts.consentCleared,
});

test('a conversation is offered for the pillars it serves', () => {
  const m = pickForPillar([cand('a', ['conversation'])], 'tips');
  assert.ok(m);
  assert.equal(m!.id, 'a');
  assert.match(m!.why, /already in the palette/);
});

test('nothing is offered for a pillar the folder cannot serve', () => {
  // The finding this module exists for: twenty-two photographs of people
  // talking do not make a food cover, and offering one would be worse than
  // generating.
  const business = ['a', 'b', 'c'].map((id) => cand(id, ['conversation']));
  for (const pillar of ['nutrition', 'sleep', 'movement', 'stress', 'recipes']) {
    assert.equal(pickForPillar(business, pillar), null, pillar);
  }
});

test('a picture the cover rules refuse is never offered', () => {
  for (const blocker of ['text', 'procedure', 'device-on-person', 'render']) {
    assert.equal(pickForPillar([cand('x', ['conversation'], { blockers: [blocker] })], 'tips'), null, blocker);
  }
});

test('a recognisable customer waits for a release', () => {
  const shot = cand('p', ['conversation'], { blockers: ['identifiable-patient'] });
  assert.equal(pickForPillar([shot], 'tips'), null, 'no release recorded');
  assert.ok(pickForPillar([{ ...shot, consentCleared: true }], 'tips'), 'release recorded');
});

test('an unmeasured picture is passed over, not assumed fine', () => {
  assert.equal(pickForPillar([cand('u', ['conversation'], { stats: null })], 'tips'), null);
});

test('a picture too far from the palette is passed over', () => {
  assert.equal(pickForPillar([cand('m', ['workspace'], { stats: magenta })], 'behind-the-scenes'), null);
});

test('a focused picture beats a scattered one, and an in-palette one beats a graded one', () => {
  const focused = cand('team', ['team']);                        // serves 2 themes
  const scattered = cand('mixed', ['conversation', 'portrait', 'team']); // serves 4
  assert.equal(pickForPillar([scattered, focused], 'customer-stories')!.id, 'team');

  const ready = cand('ready', ['conversation']);
  const needsWork = cand('cool', ['conversation'], { stats: gradeable });
  assert.equal(pickForPillar([needsWork, ready], 'tips')!.id, 'ready');
});

test('a picture needing a grade still carries its filters', () => {
  const m = pickForPillar([cand('cool', ['conversation'], { stats: gradeable })], 'tips');
  assert.ok(m);
  assert.equal(m!.filters.length, 2);
  assert.match(m!.why, /graded into the palette/);
});

test('coverage names the pillars that need photographs taken, not code', () => {
  const folder = [
    cand('c1', ['conversation']), cand('c2', ['conversation']), cand('t1', ['workspace']),
    cand('r1', ['reception']), cand('f1', ['food']),
    cand('x1', ['procedure'], { blockers: ['procedure'] }),
    cand('x2', ['rest'], { blockers: ['text'] }),        // the only sleep photo, refused
  ];
  const { served, empty } = coverage(folder, ['tips', 'recipes', 'sleep', 'movement', 'behind-the-scenes']);
  assert.ok(served.tips >= 2);
  assert.equal(served.recipes, 1);
  assert.equal(served['behind-the-scenes'], 1);
  assert.equal(served.sleep, 0, 'the one rest photo has signage in it');
  assert.equal(served.movement, 0);
  assert.deepEqual(empty, ['sleep', 'movement']);
});

test('an empty folder offers nothing and claims nothing', () => {
  assert.equal(pickForPillar([], 'tips'), null);
  const { empty } = coverage([], ['tips', 'sleep']);
  assert.deepEqual(empty, ['tips', 'sleep']);
});

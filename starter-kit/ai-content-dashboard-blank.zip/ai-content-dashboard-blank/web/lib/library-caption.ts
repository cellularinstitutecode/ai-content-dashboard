// web/lib/library-caption.ts
//
// WHAT IS ACTUALLY IN THE PHOTO FOLDER.
//
// A team's Drive folder tends to hold hundreds of photographs named
// DSC00757.png and 12 (1).png. Nothing about a filename says whether the
// picture shows a conversation, a product or the car park, so a post about
// cooking cannot find the right photograph even when one exists. This reads
// each picture once with the vision model the image checker already uses, and
// records what it shows and what would stop it being used.
//
// Two separate questions, deliberately kept apart:
//
//   SUBJECT   what the photograph is of, which decides the posts it could
//             illustrate.
//   BLOCKERS  what the cover rules would refuse it for - rendered text, a
//             medical procedure in progress, a device attached to a person,
//             an identifiable member of the public. Counting subjects
//             without counting blockers would flatter the library badly.
//
// WHICH POSTS A SUBJECT SERVES is said in THEMES — the same kinds of picture
// lib/planner-image.ts reads a strategy pillar as (food, craft, people…) —
// never in a particular strategy's pillar ids, so a deployment's own pillars
// find their photographs without this file knowing their names. Any pillar id
// or name handed in is read for its theme (kindOf).
//
// Pure on purpose: the vocabulary, the parsing and the theme mapping decide
// what the team is told it has, so they are tested rather than trusted.
import { kindOf } from './planner-image.ts';

/** The subjects worth telling apart in a photo folder. */
export const SUBJECTS = [
  'conversation',      // two or more people talking at a desk, counter or table
  'portrait',          // one person, posed or candid
  'team',              // two or more staff together, group or corridor
  'workspace',         // the room, studio, shop or office itself, with or without people
  'product',           // an item the brand makes or sells, as the subject
  'process',           // hands at work, something being made, prepared or repaired
  'procedure',         // something medical being administered or performed
  'reception',         // front desk, counter, waiting area, lobby
  'exterior',          // building, street, landscape, outdoors
  'lab',               // bench, microscope, samples
  'equipment',         // a machine, tool or instrument as the subject
  'food',              // meals, ingredients, drinks, kitchen
  'movement',          // walking, exercise, stretching, sport
  'rest',              // sleep, bedroom, quiet domestic calm
  'document',          // paperwork, screens, slides, printed material
  'graphic',           // a render, diagram or designed image, not a photograph
] as const;
export type Subject = (typeof SUBJECTS)[number];

/** What would stop a picture being used as a post cover. */
export const BLOCKERS = [
  'text',                 // any legible words, signage, branding, slides
  'procedure',            // a medical procedure being carried out
  'device-on-person',     // cuff, IV line, electrodes, mask, probe on a body
  'identifiable-patient', // a customer's or patient's face, clearly recognisable (not staff)
  'render',               // 3D or illustrated rather than photographed
] as const;
export type Blocker = (typeof BLOCKERS)[number];

export type Caption = {
  /** One sentence, plain, what a person would say the picture shows. */
  caption: string;
  subjects: Subject[];
  blockers: Blocker[];
};

/**
 * Which themes each subject can honestly illustrate (lib/planner-image.ts
 * SceneKind). Older index rows may carry subjects no longer listed; they
 * simply serve nothing.
 */
const SUBJECT_THEMES: Record<string, string[]> = {
  conversation: ['general', 'expertise', 'people'],
  portrait: ['people', 'general', 'expertise'],
  team: ['people', 'craft'],
  workspace: ['craft', 'general', 'place'],
  product: ['product'],
  process: ['craft', 'expertise', 'product'],
  procedure: [],                       // never a cover, so it illustrates nothing
  reception: ['place', 'general'],
  exterior: ['place', 'lifestyle'],
  lab: ['expertise', 'craft'],
  equipment: ['craft', 'product'],
  food: ['food'],
  movement: ['lifestyle'],
  rest: ['rest'],
  document: [],
  graphic: [],
};

/** The theme a pillar id, pillar name or theme is served under. */
export function themeOf(pillar: string): string {
  return kindOf(pillar);
}

/** The themes a captioned picture could serve. Empty when it could serve none. */
export function pillarsFor(c: Pick<Caption, 'subjects'>): string[] {
  const out = new Set<string>();
  for (const s of c.subjects) for (const p of SUBJECT_THEMES[s] || []) out.add(p);
  return [...out].sort();
}

/** Could this picture illustrate a post under this pillar (an id, a name, or a theme)? */
export function servesPillar(c: Pick<Caption, 'subjects'>, pillar: string): boolean {
  return pillarsFor(c).includes(themeOf(pillar));
}

/**
 * Could this picture be a post cover at all?
 *
 * An identifiable member of the public is not a defect in the photograph — it
 * is a consent question for the team — so it is reported separately rather than folded in
 * with the rule failures.
 */
export function coverSafe(c: Pick<Caption, 'blockers'>): { ok: boolean; why: Blocker[]; needsConsent: boolean } {
  const why = c.blockers.filter((b) => b !== 'identifiable-patient');
  return { ok: why.length === 0, why, needsConsent: c.blockers.includes('identifiable-patient') };
}

export function captionSystemPrompt(): string {
  return [
    'You are cataloguing a business\'s own photo library so its marketing team can find pictures by what they show.',
    'Look at the photograph and answer two things.',
    `SUBJECTS: which of these it shows — ${SUBJECTS.join(', ')}. Choose every one that genuinely applies, usually one or two, never more than three.`,
    '"procedure" means a medical or cosmetic treatment is being given or performed on someone (ordinary work with the hands is "process"). "graphic" means it is a render, diagram or designed image rather than a photograph.',
    `BLOCKERS: which of these are present — ${BLOCKERS.join(', ')}.`,
    '"text" means ANY legible words anywhere: signage, a logo on a wall or uniform, a slide, a screen, printed paper, a label. When in doubt, say text.',
    '"device-on-person" means something medical is worn by, clipped to, connected to or held against a person: a cuff, an IV line, electrodes, a mask, a probe.',
    '"identifiable-patient" means the face of a customer, client or patient is clearly recognisable. Staff at work do not count.',
    'Also give one plain sentence saying what the picture shows, as a person would describe it.',
    'Answer with STRICT JSON only: {"caption": "one sentence", "subjects": ["..."], "blockers": ["..."]}',
  ].join(' ');
}

/** Parse and sanitise the model's answer. Null when unusable. */
export function parseCaption(raw: unknown): Caption | null {
  let obj: unknown = raw;
  if (typeof raw === 'string') {
    const m = raw.match(/\{[\s\S]*\}/);
    if (!m) return null;
    try { obj = JSON.parse(m[0]); } catch { return null; }
  }
  if (!obj || typeof obj !== 'object') return null;
  const o = obj as Record<string, unknown>;
  const caption = String(o.caption ?? '').replace(/\s+/g, ' ').trim().slice(0, 200);
  const pick = <T extends string>(v: unknown, allowed: readonly T[]): T[] => {
    const arr = Array.isArray(v) ? v : [];
    const seen = new Set<string>();
    return arr
      .map((x) => String(x).trim().toLowerCase())
      .filter((x): x is T => (allowed as readonly string[]).includes(x) && !seen.has(x) && !!seen.add(x));
  };
  const subjects = pick(o.subjects, SUBJECTS).slice(0, 3);
  const blockers = pick(o.blockers, BLOCKERS);
  if (!caption || !subjects.length) return null;
  return { caption, subjects, blockers };
}

export type Inventory = {
  /** How many pictures could cover each pillar (read for its theme), after the rules. */
  byPillar: Record<string, number>;
  /** How many were refused for each reason. */
  byBlocker: Record<string, number>;
  usable: number;
  needsConsent: number;
  total: number;
};

/** Roll a set of captions up into the answer the team actually asked for. */
export function inventory(caps: Caption[], pillars: readonly string[]): Inventory {
  const byPillar: Record<string, number> = Object.fromEntries(pillars.map((p) => [p, 0]));
  const byBlocker: Record<string, number> = Object.fromEntries(BLOCKERS.map((b) => [b, 0]));
  let usable = 0, needsConsent = 0;
  for (const c of caps) {
    for (const b of c.blockers) byBlocker[b] = (byBlocker[b] ?? 0) + 1;
    const safe = coverSafe(c);
    if (safe.needsConsent) needsConsent += 1;
    if (!safe.ok) continue;
    usable += 1;
    const themes = pillarsFor(c);
    for (const p of pillars) if (themes.includes(themeOf(p))) byPillar[p] += 1;
  }
  return { byPillar, byBlocker, usable, needsConsent, total: caps.length };
}

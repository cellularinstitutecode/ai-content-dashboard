// Unit tests for the KEYWORDS cell's hashtags. Run with: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { HOUSE_HASHTAG, MAX_HASHTAGS, hashtagFrom, hashtagsFrom } from './hashtags.ts';

test('a phrase becomes one closed-up lowercase tag', () => {
  assert.equal(hashtagFrom('Cold Brew Coffee'), '#coldbrewcoffee');
  assert.equal(hashtagFrom('pour over'), '#pourover');
  assert.equal(hashtagFrom('  Specialty   Coffee  '), '#specialtycoffee');
});

// Keyword briefs are often in accented languages. Stripping accents instead of folding them would
// cut every accented word short — "panadería" losing its tail to become #panader.
test('accents fold to their base letter, never truncating the word', () => {
  assert.equal(hashtagFrom('panadería'), '#panaderia');
  assert.equal(hashtagFrom('café de especialidad en Bogotá'), '#cafedeespecialidadenbogota');
  assert.equal(hashtagFrom('café con leche'), '#cafeconleche');
});

test('punctuation closes up rather than splitting the tag', () => {
  assert.equal(hashtagFrom('anti-aging'), '#antiaging');
  assert.equal(hashtagFrom('tea vs. coffee'), '#teavscoffee');
  assert.equal(hashtagFrom('#alreadyatag'), '#alreadyatag');
});

test('what cannot be a tag is dropped, not mangled into one', () => {
  assert.equal(hashtagFrom(''), '');
  assert.equal(hashtagFrom('a'), '', 'too short to mean anything');
  assert.equal(hashtagFrom('!!!'), '');
  assert.equal(hashtagFrom('2026 trends'), '', 'most networks refuse a tag starting with a digit');
  assert.equal(hashtagFrom('a'.repeat(40)), '', 'a sentence pasted into the wrong cell');
  assert.equal(hashtagFrom(null), '');
});

test('the house tag comes from the deployment\'s BRAND_HASHTAG, and a blank one means none', () => {
  assert.equal(HOUSE_HASHTAG, process.env.BRAND_HASHTAG ? HOUSE_HASHTAG : '', 'no env, no house tag');
  const out = hashtagsFrom(['cold brew coffee']);
  assert.deepEqual(out, HOUSE_HASHTAG ? [HOUSE_HASHTAG, '#coldbrewcoffee'] : ['#coldbrewcoffee']);
});

test('the house tag leads and the brief follows', () => {
  const out = hashtagsFrom(['cold brew coffee', 'pour over'], { house: '#acmestudio' });
  assert.deepEqual(out, ['#acmestudio', '#coldbrewcoffee', '#pourover']);
});

// Semrush returns casing variants of the same phrase as separate keywords.
test('casing variants collapse to one tag', () => {
  const out = hashtagsFrom(['Cold Brew Coffee', 'cold brew coffee', 'COLD BREW COFFEE'], { house: '#acmestudio' });
  assert.deepEqual(out, ['#acmestudio', '#coldbrewcoffee']);
});

test('the house tag is never repeated by a keyword that matches it', () => {
  const out = hashtagsFrom(['Acme Studio', 'latte art'], { house: '#acmestudio' });
  assert.deepEqual(out, ['#acmestudio', '#latteart']);
});

test('a caption is not allowed to become tag spam', () => {
  const many = Array.from({ length: 40 }, (_, i) => 'keyword number ' + 'x'.repeat(i + 3));
  assert.equal(hashtagsFrom(many).length, MAX_HASHTAGS);
  assert.equal(hashtagsFrom(many, { house: '#acmestudio' }).length, MAX_HASHTAGS, 'the house tag counts toward the cap');
});

test('the house tag can be turned off without losing the rest', () => {
  assert.deepEqual(hashtagsFrom(['cold brew'], { house: '' }), ['#coldbrew']);
});

// web/lib/rate-limit.ts
// DB-backed sliding-window rate limiter for expensive AI routes.
//
// Uses the service-role client so it can read/write usage_events regardless of
// RLS. Counts a user's events for a given action within the trailing window and
// rejects once the cap is reached.
//
// IMPORTANT: this limiter FAILS CLOSED. If the usage_events table does not exist
// yet (migration not applied) or the DB errors, we REJECT the request so an
// outage can't remove the only cap on AI spend. For the one-time pre-migration
// bootstrap you may set RATE_LIMIT_FAIL_OPEN=true to temporarily allow traffic;
// leave it unset in production. Apply web/supabase/schema.sql to activate.
import 'server-only';
import { supabaseAdmin } from '@/lib/supabase-admin';
import { redact } from './report.ts';

export type RateLimitResult = {
  ok: boolean;
  limit: number;
  remaining: number;
  retryAfterSec: number;
};

// Per-action policy: max requests allowed within windowSec.
type Policy = { limit: number; windowSec: number };

const POLICIES: Record<string, Policy> = {
  generate: { limit: 30, windowSec: 3600 },
  assistant: { limit: 60, windowSec: 3600 },
  'opus-clip': { limit: 10, windowSec: 3600 },
  image: { limit: 20, windowSec: 3600 },
  // Paid third-party credit spend — these were previously uncapped.
  'autopilot-tick': { limit: 12, windowSec: 3600 },
  // Each sweep can transcribe several videos and write a content pack for each
  // — the most expensive single button in the app.
  'video-sweep': { limit: 12, windowSec: 3600 },
  // Prepare has its own allowance rather than sharing `generate`'s thirty.
  //
  // A long video costs TWO requests — the first banks the transcript and stops before the
  // clock kills it — so thirty meant fifteen videos an hour, and the sheet has thirty-three
  // rows waiting. Sharing the bucket also meant a morning of batch work locked a person
  // out of the composer.
  //
  // Worth being plain about what this is: the limiter counts requests, not money. Each of
  // these spends a Drive download, a transcription and two or three model calls, and the
  // count is read-then-write (see below) so a burst can overshoot by the size of the burst.
  // It is a brake, not an accountant.
  'video-prepare': { limit: 120, windowSec: 3600 },
  'autopilot-action': { limit: 40, windowSec: 3600 },
  semrush: { limit: 120, windowSec: 3600 },
  keywords: { limit: 60, windowSec: 3600 },
  // One database read, no third party, no spend — but a picker that opens on
  // every composer visit should still not be the one uncapped door.
  'media-list': { limit: 240, windowSec: 3600 },
  // Copies a file inside the brand's Drive and opens it to anyone with the
  // link. Cheap in time, permanent in effect — nothing in this app deletes one.
  'media-copy': { limit: 40, windowSec: 3600 },
  // Routes that reach the shared Metricool account. Each was uncapped: `posts`
  // is the one that APPROVES into the live queue and DELETES.
  posts: { limit: 120, windowSec: 3600 },
  // Reading the publishing list. It is a read of the account's own rows (and
  // a Sheets tab id cached for an hour) — no Metricool, no Drive — but four
  // screens read it and re-read it on every 'posts' refresh signal. Counted in
  // the write bucket above it ran out within a working hour, and the calendar,
  // the dashboard queue and the sources board all went blank for up to an
  // hour. Its own ceiling: still a stop for a runaway loop.
  'posts-read': { limit: 1200, windowSec: 3600 },
  // The strategy's per-pillar performance (Phase 4). Database reads only.
  'strategy-performance': { limit: 240, windowSec: 3600 },
  'metricool-read': { limit: 120, windowSec: 3600 },
  'metricool-sync': { limit: 12, windowSec: 3600 },
  // Named by sources/route.ts but absent from this table, so both silently took
  // DEFAULT_POLICY — the same mistake the 'ai-research' note above records.
  'sources-edit': { limit: 120, windowSec: 3600 },
  'sources-import': { limit: 60, windowSec: 3600 },
  // The research copilot runs a Semrush pre-filter AND an LLM call, so it is
  // at least as expensive as `generate`. Without an entry here it silently
  // took DEFAULT_POLICY — double the cap of the cheaper operation.
  'ai-research': { limit: 30, windowSec: 3600 },
  // Writing a template is cheap, but every active one becomes automated spend
  // on the next Autopilot tick. Nobody edits a weekly cadence 60 times an hour.
  templates: { limit: 60, windowSec: 3600 },
  // Writing the posts of a dropped strategy: a week is fourteen posts, each
  // a copy request and a picture request, started the moment the week is
  // read — and a person may drop the document twice in an hour.
  'strategy-draft': { limit: 150, windowSec: 3600 },
  // Reaches a live brand account through a paid third party.
  schedule: { limit: 60, windowSec: 3600 },
  // Each call mints a spendable OpenAI Realtime credential.
  realtime: { limit: 20, windowSec: 3600 },
  // The clip POLL. Generous, because the dashboard polls every 5s per pending
  // job, but not unbounded: on the ready path each call can download clips from
  // Opus and upload them to Drive.
  'opus-poll': { limit: 900, windowSec: 3600 },
  // The nightly sweep, when a person asks for its report by hand. Lists the
  // whole bucket and reads every draft; nobody needs that twelve times an hour.
  'maintenance-prune': { limit: 12, windowSec: 3600 },
  // One short model call to name a post. Cheap, pressed a few times per draft
  // while somebody settles on a title, and never worth an unbounded loop.
  title: { limit: 120, windowSec: 3600 },
};

const DEFAULT_POLICY: Policy = { limit: 60, windowSec: 3600 };

// Check (and record) a usage event for a user + action.
// Returns ok:false when the trailing-window count is at or above the limit.
export async function checkRateLimit(userId: string, action: string): Promise<RateLimitResult> {
  const policy = POLICIES[action] || DEFAULT_POLICY;
  const windowStart = new Date(Date.now() - policy.windowSec * 1000).toISOString();
  // Explicit opt-in for the pre-migration bootstrap window only. Leave unset in prod.
  const failOpen = process.env.RATE_LIMIT_FAIL_OPEN === 'true';

  try {
    const admin = supabaseAdmin();

    const { count, error } = await admin
      .from('usage_events')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('action', action)
      .gte('created_at', windowStart);

    // Fail CLOSED on any DB error (e.g. table missing before migration) unless
    // explicitly bootstrapping via RATE_LIMIT_FAIL_OPEN.
    if (error) {
      return failOpen
        ? { ok: true, limit: policy.limit, remaining: policy.limit, retryAfterSec: 0 }
        : { ok: false, limit: policy.limit, remaining: 0, retryAfterSec: policy.windowSec };
    }

    const used = count || 0;
    if (used >= policy.limit) {
      return { ok: false, limit: policy.limit, remaining: 0, retryAfterSec: policy.windowSec };
    }

    // Under the cap: record this event. The insert is what MAKES the limiter
    // work — if it silently fails, `count` stays flat and the cap never trips.
    // The module's contract is fail-closed, so a failed insert is treated the
    // same way a failed count is.
    const { error: insertError } = await admin.from('usage_events').insert({ user_id: userId, action });
    if (insertError) {
      console.error('rate-limit: usage_events insert failed', action, redact(insertError.message));
      return failOpen
        ? { ok: true, limit: policy.limit, remaining: policy.limit, retryAfterSec: 0 }
        : { ok: false, limit: policy.limit, remaining: 0, retryAfterSec: policy.windowSec };
    }

    return {
      ok: true,
      limit: policy.limit,
      remaining: Math.max(0, policy.limit - used - 1),
      retryAfterSec: 0,
    };
  } catch {
    return failOpen
      ? { ok: true, limit: policy.limit, remaining: policy.limit, retryAfterSec: 0 }
      : { ok: false, limit: policy.limit, remaining: 0, retryAfterSec: policy.windowSec };
  }
}

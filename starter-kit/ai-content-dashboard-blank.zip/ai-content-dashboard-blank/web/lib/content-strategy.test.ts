// web/lib/content-strategy.test.ts
//
// The built-in example strategy, pinned. These tests are not about logic —
// there is almost none — they are about the data keeping the shape the engine
// depends on, because every one of these strings ends up in a published
// post's brief. Replace the example with your own and update them with it.
//
// The one thing worth asserting hardest: a template pinned to ONE day advances
// its seed list once a week (lib/autopilot.ts rotates by occurrence), so the
// angle bank's LENGTH is how many weeks pass before a pillar repeats itself.
// That is the strategy's core rule — "repeat the pillar, not the wording" —
// expressed as a number, and it is the number that breaks first if somebody
// trims a bank to save a line.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_POST_TIMES } from './video-slot.ts';
import {
  ARTICLE_CITATION,
  COMMUNITY_RULE,
  DAY_THEMES,
  FREQUENCY_PILLARS,
  PILLARS,
  POSTS_PER_WEEK,
  SLOT_TIMES,
  STORIES_RULE,
  WEEK,
  WEEKLY_MIX,
  citationPolicyForSlot,
  daysFor,
  frequencyDays,
  frequencyPillarById,
  mixByPillarDays,
  pillarById,
  plannedTemplates,
  rulesForSlot,
  slotContext,
  slotKey,
} from './content-strategy.ts';

test('fourteen posts a week, two a day, seven days', () => {
  assert.equal(WEEK.length, 14);
  assert.equal(POSTS_PER_WEEK, 14);
  for (const day of [0, 1, 2, 3, 4, 5, 6]) {
    const onThatDay = WEEK.filter((s) => s.day === day);
    assert.equal(onThatDay.length, 2, 'day ' + day + ' must hold exactly two posts');
    assert.deepEqual(onThatDay.map((s) => s.post).sort(), [1, 2], 'a Post 1 and a Post 2');
  }
});

test('each day page\'s angle bank sits on its day', () => {
  // The day map. Monday: how-to + spotlight. Thursday: getting started +
  // community. Sunday: reflections + community spotlight. And so on.
  // (The frequency table's two-day rows are asserted separately below.)
  assert.deepEqual(daysFor('how-to'), [1]);
  assert.deepEqual(daysFor('spotlight'), [1]);
  assert.deepEqual(daysFor('quick-tips'), [2]);
  assert.deepEqual(daysFor('industry-news'), [2]);
  assert.deepEqual(daysFor('behind-the-scenes'), [3]);
  assert.deepEqual(daysFor('inspiration'), [3]);
  assert.deepEqual(daysFor('getting-started'), [4]);
  assert.deepEqual(daysFor('community'), [4]);
  assert.deepEqual(daysFor('faq'), [5]);
  assert.deepEqual(daysFor('customer-stories'), [5]);
  assert.deepEqual(daysFor('process'), [6]);
  assert.deepEqual(daysFor('practical-tips'), [6]);
  assert.deepEqual(daysFor('reflections'), [0]);
  assert.deepEqual(daysFor('community-stories'), [0]);
});

test('every pillar carries enough angles to keep a month apart', () => {
  // A template occurs once a week, so the bank length IS the repeat interval.
  // Five is the shortest bank; anything under it would bring a pillar back to
  // the same angle inside a month.
  for (const p of PILLARS) {
    assert.ok(p.angles.length >= 5, p.id + ' has only ' + p.angles.length + ' angles');
    assert.ok(p.angles.length <= 12, p.id + ' exceeds the 12 the strategy column stores');
    assert.equal(new Set(p.angles).size, p.angles.length, p.id + ' repeats an angle inside its own bank');
    for (const angle of p.angles) {
      assert.ok(angle.trim().length > 12, p.id + ' has a stub angle: ' + JSON.stringify(angle));
    }
  }
  // No angle appears in two banks: the rotation deals them as distinct cards.
  const all = PILLARS.flatMap((p) => p.angles);
  assert.equal(new Set(all).size, all.length, 'an angle is shared between banks');
});

test('every slot resolves to a pillar, and every pillar is used', () => {
  for (const slot of WEEK) {
    assert.ok(pillarById(slot.pillarId), 'no pillar for ' + slot.pillarId);
  }
  const used = new Set(WEEK.map((s) => s.pillarId));
  for (const p of PILLARS) {
    assert.ok(used.has(p.id), p.id + ' is defined but never scheduled');
  }
});

test('every pillar has its own name', () => {
  // The names become template names, and the seeder matches on them to update
  // rather than duplicate — so two pillars sharing a name would quietly become
  // one template.
  const names = PILLARS.map((p) => p.name);
  assert.equal(new Set(names).size, names.length, 'two pillars share a name');
  assert.ok(names.includes('How-to guides'));
  assert.ok(names.includes('Customer stories'));
  assert.ok(names.includes('Community spotlight'));
  assert.ok(names.includes('Lessons and reflections'));
});

test('the example is brand-neutral: no place, industry or brand in it', () => {
  const text = JSON.stringify({ PILLARS, FREQUENCY_PILLARS, DAY_THEMES, WEEK, STORIES_RULE, COMMUNITY_RULE });
  assert.doesNotMatch(text, /canc[uú]n|m[eé]xic|clinic|patient|physician|medical|stem[- ]cell|cellular/i);
});

test('the two standing notes govern every slot counted towards their rows', () => {
  // The example's only two rules that are not about a day. They attach to the
  // frequency table's rows, not to one day's post — so Sunday's "Community
  // spotlight", which the table counts under BOTH customer stories and
  // community, carries both.
  const community = frequencyPillarById('community');
  assert.match(community?.rule || '', /Never claim the brand is categorically better/);
  assert.match(community?.rule || '', /specific, checkable things/);
  const stories = frequencyPillarById('customer-stories');
  assert.match(stories?.rule || '', /with their permission/);
  assert.match(stories?.rule || '', /never invent a customer, a quote, a review or a result/);

  assert.equal(rulesForSlot('thu-2'), COMMUNITY_RULE);
  assert.equal(rulesForSlot('fri-2'), STORIES_RULE);
  assert.match(rulesForSlot('sun-2'), /categorically better/);
  assert.match(rulesForSlot('sun-2'), /with their permission/);
  // And nothing else invents one.
  const withRules = WEEK.map((s) => slotKey(s)).filter((k) => rulesForSlot(k));
  assert.deepEqual(withRules.sort(), ['fri-2', 'sun-2', 'thu-2']);
  assert.ok(rulesForSlot('sun-2').length <= 800, 'both rules fit the stored rule cap');
});

test('the frequency table is data, and the day map reproduces every row of it', () => {
  assert.equal(FREQUENCY_PILLARS.length, 9);
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const expected: Record<string, number[]> = {
    education: [1, 4], spotlight: [1, 5], tips: [2, 6], industry: [2],
    'behind-the-scenes': [3, 6], inspiration: [3, 0], 'customer-stories': [5, 0], community: [4, 0],
  };
  for (const [id, days] of Object.entries(expected)) {
    assert.deepEqual(frequencyDays(id, ['primary']).sort(), days.slice().sort(), id);
    const row = frequencyPillarById(id)!;
    for (const d of days) assert.match(row.days, new RegExp(dayNames[d]), id + ' names ' + dayNames[d]);
  }
  // "Primarily Friday; also integrated into education content".
  assert.deepEqual(frequencyDays('faq', ['primary']), [5]);
  assert.deepEqual(frequencyDays('faq', ['integrated']), [1]);
  assert.match(frequencyPillarById('faq')!.days, /Primarily Friday; also integrated into education content/);
});

test('the recommended mix and the day map are both recorded, and the one difference named', () => {
  // The example recommends 5 educate / 5 everyday / 2 proof / 2 connect.
  // Counted the frequency table's way (each primary row a slot belongs to),
  // the day map gives exactly that for educate, proof and connect — and 7
  // everyday, because Saturday's two posts are extra everyday ones. Both are
  // asserted so changing either is a decision somebody makes on purpose.
  assert.deepEqual(WEEKLY_MIX, { educate: 5, everyday: 5, proof: 2, connect: 2 });
  assert.equal(Object.values(WEEKLY_MIX).reduce((a, b) => a + b, 0), 14);
  const mix = mixByPillarDays();
  assert.deepEqual(mix, { educate: 5, everyday: 7, proof: 2, connect: 2 });
  assert.equal(Object.values(mix).reduce((a, b) => a + b, 0), 16, 'sixteen pillar-days over fourteen slots');
  assert.notEqual(mix.everyday, WEEKLY_MIX.everyday, 'the example disagrees with itself here on purpose; do not paper over it');
});

test('every slot knows its day theme and what else it counts as', () => {
  assert.equal(Object.keys(DAY_THEMES).length, 7);
  assert.deepEqual(slotContext('mon-1'), { dayTheme: 'Teach something useful', alsoCovers: [], integrated: ['FAQ and myth-busting'] });
  assert.deepEqual(slotContext('fri-1')!.alsoCovers, ['Product or service spotlight', 'FAQ and myth-busting']);
  assert.deepEqual(slotContext('sun-2')!.alsoCovers, ['Customer stories', 'Community and values']);
  assert.equal(slotContext('sun-2')!.dayTheme, 'Stories and community');
  assert.equal(slotContext('mon-blog'), null);
});

test('no slot of the example forces a citation; only an unknown key does', () => {
  // A generic strategy makes no health claim by default, so every row cites a
  // study only when a post makes one. Unknown keys stay on the strict default.
  const relaxed = WEEK.map((s) => slotKey(s)).filter((k) => citationPolicyForSlot(k) === 'if-health-claim');
  assert.equal(relaxed.length, 14);
  for (const f of FREQUENCY_PILLARS) assert.equal(f.citation, 'if-health-claim', f.id);
  assert.equal(ARTICLE_CITATION, 'if-health-claim');
  assert.equal(citationPolicyForSlot('mon-blog'), ARTICLE_CITATION);
  assert.equal(citationPolicyForSlot('nonsense'), 'required');
});

// --- WHAT THE ENGINE IS HANDED ----------------------------------------------

test('each slot becomes a one-day template, which is what makes the rotation weekly', () => {
  // THE LOAD-BEARING DETAIL. lib/autopilot.ts advances the seed list by
  // OCCURRENCE, not by week. A seven-day template would advance it daily and
  // the pillars would drift off their days inside a week; a one-day template
  // advances once a week, which is exactly "the same pillar, a new angle".
  const planned = plannedTemplates();
  assert.equal(planned.length, 14);
  for (const t of planned) {
    assert.equal(t.weekdays.length, 1, t.name + ' must be pinned to a single day');
    assert.ok(t.pillars.length >= 5, t.name + ' must hand over its whole angle bank');
  }
  const monday = planned.filter((t) => t.weekdays[0] === 1);
  assert.deepEqual(monday.map((t) => t.time_of_day), [SLOT_TIMES[1], SLOT_TIMES[2]]);
  assert.equal(monday[0].name, 'How-to guides');
  assert.match(monday[0].pillars[0], /step-by-step guide/);
});

test('the slot times stay clear of the video pipeline', () => {
  // The reels publish at 13:00 and 17:00 (lib/video-slot.ts DEFAULT_POST_TIMES).
  // These 14 are additional, by your decision — so they should not land in the
  // same hour and make the calendar unreadable.
  assert.equal(SLOT_TIMES[1], '09:00');
  assert.equal(SLOT_TIMES[2], '18:00');
  for (const t of Object.values(SLOT_TIMES)) {
    assert.ok(!DEFAULT_POST_TIMES.includes(t), 'collides with a video slot');
  }
});

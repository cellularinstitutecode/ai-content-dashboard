import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BLOCKERS, SUBJECTS, captionSystemPrompt, coverSafe, inventory, parseCaption, pillarsFor, servesPillar, themeOf } from './library-caption.ts';
import { PILLARS } from './content-strategy.ts';
import { PILLAR_SCENES } from './planner-image.ts';

const cap = (subjects: string[], blockers: string[] = []) =>
  parseCaption({ caption: 'a picture', subjects, blockers })!;

test('a well-formed answer parses, and unknown words are dropped rather than trusted', () => {
  const c = parseCaption({ caption: '  Two people  talking at a desk. ', subjects: ['conversation', 'nonsense', 'portrait'], blockers: ['text', 'aliens'] })!;
  assert.equal(c.caption, 'Two people talking at a desk.');
  assert.deepEqual(c.subjects, ['conversation', 'portrait']);
  assert.deepEqual(c.blockers, ['text']);
});

test('a JSON answer wrapped in prose still parses', () => {
  const c = parseCaption('Sure! ```json\n{"caption":"A workbench.","subjects":["workspace"],"blockers":[]}\n``` hope that helps');
  assert.equal(c?.subjects[0], 'workspace');
});

test('an answer with no subject is unusable', () => {
  assert.equal(parseCaption({ caption: 'something', subjects: [], blockers: [] }), null);
  assert.equal(parseCaption({ caption: '', subjects: ['portrait'] }), null);
  assert.equal(parseCaption('not json at all'), null);
});

test('duplicates are collapsed and the subject list is capped', () => {
  const c = cap(['portrait', 'portrait', 'team', 'exterior', 'lab', 'food']);
  assert.equal(c.subjects.length, 3);
  assert.equal(new Set(c.subjects).size, 3);
});

test('every subject maps to themes the planner knows, and any pillar is read for one', () => {
  for (const s of SUBJECTS) {
    for (const p of pillarsFor({ subjects: [s] })) {
      assert.ok(PILLAR_SCENES[p], `${s} maps to "${p}", which is not a theme`);
    }
  }
  // Whatever pillars the strategy ships, each is served under some theme.
  for (const p of PILLARS) assert.ok(PILLAR_SCENES[themeOf(p.id)], p.id);
  assert.equal(themeOf('recipes'), 'food');
  assert.equal(themeOf('food'), 'food');
  assert.equal(themeOf('zz-unknown'), 'general');
});

test('the lifestyle themes can only be served by lifestyle subjects', () => {
  // The finding that matters: no amount of photography of the business covers
  // a post about food, sleep or movement.
  for (const business of ['conversation', 'team', 'workspace', 'product', 'process', 'reception'] as const) {
    const p = pillarsFor({ subjects: [business] });
    for (const lifestyle of ['food', 'rest', 'lifestyle']) {
      assert.ok(!p.includes(lifestyle), `${business} should not claim to illustrate ${lifestyle}`);
    }
    assert.equal(servesPillar({ subjects: [business] }, 'recipes'), false);
  }
  assert.deepEqual(pillarsFor({ subjects: ['food'] }), ['food']);
  assert.deepEqual(pillarsFor({ subjects: ['rest'] }), ['rest']);
  assert.equal(servesPillar({ subjects: ['food'] }, 'nutrition'), true);
  assert.equal(servesPillar({ subjects: ['rest'] }, 'sleep-stress'), true);
  // An older index row with a subject no longer listed serves nothing, and does not throw.
  assert.deepEqual(pillarsFor({ subjects: ['iv-suite' as never] }), []);
});

test('a procedure photograph illustrates nothing, however good it is', () => {
  assert.deepEqual(pillarsFor({ subjects: ['procedure'] }), []);
  assert.equal(coverSafe({ blockers: ['procedure'] }).ok, false);
});

test('consent is reported apart from the rule failures', () => {
  const s = coverSafe({ blockers: ['identifiable-patient'] });
  assert.equal(s.ok, true, 'a recognisable customer is a consent question, not a defect');
  assert.equal(s.needsConsent, true);
  assert.deepEqual(s.why, []);

  const t = coverSafe({ blockers: ['identifiable-patient', 'text'] });
  assert.equal(t.ok, false);
  assert.deepEqual(t.why, ['text']);
  assert.equal(t.needsConsent, true);
});

test('the inventory counts only pictures the rules would actually allow', () => {
  const ids = ['tips', 'recipes', 'sleep'];
  const inv = inventory([
    cap(['conversation']),                    // usable
    cap(['conversation'], ['text']),          // refused — signage
    cap(['procedure'], ['procedure', 'device-on-person']),
    cap(['food']),                            // usable, and the only food hit
    cap(['portrait'], ['identifiable-patient']), // usable, but needs a release
  ], ids);
  assert.equal(inv.total, 5);
  assert.equal(inv.usable, 3);
  assert.equal(inv.needsConsent, 1);
  assert.equal(inv.byPillar.recipes, 1);
  assert.equal(inv.byPillar.sleep, 0);
  assert.equal(inv.byPillar.tips, 2, 'the conversation and the portrait');
  // The strategy's own pillar ids are all keys of the answer, whatever they are.
  const all = inventory([cap(['conversation'])], PILLARS.map((p) => p.id));
  for (const p of PILLARS) assert.ok(p.id in all.byPillar, p.id);
  assert.equal(inv.byBlocker.text, 1);
  assert.equal(inv.byBlocker.procedure, 1);
});

test('the prompt names every word the parser will accept', () => {
  const p = captionSystemPrompt();
  for (const s of SUBJECTS) assert.ok(p.includes(s), `the prompt never mentions "${s}"`);
  for (const b of BLOCKERS) assert.ok(p.includes(b), `the prompt never mentions "${b}"`);
  assert.match(p, /When in doubt, say text/);
});

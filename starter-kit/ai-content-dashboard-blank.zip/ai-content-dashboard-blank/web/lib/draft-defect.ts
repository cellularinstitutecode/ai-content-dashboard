// web/lib/draft-defect.ts
// What is wrong with this draft, and what to tell the writer about it.
//
// prepareVideo asked the writer for copy exactly once and then refused the
// whole video if that single draft was unusable — no REF line, or a person
// named in it. Both are model-output failures, not facts about the video: the
// prompt is identical, the temperature is 0.4, and the transcript is already
// paid for and cached by the time either is discovered. Asking again is
// cheap and usually enough.
//
// Two of those refusals are classified TERMINAL in lib/failure-kind.ts, so
// nothing ever comes back to them — which made a single bad draft the end of
// that video until a person noticed. This is the check that decides whether a
// second draft is worth asking for, and what to say when asking.
//
// No imports, deliberately: the test runner strips types and runs this file
// directly. It is handed the facts (the extracted REF, the names that leaked)
// rather than the text, so the compliance and naming regexes stay in the one
// place each already lives.

export type DefectKind = 'no_citation' | 'named_a_person' | 'repeats_opening' | 'unsupported_citation';

export type DraftDefect = {
  /**
   * Which refusal this becomes if the re-roll does not fix it.
   *
   * A leaked name outranks a missing citation: a brand appearing to quote a
   * customer who never spoke is the worse of the two to publish.
   *
   * 'repeats_opening' is the exception and does NOT become a refusal. A caption
   * that opens like last week's is worth one more attempt and nothing more —
   * refusing the video over it would hold back a perfectly publishable post
   * over a matter of style, and leave the row waiting on a person who never
   * asked to be involved. See `blocking` below and its use in
   * lib/video-prepare.ts.
   */
  kind: DefectKind;
  /** Appended to the writer's brief on the next attempt. */
  corrective: string;
  /**
   * Should the video be REFUSED if the last attempt still has this defect?
   *
   * Explicit rather than derived from `kind`, because the refusal in
   * lib/video-prepare.ts used to read "if (defect) ... else no_citation" — an
   * else-branch that turns any future defect kind into a bogus "no verifiable
   * citation" message. Adding a third kind without this flag would have
   * refused a repeated opening line by telling the team its citation was
   * missing.
   */
  blocking: boolean;
};

/**
 * Phrased like the corrective already in lib/ai.ts for a DOI Crossref rejects:
 * name what the previous draft did, then say what to do instead. Vague
 * encouragement ("remember the citation") is what the original prompt already
 * said, and it did not work the first time.
 */
const REF_CORRECTIVE =
  'IMPORTANT: your previous draft contained no REF line at all. Every draft MUST cite a real, published study — ' +
  'a line beginning "REF:" naming the authors, journal and year, with a real DOI. It is not optional: this post ' +
  'cannot be published without one.';

/**
 * Deliberately does NOT quote the name back.
 *
 * The obvious phrasing — 'your draft named "Alex", do not name "Alex"' —
 * puts the banned name straight back into the prompt, and a model told to
 * avoid a token is a well-known way to make it produce that token. It is also
 * the exact regression this pipeline already paid for once: the file name used
 * to be handed over, the model read "Reel_MolecularHydrogen_Alex", and it
 * wrote "As our patient Alex shares:" over a line of the transcript.
 * lib/video-copy.ts strips the owner suffix before the topic is built for that
 * reason, and a corrective that reintroduces it would undo the fix.
 *
 * The rule is categorical anyway. The writer does not need to know which name
 * it used; it needs to know it must not use any.
 */
function nameCorrective(count: number): string {
  return (
    'IMPORTANT: your previous draft named ' + (count === 1 ? 'a person' : 'people') + ' — ' +
    (count === 1 ? 'someone' : 'people') + ' who filmed or uploaded this video, not anybody speaking in it. ' +
    'Never name any individual: no customer, patient, presenter, staff member or uploader. Never attribute a quote, a result ' +
    'or an experience to a named person. Write only as the brand sharing its own video.'
  );
}

/**
 * Deliberately does NOT quote the offending sentence back.
 *
 * The same reasoning as nameCorrective above, for the same reason it was
 * learned: handing a model a sentence and telling it not to write that sentence
 * is a well-known way to get that sentence back, lightly reworded — which is
 * precisely the failure being corrected, since "the same sentence with the
 * nouns swapped" is what the team was already seeing.
 *
 * So this names the SHAPE that failed and demands a different anchor. The
 * writer does not need to know which opening it echoed; it needs to be told to
 * start from something in this video that no other video contains.
 */
const OPENING_CORRECTIVE =
  'IMPORTANT: your previous draft opened almost exactly like a post this brand has already published. ' +
  'Do not adjust that sentence — throw it away and write a different one. Open instead on something ' +
  'CONCRETE that appears only in THIS video: a number the speaker says, a piece of equipment they name, ' +
  'a material, a setting, a step they physically perform. Do not open on a general statement about ' +
  'the brand\'s field, safety, wellness or the industry — that is the shape that repeated.';

/**
 * Not "cite something else" — "say something the paper you were given shows".
 *
 * The draft that triggers this already HAS a real, DOI-verified citation; what
 * it does not have is a claim that citation supports (lib/claim-support.ts).
 * Telling the writer to find a better study would be the wrong instruction and
 * the expensive one: the papers in front of it were chosen from PubMed by
 * relevance and their DOIs are already checked, so the fix is to make the point
 * one of them actually makes.
 *
 * BLOCKING, since the September audit. This used to be "never blocking":
 * a post whose citation was real and verified but whose claim the abstract
 * did not back got one more draft and then published flagged, because a row
 * that waits for a person was thought the worse outcome. The audit found the
 * result: a tadalafil trial under a peptides post, a vaccinia paper under a
 * spine post, an unboxing-videos study under a third — a credibility and
 * compliance risk on medical advertising. A reference that backs nothing the
 * post says is worse than a row that waits, so after the second attempt it
 * refuses, with the reason written down and the transcript banked.
 */
const SUPPORT_CORRECTIVE =
  'IMPORTANT: your previous draft made a claim the study it cited does not actually show. Do not go looking ' +
  'for a different study — use the papers in the research section above, which were retrieved for this video ' +
  'and checked. Pick ONE of them, make a concrete point its abstract genuinely reports, and cite THAT paper. ' +
  'Do not state an outcome the abstract never measured, and do not turn a hedged or partial finding into a ' +
  'firm one. This is health advertising: the reference under it has to support the sentence above it.';

/**
 * Is this draft publishable, and if not, what should the writer be told?
 *
 * Every problem present is reported together, so one more attempt can fix all
 * of them rather than trading one refusal for another.
 *
 * @param ref the citation extracted from the composed copy; empty means none
 * @param leaked names the guard found in the copy
 * @param repeatsOpening lib/opening-line.ts found this opening in a recent post
 * @param unsupported the citation is real and verified, but no abstract backs
 *   the claim (lib/claim-support.ts). Blocking — see SUPPORT_CORRECTIVE.
 */
export function draftDefect(
  ref: string,
  leaked: readonly string[],
  repeatsOpening = false,
  unsupported = false,
): DraftDefect | null {
  const correctives: string[] = [];
  if (leaked.length) correctives.push(nameCorrective(leaked.length));
  if (!String(ref || '').trim()) correctives.push(REF_CORRECTIVE);
  if (unsupported) correctives.push(SUPPORT_CORRECTIVE);
  if (repeatsOpening) correctives.push(OPENING_CORRECTIVE);
  if (!correctives.length) return null;

  const blocking = Boolean(leaked.length) || !String(ref || '').trim() || unsupported;
  // Ordered by what is worst to publish, not by what was discovered first.
  const kind: DefectKind = leaked.length
    ? 'named_a_person'
    : (!String(ref || '').trim() ? 'no_citation' : (unsupported ? 'unsupported_citation' : 'repeats_opening'));
  return { kind, corrective: correctives.join('\n\n'), blocking };
}

// web/lib/compliance.ts
// The advertising rule for the brand's posts, as pure functions so it can be
// unit-tested and applied identically everywhere.
//
// It started as an Instagram and Facebook rule and is not one any more:
// LinkedIn and TikTok were added on 9 September and YouTube on 10 September,
// because complianceGate was answering "does not apply" for the very networks
// the video work goes to. SOCIAL_NETWORKS below is the list, and
// complianceNetworksLabel() builds every sentence from it so the wording can
// never again claim a narrower rule than the one being enforced.
//
// The rule has two parts, each of which can be switched off:
//
//     1. A regulatory advertising notice — an "AVISO DE PUBLICIDAD: <permit>"
//        line. Some jurisdictions require health advertising to carry the
//        advertiser's permit number. OPT-IN: it is required (and appended)
//        only when a permit number is configured, in Brand Brain
//        (brand_profiles.aviso_publicidad) or in the AVISO_PUBLICIDAD
//        environment variable. With neither set there is no AVISO line,
//        nothing appends one, and nothing refuses a post for lacking one.
//
//     2. A "REF:" line citing a peer-reviewed study (with a DOI) that supports
//        what the post says. Governed by REQUIRE_CITATIONS (see
//        citationRequirement below): by default it is required only when the
//        post makes a health claim (lib/health-claim.ts); 'always' requires it
//        on every post; 'off' never does.
//
// Where it applies: the generator asks the model for the REF line and this
// module appends the AVISO line deterministically (a permit number is not
// something to leave to a language model); the composer shows the state and
// offers a one-click fix for the AVISO; and the two doors to Metricool —
// "Send for review" and "Approve" — refuse a covered post that is missing
// either required line. Nothing about the rule lives in the UI alone.

import { makesHealthClaim } from './health-claim.ts';

/**
 * How strictly the REF (citation) line is required, from REQUIRE_CITATIONS
 * (NEXT_PUBLIC_REQUIRE_CITATIONS mirrors it for the composer's in-browser
 * preview, where server variables are not visible):
 *
 *   'health-claims' (default) — only a post that makes a health claim needs a
 *                               REF line; a post that makes none passes
 *                               without one. A brand that never talks about
 *                               health is never asked for a citation.
 *   'always'                  — every covered post needs a REF line, except
 *                               where a draft was written under the relaxed
 *                               'if-health-claim' policy (refPolicyOf).
 *   'off'                     — no REF line is ever required.
 *
 * A REF line that IS present is still checked for a DOI unless 'off'.
 * Read on every call, not at load, so a test or a long-lived process sees the
 * current value.
 */
export type CitationRequirement = 'always' | 'health-claims' | 'off';

export function citationRequirement(): CitationRequirement {
  // NEXT_PUBLIC_* written out literally: that is the only form Next.js inlines into the browser bundle.
  const raw = String(
    (typeof process !== 'undefined' ? process.env?.REQUIRE_CITATIONS || process.env.NEXT_PUBLIC_REQUIRE_CITATIONS : '') || '',
  ).trim().toLowerCase();
  if (raw === 'always' || raw === 'required' || raw === 'true') return 'always';
  if (raw === 'off' || raw === 'none' || raw === 'false' || raw === 'never') return 'off';
  return 'health-claims';
}

/**
 * Networks the rule applies to. Metricool's ids and the app's ids both appear.
 *
 * LinkedIn and TikTok were missing, so complianceGate answered "does not apply" for the
 * two networks the video pipeline actually publishes to — the gate that exists to stop an
 * uncited medical claim reaching a queue was never consulted for them. The rule is about
 * advertising, which does not stop being true because the post is on LinkedIn.
 *
 * YouTube joined them for exactly the same reason once it became selectable in the
 * composer. A video description making a therapeutic claim is advertising; the platform
 * it is hosted on has never been what the rule turns on.
 */
const SOCIAL_NETWORKS = new Set(['instagram', 'facebook', 'ig', 'fb', 'linkedin', 'tiktok', 'youtube']);

/**
 * And the blog, which is not a social network and was therefore exempt from a
 * rule that has nothing to do with social networks.
 *
 * The same reasoning as LinkedIn's and YouTube's, one step further: the rule is
 * about advertising, and an 800-word article making a health claim is
 * advertising by any reading. It was the ONE format that skipped the notice and
 * the citation — and the longest-lived thing the brand publishes, sitting on
 * its own domain being indexed, long after a post has scrolled away.
 *
 * Kept separate from SOCIAL_NETWORKS only so the refusal sentence can say
 * "blog articles" rather than listing it among the networks.
 */
const ARTICLE_CHANNELS = new Set(['blog']);

/** Every channel the rule covers. */
const GATED_CHANNELS = new Set([...SOCIAL_NETWORKS, ...ARTICLE_CHANNELS]);

/** Proper names for the channel ids, for a sentence a person reads. */
const NETWORK_NAMES: Record<string, string> = {
  instagram: 'Instagram', ig: 'Instagram', facebook: 'Facebook', fb: 'Facebook',
  linkedin: 'LinkedIn', tiktok: 'TikTok', youtube: 'YouTube', blog: 'blog article',
};

/**
 * The networks this rule covers, named, for the sentence shown when a post is
 * refused — derived from SOCIAL_NETWORKS rather than typed out beside it.
 *
 * Every message used to say "Instagram and Facebook posts…" and kept saying it
 * for a week after LinkedIn, TikTok and YouTube joined the set, so somebody
 * with none of those two selected was told their post failed a rule about two
 * networks they were not posting to. Reading the set is what stops that
 * happening again the next time it changes.
 *
 * `only` narrows it to the networks actually selected, which is what the
 * composer wants; with no argument it names them all.
 */
export function complianceNetworksLabel(only?: readonly string[] | null): string {
  const ids = (only && only.length ? only.map((p) => String(p || '').trim().toLowerCase()).filter((p) => GATED_CHANNELS.has(p)) : [...GATED_CHANNELS]);
  const names: string[] = [];
  for (const id of ids) {
    const name = NETWORK_NAMES[id] || id;
    if (!names.includes(name)) names.push(name);
  }
  if (!names.length) return 'These';
  if (names.length === 1) return names[0];
  return names.slice(0, -1).join(', ') + ' and ' + names[names.length - 1];
}

export function appliesTo(providers: readonly string[] | string | null | undefined): boolean {
  const list = Array.isArray(providers) ? providers : providers ? [providers] : [];
  return list.some((p) => GATED_CHANNELS.has(String(p || '').trim().toLowerCase()));
}

/**
 * The permit number to use: Brand Brain first, then the AVISO_PUBLICIDAD
 * environment variable. '' when neither is set — the advertising notice is
 * opt-in, and '' means "this deployment has none": not required, not appended.
 */
export function avisoNumberFor(brandValue?: string | null): string {
  const b = (brandValue || '').trim();
  if (b) return b.toUpperCase();
  const e = (typeof process !== 'undefined' ? process.env?.AVISO_PUBLICIDAD : '') || '';
  return e.trim().toUpperCase();
}

/** The exact AVISO line for a permit number; '' when no permit is configured. */
export function avisoLine(avisoNumber: string | null | undefined): string {
  const n = (avisoNumber || '').trim().toUpperCase() || avisoNumberFor(null);
  return n ? 'AVISO DE PUBLICIDAD: ' + n : '';
}

const AVISO_RE = /AVISO\s+DE\s+PUBLICIDAD\s*[:：]\s*([A-Z0-9]{8,})/i;
// "REF:" (or "REF." / "Ref:") followed by something that looks like a citation:
// at least a handful of characters, not just the label.
//
// Shape only, deliberately — the DOI is what makes it checkable, and that is tested
// separately below so a citation can be REPORTED as present-but-unverifiable rather than
// silently accepted. verifyDoi only ever sees citations that carry one.
const REF_RE = /(^|\n)[ \t]*REF(?:ERENCIA)?[ \t]*[.:：][ \t]*(\S[^\n]{15,})/i;
const DOI_RE = /\b(10\.\d{4,9}\/[^\s"'<>)\]]+)/i;

export type ComplianceCheck = {
  ok: boolean;
  /**
   * What is wrong. 'ref' means there is no REF line at all; 'doi' means there
   * IS one and it carries no DOI. Told apart on purpose: one message for both
   * sent people hunting for a line that was already sitting in front of them.
   */
  missing: ('aviso' | 'ref' | 'doi')[];
  /** The permit number found in the text, when an AVISO line is present. */
  avisoFound: string | null;
  /** True when the AVISO line is present but carries a different number. */
  avisoMismatch: boolean;
  /** The REF line's text (without the label), when present. */
  ref: string | null;
  /** The DOI inside the REF line, when it has one. */
  doi: string | null;
  /**
   * True when no REF line was needed: the post is under the "only when it
   * makes a health claim" policy and makes none (lib/health-claim.ts).
   */
  refWaived?: boolean;
};

/**
 * Whether a post must carry a REF line: 'required' (the default for every
 * caller that does not say otherwise), or 'if-health-claim' — the weekly
 * strategy's logistics/destination posts. REQUIRE_CITATIONS can only relax
 * this further (citationRequirement): under its default 'health-claims' every
 * post is treated as 'if-health-claim', and under 'off' none needs a REF. The
 * AVISO, when a permit is configured, is required either way.
 */
export type RefPolicy = 'required' | 'if-health-claim';

/** The policy a draft was written under, read from its compliance stamp. Anything else is 'required'. */
export function refPolicyOf(pack: unknown): RefPolicy {
  const stamp = pack && typeof pack === 'object' ? (pack as { _compliance?: { refPolicy?: unknown } })._compliance : null;
  return stamp?.refPolicy === 'if-health-claim' ? 'if-health-claim' : 'required';
}

/**
 * Does this caption satisfy the rule? `expectedAviso` is the permit number the
 * post should carry (blank: the AVISO_PUBLICIDAD environment variable; blank
 * too: no notice is required at all). A present-but-different number is
 * reported as a mismatch (and counts as missing, because the wrong permit is
 * not compliance).
 *
 * `requireCitations` overrides REQUIRE_CITATIONS for this one call.
 */
export function checkCompliance(
  text: string,
  expectedAviso?: string | null,
  opts: { refPolicy?: RefPolicy; requireCitations?: CitationRequirement } = {},
): ComplianceCheck {
  const t = String(text || '');
  const missing: ('aviso' | 'ref' | 'doi')[] = [];
  const av = AVISO_RE.exec(t);
  const avisoFound = av ? av[1].toUpperCase() : null;
  const expected = (expectedAviso || '').trim().toUpperCase() || avisoNumberFor(null);
  // No permit configured: the notice is not part of the rule, so neither its
  // absence nor whatever number a pasted line carries is held against the post.
  const avisoMismatch = Boolean(expected && avisoFound && avisoFound !== expected);
  if (expected && (!avisoFound || avisoMismatch)) missing.push('aviso');
  const rf = REF_RE.exec(t);
  const ref = rf ? rf[2].trim() : null;
  const doi = ref ? (DOI_RE.exec(ref)?.[1] ?? null) : null;
  // A citation with no DOI is not a citation this app can stand behind. Only a DOI
  // reaches Crossref, so a plausible-looking reference without one was passing every
  // check while nothing had ever confirmed the study exists — the exact failure the
  // "never invent a citation" instruction is there to prevent, with no way to catch it.
  //
  // Waived only when the policy allows it AND the post makes no health claim —
  // decided on the text itself, every time, so a policy stamped on a draft can
  // never carry an uncited claim past this line. A REF that IS present is
  // checked as always (unless citations are switched off entirely).
  const mode = opts.requireCitations ?? citationRequirement();
  const claimOnly = mode === 'health-claims' || opts.refPolicy === 'if-health-claim';
  const refWaived = !ref && (mode === 'off' || (claimOnly && !makesHealthClaim(t)));
  if (!ref) { if (!refWaived) missing.push('ref'); }
  else if (!doi && mode !== 'off') missing.push('doi');
  return {
    ok: missing.length === 0, missing, avisoFound, avisoMismatch, ref, doi: doi ? doi.replace(/[.,;]+$/, '') : null,
    ...(refWaived ? { refWaived: true } : {}),
  };
}

/**
 * Add (or correct) the AVISO line. Idempotent: a correct line is left alone; a
 * wrong number is replaced; otherwise the line is appended after a blank line.
 * With no permit configured it is a no-op: the text comes back unchanged.
 * The REF line is never invented here — a citation has to come from a source.
 */
export function ensureAviso(text: string, avisoNumber?: string | null): string {
  const line = avisoLine(avisoNumber);
  if (!line) return String(text || '');
  const t = String(text || '').replace(/\s+$/, '');
  const m = AVISO_RE.exec(t);
  if (m) {
    if (m[1].toUpperCase() === line.slice('AVISO DE PUBLICIDAD: '.length)) return t;
    return t.replace(AVISO_RE, line);
  }
  return t ? t + '\n\n' + line : line;
}

/**
 * The text with its REF and AVISO lines removed — the post as a reader reads
 * it, for checks that are about what the POST says. A paper title in the REF
 * line ("…in patients diagnosed with…", "1.6 g/kg/day") is the study's
 * wording, not the brand's, and scanning it as copy flagged the citation the
 * rule requires.
 */
export function stripComplianceLines(text: string): string {
  return String(text || '')
    .split('\n')
    .filter((line) => !/^[ \t]*REF(?:ERENCIA)?[ \t]*[.:：]/i.test(line) && !/^[ \t]*AVISO\s+DE\s+PUBLICIDAD\b/i.test(line))
    .join('\n');
}

/** Sentence for a person, when a post is refused. */
export function complianceMessage(check: ComplianceCheck, networks?: readonly string[] | null): string {
  if (check.ok) return '';
  const parts: string[] = [];
  if (check.missing.includes('aviso')) {
    parts.push(check.avisoMismatch
      ? 'the AVISO DE PUBLICIDAD line carries a different permit number'
      : 'the AVISO DE PUBLICIDAD line is missing');
  }
  if (check.missing.includes('ref')) parts.push('the REF line citing a scientific study is missing');
  if (check.missing.includes('doi')) parts.push('the REF line has no DOI — it needs one like 10.1016/j.example.2024.01.001, which is what lets the citation be checked');
  // Name only what this deployment requires: a brand with no permit configured
  // is never told about an advertising notice it does not need.
  const wants = check.missing.includes('aviso') && (check.missing.includes('ref') || check.missing.includes('doi'))
    ? 'the advertising notice and a scientific reference'
    : check.missing.includes('aviso') ? 'the advertising notice' : 'a scientific reference';
  return complianceNetworksLabel(networks) + ' posts must carry ' + wants + ' \u2014 ' + parts.join(', and ') + '.';
}

/**
 * The instruction handed to the writer for a post under the "only when it
 * makes a health claim" policy: a logistics or destination post needs no
 * study, and must not reach for a health claim just to be able to cite one.
 */
const REF_IF_CLAIM_TEXT =
  ' Citations: if — and only if — the post makes a health claim (anything about' +
  ' the body, an outcome, a treatment or a condition), the "instagram" and "facebook" values MUST each end with a line that starts' +
  ' with "REF: " citing ONE real, peer-reviewed study that supports that claim, with its real DOI (checked against Crossref; never' +
  ' invent one). A post that makes no health claim (travel, logistics, events, the customer experience, products) needs no REF' +
  ' line — do not add a health claim just to have something to cite. Do NOT write an "AVISO DE PUBLICIDAD" line yourself; the app adds it when one is required.';

/**
 * The instruction handed to the writer for Instagram / Facebook copy when every
 * post must cite.
 *
 * It names those two because they are the two the writer is asked to compose
 * the citation FOR; the app copies the verified REF onto the other gated
 * channels itself (lib/ai.ts), which is why they are not listed here as
 * something to write separately — a second citation would need verifying a
 * second time.
 */
const REF_ALWAYS_TEXT =
  ' Citations: the "instagram" and "facebook" values MUST each end with' +
  ' a line that starts with "REF: " citing ONE real, peer-reviewed study that supports the post\'s main claim, in the form' +
  ' Author, A.B., et al. (Year). "Title." Journal, volume(issue), pages. DOI: 10.xxxx/xxxxx — only cite a study you are' +
  ' confident exists, and it MUST carry its real DOI, because the DOI is checked against Crossref and a citation without' +
  ' one is rejected; never invent a citation. The same citation also carries the LinkedIn, TikTok and blog-article versions' +
  ' of this post, so it has to support what all of them claim. Put the REF line last, after the hashtags — the app moves it' +
  ' into its final position. Do NOT write an "AVISO DE PUBLICIDAD" line yourself; the app adds it when one is required.';

/** With citations switched off the writer is only told not to invent the compliance lines. */
const REF_OFF_TEXT =
  ' Do NOT write a "REF:" line or an "AVISO DE PUBLICIDAD" line yourself; the app adds any line that is required.';

/**
 * What the writer is told under each REQUIRE_CITATIONS setting. Fixed at load
 * (they are prompt constants); checkCompliance reads the setting per call.
 * REF_INSTRUCTION is the "required" policy's text, so under the default
 * 'health-claims' it is the same as REF_IF_CLAIM_INSTRUCTION.
 */
const LOAD_MODE = citationRequirement();
export const REF_IF_CLAIM_INSTRUCTION = LOAD_MODE === 'off' ? REF_OFF_TEXT : REF_IF_CLAIM_TEXT;
export const REF_INSTRUCTION = LOAD_MODE === 'off' ? REF_OFF_TEXT : LOAD_MODE === 'always' ? REF_ALWAYS_TEXT : REF_IF_CLAIM_TEXT;

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { isStrategySlot, pillarForName, strategyBrand, strategyPositioning, strategyTopicPrompt, promotionFlags, SOFT_CTA_RE } from './strategy-voice.ts';

/** Offer names for the checks that need them; the template ships with none. */
const SERVICES = { services: ['Premium Plan', 'Studio Session', 'Gift Box'] };

test('only seeded slots use the strategy voice', () => {
  assert.equal(isStrategySlot({ seeded: 'weekly-strategy' }), true);
  assert.equal(isStrategySlot({}), false);
  assert.equal(isStrategySlot(null), false);
});

test('template names map back to their pillar', () => {
  assert.equal(pillarForName('Practical tips')?.id, 'practical-tips');
  assert.equal(pillarForName('  community and VALUES ')?.id, 'community');
  assert.equal(pillarForName('Weekly article'), null);
});

test('the strategy brand drops the promotional guidelines but keeps name, voice, aviso and visual', () => {
  const b = strategyBrand<Record<string, unknown>>({ name: 'Acme', voice: 'warm', guidelines: 'Always include Book now', keywords: ['widgets'], aviso_publicidad: 'X1', visual: { a: 1 } });
  assert.equal(b.name, 'Acme');
  assert.equal(b.voice, 'warm');
  assert.equal(b.aviso_publicidad, 'X1');
  assert.deepEqual(b.visual, { a: 1 });
  assert.deepEqual(b.keywords, []);
  assert.doesNotMatch(String(b.guidelines), /Always include Book now/);
  assert.match(String(b.guidelines), /Educational/);
  // The positioning names the loaded brand, and nothing else.
  assert.match(String(b.mission), /^Acme shares practical, honest content/);
  assert.equal(b.mission, strategyPositioning('Acme'));
  assert.doesNotMatch(String(b.guidelines) + String(b.mission), /clinic|patient|canc[uú]n|cellular/i);
});

test('the brief names the pillar, the angle and the rule', () => {
  const p = strategyTopicPrompt({ angle: 'Why slowing down can be worth it', pillarName: 'Lessons and reflections', rule: 'R1' });
  assert.match(p, /weekly "Lessons and reflections" post/);
  assert.match(p, /slowing down/);
  assert.match(p, /STANDING RULE.*R1/);
});

test('promotional habits are caught; an offer named by the angle is allowed', () => {
  const pitch = 'Planning matters. See if you are a candidate for our drug-free Premium Plan. Schedule your free consultation. #PremiumPlan';
  const f = promotionFlags(pitch, 'weekly planning', SERVICES);
  for (const l of ['sales hook', 'candidate pitch', '"drug-free / surgery-free" selling point', 'offer hashtag', 'offer pitch']) assert.ok(f.includes(l), l);
  assert.equal(promotionFlags('A short plan saves time all week. Save this for Monday.', 'planning', SERVICES).length, 0);
  assert.ok(!promotionFlags('The Gift Box is one option.', 'What goes into the Gift Box', SERVICES).includes('offer pitch'));
});

test('the template ships with no named offers, so those checks are off until a brand adds its own', () => {
  const text = 'Our Premium Plan packages are available now. Premium Plan, Premium Plan, Premium Plan.';
  assert.deepEqual(promotionFlags(text, ''), []);
  assert.ok(promotionFlags(text, '', SERVICES).includes('service promotion'));
});

test('a gentle next step counts as a call to action', () => {
  assert.match('Save this for your next trip.', SOFT_CTA_RE);
  assert.match('Talk it through with your physician.', SOFT_CTA_RE);
  assert.match('Ask an expert before you start.', SOFT_CTA_RE);
});

test('named offers may be introduced, never sold', () => {
  assert.ok(promotionFlags('Our Studio Session and Gift Box packages make great presents.', 'gifts', SERVICES).includes('service promotion'));
  assert.ok(promotionFlags('Reserve your Studio Session today.', 'studio', SERVICES).includes('service promotion'));
  assert.deepEqual(
    promotionFlags('A good routine may involve planning, rest and, for some people, tools such as a Studio Session or a Gift Box.', 'Tools such as a Studio Session or a Gift Box', SERVICES),
    [],
  );
  const around = 'A Studio Session takes an hour. A Studio Session uses natural light. Many people ask about the Studio Session.';
  assert.ok(promotionFlags(around, 'photography', SERVICES).includes('post built around one service'));
});

test('a sales close is flagged; a weekly schedule is not', () => {
  assert.ok(promotionFlags('Planning matters. Book your visit today.', 'planning').includes('booking call to action'));
  assert.ok(promotionFlags('Questions? Contact us or DM us.', 'planning').includes('booking call to action'));
  assert.ok(promotionFlags('Love it? Shop now.', 'planning').includes('booking call to action'));
  assert.deepEqual(promotionFlags('Keep a steady weekly schedule, even on busy weeks.', 'planning'), []);
  assert.deepEqual(promotionFlags('Talk it through with your physician.', 'planning'), []);
});

test('invented customer testimonials are flagged', () => {
  assert.ok(promotionFlags('As one customer put it: "It changed my mornings."', 'routines').includes('invented testimonial'));
  assert.ok(promotionFlags('Our clients often tell us the checklist helps.', 'checklists').includes('invented testimonial'));
  assert.ok(promotionFlags('As one patient put it: "I slept like a baby."', 'sleep').includes('invented testimonial'));
  assert.deepEqual(promotionFlags('One customer may need three sessions while another needs one.', 'personal advice'), []);
});

test('the brand is described by what it does, never ranked above anyone else', () => {
  assert.ok(promotionFlags('We are the best company in town, far ahead of our competitors.', 'values').includes('superiority claim'));
  assert.ok(promotionFlags('Unlike other brands, we do it all.', 'values').includes('superiority claim'));
  assert.deepEqual(promotionFlags('We bake every loaf by hand before 6am and deliver within the city.', 'values'), []);
  assert.deepEqual(promotionFlags('A short walk is better than nothing.', 'tips'), [], 'nothing compared with anyone else in the sentence');
  assert.deepEqual(promotionFlags('We are not better than every other company; we do a few specific things well.', 'values'), []);
});

test('identical outcomes are flagged; "not everyone will" is the point', () => {
  assert.ok(promotionFlags('Everyone who follows this will feel ten years younger.', 'tips').includes('outcome promise'));
  assert.ok(promotionFlags('This approach reverses aging.', 'tips').includes('outcome promise'));
  assert.ok(promotionFlags('A 90% success rate.', 'tips').includes('outcome promise'));
  assert.ok(promotionFlags('Every customer will get the same result.', 'tips').includes('outcome promise'));
  assert.deepEqual(promotionFlags('Not everyone will respond the same way, which is why plans differ.', 'tips'), []);
});

test('a seeded slot finds its pillar by key, even after a rename', async () => {
  const { pillarForStrategy } = await import('./strategy-voice.ts');
  assert.equal(pillarForStrategy({ pillarId: 'quick-tips' }, 'Tips and quick wins (Tuesday AM)')?.id, 'quick-tips');
  assert.equal(pillarForStrategy({ slot: 'sun-2' }, 'Whatever')?.id, 'community-stories');
  assert.equal(pillarForStrategy({}, 'Practical tips')?.id, 'practical-tips', 'legacy rows fall back to the name');
  assert.equal(pillarForStrategy({ slot: 'mon-blog' }, 'Weekly article'), null);
});

test('the supporting phrase is on the angle, never a sales search', async () => {
  const { pickSupportingPhrase } = await import('./strategy-voice.ts');
  const angle = 'Easy ways to save time this week';
  assert.equal(pickSupportingPhrase(angle, 'Practical tips', [
    { keyword: 'cheap time saving gadgets', intents: ['informational'] },
    { keyword: 'best time management app', intents: ['commercial'] },
    { keyword: 'easy ways to save time at home', intents: ['informational'] },
  ]), 'easy ways to save time at home');
  assert.equal(pickSupportingPhrase(angle, 'Practical tips', [{ keyword: 'buy time saving tools near me', intents: [] }]), undefined, 'a shopping search is never offered');
  assert.equal(pickSupportingPhrase(angle, 'Practical tips', [{ keyword: 'knee replacement recovery', intents: [] }]), undefined, 'off the subject');
  assert.equal(pickSupportingPhrase('A trend worth watching this year', 'Industry news and insights', [{ keyword: 'industry trends this year', intents: ['informational'] }]), 'industry trends this year');
});

test('the brief carries the day theme, both pillars of a shared slot, and the FAQ where it is woven in', () => {
  const p = strategyTopicPrompt({
    angle: 'A step-by-step guide to getting started',
    pillarName: 'How-to guides',
    dayTheme: 'Teach something useful',
    integrated: ['FAQ and myth-busting'],
  });
  assert.match(p, /day's theme is "Teach something useful"/);
  assert.match(p, /connect the angle to "FAQ and myth-busting"/);
  const sun = strategyTopicPrompt({ angle: 'How our community has shaped what we do', pillarName: 'Community spotlight', alsoCovers: ['Customer stories', 'Community and values'] });
  assert.match(sun, /counts for both "Customer stories" and "Community and values" in the brand's weekly mix/);
});

test('"Balanced" names every kind of content the example strategy mixes', async () => {
  const { EDITORIAL_DIRECTION } = await import('./strategy-voice.ts');
  assert.match(EDITORIAL_DIRECTION, /Balanced: teaching supported by everyday tips, behind-the-scenes, stories and community content — not only what the brand sells\./);
  assert.doesNotMatch(EDITORIAL_DIRECTION, /clinic|patient|medical/i);
});

test('the brief names what related slots already cover this week', () => {
  const p = strategyTopicPrompt({ angle: 'A two-minute tip that saves time', pillarName: 'Tips and quick wins', coveredThisWeek: ['Easy ways to save time this week'] });
  assert.match(p, /Related posts this week cover: "Easy ways to save time this week"\. Build on them/);
});

test('superiority in softer words is still superiority, in a sentence about the competition', () => {
  assert.ok(promotionFlags('For gifts, we are the ideal alternative to big-box stores.', 'gifts').includes('superiority claim'));
  assert.ok(promotionFlags('Our competitors cannot match our world-class, unbeatable service.', 'values').includes('superiority claim'));
  assert.deepEqual(promotionFlags('An ideal breakfast has protein in it.', 'tips'), [], 'not a sentence about anyone else');
});

test('named offers are never compared', () => {
  assert.ok(promotionFlags('The Premium Plan is more effective than the Studio Session for beginners.', 'plans', SERVICES).includes('service comparison'));
  assert.deepEqual(promotionFlags('Some people start with a Studio Session, others with a Gift Box, depending on what they need.', 'Tools such as a Studio Session or a Gift Box', SERVICES), []);
});

test('a universal prescription is the opposite of personal advice', () => {
  assert.ok(promotionFlags('Everyone should buy two of these.', 'tips').includes('universal prescription'));
  assert.ok(promotionFlags('This routine works for everyone.', 'tips').includes('universal prescription'));
  assert.deepEqual(promotionFlags('Everyone should talk to an expert before starting.', 'tips'), []);
  assert.deepEqual(promotionFlags('There is no one-size-fits-all plan.', 'tips'), [], 'negated');
});

test('related posts are built on, and the integrated example varies by week', () => {
  const a = strategyTopicPrompt({ angle: 'x', pillarName: 'How-to guides', integrated: ['FAQ and myth-busting'], coveredThisWeek: ['y'], variant: 0 });
  const b = strategyTopicPrompt({ angle: 'x', pillarName: 'How-to guides', integrated: ['FAQ and myth-busting'], variant: 1 });
  assert.match(a, /Build on them from a different point/);
  assert.notEqual(a.match(/for example, ([^.]+)/)?.[1], b.match(/for example, ([^.]+)/)?.[1]);
});

test('Phase 3: the dealt format, reader and closing reach the writer, and a returning angle is told its old opening', () => {
  const p = strategyTopicPrompt({
    angle: 'A lesson we learned the hard way',
    pillarName: 'Lessons and reflections',
    formatBrief: 'Shape: myth vs fact — open with a common belief.',
    audienceBrief: 'an existing customer getting more out of what they have',
    closingBrief: 'Close with one short question back to the reader.',
    previousOpening: 'Fast is not the same as finished.',
  });
  assert.match(p, /Write it for an existing customer getting more out of what they have — speak to their situation, and make no assumptions about their circumstances or their results\./);
  assert.match(p, /Shape: myth vs fact/);
  assert.match(p, /For this post: Close with one short question back to the reader\./);
  assert.match(p, /published before, opening with: "Fast is not the same as finished\."/);
  assert.match(p, /do not reuse that opening/);
  // The closing comes after the no-promotion rules, so it is the last word on how to end.
  assert.ok(p.indexOf('For this post:') > p.indexOf('Shape:'));
});

test('Phase 3: without a deal the prompt is unchanged', () => {
  const p = strategyTopicPrompt({ angle: 'A lesson we learned the hard way', pillarName: 'Lessons and reflections' });
  assert.doesNotMatch(p, /Write it for|For this post:|published before/);
});

test('Phase 3: the new gentle closings count as a soft next step', () => {
  for (const s of ['What does your Monday look like?', 'How do you plan your week?', 'Try this tonight.', 'Try it this week.']) {
    assert.match(s, SOFT_CTA_RE, s);
  }
});

test('Phase 3: myth vs fact — the stated myth is not an outcome promise, the post\'s own promise still is', () => {
  assert.ok(!promotionFlags('Myth: everyone will respond the same way.\nFact: every situation is different.').includes('outcome promise'));
  assert.ok(promotionFlags('Everyone will respond the same way.').includes('outcome promise'));
});

test('Phase 3: an everyday scenario may not end in a result', () => {
  assert.ok(promotionFlags('Picture someone who started walking after dinner and felt so much better within a week.').includes('scenario outcome'));
  assert.ok(!promotionFlags('Picture someone who started walking after dinner. A short walk can be a calm end to the day.').includes('scenario outcome'));
  assert.ok(!promotionFlags('Someone who rests well is not guaranteed to feel better.').includes('scenario outcome'));
  assert.ok(!promotionFlags('Someone who got better sleep by dimming the lights still has busy mornings.').includes('scenario outcome'), 'better sleep is a habit, not a result');
  assert.ok(promotionFlags('Someone who tried it was pain-free in two weeks.').includes('scenario outcome'));
  assert.ok(promotionFlags('A customer who switched felt so much better within a week.').includes('scenario outcome'));
});

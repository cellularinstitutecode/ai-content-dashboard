// web/lib/schedule-clock.ts
// One clock for everything a person READS, to match lib/timezone.ts — the one
// clock for everything the app WRITES.
//
// The bug this exists to kill: the composer promised "times are in the
// schedule timezone" and the server honoured that, but every list on the screen
// rendered the same instant with toLocaleString(undefined, …) — the *browser's*
// timezone. A coordinator two zones west scheduled a post for 9:00 AM, and the
// queue and the calendar immediately told them it was 7:00 AM. Same post, three
// panels, two different answers.
//
// Client components cannot read SCHEDULE_TIMEZONE (it is a server variable), so
// the server stamps the resolved zone on <html data-schedule-tz> in the root
// layout and everything here reads it back. No new environment variable to set,
// and no way for the two clocks to drift apart.

import { wallClockInTz, zonedTimeToUtc, DEFAULT_TIMEZONE } from './timezone.ts';

/** Used only when nothing was stamped (tests, or a page outside the root layout). */
export const DEFAULT_SCHEDULE_TZ = DEFAULT_TIMEZONE;

/** The timezone every scheduled time in the UI is displayed in. */
export function scheduleTz(): string {
  if (typeof document !== 'undefined') {
    const stamped = document.documentElement.dataset.scheduleTz;
    if (stamped) return stamped;
  }
  return DEFAULT_SCHEDULE_TZ;
}

/** "New York" — the city, for a label a person reads, not the IANA string. */
export function scheduleTzLabel(tz: string = scheduleTz()): string {
  const city = tz.split('/').pop() || tz;
  return city.replace(/_/g, ' ');
}

function fmt(input: unknown, opts: Intl.DateTimeFormatOptions): string {
  try {
    const d = new Date(input as string);
    if (isNaN(d.getTime())) return String(input ?? '');
    return new Intl.DateTimeFormat(undefined, { ...opts, timeZone: scheduleTz() }).format(d);
  } catch {
    return String(input ?? '');
  }
}

/** "Sep 1, 9:00 AM" — a scheduled post in a list. */
export function fmtScheduleDateTime(input: unknown): string {
  return fmt(input, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

/** "Tue, Sep 1, 9:00 AM" — a slot that needs its weekday. */
export function fmtScheduleSlot(input: unknown): string {
  return fmt(input, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

/** "9:00 AM" — the time alone, for a calendar cell. 12-hour, as every clock on the site reads. */
export function fmtScheduleTime(input: unknown): string {
  return fmt(input, { hour: 'numeric', minute: '2-digit' });
}

/** "2026-09-01" in the schedule zone — the key a calendar grid buckets by. */
export function scheduleDateKey(input: unknown): string {
  try {
    const d = new Date(input as string);
    if (isNaN(d.getTime())) return '';
    // en-CA renders ISO-shaped YYYY-MM-DD, which is exactly the key shape.
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: scheduleTz(), year: 'numeric', month: '2-digit', day: '2-digit',
    }).format(d);
  } catch { return ''; }
}

/**
 * "YYYY-MM-DDTHH:MM" for a <input type="datetime-local">, `days` from now at
 * `hour` — computed on the SCHEDULE clock, not the browser's. A preset labelled
 * "Tomorrow 9 AM" pressed late in the evening from a browser in another zone
 * used to land on the wrong day.
 */
export function schedulePresetValue(days: number, hour: number, now: Date = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: scheduleTz(), year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(now);
  const get = (t: string) => parseInt(parts.find((p) => p.type === t)?.value || '0', 10);
  // Date arithmetic in UTC so the day roll cannot be shifted by the browser zone.
  const base = new Date(Date.UTC(get('year'), get('month') - 1, get('day') + days));
  const p = (n: number) => String(n).padStart(2, '0');
  return `${base.getUTCFullYear()}-${p(base.getUTCMonth() + 1)}-${p(base.getUTCDate())}T${p(hour)}:00`;
}

/**
 * The instant at which the schedule clock reads y-m-d hh:mm.
 *
 * The calendar used to build this with `new Date(day); setHours(9,0)` — the
 * BROWSER's 9 AM. From a browser two zones west that is 11 AM on the schedule
 * clock, so a post the calendar labelled "09:00" went out two hours late. Same two-pass, DST-safe conversion
 * the server schedules with (lib/timezone.ts), so both ends agree.
 */
export function isoAtScheduleWallClock(
  y: number, m: number, d: number, hh: number, mm: number
): string {
  return zonedTimeToUtc(y, m, d, hh, mm, scheduleTz()).toISOString();
}

/** What the schedule clock reads at a given instant. */
export function scheduleWallClock(input: unknown) {
  const at = new Date(input as string);
  return wallClockInTz(isNaN(at.getTime()) ? new Date() : at, scheduleTz());
}

/**
 * An instant as the value a `datetime-local` box shows on the schedule
 * clock: "YYYY-MM-DDTHH:mm" in the brand's zone, whatever the browser's is.
 */
export function scheduleInputValue(input: unknown): string {
  const w = scheduleWallClock(input);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${w.y}-${p(w.m)}-${p(w.d)}T${p(w.hh)}:${p(w.mm)}`;
}

/**
 * The instant a `datetime-local` value names ON THE SCHEDULE CLOCK.
 *
 * The composer used to send the box's raw string, which the server took as
 * brand wall clock — right only when the browser's clock and the brand's
 * agreed. From a UTC machine "14:18" went out as 2:18 PM schedule-clock time.
 */
export function scheduleInstantFromInput(value: string): string | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(String(value || '').trim());
  if (!m) return null;
  const iso = isoAtScheduleWallClock(Number(m[1]), Number(m[2]), Number(m[3]), Number(m[4]), Number(m[5]));
  return /^\d{4}-/.test(iso) ? iso : null;
}

// web/lib/brand-marks.ts
// The brand's logo as vector paths, so the card compositor can set it crisply
// at any size and in any palette colour, with no image file to load.
//
// Ships EMPTY: a fresh deployment has no logo, and every consumer draws
// nothing where a mark would go. To add yours, paste your logo's SVG path data
// (the `d` attribute of each <path>, filled even-odd) into `paths` and its
// viewBox into `viewBox`:
//   WORDMARK  — the name set as a logotype (wide, e.g. 7:1), bottom of each card
//   BRANDMARK — the symbol on its own (compact), top of each card and the
//               faint watermark behind it

export type BrandMark = { viewBox: string; paths: string[] };

/** The brand's wordmark (logotype). Empty until a brand adds its own. */
export const WORDMARK: BrandMark = {
  viewBox: '0 0 700 100',
  paths: [],
};

/** The brand's symbol. Empty until a brand adds its own. */
export const BRANDMARK: BrandMark = {
  viewBox: '0 0 200 100',
  paths: [],
};

/** True when a mark has something to draw. */
export function hasMark(mark: BrandMark | null | undefined): mark is BrandMark {
  return Boolean(mark && Array.isArray(mark.paths) && mark.paths.some((d) => typeof d === 'string' && d.trim()));
}

/** Width → height for a mark, from its viewBox (0 when the viewBox is unusable). */
export function markHeight(mark: BrandMark, width: number): number {
  const [, , vw, vh] = String(mark.viewBox || '').split(/[\s,]+/).map(Number);
  if (!(vw > 0) || !(vh > 0)) return 0;
  return Math.round((width * vh) / vw);
}

/** Inline SVG markup for a mark, for renderers that take HTML/SVG strings. '' when there is no mark. */
export function markSvg(mark: BrandMark, color: string, width: number): string {
  if (!hasMark(mark)) return '';
  return (
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${mark.viewBox}" width="${width}" height="${markHeight(mark, width)}">` +
    mark.paths.map((d) => `<path d="${d}" fill="${color}" fill-rule="evenodd"/>`).join('') +
    '</svg>'
  );
}

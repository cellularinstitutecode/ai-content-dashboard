// web/lib/content-strategy.ts
// The built-in EXAMPLE weekly content strategy, as data the engine can run.
//
// THIS IS A PLACEHOLDER. It is a brand-neutral starting point — eight generic
// content pillars, two posts a day, Monday to Sunday — for a new deployment to
// replace with its own. Rename the pillars, rewrite the angle banks and the
// day themes for your brand, or skip this file entirely and drop your own
// written strategy on the Templates page (lib/strategy-upload.ts turns any
// strategy document into slots the same way).
//
// The example is shaped like a real written strategy so every part of the
// engine has something to run on: 14 posts a week, two a day. "8 recurring
// content pillars", plus a frequency table of nine rows (FREQUENCY_PILLARS),
// fourteen day-page angle banks (PILLARS) and a day map that joins them (WEEK).
// Its governing rule is the one that makes a calendar worth following:
//
//   "The calendar repeats strategic content pillars, not identical posts.
//    Each time a pillar returns, the angle, question, format, or audience
//    should change."  —  "Repeat the content pillar, not the wording."
//
// WHY THIS FILE IS A LIST AND NOT AN ENGINE. The engine already exists.
// lib/autopilot.ts runs a template once per weekday and rotates its seed list by
// occurrence — `seedPool[occurrenceIndex % seedPool.length]`. A template pinned
// to ONE day therefore advances its list once a week. So the strategy is
// satisfied by giving each day's template that pillar's own ANGLES as its seed
// list: the pillar stays, the angle moves on, and the bank takes five or six
// weeks to come round.
//
// WHEN YOU EDIT IT. Keep the shape — fourteen slots, ids that match between
// WEEK, PILLARS and FREQUENCY_PILLARS, five angles in each Monday bank and six
// in the others (lib/strategy-rotation.ts deals each bank as a deck, and the
// weekly article draws from the four "educate" banks; see WEEKLY_MIX for the
// one place the example's two counts deliberately differ). The tests in
// content-strategy.test.ts and content-strategy.snapshot.test.ts pin the
// example word for word, so update them with it.
//
// Pure: no imports, so the test runner reads this file directly.

/** 0 = Sunday, as JavaScript counts and as `schedule_templates.weekdays` stores. */
export type Weekday = 0 | 1 | 2 | 3 | 4 | 5 | 6;

/**
 * The four groups the example's "recommended weekly mix" is counted in:
 * teaching (educate), everyday value (everyday), social proof (proof) and
 * community (connect).
 */
export type MixGroup = 'educate' | 'everyday' | 'proof' | 'connect';

export type Pillar = {
  id: string;
  /** The pillar's name, as the strategy's day pages head it. */
  name: string;
  group: MixGroup;
  /**
   * The angles the strategy lists for this pillar.
   *
   * This is the seed list a template rotates through — one per week — so the
   * ORDER is the order they were written in, and the LENGTH is how many weeks
   * pass before the pillar returns to its first angle.
   */
  angles: string[];
};

/** How a slot relates to a row of the frequency table. */
export type SlotTag = {
  freqId: string;
  /**
   * 'primary': the slot IS this pillar's post that day. 'integrated': the
   * pillar is woven into the slot without being its subject — the table's
   * "FAQ … also integrated into education content".
   */
  role: 'primary' | 'integrated';
};

export type Slot = {
  day: Weekday;
  /** 1 or 2 — "Post 1" and "Post 2" as the strategy numbers them. */
  post: 1 | 2;
  /** The day page's angle bank this slot rotates (PILLARS). */
  pillarId: string;
  /** The slot's name in the day map, which is not always its day-page heading. */
  mapName: string;
  /** The frequency-table rows this slot counts towards. */
  tags: SlotTag[];
};

/**
 * The example's two standing notes, as writer rules. Generic on purpose —
 * replace them with your own, or leave a row's `rule` out for none.
 */
export const STORIES_RULE =
  'Only tell a real person\'s story with their permission, and never invent a customer, a quote, a review or a result. ' +
  'Without a real, approved story, write about the situation and the approach rather than about an individual.';

export const COMMUNITY_RULE =
  'Never claim the brand is categorically better than anyone else, and do not criticise competitors. ' +
  'Write about specific, checkable things instead: what the brand does, how it does it, and who it does it for.';

/** Whether a post in this pillar must carry a REF citation (see lib/compliance.ts). */
export type CitationPolicy = 'required' | 'if-health-claim';

export type FrequencyPillar = {
  id: string;
  /** The table's own words, for all three columns. */
  name: string;
  days: string;
  frequency: string;
  group: MixGroup;
  /**
   * Whether this row's posts cite a study. The example asks for one only when
   * a post makes a health claim — most brands' posts make none. A brand that
   * teaches health can set 'required' on the rows that do.
   */
  citation: CitationPolicy;
  /** A standing note that governs every slot counted towards this row. */
  rule?: string;
};

/** The example's frequency table, row for row. */
export const FREQUENCY_PILLARS: FrequencyPillar[] = [
  { id: 'education', name: 'Education and how-to', days: 'Monday and Thursday', frequency: '2x weekly', group: 'educate', citation: 'if-health-claim' },
  { id: 'spotlight', name: 'Product or service spotlight', days: 'Monday and Friday', frequency: '2x weekly', group: 'educate', citation: 'if-health-claim' },
  { id: 'tips', name: 'Tips and quick wins', days: 'Tuesday and Saturday', frequency: '2x weekly', group: 'everyday', citation: 'if-health-claim' },
  { id: 'industry', name: 'Industry news and insights', days: 'Tuesday', frequency: '1x weekly', group: 'everyday', citation: 'if-health-claim' },
  { id: 'behind-the-scenes', name: 'Behind the scenes', days: 'Wednesday and Saturday', frequency: '2x weekly', group: 'everyday', citation: 'if-health-claim' },
  { id: 'inspiration', name: 'Ideas and inspiration', days: 'Wednesday and Sunday', frequency: '2x weekly', group: 'everyday', citation: 'if-health-claim' },
  { id: 'customer-stories', name: 'Customer stories', days: 'Friday and Sunday', frequency: '2x weekly', group: 'proof', citation: 'if-health-claim', rule: STORIES_RULE },
  { id: 'community', name: 'Community and values', days: 'Thursday and Sunday', frequency: '2x weekly', group: 'connect', citation: 'if-health-claim', rule: COMMUNITY_RULE },
  { id: 'faq', name: 'FAQ and myth-busting', days: 'Primarily Friday; also integrated into education content', frequency: '1-2x weekly', group: 'educate', citation: 'if-health-claim' },
];

/** Each day page's subtitle — the theme the day's two posts share. 0 = Sunday. */
export const DAY_THEMES: Record<Weekday, string> = {
  1: 'Teach something useful',
  2: 'Quick wins and what is new',
  3: 'Show how it is made',
  4: 'Learn and connect',
  5: 'Questions, answered',
  6: 'Ideas for the weekend',
  0: 'Stories and community',
};

export const PILLARS: Pillar[] = [
  {
    id: 'how-to',
    name: 'How-to guides',
    group: 'educate',
    angles: [
      'A step-by-step guide to getting started',
      'The mistake beginners make most often, and how to avoid it',
      'How to choose the right option for your situation',
      'What to know before you begin',
      'A simple checklist for getting it right the first time',
    ],
  },
  {
    id: 'spotlight',
    name: 'Product or service spotlight',
    group: 'educate',
    angles: [
      'One detail most people overlook',
      'Who this is for, and who it is not for',
      'How it works, explained in plain words',
      'What goes into making it',
      'How to get the most value from it',
    ],
  },
  {
    id: 'quick-tips',
    name: 'Tips and quick wins',
    group: 'everyday',
    angles: [
      'A two-minute tip that saves time',
      'Three small habits that make a big difference',
      'A shortcut our team uses every day',
      'A common problem and a quick fix',
      'How to do more with what you already have',
      'One thing to stop doing this week',
    ],
  },
  {
    id: 'industry-news',
    name: 'Industry news and insights',
    group: 'everyday',
    angles: [
      'A recent change in our industry and what it means for you',
      'A trend worth watching this year',
      'What the latest numbers say, in plain words',
      'A question everyone in our field is asking right now',
      'How the way people shop for this has changed',
      'An overlooked idea from a recent report or event',
    ],
  },
  {
    id: 'behind-the-scenes',
    name: 'Behind the scenes',
    group: 'everyday',
    angles: [
      'A day in the life of our team',
      'How an idea becomes something we offer',
      'The tools we rely on, and why',
      'Meet someone on the team',
      'What a busy week looks like from the inside',
      'A mistake we made and what we changed',
    ],
  },
  {
    id: 'inspiration',
    name: 'Ideas and inspiration',
    group: 'everyday',
    angles: [
      'An idea to try this season',
      'Small ways to make an ordinary day better',
      'Where our team finds inspiration',
      'A creative use for something you already own',
      'A goal worth setting this month',
      'A book, podcast or idea that changed how we think',
    ],
  },
  {
    id: 'getting-started',
    name: 'Getting started',
    group: 'educate',
    angles: [
      'Where to begin if you are completely new to this',
      'The terms worth knowing, explained simply',
      'How to tell whether you are on the right track',
      'Questions to ask before you decide',
      'How to compare your options fairly',
      'What realistic progress looks like',
    ],
  },
  {
    id: 'community',
    name: 'Community and values',
    group: 'connect',
    angles: [
      'What we stand for, and why it matters to us',
      'A local cause or partner we support',
      'How we try to do business responsibly',
      'Thank you to the people who make this possible',
      'A conversation we want to start with our community',
      'The story of how we started',
    ],
  },
  {
    id: 'faq',
    name: 'FAQ and myth-busting',
    group: 'educate',
    angles: [
      'The question we hear most often, answered',
      'A common myth, and what is actually true',
      'What to expect when you work with us',
      'How long it really takes, and why',
      'Why the right choice depends on your needs',
      'How to look after it so it lasts',
    ],
  },
  {
    id: 'customer-stories',
    name: 'Customer stories',
    group: 'proof',
    angles: [
      'A common challenge people bring to us, and how we approach it',
      'Questions people ask before they decide to work with us',
      'How we handle it when something goes wrong',
      'Feedback that changed how we work',
      'What a great experience with us looks like',
      'How a small request became something we now offer everyone',
    ],
  },
  {
    id: 'process',
    name: 'How we work',
    group: 'everyday',
    angles: [
      'The steps behind a finished piece of work',
      'How we check quality before anything goes out',
      'Why we do it this way and not the quick way',
      'The part of the work nobody sees',
      'How our process has improved over time',
      'What we prepare before the week begins',
    ],
  },
  {
    id: 'practical-tips',
    name: 'Practical tips',
    group: 'everyday',
    angles: [
      'A weekend project worth trying',
      'How to make it last longer',
      'Easy ways to save time this week',
      'Common beginner mistakes and how to avoid them',
      'A simple routine that keeps things running smoothly',
      'What to keep on hand, and what you can skip',
    ],
  },
  {
    id: 'reflections',
    name: 'Lessons and reflections',
    group: 'everyday',
    angles: [
      'A lesson we learned the hard way',
      'What we would tell ourselves on day one',
      'Why slowing down can be worth it',
      'A small win worth celebrating this week',
      'What a good week looks like for us',
      'Something we changed our mind about',
    ],
  },
  {
    id: 'community-stories',
    name: 'Community spotlight',
    group: 'proof',
    angles: [
      'A customer or partner we are proud to work with',
      'How our community has shaped what we do',
      'An event or moment worth remembering',
      'People in our community doing great work',
      'A thank-you to someone who helped us grow',
      'How to get involved and connect with others',
    ],
  },
];

/**
 * The example's day map: two posts a day, Monday through Sunday.
 *
 * `tags` are the frequency table's rows. Two slots count towards two rows:
 * Friday's first post is both "Product or service spotlight — Monday and
 * Friday" and "FAQ and myth-busting — primarily Friday", and Sunday's second
 * is both "Customer stories — Friday and Sunday" and "Community and values —
 * Thursday and Sunday" (its day-map name is "Stories from the community").
 * Monday's how-to post carries the FAQ as 'integrated', the table's "also
 * integrated into education content".
 */
export const WEEK: Slot[] = [
  { day: 1, post: 1, pillarId: 'how-to', mapName: 'Education and how-to', tags: [{ freqId: 'education', role: 'primary' }, { freqId: 'faq', role: 'integrated' }] },
  { day: 1, post: 2, pillarId: 'spotlight', mapName: 'Product or service spotlight', tags: [{ freqId: 'spotlight', role: 'primary' }] },
  { day: 2, post: 1, pillarId: 'quick-tips', mapName: 'Tips and quick wins', tags: [{ freqId: 'tips', role: 'primary' }] },
  { day: 2, post: 2, pillarId: 'industry-news', mapName: 'Industry news and insights', tags: [{ freqId: 'industry', role: 'primary' }] },
  { day: 3, post: 1, pillarId: 'behind-the-scenes', mapName: 'Behind the scenes', tags: [{ freqId: 'behind-the-scenes', role: 'primary' }] },
  { day: 3, post: 2, pillarId: 'inspiration', mapName: 'Ideas and inspiration', tags: [{ freqId: 'inspiration', role: 'primary' }] },
  { day: 4, post: 1, pillarId: 'getting-started', mapName: 'Getting started', tags: [{ freqId: 'education', role: 'primary' }] },
  { day: 4, post: 2, pillarId: 'community', mapName: 'Community and values', tags: [{ freqId: 'community', role: 'primary' }] },
  { day: 5, post: 1, pillarId: 'faq', mapName: 'FAQ about what we offer', tags: [{ freqId: 'spotlight', role: 'primary' }, { freqId: 'faq', role: 'primary' }] },
  { day: 5, post: 2, pillarId: 'customer-stories', mapName: 'Customer stories', tags: [{ freqId: 'customer-stories', role: 'primary' }] },
  { day: 6, post: 1, pillarId: 'process', mapName: 'Process and craft', tags: [{ freqId: 'behind-the-scenes', role: 'primary' }] },
  { day: 6, post: 2, pillarId: 'practical-tips', mapName: 'Practical tips', tags: [{ freqId: 'tips', role: 'primary' }] },
  { day: 0, post: 1, pillarId: 'reflections', mapName: 'Lessons and reflections', tags: [{ freqId: 'inspiration', role: 'primary' }] },
  { day: 0, post: 2, pillarId: 'community-stories', mapName: 'Stories from the community', tags: [{ freqId: 'customer-stories', role: 'primary' }, { freqId: 'community', role: 'primary' }] },
];

/**
 * The example's recommended weekly mix — 5 educate, 5 everyday, 2 proof,
 * 2 connect — recorded as what it is: a RECOMMENDATION, counted in posts.
 *
 * Counted the way the frequency table counts (mixByPillarDays: every primary
 * row a slot belongs to, so sixteen pillar-days over fourteen slots), the day
 * map gives educate 5, proof 2 and connect 2 — exactly the recommendation —
 * and everyday 7: Saturday's two posts, "How we work" and "Practical tips",
 * are the extra ones. The example keeps that difference on purpose, so the
 * planner shows how a recommendation and a day map can disagree; when you
 * write your own strategy, decide which one to follow. The test asserts both
 * numbers so a change to either is deliberate.
 */
export const WEEKLY_MIX: Record<MixGroup, number> = {
  educate: 5,
  everyday: 5,
  proof: 2,
  connect: 2,
};

const DAY_KEYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'] as const;

/**
 * A slot's stable identity: 'mon-1' … 'sun-2'.
 *
 * Stored on every seeded template (`strategy.slot`) so the seed, the brief and
 * the planner picture can find a slot's pillar without going through its NAME.
 * Names are the one thing a person is free to change, and matching on them
 * meant a renamed "Practical tips" was duplicated by the next "Load the weekly
 * strategy" and lost its pillar in the brief and the picture.
 */
export function slotKey(slot: Pick<Slot, 'day' | 'post'>): string {
  return DAY_KEYS[slot.day] + '-' + slot.post;
}

/** The weekly article's key. It is not one of the strategy's fourteen. */
export const BLOG_SLOT_KEY = 'mon-blog';

/** The slot a key names, or null (the article's key names no strategy slot). */
export function slotByKey(key: unknown): Slot | null {
  const k = String(key || '').trim().toLowerCase();
  return WEEK.find((s) => slotKey(s) === k) ?? null;
}

/** Every slot, in the order the week runs — Monday first, as the strategy reads. */
export const WEEK_ORDER: Weekday[] = [1, 2, 3, 4, 5, 6, 0];

/** The times the two daily slots default to, clear of the video pipeline's 13:00 / 17:00. */
export const SLOT_TIMES: Record<1 | 2, string> = { 1: '09:00', 2: '18:00' };

export function pillarById(id: string): Pillar | null {
  return PILLARS.find((p) => p.id === id) ?? null;
}

/**
 * The days a day-page angle bank is scheduled on, from the day map. Each bank
 * is one slot, so this is one day; for the frequency table's rows, which span
 * two, see frequencyDays.
 */
export function daysFor(pillarId: string): Weekday[] {
  return WEEK.filter((s) => s.pillarId === pillarId).map((s) => s.day);
}

export function frequencyPillarById(id: string): FrequencyPillar | null {
  return FREQUENCY_PILLARS.find((f) => f.id === id) ?? null;
}

/** The days a frequency-table row covers, derived from the day map. */
export function frequencyDays(freqId: string, roles: readonly SlotTag['role'][] = ['primary', 'integrated']): Weekday[] {
  const out: Weekday[] = [];
  for (const s of WEEK) {
    if (s.tags.some((t) => t.freqId === freqId && roles.includes(t.role)) && !out.includes(s.day)) out.push(s.day);
  }
  return out;
}

/** The week counted the frequency table's way: each primary row a slot belongs to. */
export function mixByPillarDays(): Record<MixGroup, number> {
  const out: Record<MixGroup, number> = { educate: 0, everyday: 0, proof: 0, connect: 0 };
  for (const s of WEEK) {
    for (const t of s.tags) {
      if (t.role !== 'primary') continue;
      const f = frequencyPillarById(t.freqId);
      if (f) out[f.group] += 1;
    }
  }
  return out;
}

/**
 * Every standing rule that governs a slot: the rules of every frequency row it
 * counts towards. So Sunday's "Community spotlight" carries BOTH the
 * customer-stories note and the community note.
 */
export function rulesForSlot(key: string): string {
  const slot = slotByKey(key);
  if (!slot) return '';
  const rules: string[] = [];
  for (const t of slot.tags) {
    const r = frequencyPillarById(t.freqId)?.rule;
    if (r && !rules.includes(r)) rules.push(r);
  }
  return rules.join(' ');
}

/**
 * The weekly article's citation policy. It has no frequency row of its own, so
 * it is set here: like the example's rows, a study only when the article makes
 * a health claim. A brand whose articles teach health can set 'required'.
 */
export const ARTICLE_CITATION: CitationPolicy = 'if-health-claim';

/**
 * 'if-health-claim' when a row the slot is primarily about allows it; the
 * article follows ARTICLE_CITATION; anything unknown is 'required'.
 */
export function citationPolicyForSlot(key: string): CitationPolicy {
  if (String(key || '').trim().toLowerCase() === BLOG_SLOT_KEY) return ARTICLE_CITATION;
  const slot = slotByKey(key);
  if (!slot) return 'required';
  return slot.tags.some((t) => t.role === 'primary' && frequencyPillarById(t.freqId)?.citation === 'if-health-claim')
    ? 'if-health-claim'
    : 'required';
}

/**
 * What the writer is told about a slot beyond its angle: the day's theme, the
 * rows it counts as when there are two, and a pillar woven into it.
 */
export function slotContext(key: string): { dayTheme: string; alsoCovers: string[]; integrated: string[] } | null {
  const slot = slotByKey(key);
  if (!slot) return null;
  const primary = slot.tags.filter((t) => t.role === 'primary').map((t) => frequencyPillarById(t.freqId)?.name || '').filter(Boolean);
  return {
    dayTheme: DAY_THEMES[slot.day],
    alsoCovers: primary.length > 1 ? primary : [],
    integrated: slot.tags.filter((t) => t.role === 'integrated').map((t) => frequencyPillarById(t.freqId)?.name || '').filter(Boolean),
  };
}

/** How many posts a week this calendar holds. The cadence everything else is sized against. */
export const POSTS_PER_WEEK = WEEK.length;

export type PlannedTemplate = {
  name: string;
  weekdays: Weekday[];
  time_of_day: string;
  /** The angle bank the engine rotates through, one per week. */
  pillars: string[];
  rule: string;
  pillarId: string;
  /** slotKey() — the identity the seed matches on. */
  slot: string;
};

/**
 * The 14 templates this strategy becomes.
 *
 * One per slot, each pinned to a SINGLE day, because that is what makes the
 * rotation weekly: lib/autopilot.ts advances the seed list once per occurrence,
 * and a one-day template occurs once a week. A seven-day template would advance
 * it daily and the pillars would drift off their days within a week.
 */
export function plannedTemplates(): PlannedTemplate[] {
  return WEEK.map((slot) => {
    const pillar = pillarById(slot.pillarId);
    if (!pillar) throw new Error('content-strategy: no pillar for slot ' + slot.pillarId);
    return {
      name: pillar.name,
      weekdays: [slot.day],
      time_of_day: SLOT_TIMES[slot.post],
      pillars: pillar.angles.slice(),
      rule: rulesForSlot(slotKey(slot)),
      pillarId: pillar.id,
      slot: slotKey(slot),
    };
  });
}

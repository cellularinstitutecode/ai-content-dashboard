import test from 'node:test';
import assert from 'node:assert/strict';
import { METRICOOL_BLOG_ID, METRICOOL_USER_ID, metricoolPlannerUrl } from './metricool-links.ts';

test('every planner link carries BOTH ids', () => {
  // The whole point of this module. Metricool resolves a brand only inside a
  // user, so a link with blogId alone opens its "there was an error that
  // prevented loading the page" — which is what happened, and what a second
  // copy of this URL somewhere else would bring back.
  const u = new URL(metricoolPlannerUrl('1234567', '7654321'));
  assert.equal(u.searchParams.get('blogId'), '1234567');
  assert.equal(u.searchParams.get('userId'), '7654321');
});

test('it is the planner calendar on Metricool, over https', () => {
  const u = new URL(metricoolPlannerUrl());
  assert.equal(u.protocol, 'https:');
  assert.equal(u.host, 'app.metricool.com');
  assert.equal(u.pathname, '/planner/calendar');
});

test('the default ids come from the environment, never a built-in account', () => {
  assert.equal(METRICOOL_BLOG_ID, String(process.env.NEXT_PUBLIC_METRICOOL_BLOG_ID || '').trim());
  assert.equal(METRICOOL_USER_ID, String(process.env.NEXT_PUBLIC_METRICOOL_USER_ID || '').trim());
});

test('an empty or blank brand falls back to the configured default, and is omitted when there is none', () => {
  for (const bad of ['', '   ', null, undefined]) {
    const u = new URL(metricoolPlannerUrl(bad as string));
    assert.equal(u.searchParams.get('blogId'), METRICOOL_BLOG_ID || null);
    assert.ok(!/blogId=(&|$)/.test(u.search), 'never an empty blogId= parameter');
  }
});

test('with no ids configured at all it is still a valid planner URL with no empty params', () => {
  if (METRICOOL_BLOG_ID || METRICOOL_USER_ID) return; // only meaningful on a blank deployment
  assert.equal(metricoolPlannerUrl(), 'https://app.metricool.com/planner/calendar');
  assert.equal(metricoolPlannerUrl('1234567'), 'https://app.metricool.com/planner/calendar?blogId=1234567');
});

test('a brand id is encoded, not interpolated raw', () => {
  const u = new URL(metricoolPlannerUrl('a b&c=d', '7654321'));
  assert.equal(u.searchParams.get('blogId'), 'a b&c=d');
  assert.equal(u.searchParams.get('userId'), '7654321');
});

// web/lib/citation-from-evidence.ts
// A REF line built from a paper that actually exists.
//
// THE PROBLEM. A post that must cite (lib/compliance.ts) carries a REF line with
// a DOI, and the writer was asked for one only on the Instagram and Facebook
// variants. When it produced none — or produced a citation with no DOI — the
// row was prepared anyway and the post was refused at the door, with nothing
// to do but write a citation by hand.
//
// THE THING THAT MAKES THIS SAFE. The pipeline ALREADY searches PubMed for
// real papers on the video's subject (lib/evidence.ts findEvidence) and hands
// them to the writer as background. Those items carry a title, a journal, a
// year, a first author and a DOI, straight from PubMed. They were then thrown
// away. So nothing here invents a citation: it uses a paper that was already
// found, and the caller verifies the DOI against Crossref before it is used.
//
// If no paper was found, this returns null and the post is refused exactly as
// it is today. A missing citation is a problem; a fabricated one on a medical
// advertisement is a different and much worse thing, and no amount of
// convenience is worth it.
//
// Pure: `./x.ts` imports only, so the test runner reads this file directly.
import type { EvidenceItem } from './evidence-parse.ts';

/** A DOI as it really looks. The same shape lib/compliance.ts accepts. */
const DOI_RE = /^10\.\d{4,9}\/\S+$/;

/** Is this item usable as a citation — a real paper with a real DOI? */
export function citable(item: EvidenceItem | null | undefined): boolean {
  if (!item) return false;
  const doi = String(item.doi || '').trim();
  return DOI_RE.test(doi) && Boolean(String(item.title || '').trim());
}

/**
 * The best paper to cite from what the search found.
 *
 * RELEVANCE ORDER IS KEPT. lib/evidence.ts queries PubMed with
 * `sort=relevance`, so the list arrives best-match first — and an earlier
 * version of this function re-sorted it by year, which threw that away: a
 * newer but less relevant paper displaced the one PubMed had judged the best
 * match for the subject. On a medical advertisement the citation being ABOUT
 * the claim matters more than it being recent.
 *
 * So: the first citable item, in the order the search returned it.
 */
export function pickCitation(items: readonly EvidenceItem[] | null | undefined): EvidenceItem | null {
  return (items || []).find(citable) ?? null;
}

/**
 * The REF line for a paper: author, year, title, journal, DOI.
 *
 * Shaped to pass lib/compliance.ts's check — a "REF:" label, more than sixteen
 * characters, and a DOI it can find — because a citation this app writes and
 * its own gate then refuses would be worse than useless.
 */
export function refLineFrom(item: EvidenceItem): string {
  const author = String(item.firstAuthor || '').trim();
  const year = Number(item.year) || null;
  const title = String(item.title || '').trim().replace(/\s+/g, ' ').replace(/\.*$/, '');
  const journal = String(item.journal || '').trim();
  const doi = String(item.doi || '').trim();

  const parts: string[] = [];
  if (author) parts.push(year ? author + ' et al. (' + year + ').' : author + '.');
  else if (year) parts.push('(' + year + ').');
  if (title) parts.push(title + '.');
  if (journal) parts.push(journal + '.');
  parts.push('DOI: ' + doi);
  return 'REF: ' + parts.join(' ');
}

/** The REF line for the best paper found, or null when nothing is citable. */
export function refLineFromEvidence(items: readonly EvidenceItem[] | null | undefined): string | null {
  const best = pickCitation(items);
  return best ? refLineFrom(best) : null;
}

// Server-only Metricool client.
// Docs: https://app.metricool.com/resources/apidocs/index.html
// Base: https://app.metricool.com/api  |  Auth header: X-Mc-Auth: <userToken>

import { formatForMetricool, SCHEDULE_TZ } from '@/lib/timezone';
import { modeFlags, replacePostBody, type PostMode, type ReplacePostInput } from '@/lib/metricool-post';
import type { YoutubeData } from '@/lib/youtube-meta';
import type { TiktokData } from '@/lib/tiktok-meta';
import { recordProviderOutcome } from '@/lib/provider-status';
import { readNormalizedUrl } from '@/lib/metricool-normalize-parse';
import { metricoolNetworks, type McNetwork } from '@/lib/metricool-networks';
export { modeFlags, replacePostBody, type PostMode, type ReplacePostInput };
export { metricoolNetworks };

/**
 * The networks this client posts to.
 *
 * Derived from lib/metricool-networks.ts rather than written out again, so the
 * LIST that filters a template's channels and the TYPE that describes them
 * cannot drift apart. That file is pure, which is what lets the filter be
 * tested — this one reaches half the app through `@/` aliases.
 */
export type Provider = McNetwork;

export interface SchedulePostInput {
  text: string;
  providers: Provider[];
  // UTC instant (ISO string); converted to the schedule timezone's wall clock
  // for the Metricool API automatically.
  publicationDate: string;
  firstCommentText?: string;
  media?: { url: string }[];
  /** YouTube's own fields — title, Short-or-video, visibility, audience. */
  youtubeData?: YoutubeData | null;
  /** TikTok's own settings (public, comments/duet/stitch on). lib/tiktok-meta.ts. */
  tiktokData?: TiktokData | null;
}

// Overridable so the end-to-end harness can point the client at a local mock.
// Production never sets it; app.metricool.com is the default.
export function apiBase(): string {
  return (process.env.METRICOOL_API_BASE || 'https://app.metricool.com/api').replace(/\/+$/, '');
}

function env() {
  const token = process.env.METRICOOL_USER_TOKEN;
  const blogId = process.env.METRICOOL_BLOG_ID;
  const userId = process.env.METRICOOL_USER_ID;
  if (!token || !blogId || !userId) {
    throw new Error('Metricool env vars missing (METRICOOL_USER_TOKEN/BLOG_ID/USER_ID)');
  }
  return { token, blogId, userId };
}

/** True when the three Metricool credentials are present. */
export function metricoolConfigured(): boolean {
  return Boolean(
    process.env.METRICOOL_USER_TOKEN &&
    process.env.METRICOOL_BLOG_ID &&
    process.env.METRICOOL_USER_ID
  );
}

// Every call is bounded. Without this a slow upstream held the whole serverless
// function until the platform killed it, which returns a bodyless 504 the UI
// cannot explain — see the schedule/insights routes.
const DEFAULT_TIMEOUT_MS = 15_000;

export async function metricoolFetch(
  path: string,
  /** `blogId` names the brand for this one call; unset, the configured brand. */
  init: RequestInit & { timeoutMs?: number; blogId?: string | null } = {},
): Promise<Response> {
  const { token, blogId, userId } = env();
  const url = new URL(apiBase() + path);
  url.searchParams.set('blogId', String(init.blogId || '').trim() || blogId);
  url.searchParams.set('userId', userId);

  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), init.timeoutMs ?? DEFAULT_TIMEOUT_MS);
  try {
    return await fetch(url.toString(), {
      ...init,
      signal: ctl.signal,
      headers: { 'Content-Type': 'application/json', 'X-Mc-Auth': token, ...(init.headers || {}) },
    });
  } catch (e) {
    if ((e as any)?.name === 'AbortError') {
      throw new Error('Metricool timed out after ' + ((init.timeoutMs ?? DEFAULT_TIMEOUT_MS) / 1000) + 's');
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Hand Metricool a media URL it will actually keep.
 *
 * THIS STEP WAS MISSING ENTIRELY, and it is why no post this app has ever sent
 * arrived with its picture or its video. Metricool does not attach a raw URL
 * from the `media` array: the URL has to be normalised first — the file is
 * pulled onto Metricool's own storage and a usable reference comes back — and
 * a post whose media was not normalised is, in their own words, "scheduled
 * without media". Silently. With a 200. So every image and every video we sent
 * was dropped on the floor, and the first anyone knew of it was Metricool's
 * own editor refusing to save the draft with "Add at least 1 video."
 *
 * The response shape is not pinned down in the public documentation, so this
 * accepts the handful it could reasonably be — a bare string, {url}, {data:{url}},
 * {mediaId}, {id} — and reports anything it cannot read rather than guessing.
 * A shape we do not recognise is logged WITH its body, so the first real run
 * says what the contract actually is instead of failing the same way twice.
 *
 * Returns the URL to put in the post. Never throws: losing the picture is bad,
 * losing the post is worse — the caller sends what it has and the draft still
 * lands for a person to look at.
 */
// The sniffers live in the pure module so they can be tested; re-exported here
// because callers have always imported them from this file.
export { looksLikeVideoUrl, mayBeVideoUrl } from '@/lib/metricool-normalize-parse';
import { mayBeVideoUrl } from '@/lib/metricool-normalize-parse';
import { imageUploadEligible, isMetricoolHostedUrl } from '@/lib/metricool-upload-parse';
import { imageRefusalMessage } from '@/lib/media-normalize-reason';

export type NormalizeOutcome = {
  /** What to put in the post: Metricool's own reference, or '' when it failed. */
  url: string;
  ok: boolean;
  /** Metricool's status, when it answered at all. */
  status: number | null;
  /** The transport failure, when it did not. */
  error: string | null;
  /**
   * The answer's structure, in TYPES — "{data:string, status:number}".
   *
   * Carried so an unreadable reply diagnoses itself on the screen instead of in
   * a console nobody reads. Types only: the shape is the fact worth having, and
   * a response body is not ours to display.
   */
  shape?: string;
  /** Every endpoint tried, and what it answered. Reported when none worked. */
  attempts?: { path: string; status: number; method?: string }[];
  /**
   * Metricool handed back the very URL it was given.
   *
   * Not a normalise: the file never moved onto their storage, and a post
   * carrying that URL is one they accept with a 200 and publish with no video.
   * Distinguished from every other failure because it is the one that LOOKS
   * like success — and, until this flag existed, was the one whose diagnosis
   * fell through the caller entirely.
   */
  echoed?: boolean;
  /**
   * The URL was already on Metricool's own storage, so nothing was asked.
   *
   * A file this app uploaded straight into Metricool (lib/metricool-upload.ts)
   * lives on static.metricool.com or a metricool-* bucket — the hosts
   * Metricool's own clients send in `media` without a normalise step. Asking
   * anyway gets the URL handed back, which the caller would read as an echo
   * and refuse: the one route that moves the file would fail at the very
   * check that exists to catch files that did not move.
   */
  hosted?: boolean;
  /** An image the normalise would not take, uploaded into Metricool's storage instead. */
  uploaded?: boolean;
  /** The sentence for a person, when this outcome already knows it (an image). */
  message?: string;
};

/**
 * Normalise one URL, keeping the reason when it does not work.
 *
 * The status was ALREADY KNOWN here — logged to a console nobody reads — while
 * the person was told "the video copy needs a look" for a 403, a 413, a 502 and
 * a timeout alike. lib/media-normalize-reason.ts turns this into the sentence.
 */
/** The same link, allowing for a trailing slash or a different case of host. */
function sameUrl(a: string, b: string): boolean {
  const norm = (v: string) => String(v || '').trim().replace(/\/+$/, '');
  if (norm(a) === norm(b)) return true;
  try {
    const x = new URL(norm(a));
    const y = new URL(norm(b));
    return x.host.toLowerCase() === y.host.toLowerCase() && x.pathname === y.pathname;
  } catch {
    return false;
  }
}

export async function normalizeMediaDetailed(rawUrl: string): Promise<NormalizeOutcome> {
  const url = String(rawUrl || '').trim();
  if (!url) return { url: '', ok: false, status: null, error: 'no url', attempts: [] };
  // Already where a normalise would put it. See `hosted` above.
  if (isMetricoolHostedUrl(url)) {
    console.info('metricool:normalize-media already hosted, sent as is');
    return { url, ok: true, status: null, error: null, attempts: [], hosted: true };
  }
  // Uploaded a moment ago for another network of the same post.
  const known = uploadedImages.get(url);
  if (known && Date.now() - known.at < UPLOADED_IMAGE_TTL_MS) {
    return { url: known.url, ok: true, status: null, error: null, attempts: [], uploaded: true };
  }
  let lastStatus: number | null = null;
  let lastShape = '';
  let sawEcho = false;
  /** Which endpoints answered what. Reported when nothing worked. */
  const attempts: { path: string; status: number; method?: string }[] = [];
  try {
    // THE REGRESSION THIS LOOP EXISTS TO UNDO.
    //
    // Until #249 there was ONE call here — /actions/normalize/image/url — and
    // videos reached Metricool through it. #249 added a /video/ endpoint and
    // tried it first, and the loop stopped at the first response that was
    // merely `ok`. So the moment that endpoint answered 200 with something
    // that is not a media reference, this app stopped — and never reached the
    // endpoint that had been working. Every video since has failed at the
    // door, whatever its size, which is exactly what a 40 MB reel failing
    // alongside a 477 MB one says.
    //
    // So the loop now stops on a USABLE ANSWER, not on a status. A 200 that
    // yields no reference, or yields back the very URL it was given, is not an
    // answer: it is one more endpoint that did not work, and the next one is
    // still worth asking.
    const isVideo = mayBeVideoUrl(url);
    const paths = isVideo
      ? [
          // The one that worked before #249 leads, because "it worked" beats
          // every theory about which spelling is more correct.
          '/actions/normalize/image/url',
          '/actions/normalize/video/url',
          '/v2/actions/normalize/video/url',
          '/v2/actions/normalize/image/url',
        ]
      : ['/actions/normalize/image/url', '/v2/actions/normalize/image/url'];

    // Four minutes for a video, one for an image — but shared across every
    // attempt, not granted to each. Metricool is PULLING the file onto its own
    // storage, so two attempts on a 477 MB reel is two transfers; without one
    // clock over all of them, trying harder is how the request gets killed by
    // the platform at 300s with nothing to show.
    const budgetMs = isVideo ? 240_000 : 60_000;
    const deadline = Date.now() + budgetMs;

    for (const method of ['GET', 'POST'] as const) {
      for (const path of paths) {
        const left = deadline - Date.now();
        // Under ten seconds left is not an attempt, it is a guaranteed abort
        // that costs the diagnosis its clarity.
        if (left < 10_000) break;
        const res = await metricoolFetch(path + '?url=' + encodeURIComponent(url), { timeoutMs: left, method });
        attempts.push({ path, status: res.status, method });
        if (!res.ok) {
          lastStatus = res.status;
          console.warn('metricool:normalize-media non-ok', method, path, res.status);
          continue;
        }
        const raw = await res.text();
        const parsed = readNormalizedUrl(raw, url);
        // An echo is not a normalise: the file never moved onto their storage,
        // and a post carrying that URL is one Metricool accepts with a 200 and
        // publishes with no video.
        if (parsed.url && !sameUrl(parsed.url, url)) {
          console.info('metricool:normalize-media via', method, path);
          return { url: parsed.url, ok: true, status: res.status, error: null, shape: parsed.shape, attempts };
        }
        lastStatus = res.status;
        lastShape = parsed.shape;
        if (parsed.url) sawEcho = true;
        console.warn('metricool:normalize-media unusable answer', method, path, res.status, parsed.shape, raw.slice(0, 200));
      }
    }
    const failed: NormalizeOutcome = {
      url,
      ok: false,
      status: lastStatus,
      error: null,
      shape: lastShape || undefined,
      attempts,
      ...(sawEcho ? { echoed: true } : {}),
    };
    // An image the normalise echoed or refused goes up the upload route instead.
    return isVideo ? failed : await uploadImageInstead(failed);
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    console.warn('metricool:normalize-media failed', message);
    const failed: NormalizeOutcome = { url, ok: false, status: lastStatus, error: message, attempts };
    return mayBeVideoUrl(url) ? failed : await uploadImageInstead(failed);
  }
}

/** Images already uploaded, by source link, so one approve uploads once for all its networks. */
const uploadedImages = new Map<string, { url: string; at: number }>();
const UPLOADED_IMAGE_TTL_MS = 6 * 60 * 60_000;

/**
 * Upload an image the normalise did not take into Metricool's own storage
 * (lib/metricool-upload.ts), or refuse with what each step said. Drive links
 * and videos never reach here.
 */
async function uploadImageInstead(failed: NormalizeOutcome): Promise<NormalizeOutcome> {
  const src = failed.url;
  let upload: string | null = null;
  if (imageUploadEligible(src)) {
    // Imported here: lib/metricool-upload.ts imports this module.
    const { uploadImageUrlToMetricool } = await import('@/lib/metricool-upload');
    const up = await uploadImageUrlToMetricool(src);
    if (up.ok) {
      console.info('metricool:normalize-media image uploaded instead');
      if (uploadedImages.size > 100) uploadedImages.clear();
      uploadedImages.set(src, { url: up.url, at: Date.now() });
      return { url: up.url, ok: true, status: failed.status, error: null, attempts: failed.attempts, uploaded: true };
    }
    upload = up.message;
  }
  return {
    ...failed,
    message: imageRefusalMessage({ status: failed.status, error: failed.error, echoed: failed.echoed, attempts: failed.attempts, upload }),
  };
}

export { acceptEcho } from '@/lib/metricool-echo';
import { acceptEcho } from '@/lib/metricool-echo';

/** The URL to post, or the one we were given when it did not work. Unchanged for callers that only need that. */
export async function normalizeMedia(rawUrl: string): Promise<string> {
  const out = await normalizeMediaDetailed(rawUrl);
  return out.url;
}

/**
 * Normalise every attachment, in order, dropping the ones that come back empty.
 *
 * `degraded` is the part that matters: a normalise that failed returns the
 * ORIGINAL url, which Metricool accepts with a 200 and then silently discards.
 * Without a flag saying so, the caller reports a perfectly successful post and
 * the person finds out days later from Metricool's own editor. Callers that can
 * surface a warning should; none may treat this as ordinary success.
 */
export async function normalizeMediaList(
  urls: readonly string[],
): Promise<{ media: string[]; degraded: boolean; failure: NormalizeOutcome | null; accepted: boolean }> {
  const media: string[] = [];
  let degraded = false;
  /** An echo was let through by METRICOOL_ACCEPT_ECHO. Marked, so the caller can say so. */
  let accepted = false;
  /** The FIRST thing that went wrong, kept so the caller can say what it was. */
  let failure: NormalizeOutcome | null = null;
  for (const u of urls) {
    const trimmed = String(u || '').trim();
    const out = await normalizeMediaDetailed(trimmed);
    const n = out.url;
    if (!n) {
      // Nothing came back at all. Skipping it quietly produced a post with an
      // empty media list, reported as a success.
      if (trimmed) degraded = true;
      if (!failure) failure = out;
      continue;
    }
    if (n === trimmed && !out.ok) {
      // Unchanged means normalise did not happen — every success path returns
      // Metricool's own reference, never the URL it was given. The one
      // exception is a URL already on Metricool's storage (`hosted`), which
      // comes back unchanged AND ok, and is the file exactly where it belongs.
      degraded = true;
      // THE ONE QUESTION LEFT, AND THE ONLY WAY TO ANSWER IT.
      //
      // The trace from row 191 settles what these endpoints are:
      //
      //   image 200 · video 404 · v2/video 404 · v2/image 404
      //   image POST 500 · video POST 404 · v2/video POST 404 · v2/image POST 404
      //
      // Every video path, in every spelling, 404. Only
      // /actions/normalize/image/url exists at all, and it hands the link back.
      // So "Metricool pulls the file onto its own storage" was only ever true
      // for IMAGES; there is no video equivalent to call.
      //
      // Which leaves one thing nobody here knows: does Metricool fetch the
      // media URL ITSELF when the post publishes? The echo was read as "no" in
      // #274 — but rows 184 and 186 went out WITH their video two days before
      // #274 existed, on the bucket route, and nobody recorded whether that
      // was a copy or an echo. And the "no" was formed when the URL we handed
      // over was a Vercel function that could not serve the file to anyone.
      //
      // The link is not broken now. So with METRICOOL_ACCEPT_ECHO on, the
      // echoed URL goes into the post, `degraded` and `accepted` both stay
      // true so the post is marked, and `failure` is NOT set — because every
      // caller refuses on `failure`, and the first version of this switch
      // left it set (and skipped the push), so the flag changed nothing and
      // printed the identical sentence. Off by default; the cost of being
      // wrong is a reel on YouTube and TikTok with no video in it.
      // TESTED 21 SEPTEMBER: NO. Metricool stored the echoed Drive link as
      // given, could not preview it, and would have published without it.
      // The switch stays, off, so the record of the test stays with the code
      // — but the answer is a plain .mp4 on a plain host, and nothing else.
      if (acceptEcho()) {
        accepted = true;
      } else if (!failure) {
        // A FAILURE, with everything known about it. This was the hole: an
        // echoed URL set `degraded` without setting `failure`, so the caller
        // had nothing to explain it with and printed the bare fallback.
        failure = { ...out, ok: false, echoed: true };
      }
    } else if (!out.ok && !failure) {
      failure = out;
    }
    media.push(n);
  }
  return { media, degraded, failure, accepted };
}

// Metricool wants a wall-clock "YYYY-MM-DDTHH:MM:SS" plus an IANA timezone —
// it rejects/misreads full ISO strings with 'Z' or milliseconds. Convert the
// UTC instant we store internally into the schedule timezone's wall clock so the
// post shows up in the Metricool planner at the intended local time.
function wallClock(publicationDate: string): string {
  const at = new Date(publicationDate);
  return isNaN(at.getTime()) ? String(publicationDate) : formatForMetricool(at, SCHEDULE_TZ);
}

/**
 * Thrown before a post is created when its media did not normalise.
 *
 * This used to be a console.error and the post went out anyway — with a 200
 * from Metricool and no video in it. A post the person will approve believing
 * it carries its video is worse than no post: callers catch this by class and
 * say so.
 */
export class MediaNotNormalisedError extends Error {
  readonly code = 'media_unverified' as const;
  constructor(message = 'Metricool did not take the media, so the post was not created \u2014 a post without its video would have looked finished and gone out empty.') {
    super(message);
    this.name = 'MediaNotNormalisedError';
  }
}

export async function metricoolSchedulePost(input: SchedulePostInput, mode: PostMode = 'review') {
  // Normalised before the post is built, never after: an un-normalised URL is
  // accepted and then discarded, so "media sent" and "media attached" are two
  // different things and only this call makes them the same one.
  const { media, degraded, failure } = await normalizeMediaList((input.media || []).map((m) => m.url).filter(Boolean));
  if (degraded) {
    // Refused, not warned about: the failure is otherwise invisible — Metricool
    // answers 200 and the post arrives with no video.
    console.error('metricool:media-not-normalised — the post is NOT created', { count: media.length });
    // An image carries its own reason; a video keeps the standing sentence.
    throw new MediaNotNormalisedError(failure?.message || undefined);
  }

  const body = {
    text: input.text,
    // Metricool's scheduler expects provider OBJECTS ({ network }), not bare
    // strings — this mirrors the interactive /api/metricool/schedule route.
    // Sending bare strings silently fails / mis-files the post.
    providers: input.providers.map((network) => ({ network })),
    publicationDate: { dateTime: wallClock(input.publicationDate), timezone: SCHEDULE_TZ },
    firstCommentText: input.firstCommentText,
    // An array of URLs. This was an array of {url} OBJECTS, which is the shape
    // Metricool ANSWERS with, not the one it accepts.
    media,
    // Only sent for a YouTube post, and only when there is a real title:
    // Metricool refuses to save a YouTube draft without one.
    ...(input.youtubeData && input.providers.includes('youtube') ? { youtubeData: input.youtubeData } : {}),
    // TikTok's own settings, so the draft is a direct publication (public,
    // comments/duet/stitch on) and not Metricool's "finish on your phone" mode.
    ...(input.tiktokData && input.providers.includes('tiktok') ? { tiktokData: input.tiktokData } : {}),
    // Publishing is a human decision. The default lands the post in Metricool's
    // review queue; only an explicit `mode: 'scheduled'` — which every caller
    // reaches through a person pressing Approve in the dashboard — puts it in
    // the live queue. draft:true is what keeps an autoPublish:false post out of
    // the live-pending state.
    ...modeFlags(mode),
  };

  let res = await metricoolFetch('/v2/scheduler/posts', {
    method: 'POST',
    body: JSON.stringify(body),
  });
  let data = await res.json().catch(() => ({}));
  // The tiktokData field names come from public clients of this endpoint,
  // not from documentation this app could read. If Metricool refuses the
  // block by name, the post is sent once more without it — a wrong preset
  // costs the preset, never the post — and the log says so.
  if (!res.ok && res.status === 400 && 'tiktokData' in body && /tiktok/i.test(JSON.stringify(data))) {
    console.warn('metricool:tiktokData refused, sending without it', JSON.stringify(data).slice(0, 300));
    const withoutTiktok = { ...(body as Record<string, unknown>) };
    delete withoutTiktok.tiktokData;
    res = await metricoolFetch('/v2/scheduler/posts', { method: 'POST', body: JSON.stringify(withoutTiktok) });
    data = await res.json().catch(() => ({}));
  }
  if (!res.ok) {
    const message = 'Metricool ' + res.status + ': ' + JSON.stringify(data);
    // Capability, not configuration. The `metricool` health check asks only
    // whether three environment variables are non-empty, so a rotated or
    // rejected token reported healthy indefinitely while every schedule failed
    // — the same blind spot the images check was rewritten to close.
    recordProviderOutcome('metricool', { ok: false, message });
    throw new Error(message);
  }
  recordProviderOutcome('metricool', { ok: true });
  return data;
}

/** Pull the post id out of whatever envelope Metricool answered with. */
export function readPostId(data: any): string | null {
  const post = data && data.data ? data.data : data;
  const id = post && (post.id ?? post.postId);
  return id == null || id === '' ? null : String(id);
}

/**
 * Move an already-scheduled post to a new time.
 *
 * The dashboard used to update only its own `posts` row, so a reschedule in the
 * queue or a drag on the calendar moved the chip and left Metricool holding the
 * original time — the post then published on the old date while every screen in
 * the app showed the new one. Callers must treat a throw here as "the move did
 * not happen" and leave their local row alone.
 *
 * Metricool's PUT is a REPLACE, not a patch. Sending only the new
 * publicationDate is rejected:
 *
 *   400 ValidationError { text: "must not be null",
 *                         providers: "must not be empty" }
 *
 * so the post's existing text and networks have to be sent back with it. They
 * come from our own `posts` row, which is written at schedule time and is the
 * same content Metricool already holds. `draft` and `autoPublish` are repeated
 * here for the same reason they are constants everywhere else: a replace that
 * omitted them would drop the post out of the review queue.
 */
/**
 * REPLACE a post in Metricool. Everything the post should still have must be
 * in `post` — text, networks, date, media and which queue it sits in.
 */
export async function metricoolReplacePost(postId: string, post: ReplacePostInput): Promise<void> {
  const res = await metricoolFetch('/v2/scheduler/posts/' + encodeURIComponent(postId), {
    method: 'PUT',
    body: JSON.stringify(replacePostBody(post)),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    throw new Error('Metricool ' + res.status + ': ' + detail.slice(0, 300));
  }
}

/**
 * Move a post to a new time, keeping it in whichever queue it is already in.
 * A post the reviewer has approved must not fall back into review because it
 * was dragged to another day; a draft must not go live because it was moved.
 */
export async function metricoolUpdatePostDate(
  postId: string,
  publicationDate: string,
  post: { text: string; providers: Provider[]; media?: string[]; mode?: PostMode },
): Promise<void> {
  await metricoolReplacePost(postId, {
    text: post.text,
    providers: post.providers,
    publicationDate,
    media: post.media,
    mode: post.mode || 'review',
  });
}

/**
 * Remove a scheduled post from Metricool.
 *
 * A post Metricool no longer has (404/410) counts as deleted: the caller's goal
 * is "this post is gone", and refusing to clean up the local row because the
 * remote copy is already missing would strand it forever.
 */
export async function metricoolDeletePost(postId: string): Promise<void> {
  const res = await metricoolFetch('/v2/scheduler/posts/' + encodeURIComponent(postId), {
    method: 'DELETE',
  });
  if (res.ok || res.status === 404 || res.status === 410) return;
  const detail = await res.text().catch(() => '');
  throw new Error('Metricool ' + res.status + ': ' + detail.slice(0, 300));
}

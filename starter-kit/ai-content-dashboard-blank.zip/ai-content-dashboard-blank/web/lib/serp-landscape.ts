// web/lib/serp-landscape.ts
// Who already owns this search, and what that means for what the post should
// do about it.
//
// serpCompetitors() has been in lib/semrush.ts all along — cached, budget-
// guarded, returning the domains and URLs ranking for a phrase — and only the
// manual research screen ever called it. The video pipeline cited studies
// nobody could argue with and had no idea who it was standing next to.
//
// The reason this file is not one paragraph of advice is that the advice
// inverts. Two kinds of result page, for two keywords of the same brand:
//
//   "<what the thing is>"        -> large publishers and reference sites:
//                                   a famous institution, an encyclopedia,
//                                   a government or university page
//   "<the thing> in <place>"     -> the brand's actual competitors, whose
//                                   slugs say what the fight is about:
//                                   /best-<thing>-in-<place>, /cost-of-<thing>,
//                                   /travel-overview/, /licensed-<thing>
//
// A small brand will not out-explain a national institution on what something
// IS, and a post that tries has spent its 1,100 characters losing. Against
// peers the problem is the opposite: everyone makes the same promise.
//
// Same pipeline, same brand, opposite instructions. So the landscape is
// classified and the posture follows from it.
//
// No imports: the test runner strips types and runs this file directly.

export type SerpRow = { domain: string; url: string };

export type SerpKind =
  /** A large institution (a famous hospital, a university) — a general explainer. */
  | 'institution'
  /** Government, encyclopedia and literature sites — reference material. */
  | 'reference'
  /** Another business selling the same thing. The real competitive set. */
  | 'peer'
  /** YouTube, Instagram, TikTok — where this post is actually going. */
  | 'social'
  | 'other';

const INSTITUTION = /(mayoclinic|hopkinsmedicine|clevelandclinic|ucsfhealth|stanford|harvard|mountsinai|cedars|mskcc|unitypoint|kaiserpermanente|nhs\.uk)/i;
const REFERENCE = /(ncbi\.nlm\.nih\.gov|pubmed|medlineplus|medscape|webmd|healthline|wikipedia|cochrane|\.gov$|\.edu$)/i;
const SOCIAL = /(youtube|instagram|tiktok|facebook|reddit|linkedin|x\.com|twitter)/i;
/**
 * A peer business, recognised by what such businesses put in their domains.
 *
 * Deliberately last and deliberately loose: anything that is not an
 * institution, a reference or a social platform, and that names a trade in its
 * own domain, is competing for the same customer.
 */
const PEER = /(clinic|therapy|medical|institute|health|wellness|studio|shop|store|agency|services?|solutions|company|group|center|centre)/i;

export function classifyDomain(domain: string): SerpKind {
  const d = String(domain || '').toLowerCase().trim();
  if (!d) return 'other';
  // Order matters: a rival "…institute.com" contains "institute", and
  // pmc.ncbi.nlm.nih.gov contains nothing that would mark it a peer — but
  // clevelandclinic contains "clinic", so the named lists must win first.
  if (SOCIAL.test(d)) return 'social';
  if (INSTITUTION.test(d)) return 'institution';
  if (REFERENCE.test(d)) return 'reference';
  if (PEER.test(d)) return 'peer';
  return 'other';
}

/**
 * What the ranking pages are competing ON, read from their URL paths.
 *
 * Free signal — the slugs are already in the response serpCompetitors returns,
 * so this costs nothing extra — and unusually honest, because a page's path is
 * chosen to match the query it wants. /cost-of-<thing>-in-<place> is a
 * competitor telling you what its visitors are worried about.
 */
const THEMES: ReadonlyArray<readonly [RegExp, string]> = [
  [/\bbest\b|\btop-?\d*\b|\branking\b/i, 'being called the best'],
  [/\bcost|\bprice|\bpricing|\bcheap|\baffordab/i, 'what it costs'],
  [/\blicens|\bcertif|\bapprov|\baccredit|\blegal|\bregulat|\bsafe/i, 'whether it is legitimate and safe'],
  [/\btravel|\btourism|\bpackage|\bstay|\bvisit/i, 'the logistics of getting there'],
  [/\breview|\btestimonial|\bsuccess|\bresult/i, 'other customers’ results'],
  [/\bside-?effect|\brisk|\bcontraindicat/i, 'risks and side effects'],
  [/\bhow-?it-?works|\bwhat-?is|\babout|\bguide|\boverview|\bprocedure|\btreatments?\b|\bservices?\b/i, 'explaining what the offering is'],
];

export function themesFrom(rows: readonly SerpRow[]): string[] {
  const found: string[] = [];
  for (const r of rows) {
    for (const [re, label] of THEMES) {
      if (re.test(String(r.url || '')) && !found.includes(label)) found.push(label);
    }
  }
  return found;
}

function tally(rows: readonly SerpRow[]): Record<SerpKind, number> {
  const out: Record<SerpKind, number> = { institution: 0, reference: 0, peer: 0, social: 0, other: 0 };
  for (const r of rows) out[classifyDomain(r.domain)]++;
  return out;
}

/**
 * The competitive block appended to the writer's brief.
 *
 * Returns '' when there is no SERP data, and the post is written exactly as it
 * would have been — the same fail-open rule as the keyword brief and the
 * research brief.
 */
export function serpLandscapeFrom(phrase: string, rows: readonly SerpRow[]): string {
  const usable = rows.filter((r) => r && r.domain).slice(0, 10);
  if (!usable.length || !String(phrase || '').trim()) return '';

  const counts = tally(usable);
  const themes = themesFrom(usable);
  const names = [...new Set(usable.map((r) => r.domain.replace(/^www\./, '')))].slice(0, 6);
  // The question is whether BIG PUBLISHERS own this search, not whether every
  // competitor can be named. "kalimbaroasters.com" is a rival with nothing
  // in its domain to say so, and classifying it 'other' is correct — but
  // counting it as neutral would have let two recognisable institutions
  // outvote eight competitors and hand the post the wrong instruction
  // entirely. Anything that is not an institution or a reference work is a
  // commercial page competing for the same customer.
  const authority = counts.institution + counts.reference;
  const peerLed = authority < usable.length / 2;

  const lines: string[] = [];
  lines.push('SEARCH LANDSCAPE (live SERP for "' + phrase + '" — who the reader is comparing this brand against):');
  lines.push('- Currently ranking: ' + names.join(', ') + '.');
  if (themes.length) lines.push('- What those pages compete on: ' + themes.join('; ') + '.');

  if (peerLed) {
    // The competitors ARE other businesses like this one. Everyone is making the same promise.
    lines.push(
      '- These are rival businesses selling the same thing, and they all promise the same things. ' +
      'The reader has already read those promises. Do not repeat them and do not out-claim them: answer the ' +
      'same underlying worry with something VERIFIABLE from this video — the equipment named, the step ' +
      'actually performed, the measurement stated, the check done before delivery. A specific a competitor ' +
      'cannot copy is the only durable advantage here.',
    );
  } else {
    // The competitors are large institutions and reference works. Different game entirely.
    lines.push(
      '- These are large publishers and reference sites writing general explainers. This post will not ' +
      'out-explain them and must not try — a caption spent defining the subject is a caption spent losing. ' +
      'Their structural limit is that they can never show one brand actually doing the thing. That is exactly ' +
      'what this video has, so lead with it: what happens here, in what order, with what equipment, checked how.',
    );
  }

  // Comparative advertising is separately regulated in many places, and an
  // advertiser naming a rival is a problem this pipeline should never be able to create.
  lines.push('- NEVER name a competitor, quote one, or make a comparative claim ("better than", "unlike other brands"). This is context for what to emphasise, not material to write about.');
  return lines.join('\n');
}

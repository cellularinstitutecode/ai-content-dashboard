// web/lib/brand-font-rules.ts
// What counts as a usable brand typeface file — pure, so the rules are
// unit-tested and shared by the upload route and the compositor.
//
// Any typeface can be the brand's. What a file is FOR is said when it is
// uploaded — Brand Brain asks "headline or body?" — and recorded in the stored
// name as a role prefix: `headline--Lora-Bold.otf`, `body--Inter-Regular.otf`.
// The family, weight and style are read from the rest of the name. A file with
// no role cannot quietly become the headline type.
//
// Trial and demo builds are refused: a foundry's evaluation licence does not
// cover a brand's production social cards.

export type FontFamily = string;
export type FontRole = 'headline' | 'body';
export type FontWeight = 300 | 400 | 500 | 600 | 700;
export type FontStyle = 'normal' | 'italic';

export type FontFile = { family: FontFamily; role: FontRole; weight: FontWeight; style: FontStyle };

export const MAX_FONT_BYTES = 2 * 1024 * 1024;
export const FONT_EXT = /\.(otf|ttf|woff)$/i;
/** Separates the role from the original file name: `headline--Lora-Bold.otf`. */
export const ROLE_SEP = '--';
const ROLE_PREFIX = /^(headline|body)--/i;

export function isFontRole(v: unknown): v is FontRole {
  return v === 'headline' || v === 'body';
}

const WEIGHT_WORDS = /(thin|hairline|extralight|ultralight|light|book|regular|medium|semibold|demibold|extrabold|ultrabold|bold|black|heavy|italic|oblique)+$/i;

/**
 * The family name from the part of a file name after the role: the first
 * token ("Lora-BoldItalic" → "Lora"), with a run-on weight word trimmed
 * ("LoraBold" → "Lora").
 */
export function familyFromName(rest: string): string {
  const token = String(rest || '').replace(FONT_EXT, '').split(/[-_\s]+/).filter(Boolean)[0] || '';
  const trimmed = token.replace(WEIGHT_WORDS, '');
  return (trimmed || token).replace(/[^A-Za-z0-9]/g, '');
}

/** Family, role, weight and style from a stored name like "body--Inter-Semibold.otf". Null without a role prefix. */
export function describeFontFile(name: string): FontFile | null {
  const base = String(name || '').split(/[\\/]/).pop() || '';
  if (!FONT_EXT.test(base)) return null;
  const m = ROLE_PREFIX.exec(base);
  if (!m) return null;
  const role = m[1].toLowerCase() as FontRole;
  const rest = base.slice(m[0].length);
  const family = familyFromName(rest);
  if (!family) return null;
  const lower = rest.toLowerCase();
  // "semibold" contains "bold", so the finer grades are tested first.
  const weight: FontWeight =
    /semibold|demibold/.test(lower) ? 600
    : /black|xbold|extrabold|heavy|bold/.test(lower) ? 700
    : /medium/.test(lower) ? 500
    : /light|thin|book/.test(lower) ? 300
    : 400;
  const style: FontStyle = /italic|oblique/.test(lower) ? 'italic' : 'normal';
  return { family, role, weight, style };
}

/**
 * A variable font (one file, many weights). satori sets type from static
 * instances only, so a variable file is listed and counted but never handed to
 * the renderer — the static weights alongside it are what get used.
 */
export function isVariableFont(name: string): boolean {
  return /variable|\[wght\]|-vf\b/i.test(String(name || ''));
}

/** Trial, demo and evaluation builds carry it in the file name; they are not licensed for production. */
export function isTrialFont(name: string): boolean {
  return /trial|demo|eval|sample|test/i.test(String(name || '').replace(FONT_EXT, '').replace(ROLE_PREFIX, ''));
}

export type UploadVerdict = { ok: true; file: FontFile; safeName: string } | { ok: false; reason: string };

/**
 * Decide whether an uploaded font may be stored, and under what name. `role`
 * is what the uploader said the file is for; without it the name must already
 * carry a role prefix (a file stored earlier, or one dropped in the local folder).
 */
export function validateFontUpload(name: string, bytes: number, role?: FontRole | null): UploadVerdict {
  const base = String(name || '').split(/[\\/]/).pop() || '';
  if (!FONT_EXT.test(base)) return { ok: false, reason: base + ': only .otf, .ttf and .woff font files are accepted.' };
  if (bytes <= 0) return { ok: false, reason: base + ': the file is empty.' };
  if (bytes > MAX_FONT_BYTES) return { ok: false, reason: base + ': larger than 2 MB — that is not a text font.' };
  if (isTrialFont(base)) return { ok: false, reason: base + ': this is a trial/demo build. Evaluation licences do not cover production use; upload the purchased family.' };
  const clean = base.replace(/[^A-Za-z0-9._-]/g, '_');
  const safeName = isFontRole(role) ? role + ROLE_SEP + clean.replace(ROLE_PREFIX, '') : clean;
  const file = describeFontFile(safeName);
  if (!file) return { ok: false, reason: base + ': say whether this is the headline or the body typeface (choose the role when uploading, or name the file headline--Family-Weight.otf / body--Family-Weight.otf).' };
  return { ok: true, file, safeName };
}

/**
 * Which faces a set of stored files covers, and which role still runs on a
 * stand-in. The first usable file for a role names that role's family.
 */
export function coverage(names: string[]): { headline: FontFamily | null; body: FontFamily | null; standInFaces: FontRole[] } {
  let headline: FontFamily | null = null;
  let body: FontFamily | null = null;
  for (const n of names) {
    const f = describeFontFile(n);
    if (!f || isTrialFont(n)) continue;
    if (f.role === 'headline' && !headline) headline = f.family;
    else if (f.role === 'body' && !body) body = f.family;
  }
  const standInFaces: FontRole[] = [];
  if (!headline) standInFaces.push('headline');
  if (!body) standInFaces.push('body');
  return { headline, body, standInFaces };
}

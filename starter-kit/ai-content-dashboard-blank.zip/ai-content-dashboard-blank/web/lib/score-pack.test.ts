import { test } from 'node:test';
import assert from 'node:assert/strict';
import { contentWords, scorePack } from './score-pack.ts';

const REF = '\n\nREF: Smith, A. (2020). "Sleep." J Sleep. DOI: 10.1000/x';
const body = (s: string) => s + ' '.repeat(0) + '\nSave this for tonight.' + REF;

test('a strategy post covering the angle in its own words gets full keyword marks', () => {
  const angle = { query: 'Why sleeping longer does not always mean resting better' };
  const own = { instagram: body('Eight hours in bed is not the same as rest. Quality matters more than length: deep, unbroken sleep is when repair happens, and resting well depends on rhythm, light and calm evenings. Longer nights alone rarely fix fatigue.') };
  const s = scorePack(own as never, ['instagram'], angle, { strategySlot: true });
  assert.equal(s.breakdown.keyword, 30);
  assert.ok(!s.critique.some((c) => /exact phrase/.test(c)), 'never told to paste the sentence in');
});

test('a strategy post off the angle is told to cover it in its own words', () => {
  const angle = { query: 'Why sleeping longer does not always mean resting better' };
  const off = { instagram: body('Protein at breakfast keeps energy steady through the morning, and a glass of water helps too. Start with eggs or yoghurt.') };
  const s = scorePack(off as never, ['instagram'], angle, { strategySlot: true });
  assert.ok(s.breakdown.keyword < 18);
  assert.ok(s.critique.some((c) => /in your own words; do not copy the sentence/.test(c)));
});

test('a strategy post earns CTA points only for the gentle next step', () => {
  const angle = { query: 'sleep quality' };
  const sales = scorePack({ instagram: 'Sleep quality matters for everyone reading this post today, truly it does. Book your visit today.' + REF } as never, ['instagram'], angle, { strategySlot: true });
  assert.equal(sales.breakdown.cta, 0);
  assert.ok(sales.promotionFlags?.includes('booking call to action'));
  const soft = scorePack({ instagram: body('Sleep quality matters for everyone reading this post today, truly it does, and here is why.') } as never, ['instagram'], angle, { strategySlot: true });
  assert.equal(soft.breakdown.cta, 15);
});

test('other templates keep the search-phrase rubric', () => {
  const s = scorePack({ instagram: 'Sourdough baking in Austin explained. Book a class.' } as never, ['instagram'], { query: 'sourdough baking austin' });
  assert.equal(s.breakdown.keyword, 30);
  assert.equal(s.breakdown.cta, 15);
  assert.equal(s.promotionFlags, undefined);
});

test('content words drop the filler', () => {
  assert.deepEqual(contentWords('Why the body needs time to respond'), ['needs', 'time', 'respond']);
});

test('Phase 3: a strategy post opening like one already published loses points and is flagged for the rewrite', () => {
  const angle = { query: 'sleep quality' };
  const text = body('Eight hours in bed is not the same as rest, and sleep quality matters more than length for most of us.');
  const fresh = scorePack({ instagram: text } as never, ['instagram'], angle, { strategySlot: true, recentOpenings: ['Protein at breakfast keeps energy steady.'] });
  assert.equal(fresh.openingRepeat, undefined);
  const repeat = scorePack({ instagram: text } as never, ['instagram'], angle, { strategySlot: true, recentOpenings: ['Eight hours in bed is not the same as rest, and sleep quality matters more than length for most of us.'] });
  assert.equal(repeat.openingRepeat, true);
  assert.equal(repeat.breakdown.opening, -15);
  assert.ok(repeat.total < fresh.total);
  assert.ok(repeat.critique.some((c) => /opening line repeats a recent post/.test(c)));
  // Not a strategy slot: the old scoring, untouched.
  const other = scorePack({ instagram: text } as never, ['instagram'], angle, { recentOpenings: ['Eight hours in bed is not the same as rest, and sleep quality matters more than length for most of us.'] });
  assert.equal(other.openingRepeat, undefined);
});

test('Phase 3: a dealt closing is scored on its own words, and the critique names it', () => {
  const angle = { query: 'sleep quality' };
  const txt = 'Sleep quality matters for everyone reading this post today, truly it does, and here is why.\nWhich part of your evening could be calmer?' + REF;
  const ok = scorePack({ instagram: txt } as never, ['instagram'], angle, { strategySlot: true, closing: 'reflect' });
  assert.equal(ok.breakdown.cta, 15);
  const saved = scorePack({ instagram: body('Sleep quality matters for everyone reading this post today, truly it does, and here is why.') } as never, ['instagram'], angle, { strategySlot: true, closing: 'reflect' });
  assert.equal(saved.breakdown.cta, 0, 'it was dealt a question back, not "save this"');
  assert.ok(saved.critique.some((c) => /question back to the reader/.test(c)));
  assert.ok(!saved.critique.some((c) => /save this, share it/.test(c)), 'not steered back to the old line');
});

test('Phase 3: the weekly article\'s headline is not checked against the social openings', () => {
  const head = 'Eight hours in bed is not the same as rest';
  const s = scorePack({ blog: head + '\n\nLong article body about sleep quality and rest, well over eighty characters in length.', facebook: 'x', linkedin: 'y' } as never, ['blog', 'facebook', 'linkedin'], { query: 'sleep' }, { strategySlot: true, recentOpenings: [head] });
  assert.equal(s.openingRepeat, undefined);
});

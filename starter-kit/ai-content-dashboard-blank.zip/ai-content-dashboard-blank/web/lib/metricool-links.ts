// web/lib/metricool-links.ts
// Where Metricool's own screens live, in one place.
//
// THE BUG THIS PREVENTS. Metricool's app resolves a brand only INSIDE a user,
// so every web link has to carry blogId AND userId. One link once carried only
// blogId, on a path nothing else confirmed, and pressing it landed on
// Metricool's "There was an error that prevented loading the page". The fix was
// to make every link the same shape — which only stays true if there is one
// place that builds them. A second copy of this string is how it comes back.
//
// Pure: no imports, so the test runner reads this file directly.

/**
 * This deployment's default Metricool brand and the user it lives under.
 * Read from NEXT_PUBLIC_METRICOOL_BLOG_ID / NEXT_PUBLIC_METRICOOL_USER_ID —
 * written out literally so Next inlines them into the client bundle. Blank
 * when unset: there is no built-in account.
 */
export const METRICOOL_BLOG_ID: string = String(process.env.NEXT_PUBLIC_METRICOOL_BLOG_ID || '').trim();
export const METRICOOL_USER_ID: string = String(process.env.NEXT_PUBLIC_METRICOOL_USER_ID || '').trim();

/**
 * The planner calendar for a brand — what is scheduled, and what already went out.
 *
 * `/planner/calendar` is the path that is known to work. Do not swap it for a
 * cleverer one without opening it first.
 *
 * A blank id falls back to the configured default; when that is blank too the
 * parameter is left off entirely (Metricool then opens the signed-in user's
 * current brand) rather than sending an empty `blogId=`.
 */
export function metricoolPlannerUrl(blogId: string = METRICOOL_BLOG_ID, userId: string = METRICOOL_USER_ID): string {
  const blog = String(blogId || '').trim() || METRICOOL_BLOG_ID;
  const user = String(userId || '').trim() || METRICOOL_USER_ID;
  const params: string[] = [];
  if (blog) params.push('blogId=' + encodeURIComponent(blog));
  if (user) params.push('userId=' + encodeURIComponent(user));
  return 'https://app.metricool.com/planner/calendar' + (params.length ? '?' + params.join('&') : '');
}

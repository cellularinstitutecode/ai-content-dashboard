// web/lib/health-claim.ts
// Does this post say something about health that a study would have to back?
//
// WHY. The advertising rule can make a post carry a REF line citing a
// peer-reviewed study (lib/compliance.ts, REQUIRE_CITATIONS). For a logistics
// or destination post — "How to get here", "Where to stay nearby", "What a
// companion can do during the visit" — no study supports what the post says,
// so the writer cited a loosely related paper, or reached for a health claim
// so it could cite one. So a post cites a study only when it makes a health
// claim (the default, and the strategy's citation policy). This decides
// whether one did. A brand that never talks about health never trips it.
//
// CONSERVATIVE ON PURPOSE. A false "yes" keeps today's behaviour — the post
// needs its REF line. A false "no" would let an uncited health claim through.
// So anything that sounds like one counts: a body word, an outcome verb, a
// therapy, a condition, or "studies show".
//
// Pure: imports ./compliance.ts, which imports this file back. The cycle is
// safe: each uses the other only inside function bodies, never at load time.
// ./brand-identity.ts has no imports.
import { stripComplianceLines } from './compliance.ts';
import { BRAND_NAME } from './brand-identity.ts';

const HEALTH_CLAIM = new RegExp(
  '\\b(' + [
    // outcomes
    'heal(s|ing|ed)?', 'improv\\w*', 'reduc\\w*', 'lower(s|ing|ed)?', 'boost\\w*', 'prevent\\w*', 'protect\\w*',
    'relie\\w*', 'restor\\w*', 'strengthen\\w*', 'enhanc\\w*', 'speed(s)? up', 'faster', 'benefit\\w*', 'effective\\w*',
    // the body
    'inflammat\\w*', 'immun\\w*', 'metabol\\w*', 'hormon\\w*', 'cortisol', 'nervous system', 'blood', 'circulat\\w*',
    'muscle\\w*', 'joint\\w*', 'bone\\w*', 'tissue\\w*', 'cells?', 'cellular (health|repair|function|energy|aging|ageing|regeneration)', 'brain', 'heart', 'oxygen\\w*', 'biomarker\\w*',
    'sleep quality', 'recover(y|ing|ies)?', 'repair\\w*', 'longevity', 'aging', 'ageing', 'energy levels?',
    // conditions and care
    'pain', 'symptom\\w*', 'disease\\w*', 'condition\\w*', 'disorder\\w*', 'injur\\w*', 'arthritis', 'diabet\\w*',
    'treat\\w*', 'therap\\w*', 'protocol\\w*', 'diagnos\\w*', 'clinical\\w*', 'medical\\w*', 'medication\\w*',
    'supplement\\w*', 'vitamin\\w*', 'nutrient\\w*', 'protein',
    'hbot', 'hyperbaric', 'red[- ]light', 'pemf', 'stem[- ]cells?', 'regenerat\\w*',
    // evidence talk
    'stud(y|ies)', 'research\\w*', 'evidence', 'scienc\\w*', 'proven',
  ].join('|') + ')\\b',
  'i',
);

/** A name as a whole-word, case- and spacing-tolerant pattern; null when blank. */
function namePattern(name: string): RegExp | null {
  const words = String(name || '').trim().split(/\s+/).filter(Boolean).map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  return words.length ? new RegExp('(^|[^\\p{L}\\p{N}])' + words.join('\\s+') + '(?=$|[^\\p{L}\\p{N}])', 'giu') : null;
}

/** The post as a reader reads it: no REF, no AVISO, no hashtags, no brand name. */
function bodyOf(text: string, brandNames: readonly string[]): string {
  let body = stripComplianceLines(text)
    .split('\n')
    .filter((l) => !/^\s*(#\S+\s*)+$/.test(l))
    .join('\n');
  // The brand's own name is not a claim. A name with a body word in it
  // ("Healing…", "Heart…") read as one, so a logistics post that named the
  // team — as the writer is told to, once — lost its citation waiver and was
  // refused at approval.
  for (const n of brandNames) {
    const re = namePattern(n);
    if (re) body = body.replace(re, '$1 ');
  }
  return body;
}

/**
 * The words that made a post read as a health claim, each once, as written —
 * so a rewrite that has to claim nothing can be told exactly what to replace.
 * `opts.brandName` is the Brand Brain name, when the caller has it; the
 * deployment's BRAND_NAME is always ignored too.
 */
export function healthClaimWords(text: string, opts: { brandName?: string | null } = {}): string[] {
  const body = bodyOf(String(text || ''), [BRAND_NAME, String(opts.brandName || '')]);
  const all = new RegExp(HEALTH_CLAIM.source, 'gi');
  const seen = new Set<string>();
  const out: string[] = [];
  for (const m of body.matchAll(all)) {
    const w = m[0];
    if (!seen.has(w.toLowerCase())) { seen.add(w.toLowerCase()); out.push(w); }
  }
  return out;
}

/**
 * True when the post says anything a study would have to back. When unsure: true.
 * `opts.brandName` is the Brand Brain name, when the caller has it; the
 * deployment's BRAND_NAME is always ignored too.
 */
export function makesHealthClaim(text: string, opts: { brandName?: string | null } = {}): boolean {
  const body = bodyOf(String(text || ''), [BRAND_NAME, String(opts.brandName || '')]);
  if (!body.trim()) return false;
  return HEALTH_CLAIM.test(body);
}

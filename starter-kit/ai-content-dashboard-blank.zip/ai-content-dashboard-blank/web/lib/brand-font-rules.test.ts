import { test } from 'node:test';
import assert from 'node:assert/strict';
import { describeFontFile, familyFromName, isTrialFont, isVariableFont, validateFontUpload, coverage, MAX_FONT_BYTES } from './brand-font-rules.ts';

test('family, role, weight and style are read from the stored file name', () => {
  assert.deepEqual(describeFontFile('body--Inter-Semibold.otf'), { family: 'Inter', role: 'body', weight: 600, style: 'normal' });
  assert.deepEqual(describeFontFile('headline--Lora-Medium.otf'), { family: 'Lora', role: 'headline', weight: 500, style: 'normal' });
  assert.deepEqual(describeFontFile('body--InterText-BoldItalic.otf'), { family: 'InterText', role: 'body', weight: 700, style: 'italic' });
  assert.deepEqual(describeFontFile('body--Inter-Light.otf'), { family: 'Inter', role: 'body', weight: 300, style: 'normal' });
  assert.equal(describeFontFile('Helvetica.ttf'), null, 'no role, so not a brand face');
  assert.equal(describeFontFile('body--Inter-Regular.zip'), null, 'not a font file');
});

test('the family is the first token of the name, with a run-on weight trimmed', () => {
  assert.equal(familyFromName('Lora-BoldItalic.otf'), 'Lora');
  assert.equal(familyFromName('LoraBold.otf'), 'Lora');
  assert.equal(familyFromName('Source_Serif_Regular.ttf'), 'Source');
  assert.equal(familyFromName('Bold.otf'), 'Bold', 'a family made only of a weight word keeps its name');
});

test('trial and demo builds are recognised whatever the family', () => {
  for (const n of ['Inter-Trial-Bold.otf', 'InterDemo-Light.otf', 'body--SansTextDemo-Bold.otf', 'headline--SerifTrial-Medium.otf']) {
    assert.equal(isTrialFont(n), true, n);
  }
  assert.equal(isTrialFont('Inter-Regular.otf'), false);
  assert.equal(isTrialFont('body--Inter-Bold.otf'), false);
});

test('uploads: the role chosen on upload is recorded in the stored name; trial builds and role-less files are refused', () => {
  const ok = validateFontUpload('Inter-Regular.otf', 24_576, 'body');
  assert.equal(ok.ok, true);
  if (ok.ok) { assert.equal(ok.file.family, 'Inter'); assert.equal(ok.file.role, 'body'); assert.equal(ok.safeName, 'body--Inter-Regular.otf'); }
  const head = validateFontUpload('Lora-Bold.otf', 24_576, 'headline');
  assert.equal(head.ok && head.safeName, 'headline--Lora-Bold.otf');
  const relabel = validateFontUpload('body--Lora-Bold.otf', 24_576, 'headline');
  assert.equal(relabel.ok && relabel.safeName, 'headline--Lora-Bold.otf', 'the chosen role replaces an old prefix');
  const prefixed = validateFontUpload('headline--Lora-Bold.otf', 24_576);
  assert.equal(prefixed.ok && prefixed.file.role, 'headline', 'a name that already carries its role needs no choice');
  const trial = validateFontUpload('Inter-Trial-Bold.otf', 54_204, 'body');
  assert.equal(trial.ok, false);
  if (!trial.ok) assert.match(trial.reason, /trial\/demo/);
  const noRole = validateFontUpload('Comic.ttf', 1000);
  assert.equal(noRole.ok, false);
  if (!noRole.ok) assert.match(noRole.reason, /headline or the body/);
  assert.equal(validateFontUpload('Inter-Regular.otf', 0, 'body').ok, false);
  assert.equal(validateFontUpload('Inter-Regular.otf', MAX_FONT_BYTES + 1, 'body').ok, false);
  assert.equal(validateFontUpload('Inter-Regular.pdf', 5000, 'body').ok, false);
  const pathy = validateFontUpload('../../etc/Inter Bold (1).otf', 5000, 'body');
  assert.equal(pathy.ok, true);
  if (pathy.ok) assert.equal(pathy.safeName, 'body--Inter_Bold__1_.otf', 'stored under a name with no path or odd characters');
});

test('coverage says which role still runs on a stand-in', () => {
  assert.deepEqual(coverage([]), { headline: null, body: null, standInFaces: ['headline', 'body'] });
  assert.deepEqual(coverage(['body--Inter-Regular.otf', 'body--Inter-Bold.otf']), { headline: null, body: 'Inter', standInFaces: ['headline'] });
  assert.deepEqual(coverage(['body--Inter-Trial-Bold.otf']).body, null, 'a trial build does not count');
  assert.deepEqual(coverage(['Inter-Regular.otf']).body, null, 'a file without a role does not count');
  assert.deepEqual(coverage(['headline--Lora-Regular.otf', 'body--Inter-Regular.otf']), { headline: 'Lora', body: 'Inter', standInFaces: [] });
});

test('a variable font file is recognised so the renderer can prefer the static weights', () => {
  assert.equal(isVariableFont('body--Inter-Variable.ttf'), true);
  assert.equal(isVariableFont('headline--Lora[wght].ttf'), true);
  assert.equal(isVariableFont('body--Inter-Regular.otf'), false);
  assert.equal(validateFontUpload('Inter-Variable.ttf', 40_000, 'body').ok, true, 'it is still accepted and listed');
});

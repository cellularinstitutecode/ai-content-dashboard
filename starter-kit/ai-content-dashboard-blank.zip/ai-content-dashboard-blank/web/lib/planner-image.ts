// web/lib/planner-image.ts
// What a weekly-planner post's picture should show, and the title it carries.
//
// THE LOOK. A bright, airy editorial photograph: someone from the brand in
// conversation with a customer across a light wooden table in window
// daylight, the topic told by what is on the table, a plain wall, a plant, a
// soft view outside — and ONE elegant serif title at the top ("The Importance
// of Nutrition", "Behind the Scenes") with a thin rule under it. Nothing else
// written on it.
//
// HOW WE GET THERE WITHOUT GARBLED LETTERS. Image models misspell. So the
// photograph is generated text-free and verified exactly as before, with the
// top third deliberately left as a calm wall; the title is then SET by our own
// renderer (lib/title-cover.ts) in the brand's serif. The words are exact,
// always, and the clean photograph is kept alongside for a re-title.
//
// WHY THE PILLAR DRIVES THE PICTURE. Without it every image came out as the
// same room: the first composition in STYLE_VARIANTS, every Autopilot draft
// starting at variant 0, and the Brand Brain's materials line pulling every
// frame into one interior. The pillar and angle now reach the image — for
// planner drafts only.
//
// INDUSTRY-AGNOSTIC. The weekly strategy's pillars are the deployment's own
// (lib/content-strategy.ts), so nothing here is keyed to a particular pillar.
// Each pillar is read for the KIND of picture it suits (food, a process, a
// product, people, everyday life, rest, a place, know-how) from the words in
// its id and name, and any pillar that names none of them gets the general
// set. PILLAR_SCENES, PILLAR_FAMILIES and FALLBACK_OBJECTS may still be given
// an entry under a pillar's exact id, which then wins.
//
// A draft with no weekly-strategy provenance (the Draft page, the Video
// Library, hand-written templates) returns null here and is pictured exactly as
// before.
//
// Pure: `./x.ts` imports only, so the test runner reads this file directly.
import { PILLARS } from './content-strategy.ts';
import { BLOG_SLOT } from './strategy-seed.ts';
import { BRAND_LOCATION } from './brand-identity.ts';
import type { SceneBrief } from './image-brief.ts';

/**
 * The kind of picture a theme suits. Read from the pillar's id and name
 * (kindOf below); 'general' when nothing in them points anywhere.
 */
export type SceneKind = 'general' | 'expertise' | 'craft' | 'product' | 'people' | 'lifestyle' | 'food' | 'rest' | 'place';

export type PlannerImage = {
  pillarId: string;
  pillarName: string;
  /** The kind of picture the pillar suits (kindOf). Missing on older objects: read from pillarId. */
  kind?: SceneKind;
  /** The week's angle — the picture's real subject. */
  subject: string;
  /** The words set on the cover. Short, exact (titleFor below). */
  title: string;
  /** Compositions to rotate through, one per attempt / "New image". */
  scenes: string[];
  /** Portrait: cropped to Instagram's 4:5 when the title is set. */
  size: '1024x1536';
  /** One line the vision checker uses to decide whether the picture is on topic. */
  mustShow: string;
  /**
   * Written from THIS post's text just before generation (lib/image-brief.ts).
   * When present it replaces the pillar's fixed scene and cue, so the picture
   * shows what the post is actually about.
   */
  dynamic?: SceneBrief;
  /**
   * True when the post's own body is genuinely about science — cells, tissue,
   * molecules, materials under a microscope. Only then is the science family
   * offered, so a post about a morning routine never comes back as a
   * microscope field.
   */
  science?: boolean;
  /**
   * The family the take being verified came from, stamped by lib/images.ts per
   * variant. The on-topic check reads it, because "show the objects the post
   * names" is the wrong question to ask of a microscopy frame.
   */
  shotFamily?: ShotFamily;
  /**
   * The team's notes for this take ("two women at a table, warmer light").
   * Stamped by lib/images.ts so the on-topic check judges the picture against
   * what was asked for, not only the pillar's fixed cue.
   */
  direction?: string;
};

/**
 * The photographic language of the planner look, in words an image model
 * follows. Replaces the Brand Brain's materials line for planner images; the
 * palette still grades the frame.
 */
export const PLANNER_PHOTOGRAPHY = [
  'Photographic style: a bright, airy editorial lifestyle photograph in soft natural daylight from a large window.',
  'Warm neutral tones — cream, sand, oat and soft grey; a light wooden table, pale stone and linen; one or two green plants in a ceramic pot;',
  'through the window, a soft-focus view of greenery.',
  'The person from the brand is dressed simply and neatly in plain, unbranded clothes, with a warm, attentive, approachable expression.',
  'The customer is seen three-quarter from behind or in soft profile, relaxed and engaged.',
  '35-50mm lens from slightly above eye level, shallow depth of field, realistic skin and hands, natural unposed moment.',
  'The mood is calm, premium and welcoming — never a waiting room or a reception desk.',
].join(' ');

/** The instruction that leaves room for the title the renderer sets later. */
export const TITLE_SPACE =
  'Composition rule (important): the upper 30% of the frame is EMPTY — a plain, softly lit neutral wall with nothing on it ' +
  '(no art, no shelves, no lamps, no signs, no objects) — because a title will be placed there afterwards. ' +
  'Everyone\'s head sits below that band. The table top and the key objects are in the lower third, LARGE, sharp and ' +
  'fully visible, well above the bottom edge — they tell the story, so they must never be small, blurred or cut off. Vertical framing.';

type SceneSet = { mustShow: string; scenes: string[] };

const TABLE = 'on the light wooden table between them';

/**
 * The fixed scenes per kind of theme. A key that is a pillar's exact id wins
 * over its kind (sceneSetFor), so a deployment can brief one pillar by hand.
 */
export const PILLAR_SCENES: Record<string, SceneSet> = {
  general: {
    mustShow: 'a warm, attentive conversation at a table — a notebook with blank pages and the objects the post talks about on the table',
    scenes: [
      `Two adults in a relaxed conversation across a table; one listens closely while the other explains with an open hand; a notebook with blank pages and two cups of coffee ${TABLE}; a small plant and daylight behind.`,
      `A person from the brand turning a blank tablet toward a customer to talk something through; the customer nods; a ceramic cup and a pen ${TABLE}.`,
      'Two people laughing easily mid-conversation at a sunlit table, a notebook with blank pages and a glass of water between them.',
    ],
  },
  expertise: {
    mustShow: 'someone explaining something clearly to one person — sketching on a blank notepad or pointing at the object being discussed',
    scenes: [
      `A person sketching a simple idea on a blank notepad and turning it toward the customer, both smiling slightly; ${TABLE}, two cups of tea.`,
      'A person explaining with a gentle hand gesture while the customer, a man in his 50s, listens thoughtfully; a blank tablet and reading glasses on the table.',
      `A person pointing with a pen at the object the post is about, set ${TABLE}; the customer leans in, interested.`,
    ],
  },
  craft: {
    mustShow: 'hands at work — the tools and materials of the craft the post describes, close and in sharp focus',
    scenes: [
      'Close view of a pair of skilled hands at work on a wooden workbench, the tools and raw materials of the job laid out neatly around them, window light raking across the surface.',
      'A person absorbed in their work at a bright workbench, sleeves rolled, the half-finished piece in front of them and their tools within reach.',
      'Two colleagues side by side at a work table, one showing the other a detail of the work in progress, both focused and relaxed.',
    ],
  },
  product: {
    mustShow: 'the thing the post presents, shown clearly on a table — unbranded, well lit, the clear subject of the frame',
    scenes: [
      'A clean editorial still life: the item the post presents on pale stone or linen in soft window light, a few related everyday objects beside it, generous empty space above.',
      `A person from the brand setting the item the post presents ${TABLE} in front of a customer, who reaches toward it with interest.`,
      'Hands unwrapping or holding up the item the post presents in warm daylight, plain unbranded packaging set aside.',
    ],
  },
  people: {
    mustShow: 'real people together — a small team or a customer and someone from the brand sharing a natural, warm moment',
    scenes: [
      'A small team of three gathered around a table in a bright room, mid-conversation and smiling, mugs and a notebook with blank pages in front of them.',
      'A person from the brand shaking hands warmly with a customer, both smiling; daylight and plants behind.',
      'Two people walking side by side and talking easily, seen in soft profile, warm daylight around them.',
    ],
  },
  lifestyle: {
    mustShow: 'everyday life done well — a person active and at ease, in light everyday clothes or activewear, outdoors or by a window',
    scenes: [
      'A person in light activewear and sneakers chatting at a table by a window, a water bottle beside them; through the window, a tree-lined path.',
      'A person standing by an open door to a garden path, holding a water bottle and a small towel, laughing easily.',
      'Two friends in comfortable clothes talking at a table, a rolled mat and a water bottle beside them, bright daylight.',
    ],
  },
  food: {
    mustShow: 'the food or drink the post talks about, on the table — fresh, real and clearly visible',
    scenes: [
      `Two people in conversation over a small spread of fresh food ${TABLE} — a bowl of berries, sliced avocado, bread and a carafe of water.`,
      `A person pointing at a balanced plate ${TABLE} while the other smiles; a bowl of citrus in the foreground.`,
      'An editorial still life of fresh ingredients on a wooden board in window light — greens, grains, fruit — with a linen napkin beside it.',
    ],
  },
  rest: {
    mustShow: 'calm and rest cues — a cup of herbal tea, a soft throw, gentle evening light, a relaxed person',
    scenes: [
      `A calm moment in soft late-afternoon golden light; a cup of herbal tea and a small bunch of lavender ${TABLE}; one person relaxed with shoulders down as the other speaks gently.`,
      'A person holding a warm mug with both hands, curled in an armchair with a linen throw, looking out of a window full of greenery.',
      'Two people sitting side by side on a linen sofa in a quiet corner, a cup of tea on a side table, warm dusk light through sheer curtains.',
    ],
  },
  place: {
    mustShow: 'the brand\'s surroundings — the window or terrace behind the people shows the local view: streets, landscape or water',
    scenes: [
      'A bright table beside a large window that opens onto the local view; two people talk across it; a bowl of seasonal fruit on the table.',
      'Two people seated on a shaded terrace overlooking the local landscape, two glasses of water on a small table between them.',
      'A visitor with a small travel bag beside the chair, smiling as they are welcomed; through the window, the local view in soft focus.',
    ],
  },
};

/** Which words in a pillar's id or name point to which kind. First match wins. */
const KIND_RULES: [SceneKind, RegExp][] = [
  ['food', /\b(food|foods|nutrition|nutritional|recipes?|meals?|cook\w*|kitchen|eat\w*|drinks?|coffee|tea|bak\w*|menu|diet\w*|snacks?)\b/i],
  ['rest', /\b(sleep\w*|rest|restful|stress|calm|relax\w*|mindful\w*|recover\w*|unwind\w*|self-care)\b/i],
  ['place', /\b(place|local|city|neighbou?rhood|destination|travel\w*|tourism|location|visit\w*|region)\b/i],
  ['lifestyle', /\b(lifestyle|active|living|movement|fitness|exercise|sports?|outdoors?|wellness|well-being|wellbeing|habits?|routines?|everyday|daily)\b/i],
  ['people', /\b(people|team|community|customers?|clients?|stor(?:y|ies)|testimonials?|culture|founders?|faces|members?|partners?)\b/i],
  ['craft', /\b(behind|scenes|process|craft\w*|making|made|workshop|studio|production|build\w*|design\w*)\b/i],
  ['product', /\b(products?|offers?|offering|services?|launch\w*|features?|showcase|collections?|catalog(?:ue)?|new)\b/i],
  ['expertise', /\b(tips?|how|guides?|educat\w*|learn\w*|advice|expert\w*|faqs?|myths?|questions?|insights?|explain\w*|basics|knowledge|plan\w*|personali[sz]\w*|assess\w*|prevent\w*|follow-?up)\b/i],
];

const KINDS = new Set<SceneKind>(['general', 'expertise', 'craft', 'product', 'people', 'lifestyle', 'food', 'rest', 'place']);

/** The kind of picture a pillar suits, from the words in its id and/or name. */
export function kindOf(...parts: unknown[]): SceneKind {
  const text = parts.map((p) => String(p ?? '')).join(' ').replace(/[-_]+/g, ' ').trim();
  if (KINDS.has(text as SceneKind)) return text as SceneKind;
  for (const [kind, re] of KIND_RULES) if (re.test(text)) return kind;
  return 'general';
}

/** The fixed scenes for a pillar: its own entry first, then its kind's, then the general set. */
export function sceneSetFor(pillar: { id: string; name?: string } | null | undefined): SceneSet {
  if (!pillar) return PILLAR_SCENES.general;
  return PILLAR_SCENES[pillar.id] || PILLAR_SCENES[kindOf(pillar.id, pillar.name)] || PILLAR_SCENES.general;
}

/**
 * Hand-written cover titles, keyed by the exact angle they belong to.
 *
 * Empty in the template: a deployment may add one per angle its strategy lists
 * when the angle itself would make a clumsy cover ("Why effective care begins
 * with a thorough evaluation" → "Care Begins with Evaluation"). They appear in
 * large type on the picture, so each should be a few words, title case, no
 * claim. Without one, a short angle is its own title and a long one falls back
 * to the pillar's own name, title-cased (titleFor).
 */
export const TITLES: Record<string, string> = {};

/** The longest angle that is used as its own cover title. */
export const MAX_ANGLE_TITLE = 40;

function key(s: unknown): string {
  return String(s ?? '').trim().toLowerCase().replace(/\s+/g, ' ');
}

/** Strip the "[Autopilot] " prefix the draft's topic column carries. */
export function cleanTopic(topic: unknown): string {
  return String(topic ?? '').replace(/^\s*\[autopilot\]\s*/i, '').trim();
}

const SMALL_WORDS = new Set(['a', 'an', 'and', 'as', 'at', 'but', 'by', 'for', 'in', 'nor', 'of', 'on', 'or', 'the', 'to', 'vs', 'vs.', 'with']);

/** "the role of protein in recovery" → "The Role of Protein in Recovery". Words already capitalised are kept. */
export function titleCase(s: string): string {
  return String(s || '')
    .trim()
    .replace(/[.!?:;,]+$/, '')
    .split(/\s+/)
    .map((w, i) => (i > 0 && SMALL_WORDS.has(w.toLowerCase()) ? w.toLowerCase() : w.charAt(0).toUpperCase() + w.slice(1)))
    .join(' ');
}

/**
 * The cover title for an angle: the hand-written one when TITLES has it; the
 * angle itself, title-cased, when it is short enough for a cover; otherwise
 * the pillar's name, title-cased ("Customer Stories").
 */
export function titleFor(angle: unknown, pillarName: string): string {
  const a = cleanTopic(angle);
  const written = TITLE_BY_KEY().get(key(a));
  if (written) return written;
  if (a && a.length <= MAX_ANGLE_TITLE && !/\?$/.test(a)) return titleCase(a);
  return titleCase(pillarName) || 'Worth Knowing';
}

// Read lazily so a deployment that fills TITLES at start-up is honoured.
function TITLE_BY_KEY(): Map<string, string> {
  return new Map(Object.entries(TITLES).map(([a, t]) => [key(a), t]));
}

/** Longer than this is a sentence, not a cover title (same ceiling as lib/library-cover.ts). */
export const MAX_COVER_TITLE = 60;

/**
 * The framings a repeated title steps through, so the second post on an angle
 * — or a second long angle of the same pillar, which shares the fallback —
 * does not wear the same cover as the first. Short and claim-free; each works
 * on any noun phrase.
 */
export const TITLE_FRAMINGS: ((t: string) => string)[] = [
  (t) => `A Closer Look at ${t}`,
  (t) => `${t}, Revisited`,
  (t) => `More on ${t}`,
  (t) => `${t} in Practice`,
  (t) => `Notes on ${t}`,
];

/**
 * The title for the `seq`-th occurrence of the same cover title: the written
 * one first (seq 0), then a different framing each time round. A framing that
 * runs past the cover's width falls back to the next shorter one.
 */
export function variedTitle(base: string, seq: number): string {
  const t = String(base || '').trim();
  const n = Math.max(0, Math.round(Number(seq) || 0));
  if (!t || n === 0) return t;
  const order = TITLE_FRAMINGS.slice((n - 1) % TITLE_FRAMINGS.length).concat(TITLE_FRAMINGS.slice(0, (n - 1) % TITLE_FRAMINGS.length));
  for (const frame of order) {
    const out = frame(t);
    if (out.length <= MAX_COVER_TITLE) return out;
  }
  return t;
}

/**
 * How many earlier occurrences already wore this angle's cover title. Counted
 * by TITLE, not by angle: two long angles of one pillar both fall back to the
 * pillar's name, and that repeat is the one the team noticed.
 */
export function titleSeq(angle: unknown, pillarName: string, history: readonly ({ query?: unknown } | null | undefined)[]): number {
  const mine = titleFor(angle, pillarName);
  return history.filter((h) => h && titleFor(h.query, pillarName) === mine).length;
}

/**
 * The picture brief for a draft, read from its `_autopilot` provenance.
 * Null when the draft did not come from a weekly-strategy slot.
 */
export function plannerImageFor(pack: unknown): PlannerImage | null {
  const auto = (pack && typeof pack === 'object' ? (pack as Record<string, unknown>)._autopilot : null) as
    | { template_name?: unknown; slot?: unknown; pillar_id?: unknown; title_seq?: unknown; angle?: { query?: unknown; seedTopic?: unknown; titleSeq?: unknown } }
    | null
    | undefined;
  if (!auto || typeof auto !== 'object') return null;
  const name = key(auto.template_name);
  const subject = cleanTopic(auto.angle?.query || auto.angle?.seedTopic);
  if (!name || !subject) return null;
  // Which occurrence of this cover title the post is (lib/autopilot.ts stamps
  // it from the template's approved history); 0 or missing keeps titleFor.
  const seq = Math.max(0, Math.round(Number(auto.title_seq ?? auto.angle?.titleSeq) || 0));
  if (name === key(BLOG_SLOT.name) || key(auto.slot) === 'mon-blog') {
    // The article's angles are borrowed from the pillars; picture it as the
    // pillar it came from, or with the general set when it came from none.
    const pillar = PILLARS.find((p) => p.angles.some((a) => key(a) === key(subject)));
    const set = sceneSetFor(pillar);
    const kind = pillar ? kindOf(pillar.id, pillar.name) : 'general';
    return { pillarId: 'article', pillarName: BLOG_SLOT.name, kind, subject, title: variedTitle(titleFor(subject, pillar?.name || ''), seq), ...set, size: '1024x1536' };
  }
  // The stamped pillar first: it survives a rename. The name is the fallback
  // for drafts written before the stamp existed.
  const pillar = PILLARS.find((p) => p.id === String(auto.pillar_id || '')) || PILLARS.find((p) => key(p.name) === name);
  if (!pillar) return null;
  const set = sceneSetFor(pillar);
  return { pillarId: pillar.id, pillarName: pillar.name, kind: kindOf(pillar.id, pillar.name), subject, title: variedTitle(titleFor(subject, pillar.name), seq), ...set, size: '1024x1536' };
}

/** The kind a planner image is pictured as: its stamp, else read from its pillar id. */
function kindOfImage(p: Pick<PlannerImage, 'pillarId'> & { kind?: SceneKind | null }): SceneKind {
  return p.kind && KINDS.has(p.kind) ? p.kind : kindOf(p.pillarId);
}

/**
 * THE SHOT LIBRARY.
 *
 * One fixed composition made every post look like the last one: the same
 * person at the same table, every week. A real editorial feed varies the shot
 * — a still life, a detail of hands, a candid moment, a wide room — while the
 * light, palette and craft hold it together. Each post picks its shot from its
 * own title (so two posts rarely share one) and "New image" moves to the next.
 *
 * THE FOUR FAMILIES.
 *
 *   consult  ~50%   the conversation: someone from the brand with a customer
 *   science  ~25%   real microscopy and real lab work (topic-gated)
 *   active   ~15%   the outcome: a person living well
 *   still    ~10%   the objects the post itself names
 *
 * The conversation is the spine — it is what a brand that talks with its
 * customers owns — but on its own it reads soft, so the other three carry the
 * rest.
 */
export type ShotFamily = 'consult' | 'science' | 'active' | 'still';

export type Shot = {
  id: string;
  /**
   * What the picture reads as at a glance. Three shots can all be "two people
   * at a table" and still look like one photograph repeated, so the rotation
   * below steps through FAMILIES before it steps within one.
   */
  family: ShotFamily;
  /** True when people appear — the headroom rule and casting only matter then. */
  people: boolean;
  lines: (ctx: ShotContext) => string[];
};

type ShotContext = { objects: string; foreground: string; action: string; windowView: string; cast: Cast; subject: string };

/** host: the person from the brand. guest: the customer they are with. */
type Cast = { host: string; guest: string };

/** Casting varies with the post, so the feed is not one model over and over. */
const HOSTS = [
  'a woman in her early 40s, dark wavy shoulder-length hair, tailored ivory blazer over a soft beige blouse, fine gold necklace',
  'a man in his late 40s, salt-and-pepper close-cropped hair, light grey knit polo under an unstructured cream jacket, no tie',
  'a woman in her mid 50s, Black, short natural hair, camel silk shirt and slim tortoiseshell glasses',
  'a man in his mid 30s, Asian, neat dark hair, pale blue oxford shirt with the sleeves rolled, no jacket',
  'a woman in her late 30s, fair-skinned with light-brown hair in a low twist, stone-coloured linen blazer',
];
const GUESTS = [
  'a woman in her 60s with short silver hair and a cream linen shirt',
  'a man in his 50s, broad-shouldered, in a soft olive sweater',
  'a woman in her 40s, long dark hair, in an oatmeal knit',
  'a man in his 70s, thin silver hair, pale blue shirt, relaxed and curious',
  'a woman in her 30s, athletic, hair tied back, in a sand-coloured sweatshirt',
];

/** The craft: what separates an editorial photograph from an obvious AI render. */
export const CRAFT = [
  'CRAFT: shot for a premium lifestyle magazine — Leica 50mm at f/2 on medium-format digital, natural window light through a large diffusion scrim,',
  'gentle falloff into soft shadow, true-to-life colour with a warm neutral grade, fine natural grain, a touch of optical halation in the highlights.',
  'Real skin with visible texture, pores and fine lines; no beauty retouching, no plastic sheen, no over-sharpening, no HDR.',
  'Nobody grins at the camera: expressions are quiet, warm and mid-moment, eyes usually off-camera. No stock-photo posing, no thumbs-up, no crossed arms.',
  'Clean, uncluttered set dressing: EVERY object in frame comes from what the post itself talks about. No decorative filler —',
  'no bowl of fruit, no flowers, no props added merely to fill the corner, unless the post is about them.',
  'NO RENDERS: every frame is a photograph taken with a camera. No 3D renders, no illustrations, no glowing or neon shapes, no bloom, ',
  'no lens flare, no floating particles, no DNA helices, no digital overlays — the look every competitor already has.',
  'NOTHING ATTACHED TO ANYONE: no medical device is worn by, strapped to, clipped to or connected to a person, and none is held as though it ',
  'were being given. No blood-pressure cuff on an arm, no ECG leads or electrodes, no pulse oximeter on a finger, no IV line, drip, cannula or ',
  'port, no glucose monitor or patch, no syringe, injector pen, vial or ampoule in anyone\'s hand, no oxygen mask or cannula, no bandage or ',
  'dressing. A device may rest ON THE TABLE, unused and not connected to anybody. This is a conversation, never a procedure.',
  'REAL THINGS ONLY: this is editorial photography, not a classroom. Everything in frame is an ordinary real object — real food, real cups,',
  'real paper, real linen. Absolutely no anatomical models, plastic organs, model brains, hearts or spines, skeletons, skulls, mannequins,',
  'torso models or other teaching props; no charts, posters, diagrams, illustrations or infographics of any kind.',
  'COLOUR: neutral white balance, daylight-accurate skin tones, a calm cream-and-oat palette with pale sage and soft grey-green;',
  'any strong brand colour appears only as the smallest accent, if at all. No orange cast, no amber filter, no heavy golden-hour wash, no sepia.',
].join(' ');

/** The world every shot lives in. */
const WORLD = 'THE PLACE: a calm, light-filled space that suits the brand and the subject — soft off-white and oat walls, pale wood furniture, ' +
  'linen and light stone, a few living green plants, tall windows with sheer curtains and clear daylight. Palette: white, cream, oat, pale sage and ' +
  'light grey-green, with wood as the only warm tone.';

/** The band the title needs, worded for the shot at hand. */
const titleBand = (people: boolean) =>
  'TITLE SPACE: the upper third of the frame is quiet, softly lit wall or empty background with nothing in it — a title is set there afterwards.' +
  (people ? ' The top of every head sits at least 35% of the way down the frame; pull the camera back rather than crop.' : '');

export const SHOTS: Shot[] = [
  {
    id: 'conversation',
    family: 'consult',
    people: true,
    lines: (c) => [
      'SHOT: an over-the-shoulder conversation at a table, vertical.',
      `FOREGROUND RIGHT, large and softly out of focus, seen from behind: the customer — ${c.cast.guest}.`,
      `ACROSS THE LIGHT WOODEN TABLE, centre-left: the person from the brand — ${c.cast.host} — mid-sentence, ${c.action}.`,
      `ON THE TABLE, clearly visible and sharp: ${c.objects}. In the lower-left foreground, slightly soft: ${c.foreground}.`,
      `BEHIND, LEFT: a tall window with warm afternoon light and a soft-focus view of ${c.windowView}.`,
    ],
  },
  {
    id: 'still-life',
    family: 'still',
    people: false,
    lines: (c) => [
      'SHOT: an editorial still life, no people at all, vertical.',
      `THE SUBJECT, arranged with restraint on pale stone or linen in low raking window light: ${c.objects}, with ${c.foreground} just behind.`,
      'Shallow depth of field, long soft shadows falling to the right, a few crumbs, drops or fallen leaves left where they fell — real, not styled to death.',
      'The background is a plain warm wall falling into shadow toward the top of the frame.',
    ],
  },
  {
    id: 'hands',
    family: 'consult',
    people: true,
    lines: (c) => [
      'SHOT: a close detail across the table, vertical. Two pairs of adult hands — the brand person\'s and the customer\'s — no faces in frame, or only a jaw and a shoulder at the very edge.',
      `THE ACTION, filling the lower two-thirds: the brand person's hands ${c.action}, with ${c.objects} on the light wooden table between them and ${c.foreground} nearby; the customer's hands rest at the edge of frame, listening.`,
      'Skin is real — knuckles, veins, a ring; a cuff of a plain shirt at one wrist. The movement is caught mid-gesture, slightly soft at the edges.',
      'Above the hands, the frame opens into plain sunlit tabletop and wall.',
    ],
  },
  {
    id: 'candid',
    family: 'active',
    people: true,
    lines: (c) => [
      'SHOT: a candid lifestyle moment in everyday life, vertical — this is the customer\'s own life, not a business setting.',
      `THE PERSON: ${c.cast.guest}, absorbed in what they are doing, unaware of the camera, in a home, kitchen, garden or street that suits "${c.subject}".`,
      `IN FRAME WITH THEM, unmistakable: ${c.objects}; ${c.foreground} nearby.`,
      'Natural daylight, honest everyday setting, nothing staged.',
    ],
  },
  {
    id: 'environment',
    family: 'consult',
    people: true,
    lines: (c) => [
      'SHOT: a wide environmental frame of the space, vertical, people small within it.',
      `IN THE LOWER HALF: the person from the brand — ${c.cast.host} — and the customer — ${c.cast.guest} — seated at a table, talking, ${c.action}.`,
      `On the table, catching the light: ${c.objects}; ${c.foreground} in the near foreground, out of focus.`,
      `The room breathes around them: tall windows onto ${c.windowView}, sheer curtains moving, plants, warm shadow across the upper wall.`,
    ],
  },
  {
    id: 'portrait',
    family: 'consult',
    people: true,
    lines: (c) => [
      'SHOT: a three-quarter editorial portrait, vertical, the subject turned slightly away and looking out of frame.',
      `THE SUBJECT: ${c.cast.host}, caught in a quiet moment of thought, one hand resting near ${c.objects} on the table.`,
      `Just behind, softly out of focus: ${c.foreground} and a window with a view of ${c.windowView}.`,
      'A single soft key light from the window, shadow falling gently across the wall above.',
    ],
  },
  {
    id: 'flat-lay',
    family: 'still',
    people: false,
    lines: (c) => [
      'SHOT: an overhead flat lay on a pale linen or light wooden surface, no people at all, vertical.',
      `LAID OUT IN THE LOWER TWO-THIRDS, shot straight down, evenly spaced with generous space between them: ${c.objects}, with ${c.foreground} at one edge.`,
      'Soft diffused daylight from one side, gentle shadows, nothing stacked or crowded, the arrangement calm rather than decorative.',
      'The upper third is bare surface — no object crosses into it.',
    ],
  },
  {
    id: 'microscopy',
    family: 'science',
    people: false,
    lines: () => [
      'SHOT: a PHOTOGRAPH taken down a laboratory microscope — a phase-contrast photomicrograph, captured with a camera on the eyepiece, vertical.',
      'THE FIELD, filling the lower two-thirds: the specimen the post discusses at about 100x — for living cells, slender spindle and rounded shapes lying '
        + 'flat in the plane of the dish, each with a darker nucleus and fine texture; for a material, its real fibres, grains or crystals. '
        + 'Density uneven, orientation random, a little debris — a real slide, not a pattern.',
      'The optics are honest: a shallow plane of focus so the specimen drifts soft toward the edges, faint halo fringing the way phase contrast '
        + 'actually renders it, slight chromatic softness at the corners, the gentle circular vignette of the objective.',
      'Colour: near-monochrome cool grey with the faintest warm cast. Nothing saturated, nothing glowing.',
      'IT IS NOT A PICTURE OF CELLS — it is a photograph of a microscope field. No 3D rendering, no illustration, no embossed or raised relief, no smooth '
        + 'plastic shapes, no glow, no bloom, no lens flare, no floating spheres in empty space, no scale bar, no labels, no arrows, no colour overlay.',
      'The upper third is plain, even, out-of-focus field — empty and quiet.',
    ],
  },
  {
    id: 'lab-bench',
    family: 'science',
    people: true,
    lines: (c) => [
      'SHOT: a working laboratory, vertical, documentary rather than staged.',
      `IN THE LOWER HALF: a researcher — ${c.cast.host} — in a white coat, hair tied back, blue nitrile gloves, `
        + 'holding a clear culture plate or a flask up to the light of an open laminar-flow hood, reading it, absorbed.',
      'Around them: brushed stainless, white bench, a closed incubator, a rack of clean unlabelled glassware, a microscope at the edge of frame.',
      'Cool even laboratory light, clean whites, no colour cast. No needles, no syringes, no blood, no ampoules, nothing labelled, no packaging, no branding.',
      'The upper third is plain clean wall or the flat face of a cabinet — nothing in it.',
    ],
  },
  {
    id: 'active-life',
    family: 'active',
    people: true,
    lines: (c) => [
      'SHOT: everyday life done well, vertical, outdoors in daylight — the outcome the post is about, lived.',
      `THE PERSON, in the lower two-thirds: ${c.cast.guest}, moving easily and unaware of the camera — walking a waterside path, `
        + `cycling, stretching after a walk, or carrying something up a few steps — whichever best suits "${c.subject}".`,
      'Real clothes, real weather, mid-stride, caught rather than posed. They look capable, not triumphant; no arms raised, no leaping, no fists in the air.',
      'Natural light, open air, a soft-focus background of water, trees, park or quiet street.',
      'The upper third opens into plain sky or distant water — uncluttered.',
    ],
  },
];

/** How many distinct shots a reroll can walk through. */
export const SHOT_COUNT = SHOTS.length;

/**
 * WHICH FAMILY EACH SLOT GETS, per kind of theme (or per exact pillar id).
 *
 * Slot 0 is always a conversation, so the safe pick is always on the table.
 * Each list below is the order for the slots AFTER that one, and running the
 * four slots of a typical post through it is what produces the ~50/25/15/10
 * weighting.
 */
export const PILLAR_FAMILIES: Record<string, ShotFamily[]> = {
  // Know-how, process and product themes: the objects first.
  general: ['still', 'consult', 'active'],
  expertise: ['still', 'consult', 'active'],
  craft: ['still', 'consult', 'active'],
  product: ['still', 'consult', 'active'],
  food: ['still', 'consult', 'active'],
  rest: ['still', 'active', 'consult'],
  // The living themes: the outcome, not the room.
  lifestyle: ['active', 'consult', 'still'],
  people: ['active', 'consult', 'still'],
  place: ['active', 'consult', 'still'],
};

const DEFAULT_FAMILIES: ShotFamily[] = ['still', 'consult', 'active'];

/**
 * The post's own body has to earn a science picture. Without this gate a post
 * about a daily walk comes back as a microscope field, which is both wrong and
 * the kind of overclaim no brand wants to publish.
 */
const SCIENCE_TERMS: RegExp[] = [
  /\bcell(?:s|ular)?\b/i,
  /\bstem[- ]cells?\b/i,
  /\bmolecul/i,
  /\btissues?\b/i,
  /\bmitochondri/i,
  /\bcollagen\b/i,
  /\binflammat/i,
  /\bimmune\b|\bimmunity\b/i,
  /\bbacteria\b|\bmicrob(?:e|es|ial|iome)\b/i,
  /\bproteins?\b.*\b(?:structure|synthesis|fold)/i,
  /\benzymes?\b|\bhormones?\b/i,
  /\bmicroscop/i,
  /\bbiomarkers?\b/i,
  /\bmuscle repair\b|\bcell repair\b/i,
];

/** How many distinct science ideas the post actually raises. */
export function scienceScore(text: unknown): number {
  const t = String(text ?? '');
  return SCIENCE_TERMS.reduce((n, re) => n + (re.test(t) ? 1 : 0), 0);
}

/**
 * Is this post ABOUT the science, rather than merely mentioning it?
 *
 * One passing word is not enough. A post about a daily walk that happens to
 * say "muscle" came back as a microscope field, which illustrates nothing the
 * reader is there for — so the science slot needs at least two distinct
 * scientific ideas in the post's own text before it is offered at all.
 */
export function scienceAllowed(text: unknown): boolean {
  return scienceScore(text) >= 2;
}

/**
 * The lifestyle kinds. Their picture is daily life and the conversation, never
 * a laboratory: a lab technician on a sleep post and cells on a stress post
 * both passed the check once.
 */
const LIFESTYLE_KINDS = new Set<SceneKind>(['food', 'rest', 'lifestyle', 'people', 'place']);

/** Is this pillar (an id, a name, or a SceneKind) a lifestyle theme? */
export function isLifestylePillar(pillar: unknown): boolean {
  return LIFESTYLE_KINDS.has(kindOf(pillar));
}

/** May a science (lab or microscope) frame be offered? Never for a lifestyle theme. */
export function scienceOffered(pillar: unknown, text: unknown): boolean {
  return !isLifestylePillar(pillar) && scienceAllowed(text);
}

/**
 * The family for one step of the rotation. Slot 0 is always a conversation;
 * later slots follow the theme's order, and a science slot falls back to the
 * still life whenever the post never earned it.
 */
export const PLAN_LENGTH = 4;

export function familyAt(p: Pick<PlannerImage, 'pillarId' | 'science'> & { kind?: SceneKind | null }, sceneIndex: number): ShotFamily {
  // The plan repeats every four takes. Without the wrap, a draft that had been
  // rerolled a dozen times walked off the end of its own plan and never reached
  // the outcome shot or the science slot again.
  const step = Math.abs(Math.round(sceneIndex)) % PLAN_LENGTH;
  if (step === 0) return 'consult';
  const order = PILLAR_FAMILIES[p.pillarId] || PILLAR_FAMILIES[kindOfImage(p)] || DEFAULT_FAMILIES;
  // The third take is the science slot whenever the post has earned it
  // (`science`, which scienceOffered never sets for a lifestyle theme). The
  // theme's table fills the rest.
  if (step === 2) return p.science ? 'science' : order[1 % order.length];
  // The fourth take comes back to the room. Two conversations in every four
  // is the ~50% the plan asks for, and it means a reroll past the science or
  // the still life always has somewhere safe to land.
  if (step === 3) return 'consult';
  const want = order[(step - 1) % order.length];
  return want === 'science' && !p.science ? 'still' : want;
}

/**
 * The shot itself. Within a family the choice walks forward with each lap, so a
 * fourth or fifth take is a different picture rather than the one just
 * rejected.
 */
export function shotFor(seedBase: number, sceneIndex: number, family: ShotFamily): Shot {
  const pool = SHOTS.filter((sh) => sh.family === family);
  const step = Math.abs(Math.round(sceneIndex));
  if (!pool.length) return SHOTS[Math.abs(seedBase + step) % SHOTS.length];
  const lap = Math.floor(step / 3);
  return pool[Math.abs(seedBase + step + lap) % pool.length];
}

/** A stable number from the post's own title, so different posts get different shots. */
export function seedOf(text: string): number {
  let h = 0;
  for (const ch of String(text || '')) h = (h * 31 + ch.charCodeAt(0)) % 100000;
  return h;
}

/** When no brief could be written: the theme's own objects and gesture (per kind, or per exact pillar id). */
export const FALLBACK_OBJECTS: Record<string, { table: string[]; foreground: string; action: string }> = {
  general: { table: ['a notebook with blank pages', 'two cups of coffee'], foreground: 'a small potted plant', action: 'listening closely, a pen resting on the blank notebook' },
  expertise: { table: ['a notepad with blank pages', 'a pen', 'two cups of tea'], foreground: 'a small potted plant', action: 'sketching on the blank notepad and turning it toward the customer' },
  craft: { table: ['the tools of the trade laid out neatly', 'a piece of work in progress'], foreground: 'a stack of raw materials', action: 'showing a detail of the work in progress' },
  product: { table: ['the item the post presents, unbranded', 'a folded linen cloth'], foreground: 'a small potted plant', action: 'setting the item down gently in front of the customer' },
  people: { table: ['two mugs of coffee', 'a notebook with blank pages'], foreground: 'a small potted plant', action: 'laughing easily mid-conversation' },
  lifestyle: { table: ['a water bottle', 'a pair of walking shoes', 'a folded towel'], foreground: 'a rolled mat', action: 'describing a morning walk with an open hand' },
  food: { table: ['a balanced plate of fresh food', 'a carafe of water'], foreground: 'a bowl of seasonal fruit', action: 'pointing at the plate' },
  rest: { table: ['a cup of herbal tea', 'a small bunch of lavender'], foreground: 'a folded linen throw', action: 'speaking gently, hands around a warm cup' },
  place: { table: ['two glasses of water', 'a small folded map with no writing'], foreground: 'a small potted plant', action: 'gesturing toward the view beyond the window' },
};

export function plannerPromptLines(p: PlannerImage, sceneIndex: number, direction?: string | null, family?: ShotFamily | null): string[] {
  const dir = String(direction || '').trim();
  const d = p.dynamic;
  const kind = kindOfImage(p);
  const fb = FALLBACK_OBJECTS[p.pillarId] || FALLBACK_OBJECTS[kind] || FALLBACK_OBJECTS.general;
  const objects = (d ? (d.props.length > 1 ? d.props.slice(1) : d.props) : fb.table).join(', ');
  const foreground = d && d.props.length > 1 ? d.props[0] : fb.foreground;
  const action = d ? d.scene.replace(/^(the )?(host|person from the brand|expert|physician|clinician) (is )?/i, '').replace(/\.$/, '') : fb.action;
  const windowView = kind === 'place'
    ? (BRAND_LOCATION ? `the local landscape around ${BRAND_LOCATION}` : 'the local streets and landscape')
    : 'green trees and soft hills';
  // The shot rotates with the post itself, not only with rerolls — one fixed
  // composition made every week's picture look like the last one. A cover
  // with its title turned off is seeded from the subject instead.
  const label = p.title || p.subject;
  const seed = seedOf(label + p.pillarName) + Math.abs(Math.round(sceneIndex));
  const shot = shotFor(seedOf(label + p.pillarName), sceneIndex, family || familyAt(p, sceneIndex));
  const cast: Cast = {
    host: HOSTS[seed % HOSTS.length],
    guest: GUESTS[(seed + 2) % GUESTS.length],
  };
  const ctx: ShotContext = { objects, foreground, action, windowView, cast, subject: p.subject };
  const objectLed = shot.family === 'consult' || shot.family === 'still';
  return [
    objectLed
      ? `Subject: a photograph for an educational post titled "${label}" (the weekly "${p.pillarName}" theme, on "${p.subject}"). It must clearly show ${d ? d.mustShow : p.mustShow}.`
      : `Subject: a photograph for an educational post titled "${label}" (the weekly "${p.pillarName}" theme, on "${p.subject}"). The frame below is the subject — do not add the objects the post names to it.`,
    objectLed && d?.quote ? `It illustrates this line from the post: "${d.quote}" — everything in frame comes from that.` : '',
    dir ? `Direction from the team (follow this closely, within the frame below): ${dir}` : '',
    ...shot.lines(ctx),
    titleBand(shot.people),
    WORLD,
    CRAFT,
  ].filter(Boolean);
}

/** The extra check the vision reviewer runs on a planner image. */
export function onTopicCheck(p: PlannerImage): string {
  const tail =
    'Also a DEFECT: anything in the top third, where a title will sit — a person\'s head or face, art, shelves, lamps or busy objects. ' +
    'Also a DEFECT: an anatomical model or teaching prop — a plastic brain, heart, spine, skeleton, skull, torso or mannequin — ' +
    'an anatomical chart, poster, diagram or illustration, or a pill, supplement, vitamin or medicine bottle, a blister pack or loose ' +
    'tablets. Set "onTopic": false when any of these fails.';
  // Lifestyle themes: no laboratory, and the brand's own style is preferred.
  const lab = isLifestylePillar(kindOfImage(p))
    ? 'Also a DEFECT for this lifestyle theme: a laboratory scene — a microscope, cells or a microscope field, pipettes, test tubes, ' +
      'petri dishes, vials or sample tubes, a lab bench, or a technician in a lab coat. The preferred picture is a bright, warm-neutral ' +
      'conversation or everyday moment where the topic is visible, with room for a short title only. '
    : '';
  // The team wrote what they want: the picture is on topic when it does THAT
  // and still plausibly belongs to the post. Without this a note like "no lab
  // coat, show fresh vegetables" was checked against the pillar's fixed cue
  // and refused for following the note.
  const dir = String(p.direction || '').trim();
  if (dir) {
    return `ON-TOPIC (this one is a DEFECT, not an opinion): the team asked for this picture in their own words — "${dir.slice(0, 300)}" — ` +
      `and the image must follow that; it is on topic when it does, provided it still plausibly illustrates "${p.subject}". ` +
      'A generic reception desk, front desk or waiting room does NOT count. ' + tail;
  }
  if (p.shotFamily === 'science') {
    return 'ON-TOPIC (this one is a DEFECT, not an opinion): the image must be a believable REAL laboratory photograph — either a genuine ' +
      'microscope field of the specimen, or a researcher working at a lab bench. A DEFECT: rendered or illustrated cells, glowing or ' +
      'neon spheres, bloom, lens flare, floating particles, a DNA helix, or any 3D-looking graphic in place of a photograph. ' +
      'Also a DEFECT: needles, syringes, ampoules, blood, or anything that reads as a medical procedure. ' + tail;
  }
  if (p.shotFamily === 'active') {
    return 'ON-TOPIC (this one is a DEFECT, not an opinion): the image must show a real person outdoors in daylight, moving easily and ' +
      'living normally — not an office, not a shop counter, not a medical setting. A DEFECT: any clinical room, equipment, uniform or ' +
      'procedure in frame, and any triumphant pose — raised arms, leaping, fists in the air. ' + lab + tail;
  }
  return `ON-TOPIC (this one is a DEFECT, not an opinion): the image must clearly show ${p.dynamic ? p.dynamic.mustShow : p.mustShow}. ` +
    'A generic reception desk, front desk or waiting room does NOT count. ' + lab + tail;
}

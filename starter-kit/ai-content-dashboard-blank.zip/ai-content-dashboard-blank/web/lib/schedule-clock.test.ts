import { test } from 'node:test';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { scheduleTz, scheduleTzLabel, schedulePresetValue, DEFAULT_SCHEDULE_TZ, scheduleInputValue, scheduleInstantFromInput } from './schedule-clock.ts';
import { DEFAULT_TIMEZONE } from './timezone.ts';

// The zone the root layout stamps on <html data-schedule-tz>. A fixed UTC-5
// zone with no DST, so the expectations below are arithmetic. Tests that need
// it set it explicitly and put the page back afterwards.
const UTC5 = 'America/Bogota';
function withStampedZone<T>(tz: string, fn: () => T): T {
  const g = globalThis as { document?: unknown };
  const had = 'document' in g;
  const prev = g.document;
  g.document = { documentElement: { dataset: { scheduleTz: tz } } };
  try { return fn(); } finally { if (had) g.document = prev; else delete g.document; }
}

test('the timezone label is a city, not an IANA path', () => {
  assert.equal(scheduleTzLabel('America/Bogota'), 'Bogota');
  assert.equal(scheduleTzLabel('America/New_York'), 'New York');
  assert.equal(scheduleTzLabel('UTC'), 'UTC');
});

test('the default zone is the one lib/timezone.ts falls back to', () => {
  assert.equal(DEFAULT_SCHEDULE_TZ, DEFAULT_TIMEZONE);
  assert.equal(DEFAULT_SCHEDULE_TZ, 'UTC');
  assert.equal(scheduleTz(), DEFAULT_SCHEDULE_TZ, 'nothing stamped: the default');
  assert.equal(withStampedZone(UTC5, () => scheduleTz()), UTC5, 'the stamped zone wins');
});

test('a "tomorrow" preset rolls the day on the schedule clock, not the browser', () => {
  // 02:00 UTC on Sep 2 is still 21:00 on Sep 1 at UTC-5. "Tomorrow"
  // therefore means Sep 2 there, while a UTC/browser clock would say Sep 3 —
  // the late-evening off-by-one-day this helper exists to prevent.
  const lateEvening = new Date('2026-09-02T02:00:00Z');
  assert.equal(withStampedZone(UTC5, () => schedulePresetValue(1, 9, lateEvening)), '2026-09-02T09:00');
  assert.equal(withStampedZone('UTC', () => schedulePresetValue(1, 9, lateEvening)), '2026-09-03T09:00');
});

test('a preset keeps the hour it was labelled with', () => {
  const noon = new Date('2026-09-01T17:00:00Z');
  withStampedZone(UTC5, () => {
    assert.equal(schedulePresetValue(0, 18, noon), '2026-09-01T18:00');
    assert.equal(schedulePresetValue(2, 12, noon), '2026-09-03T12:00');
  });
});

test('a box value is read on the schedule clock, and an instant is shown on it', () => {
  withStampedZone(UTC5, () => {
    // 09:00 at UTC-5 is 14:00 UTC.
    assert.equal(scheduleInstantFromInput('2026-09-16T09:00'), '2026-09-16T14:00:00.000Z');
    assert.equal(scheduleInputValue('2026-09-16T14:00:00.000Z'), '2026-09-16T09:00');
    assert.equal(scheduleInstantFromInput(''), null);
    assert.equal(scheduleInstantFromInput('not a date'), null);
  });
  // Nothing stamped: the UTC default reads the digits as the instant's own.
  assert.equal(scheduleInstantFromInput('2026-09-16T09:00'), '2026-09-16T09:00:00.000Z');
});

test('the Reschedule box round-trips through the schedule clock, whatever the browser zone', () => {
  withStampedZone(UTC5, () => {
    const iso = scheduleInstantFromInput('2026-10-02T09:30');
    assert.ok(iso, 'a valid value names an instant');
    assert.equal(scheduleInputValue(iso), '2026-10-02T09:30', 'read back on the same clock');
    // UTC-5 with no DST: 09:30 there is 14:30Z.
    assert.equal(iso, '2026-10-02T14:30:00.000Z');
  });
});

test('Reschedule is on every post row and in the preview, and sends the instant exactly as a drag does', () => {
  const page = readFileSync(new URL('../app/calendar/page.tsx', import.meta.url), 'utf8');
  assert.equal((page.match(/onClick=\{\(\) => openReschedule\(/g) || []).length, 3, 'past-due rows, upcoming rows, the preview');
  assert.match(page, /type="datetime-local"/);
  assert.match(page, /const iso = scheduleInstantFromInput\(rescheduleFor\.value\);/);
  assert.match(page, /await rescheduleTo\(id, iso\);/);
  assert.match(page, /New date and time · \{scheduleTzLabel\(\)\}/, 'the brand\'s clock, named');
});

// web/lib/autopilot.ts
// The Autopilot Content Engine: turns schedule templates from static text
// into per-occurrence strategies. For every upcoming slot of an active
// template it researches (Semrush brief + domain movers + learnings),
// decides a distinct angle, drafts with the full generation stack (brand
// voice, performance hint, keyword brief), scores the result against a
// rubric with a self-critique retry, and stages it for human review.
//
// Runs stop at ready_for_review, and approval is what pushes a Metricool post
// and writes a posts row.
//
// WHO APPROVES. A person, by default and on any account that has not said
// otherwise — this engine has never published anything by itself and still
// does not, unless AUTOPILOT_AUTOSCHEDULE is turned on. With that setting on,
// `autoSchedule` may approve a run ITSELF, and only one that clears every bar
// in lib/autoschedule.ts: a DOI verified against Crossref (not merely shaped
// like one), a score at or above the threshold, no safety flag at all, and a
// picture wherever the network refuses a post without one. Anything short of
// that waits in the queue with the reason written on its card. That floor
// fails CLOSED, which is the opposite of every other guard in this codebase,
// for the obvious reason: the cost of waiting is a button, and the cost of
// guessing is a published medical advertisement.
//
// Design constraints honored:
// - Cache-first & budget-guarded: every Semrush call goes through the
//   existing unit-floor/cache layer, so a tick can never drain the balance.
// - Idempotent, resumable steps: the hourly cron advances each run as far as
//   its budget allows; a failure retries next tick, and unique(template_id,
//   scheduled_for) makes planning re-entrant.
// - Fail-soft: a missing key or empty report degrades the angle choice, it
//   never throws the whole tick.
import { reportError, redact } from '@/lib/report';
import 'server-only';

import { supabaseAdmin } from '@/lib/supabase-admin';
import { checkCompliance, complianceMessage, ensureAviso, refPolicyOf } from '@/lib/compliance';
import { avisoForUser } from '@/lib/compliance-gate';
import { recordApproval } from '@/lib/approval-log';
import { loadBrandContext } from '@/lib/brand-context';
import {
  chatAssistant,
  generateContentPack,
  judgeClaimSupport,
  type BrandContext,
  type ContentPack,
  type ContentType,
  stampFromBrief,
  keywordLadder,
  type SemrushStamp,
  rewriteClaimToStudy,
} from '@/lib/ai';
import { fixPostCitation } from '@/lib/post-citation-fix';
import {
  buildKeywordBrief,
  briefPromptFrom,
  opportunityScore,
  recordDraftKeywords,
  researchBundle,
  type KeywordBrief,
  type SemKeyword,
} from '@/lib/semrush';
import { keywordMovers, primaryDomain, topOrganicKeywords, type KeywordMovers } from '@/lib/semrush-domain';
import { summarizeTopPerformers, type NormalizedMetric } from '@/lib/performance';
import { metricoolSchedulePost, readPostId } from '@/lib/metricool';
import { metricoolNetworks, wantsBlog, type McNetwork } from '@/lib/metricool-networks';
import { professionalTitle } from '@/lib/post-title';
import { publishArticle, wordpressConfig, wordpressConfigured } from '@/lib/wordpress';
import { ensureDraftImage, type PackImage } from '@/lib/images';
import { pictureForDraft } from '@/lib/draft-picture';
import { imageUnshippable } from '@/lib/image-verdict';
import { channelCopy, citationsIn, knownBadCitation, perNetworkPlan } from '@/lib/approve-plan';
import { ARTICLE_LINK_PLACEHOLDER, PROMO_DELAY_MINUTES, articleLogNote, articleUrl, promoLink, readArticleLog, withArticleLink } from '@/lib/article-promo';
import { refTitle, verifyDoi } from '@/lib/citation';
import { findByDoi, findEvidence } from '@/lib/evidence';
import { claimSupportRefusal } from '@/lib/citation-gate';
import { autoFixCitation } from '@/lib/citation-autofix';
import { strategyClaimSupport } from '@/lib/strategy-claim-support';
import { ensureKeywords } from '@/lib/keyword-guard';
import { competitiveBrief } from '@/lib/competitive-brief';
import { evidenceBriefFrom, type EvidenceItem } from '@/lib/evidence-brief';
import { MAX_CANDIDATES, claimFrom, claimQuery, supportedItem, type ClaimSupportStamp, type SupportVerdict } from '@/lib/claim-support';
import { pickCitation, refLineFrom } from '@/lib/citation-from-evidence';
import { FIX_STALLED_NOTE, fixImageMode, fixNote, fixPlan, fixRedraftNote, fixRunning, fixStale, imageFlagged, runFixInput, swapRefLine, type FixStatus, type FixStep } from '@/lib/fix-plan';
import { NETWORKS_NEEDING_MEDIA, mediaProblem } from '@/lib/composer';
import { SCHEDULE_TZ, upcomingSlots } from '@/lib/timezone';
import { BRAND_NAME } from '@/lib/brand-identity';
import { ANTI_REPEAT_DAYS, HORIZON_DAYS, MAX_ATTEMPTS, SCORE_THRESHOLD } from '@/lib/planner-constants';
import { ANGLE_HISTORY, chooseAngle, type AngleType, type PastAngle } from '@/lib/angle-rotation';
import { titleSeq } from '@/lib/planner-image';
import { autoScheduleVerdict, holdNote } from '@/lib/autoschedule';
import { autoSchedules } from '@/lib/autopilot-mode';
import { usableLeadHours } from '@/lib/lead-window';
import { weeklyPaceVerdict, weeklyCeiling, paceNote, ROLLING_WINDOW_DAYS, PACE_SCAN_LIMIT, NOT_PUBLISHING } from '@/lib/weekly-pace';
import { videoVerdict, pendingRefusal, type PackLike } from '@/lib/video-required';
import { isMissed, MISSED_MARGIN_MS, MISSED_RETIRE_DAYS } from '@/lib/review-queue';
import { nextFreeSlot } from '@/lib/missed-slot';
import { RECONCILABLE_STATES, reconcilePlan, slotMatches } from '@/lib/run-reconcile';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

// The template's own instructions, and the normaliser that cleans them, live
// in lib/template-strategy.ts — a pure module, so the round trip every door
// into that column depends on can actually be run by a test. Re-exported here
// because this is where callers have always looked for them.
import { normalizeStrategy, type StrategyMode, type TemplateStrategy } from '@/lib/template-strategy';
import { rulesForSlot, slotContext } from '@/lib/content-strategy';
import { angleFor, siblingAngles, weekIndex } from '@/lib/strategy-rotation';
import { varietyBriefs, varietyFor, varietyLabels, type Variety } from '@/lib/strategy-variety';
import { openingOfPack } from '@/lib/opening-line';
import { recentOpenings } from '@/lib/recent-openers';
import { BLOG_ANGLES } from '@/lib/strategy-seed';
import { scorePack, type RunScore } from '@/lib/score-pack';
export { scorePack };
import { citationPolicyFor, isStrategySlot, isUploadedSlot, pickSupportingPhrase, pillarForStrategy, strategyBrand, strategyTopicPrompt, uploadVarietyKey, usesStrategyVoice } from '@/lib/strategy-voice';
import { attachableClip, clipRelevant, pillarOf, usesPillarRotation, type PostTopic } from '@/lib/clip-relevance';
export { normalizeStrategy };
export type { StrategyFormat, StrategyMode, TemplateStrategy } from '@/lib/template-strategy';

// One definition, in lib/angle-rotation.ts, where the rotation that walks these
// four lives — re-exported here because this is where callers look for it.
export type { AngleType };

export type Angle = {
  type: AngleType;
  query: string; // the primary search phrase this post targets
  seedTopic: string; // the pillar/topic the query came from
  rationale: string; // human-readable "why this angle, this week"
  volume: number | null;
  difficulty: number | null;
  intent: string | null;
  // v2 enrichments (all optional, all fail-soft):
  strategistNote?: string; // AI strategist's 2-3 sentence guidance for the writer
  reviewerNote?: string; // human feedback carried into a regeneration
  /**
   * When a reviewer last pressed "Ask for changes". The redraft is theirs to
   * read: autoSchedule never sends a run carrying this, however the redraft
   * finished — in the request, or on a later tick that has no runId.
   */
  reviewRequestedAt?: string;
  provenPerformer?: boolean; // boosted by the measured-engagement learning loop
  supportingPhrase?: string; // weekly-strategy slots: an optional search phrase found by research
  media?: { url: string; title: string; relevant?: boolean } | null; // matching clip to attach on approve
  redatedFrom?: string; // the slot this run missed, when a reviewer moved it to the next free one
  coveredThisWeek?: string[]; // weekly-strategy slots: what the related slots write the same week
  dealtWeek?: number; // weekly-strategy slots: the week of the dealt schedule this occurrence belongs to
  format?: string; // weekly-strategy slots: the caption's shape this week (lib/strategy-variety.ts)
  audience?: string; // weekly-strategy slots: who this week's post is written for
  closing?: string; // weekly-strategy slots: the gentle next step it ends on
  /** The FIX button's progress and result, which the card polls (lib/fix-plan.ts fixView). */
  fix?: FixStatus;
  previousOpening?: string; // weekly-strategy slots: how this angle opened the last time it was published
  /** Weekly-strategy slots: how many approved occurrences already wore this angle's cover title (lib/planner-image.ts titleSeq). */
  titleSeq?: number;
};

export type { RunScore } from '@/lib/score-pack';

export type TemplateRow = {
  id: string;
  user_id: string;
  name: string;
  providers: string[];
  text: string;
  weekdays: number[];
  time_of_day: string;
  active: boolean;
  strategy: TemplateStrategy | null;
};

export type RunRow = {
  id: string;
  template_id: string;
  user_id: string;
  scheduled_for: string;
  state: string;
  attempts: number;
  regens: number;
  brief: KeywordBrief | null;
  angle: Angle | null;
  score: RunScore | null;
  draft_id: string | null;
  log: { at: string; step: string; note: string }[];
};

const ACTIVE_STATES = ['planned', 'researched', 'drafted'] as const;

/** Time a tick must have left to send a finished post itself (autoschedule only). */
const AUTOSCHEDULE_MIN_MS = 60_000;
// MAX_ATTEMPTS is two, not three. `advanceRuns` takes at most one attempt per
// run per tick, inside an eligibility window that is only ever a couple of ticks
// wide - so with a limit of 3 a broken run could never reach `failed`, never
// showed up under "Needs attention", and simply went quiet.
//
// The tick is hourly rather than daily now, which makes that window WIDER, not
// narrower: lib/lead-window.ts turns this number into the lead a template needs
// to have anything left over for a failed step.
//
// These four moved to lib/planner-constants.ts so the assistant's playbook can
// interpolate them rather than restate them from memory and drift.

function num(v: unknown): number | null {
  const n = typeof v === 'string' ? parseFloat(v) : (v as number);
  return Number.isFinite(n) ? n : null;
}


/** "Tue, Sep 29, 9:00 AM" in the schedule timezone — a slot as a reviewer reads it. */
function slotLabel(iso: string): string {
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return String(iso || '');
  return new Intl.DateTimeFormat('en-US', {
    timeZone: SCHEDULE_TZ, weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit',
  }).format(d);
}

function logLine(run: RunRow, step: string, note: string): { at: string; step: string; note: string }[] {
  // REDACTED before it is stored, not merely before it is logged.
  //
  // The error path writes a provider's raw response body into this column
  // (`anthropic ${status}: ${await res.text()}`), and lib/report.ts's own header
  // records a REAL incident of a vendor echoing a live key back in an error
  // body. Its claim that every message "passes through this before it is
  // written anywhere" was true only of console logging: this column was the
  // exception, and it is durable storage that the queue now renders on screen.
  // Redacting here covers the column, the card, and every future reader at
  // once — cheaper and safer than redacting at each display site.
  const entry = { at: new Date().toISOString(), step, note: redact(note).slice(0, 400) };
  const prior = Array.isArray(run.log) ? run.log : [];
  return [...prior.slice(-30), entry];
}

// ---------------------------------------------------------------------------
// Planner: materialize template_runs for upcoming slots.
// ---------------------------------------------------------------------------

export async function planRuns(scopeUserId?: string): Promise<{ planned: number; templates: number }> {
  const db = supabaseAdmin();
  let q = db
    .from('schedule_templates')
    .select('id, user_id, name, providers, text, weekdays, time_of_day, active, strategy')
    .eq('active', true);
  if (scopeUserId) q = q.eq('user_id', scopeUserId);
  // Surface the query error instead of discarding it. A dropped error here read
  // as "no templates", so a missing table or a rotated service-role key made the
  // cron answer {ok:true, planned:0} - green in Vercel, dead in reality.
  const { data: templates, error: tplErr } = await q;
  if (tplErr) throw new Error('planRuns: could not read templates - ' + tplErr.message);
  if (!Array.isArray(templates) || templates.length === 0) return { planned: 0, templates: 0 };

  const now = new Date();
  let planned = 0;
  let dynamicTemplates = 0;

  for (const t of templates as TemplateRow[]) {
    const strategy = normalizeStrategy(t.strategy);
    if (strategy.mode === 'off') continue; // static templates keep the old Apply flow
    dynamicTemplates++;
    const weekdays: number[] = Array.isArray(t.weekdays) ? t.weekdays : [];
    if (!weekdays.length) continue;

    // Template times are wall-clock times in the SCHEDULE TIMEZONE
    // (SCHEDULE_TZ, lib/timezone.ts), not server time — Vercel runs in UTC, so
    // the old setHours() approach fired a "09:00" template hours off.
    const rows = upcomingSlots(weekdays, t.time_of_day || '09:00', HORIZON_DAYS, SCHEDULE_TZ, now)
      .map((slot) => ({ template_id: t.id, user_id: t.user_id, scheduled_for: slot.toISOString() }));
    if (!rows.length) continue;
    // Idempotent: unique(template_id, scheduled_for) — ignore existing runs.
    const { data: inserted, error: insErr } = await db
      .from('template_runs')
      .upsert(rows, { onConflict: 'template_id,scheduled_for', ignoreDuplicates: true })
      .select('id');
    if (insErr) throw new Error('planRuns: could not plan runs - ' + insErr.message);
    planned += Array.isArray(inserted) ? inserted.length : 0;
  }
  return { planned, templates: dynamicTemplates };
}

// ---------------------------------------------------------------------------
// Step 1: research + decide. Gathers live data and picks a distinct angle.
// ---------------------------------------------------------------------------

function pickSeedTopic(strategy: TemplateStrategy, occurrenceIndex: number, seedPool: string[]): string {
  if (strategy.mode === 'fixed_topic' && strategy.topic) return strategy.topic;
  if (seedPool.length) return seedPool[occurrenceIndex % seedPool.length];
  if (strategy.topic) return strategy.topic;
  // Last resort when a template names no topic and no pillar: the brand
  // itself, which is at least on-subject for whoever deploys this.
  return BRAND_NAME;
}

// Full-auto seed discovery: the pool rotates through the user's pillars PLUS
// what the domain data says matters right now — keywords we are losing (write
// to defend) and keywords already earning traffic (write to consolidate).
async function autoSeedPool(pillars: string[], brandKeywords: string[]): Promise<string[]> {
  const pool: string[] = [...pillars];
  try {
    const movers = await keywordMovers(primaryDomain());
    for (const m of [...movers.lostKeywords, ...movers.declined].slice(0, 3)) {
      if (m.keyword) pool.push(m.keyword);
    }
  } catch (err) { /* cache/link-out mode */ reportError('autopilot:keyword-brief', err); }
  try {
    const top = await topOrganicKeywords(primaryDomain(), 30);
    for (const k of top.rows.slice(0, 5)) {
      if (k.keyword && (k.position ?? 99) > 3) pool.push(k.keyword); // consolidate non-#1 winners
    }
  } catch (err) { /* cache/link-out mode */ reportError('autopilot:keyword-questions', err); }
  for (const b of brandKeywords) pool.push(b);
  // Dedupe, keep order.
  const seen = new Set<string>();
  return pool.filter((p) => {
    const key = p.toLowerCase().trim();
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function isCommercial(k: SemKeyword): boolean {
  return k.intents.includes('commercial') || k.intents.includes('transactional');
}

function usable(k: SemKeyword | null | undefined, recent: Set<string>): k is SemKeyword {
  return Boolean(k && k.keyword && !recent.has(k.keyword.toLowerCase()));
}

// The rotation: consecutive occurrences of the same template get different
// jobs. Order is rotated by occurrence index; unavailable angles fall through.
function decideAngle(
  occurrenceIndex: number,
  seedTopic: string,
  brief: KeywordBrief,
  questions: SemKeyword[],
  movers: KeywordMovers | null,
  recent: Set<string>,
  learned: Map<string, number> = new Map(),
  history: readonly PastAngle[] = []
): Angle {
  const related = [brief.primary, ...brief.supporting].filter((k): k is SemKeyword => Boolean(k));
  // Learning loop: keywords that measurably earned engagement for THIS
  // audience get a boost on top of the volume-vs-difficulty score.
  const learnBoost = (k: SemKeyword): number => {
    let boost = 0;
    for (const [kw, eng] of learned) {
      if (k.keyword.toLowerCase().includes(kw) || kw.includes(k.keyword.toLowerCase())) {
        boost = Math.max(boost, Math.log10(1 + eng) * 10);
      }
    }
    return boost;
  };
  const byOpportunity = [...related].sort(
    (a, b) => opportunityScore(b) + learnBoost(b) - (opportunityScore(a) + learnBoost(a))
  );

  const candidates: (Angle | null)[] = [];

  // answer: a real searcher question we can own.
  const q = [...questions, ...brief.questions].find((k) => usable(k, recent));
  candidates.push(
    q
      ? {
          type: 'answer',
          query: q.keyword,
          seedTopic,
          rationale:
            'Real searcher question "' + q.keyword + '"' +
            (q.volume != null ? ' (' + q.volume + '/mo' + (q.difficulty != null ? ', KD ' + q.difficulty : '') + ')' : '') +
            ' — answering it directly builds topical authority.',
          volume: q.volume,
          difficulty: q.difficulty,
          intent: q.intents.join(', ') || null,
        }
      : null
  );

  // commercial: highest-opportunity commercial/transactional keyword.
  const c = byOpportunity.find((k) => usable(k, recent) && isCommercial(k) && (k.difficulty == null || k.difficulty < 60));
  candidates.push(
    c
      ? {
          type: 'commercial',
          query: c.keyword,
          seedTopic,
          rationale:
            'Commercial-intent opportunity "' + c.keyword + '"' +
            (c.volume != null ? ' (' + c.volume + '/mo, KD ' + (c.difficulty ?? '?') + ')' : '') +
            ' — winnable difficulty with buying intent.',
          volume: c.volume,
          difficulty: c.difficulty,
          intent: c.intents.join(', ') || null,
        }
      : null
  );

  // defense: a keyword we just lost or that is falling — defend the ranking.
  const fallen = movers
    ? [...movers.lostKeywords, ...movers.declined]
        .filter((m) => m.keyword && !recent.has(m.keyword.toLowerCase()))
        .sort((a, b) => (b.volume ?? 0) - (a.volume ?? 0))[0]
    : undefined;
  candidates.push(
    fallen
      ? {
          type: 'defense',
          query: fallen.keyword,
          seedTopic,
          rationale:
            'Ranking defense: "' + fallen.keyword + '"' +
            (fallen.volume != null ? ' (' + fallen.volume + '/mo)' : '') +
            (fallen.prevPosition ? ' slipped from #' + fallen.prevPosition : ' dropped out of the top 100') +
            ' — fresh content signals relevance to win it back.',
          volume: fallen.volume,
          difficulty: fallen.difficulty,
          intent: null,
        }
      : null
  );

  // opportunity: best remaining keyword by the brand-tuned opportunity score
  // (plus the measured-engagement learning boost).
  const o = byOpportunity.find((k) => usable(k, recent));
  const oProven = o ? learnBoost(o) > 0 : false;
  candidates.push(
    o
      ? {
          type: 'opportunity',
          query: o.keyword,
          seedTopic,
          rationale:
            'Top opportunity "' + o.keyword + '"' +
            (o.volume != null ? ' (' + o.volume + '/mo, KD ' + (o.difficulty ?? '?') + ')' : '') +
            ' by the volume-vs-difficulty score' +
            (oProven ? ' — related posts already earned measurable engagement with your audience.' : '.'),
          volume: o.volume,
          difficulty: o.difficulty,
          intent: o.intents.join(', ') || null,
          provenPerformer: oProven,
        }
      : null
  );

  const available = candidates.filter((a): a is Angle => Boolean(a));
  if (!available.length) {
    return {
      type: 'opportunity',
      query: seedTopic,
      seedTopic,
      rationale: 'No fresh keyword data available — writing on the pillar topic itself (cache/link-out mode).',
      volume: null,
      difficulty: null,
      intent: null,
    };
  }
  // Rotate by occurrence so week 1..4 differ, and skip what this template has
  // already published — see lib/angle-rotation.ts, which holds the rule and its
  // tests. Fail-open: with every candidate used it returns the rotation's own
  // first choice rather than nothing.
  return chooseAngle(available, occurrenceIndex, history) || available[0];
}

/** The variety stamped on a strategy occurrence's angle, if it has one. */
function storedVariety(angle: Angle): Variety | null {
  return angle.format && angle.audience && angle.closing
    ? { format: angle.format as Variety['format'], audience: angle.audience as Variety['audience'], closing: angle.closing as Variety['closing'] }
    : null;
}

/**
 * How this template's post on `query` opened the last time it was published,
 * or ''. Read from the approved run's draft. Fail-open: no memory is exactly
 * what the engine had before.
 */
async function previousOpeningFor(run: RunRow, query: string): Promise<string> {
  try {
    const db = supabaseAdmin();
    const { data: prior, error } = await db
      .from('template_runs')
      .select('draft_id')
      // By account, not template: a reloaded weekly strategy recreates its
      // template rows, and the memory should survive that. The angle text is
      // specific enough to the slot that wrote it.
      .eq('user_id', run.user_id)
      .eq('state', 'approved')
      .eq('angle->>query', query)
      .lt('scheduled_for', run.scheduled_for)
      .order('scheduled_for', { ascending: false })
      .limit(1)
      .maybeSingle();
    const draftId = (prior as { draft_id?: string | null } | null)?.draft_id;
    if (error || !draftId) return '';
    const { data: d } = await db.from('drafts').select('pack').eq('id', draftId).eq('user_id', run.user_id).maybeSingle();
    const pack = (d as { pack?: Record<string, unknown> } | null)?.pack || {};
    return openingOfPack(pack).slice(0, 200);
  } catch (err) {
    reportError('autopilot:previous-opening', err, { runId: run.id });
    return '';
  }
}

/** Who a strategy occurrence is written for, as the generator's "Target audience" line. */
function audienceOf(angle: Angle | null | undefined): string | undefined {
  return angle ? varietyBriefs(storedVariety(angle))?.audience : undefined;
}

async function stepResearch(run: RunRow, template: TemplateRow, strategy: TemplateStrategy): Promise<Partial<RunRow>> {
  const db = supabaseAdmin();

  // Occurrence index: how many runs of this template came before this slot.
  const { count, error: countError } = await db
    .from('template_runs')
    .select('id', { count: 'exact', head: true })
    .eq('template_id', run.template_id)
    // A run retired because its slot moved never became a post; counting it
    // moved the rotation on an extra angle every time a slot was re-timed.
    .neq('state', 'superseded')
    .lt('scheduled_for', run.scheduled_for);
  // THE ONE THAT MAKES ROTATION COLLAPSE. Unread, a failed count gives null →
  // occurrenceIndex 0 → pickSeedTopic always returns seedPool[0] and decideAngle
  // always starts at the same angle type. Every post, every week, the same
  // pillar — and nothing anywhere says why. The index is otherwise structurally
  // sound: rows are never deleted and planRuns only ever creates future slots,
  // so this dropped error was the sole way it could go constant.
  if (countError) reportError('autopilot:occurrence-count', countError, { runId: run.id });
  const occurrenceIndex = count ?? 0;

  // Brand keywords as pillar fallback.
  let brandKeywords: string[] = [];
  try {
    const { data: bp, error: bpError } = await db
      .from('brand_profiles').select('keywords').eq('user_id', run.user_id).maybeSingle();
    // supabase-js RESOLVES a failed read, so this catch never fired for a
    // database error. Losing the brand keywords drops the pillar fallback, and
    // pickSeedTopic then falls all the way through to a hardcoded topic.
    if (bpError) reportError('autopilot:brand-keywords', bpError, { runId: run.id });
    if (bp && Array.isArray((bp as { keywords?: string[] }).keywords)) {
      brandKeywords = ((bp as { keywords?: string[] }).keywords || []).filter(Boolean);
    }
  } catch (err) { /* optional */ reportError('autopilot:brand-load', err); }

  // Seed pool: pillars for 'pillars' mode; pillars + live domain data
  // (lost/declining keywords, consolidatable winners) for full 'auto'.
  let seedPool = (strategy.pillars || []).length ? [...(strategy.pillars as string[])] : [...brandKeywords];
  if (strategy.mode === 'auto') {
    seedPool = await autoSeedPool(strategy.pillars || [], brandKeywords);
  }
  let seedTopic = pickSeedTopic(strategy, occurrenceIndex, seedPool);

  // Anti-repetition: primary keywords used in the last 30 days.
  const recent = new Set<string>();
  try {
    const since = new Date(Date.now() - ANTI_REPEAT_DAYS * 24 * 60 * 60 * 1000).toISOString();
    // `topic`, not `keyword`.
    //
    // decideAngle filters candidate angle.query values against this set, and
    // angle.query is what recordDraftKeywords stores in the TOPIC column
    // (lib/semrush.ts): `role: 'primary'` marks the brief's own primary keyword,
    // which is a different string chosen from the research. So comparing
    // queries against keywords almost never matched, and the anti-repeat was
    // inert on the normal Semrush path — every fourth occurrence re-ran the
    // identical query with the identical rationale, indefinitely. It appeared to
    // work only in the degraded cache-only branch, which does store the query.
    const { data: used, error: usedError } = await db
      .from('draft_keywords')
      .select('topic')
      .eq('user_id', run.user_id)
      .gte('created_at', since)
      .limit(400);
    if (usedError) reportError('autopilot:draft-keywords', usedError, { runId: run.id });
    for (const r of used || []) recent.add(String((r as { topic: string }).topic || '').toLowerCase());
  } catch (err) { /* table optional */ reportError('autopilot:draft-keywords', err); }

  // Learning loop: measured engagement per primary keyword (view joins
  // draft_keywords × post_metrics). Empty until posts get measured — fail-soft.
  const learned = new Map<string, number>();
  try {
    const { data: perf, error: perfError } = await db
      .from('keyword_performance')
      .select('keyword, total_engagement')
      .eq('user_id', run.user_id)
      .order('total_engagement', { ascending: false })
      .limit(50);
    // Unread, this silently reverted the whole measured-engagement learning
    // loop to a plain volume/difficulty sort, with provenPerformer always false.
    if (perfError) reportError('autopilot:keyword-performance', perfError, { runId: run.id });
    for (const r of perf || []) {
      const kw = String((r as { keyword: string }).keyword || '').toLowerCase();
      const eng = Number((r as { total_engagement: number }).total_engagement) || 0;
      if (kw && eng > 0) learned.set(kw, eng);
    }
  } catch (err) { /* view optional */ reportError('autopilot:keyword-performance', err); }

  // What this template itself has already published.
  //
  // `template_runs.angle` has recorded every decided angle since the table
  // existed, and until now the only thing that read it was the review card —
  // the engine could not see its own history, so "a repeat is unlikely" rested
  // entirely on the four-way rotation. Newest first, capped, and fail-soft: an
  // unreadable history means the rotation behaves exactly as it did before.
  //
  // PUBLISHED, not merely attempted. Without the state filter a run that failed
  // at drafting, or one a reviewer skipped, still spent one of the six history
  // slots and ruled its query out — so a template with a bad week had its
  // rotation narrowed by posts that were never written.
  let angleHistory: PastAngle[] = [];
  try {
    const { data: past, error: pastError } = await db
      .from('template_runs')
      .select('angle, scheduled_for')
      .eq('template_id', run.template_id)
      .not('angle', 'is', null)
      .eq('state', 'approved')
      .lt('scheduled_for', run.scheduled_for)
      .order('scheduled_for', { ascending: false })
      .limit(ANGLE_HISTORY);
    if (pastError) reportError('autopilot:angle-history', pastError, { runId: run.id });
    angleHistory = (past || []).map((r) => (r as { angle?: PastAngle }).angle);
  } catch (err) { /* history is a tiebreak, never a blocker */ reportError('autopilot:angle-history', err); }

  // THE WEEKLY STRATEGY'S OWN ROTATION (lib/strategy-rotation.ts). For a
  // seeded slot whose bank is still the document's, the angle comes from the
  // dealt schedule — counted in weeks from a fixed Monday, never by counting
  // runs, and dealt so that sibling slots and the weekly article never write
  // the same thing, or near enough, in the same week. The slot's recently
  // published angles are handed over for the switch-over weeks. Anything else
  // (a hand-edited bank, a slot with no key) keeps the rotation above.
  let dealt: ReturnType<typeof angleFor> = null;
  if (isStrategySlot(strategy) && strategy.slot) {
    dealt = angleFor(strategy.slot, run.scheduled_for, {
      bank: strategy.pillars,
      articleBank: BLOG_ANGLES,
      avoid: angleHistory.map((h) => String((h as { query?: unknown } | null)?.query || '')).filter(Boolean),
    });
    if (dealt) seedTopic = dealt.angle;
  }

  // Live data (all cache-first + unit-floor guarded).
  const bundle = await researchBundle(seedTopic, { relatedLimit: 12, questionLimit: 6 });
  let movers: KeywordMovers | null = null;
  // Not for a strategy slot: the domain's lost and declining keywords are the
  // brand's commercial searches, and one week in four the rotation offered
  // one of them — a "<service> <city>" phrase — as the supporting phrase of a
  // post about sleep. It also spent Semrush units on a result thrown away.
  if (!usesStrategyVoice(strategy)) {
    try {
      movers = await keywordMovers(primaryDomain());
    } catch { movers = null; }
  }

  // bundle.questions, not bundle.brief.questions.
  //
  // The 4th parameter is concatenated with `brief.questions` inside decideAngle,
  // so passing the brief's own slice meant the SAME array joined to itself: the
  // six question keywords fetched and paid for were narrowed back to three, and
  // the wider `related` set never reached the angle picker at all.
  let angle = decideAngle(occurrenceIndex, seedTopic, bundle.brief, bundle.questions, movers, recent, learned, angleHistory);

  // Weekly-strategy slots write the angle the brand's document lists for this
  // week — never a Semrush keyword in its place. Left to decideAngle, a slot
  // could swap "The role of protein in recovery" for a commercial-intent
  // keyword, which is the opposite of what the strategy asks for. The keyword
  // research still counts: a non-commercial phrase it found rides along as an
  // optional supporting phrase.
  if (usesStrategyVoice(strategy)) {
    const pool = seedPool.length || 1;
    // The supporting phrase comes from research on THIS angle only — its
    // primary keyword, related searches and questions — and must be on the
    // subject, non-commercial and free of any therapy or promotion
    // (lib/strategy-voice.ts pickSupportingPhrase).
    const candidates = [bundle.brief.primary, ...(bundle.brief.supporting || []), ...(bundle.brief.questions || []), ...(bundle.questions || [])]
      .filter((k): k is SemKeyword => Boolean(k && k.keyword));
    const pillarName = pillarForStrategy(strategy, template.name)?.name || template.name;
    const picked = pickSupportingPhrase(seedTopic, pillarName, candidates);
    const pickedRow = picked ? candidates.find((k) => k.keyword === picked) : undefined;
    // The rest of "angle, question, format, or audience" (lib/strategy-variety.ts).
    // A slot from a dropped document has no dealt schedule of its own; it
    // takes the shape dealt to its place in the week (day, first or second
    // post), so it too changes format, reader and closing every week.
    const uploadKey = !dealt && isUploadedSlot(strategy) ? uploadVarietyKey(template.weekdays, template.time_of_day) : null;
    const variety = dealt
      ? varietyFor(strategy.slot, dealt.week)
      : uploadKey ? varietyFor(uploadKey, weekIndex(run.scheduled_for)) : null;
    // And what the week's other posts are writing, so this one does not
    // repeat them (the built-in slots know this from the dealt schedule).
    const uploadCovered = isUploadedSlot(strategy) ? await weekAnglesAround(run) : undefined;
    const labels = varietyLabels(variety);
    // And the memory an angle needs when it comes round again: how it opened
    // the last time it was published, so the writer can come at it afresh.
    const previousOpening = await previousOpeningFor(run, seedTopic);
    angle = {
      type: 'answer',
      query: seedTopic,
      seedTopic,
      rationale:
        'From the weekly strategy — "' + template.name + '", angle ' +
        (dealt ? dealt.position + ' of ' + dealt.of + ' (week ' + (dealt.week + 1) + ' of the dealt schedule)' : ((occurrenceIndex % pool) + 1) + ' of ' + pool) + '.' +
        (labels ? ' Format: ' + labels.format + ', written for: ' + labels.audience + '.' : '') +
        (previousOpening ? ' This angle has run before; the writer is told to open differently.' : '') +
        (picked ? ' Supporting search phrase: "' + picked + '".' : ''),
      volume: pickedRow?.volume ?? null,
      difficulty: pickedRow?.difficulty ?? null,
      intent: pickedRow ? (pickedRow.intents || []).join(', ') || null : null,
      supportingPhrase: picked,
      // What this slot's siblings — and, for the article, the week's medical
      // posts — are writing this same week, so the brief can say "not these".
      coveredThisWeek: dealt ? siblingAngles(strategy.slot || '', dealt.week) : uploadCovered,
      dealtWeek: dealt ? dealt.week : undefined,
      ...(variety ? { format: variety.format, audience: variety.audience, closing: variety.closing } : {}),
      ...(previousOpening ? { previousOpening } : {}),
      // How many approved occurrences already wore this angle's cover title:
      // the picture varies the title from the second one on (lib/planner-image.ts).
      titleSeq: titleSeq(seedTopic, pillarName, angleHistory),
    };
  }

  // AI strategist note: 2-3 sentences of editorial direction for the writer,
  // grounded in the chosen angle. Purely additive — skipped without API keys.
  try {
    const note = await chatAssistant([
      {
        role: 'user',
        content: usesStrategyVoice(strategy)
          ? 'In 2-3 short sentences, give editorial direction for an EDUCATIONAL ' + (strategy.format || 'social') +
            ' post for a brand\'s weekly "' + template.name + '" theme, on the angle "' + angle.query +
            '". It must teach something practical and must not promote any product or service or ask readers to buy or book. ' +
            // The dealt shape, reader and closing (lib/strategy-variety.ts):
            // the direction is read after them, so it must not undo them.
            (varietyBriefs(storedVariety(angle))
              ? 'It is written for ' + varietyBriefs(storedVariety(angle))!.audience + '. ' +
                varietyBriefs(storedVariety(angle))!.format + ' ' +
                varietyBriefs(storedVariety(angle))!.closing + ' Work within that shape, reader and closing; do not change them. '
              : '') +
            'What should the writer emphasize and avoid? Plain text only.'
          : 'In 2-3 short sentences, give editorial direction for a ' +
            (strategy.format || 'social') + ' post targeting the search "' + angle.query +
            '" (angle: ' + angle.type + '; rationale: ' + angle.rationale +
            '). What should the writer emphasize and avoid? Be specific and compliant — no medical claims. Plain text only.',
      },
    ]);
    if (note && note.trim()) angle.strategistNote = note.trim().slice(0, 500);
    // Labelled for what it wraps. This said 'autopilot:recent-angles', so a
    // model outage was filed under the angle rotation and whoever went looking
    // for it started in the wrong place.
  } catch (err) { /* optional */ reportError('autopilot:strategist-note', err); }

  return {
    state: 'researched',
    brief: bundle.brief.source === 'semrush' ? bundle.brief : null,
    angle,
    log: logLine(run, 'research', 'Angle: ' + angle.type + ' → "' + angle.query + '". ' + angle.rationale),
  };
}

// ---------------------------------------------------------------------------
// Step 2: draft with the full generation stack.
// ---------------------------------------------------------------------------

const GOAL_INSTRUCTION: Record<NonNullable<TemplateStrategy['goal']>, string> = {
  rank: 'Optimize to rank: use the primary phrase naturally in the opening and body.',
  traffic: 'Optimize for clicks: strong curiosity hook, clear promise of value.',
  engagement: 'Optimize for engagement: end with a question or conversation starter.',
  authority: 'Optimize for authority: cite the expert perspective, measured tone.',
};

function topicPromptFor(angle: Angle, strategy: TemplateStrategy, templateName = ''): string {
  // A weekly-strategy slot gets the strategy's own brief: pillar, angle,
  // editorial direction and the no-promotion rules (lib/strategy-voice.ts).
  if (usesStrategyVoice(strategy)) {
    // Rules, day theme and what else the slot counts as come from the document
    // data at run time when the slot is known (lib/content-strategy.ts), so a
    // change to the strategy reaches every slot on deploy without a re-seed.
    // The stored rule is the fallback for rows seeded before slot keys.
    const ctx = strategy.slot ? slotContext(strategy.slot) : null;
    const brief = strategyTopicPrompt({
      angle: angle.query,
      pillarName: pillarForStrategy(strategy, templateName)?.name || templateName || angle.seedTopic,
      rule: (strategy.slot && rulesForSlot(strategy.slot)) || strategy.rule,
      dayTheme: ctx?.dayTheme,
      alsoCovers: ctx?.alsoCovers,
      integrated: ctx?.integrated,
      coveredThisWeek: angle.coveredThisWeek,
      variant: angle.dealtWeek,
      formatBrief: varietyBriefs(storedVariety(angle))?.format,
      audienceBrief: varietyBriefs(storedVariety(angle))?.audience,
      closingBrief: varietyBriefs(storedVariety(angle))?.closing,
      previousOpening: angle.previousOpening,
      reviewerNote: angle.reviewerNote,
      supportingPhrase: angle.supportingPhrase,
    });
    return angle.strategistNote ? brief + ' Strategist direction: ' + angle.strategistNote : brief;
  }
  const parts = [
    'Write about: ' + angle.query + '.',
    'Content pillar: ' + angle.seedTopic + '.',
    'Editorial angle (' + angle.type + '): ' + angle.rationale,
    GOAL_INSTRUCTION[strategy.goal || 'rank'],
  ];
  if (angle.strategistNote) parts.push('Strategist direction: ' + angle.strategistNote);
  // Before the reviewer's note, after the strategist's: a standing rule is not
  // advice about this week's post, it is a condition on every post this pillar
  // ever produces. The ones the brand wrote down are the difference between an
  // educational post and an advertisement.
  if (strategy.rule) parts.push('STANDING RULE for this pillar (must follow): ' + strategy.rule);
  if (angle.reviewerNote) parts.push('REVIEWER FEEDBACK (must address): ' + angle.reviewerNote);
  return parts.join(' ');
}

/**
 * The angles of this user's OTHER posts scheduled in the same week as `run`
 * (three and a half days either side), for a slot from a dropped strategy
 * document: its writer is told "related posts this week cover: …" so two
 * pillars that share ground — Tuesday's nutrition and Saturday's practical
 * nutrition — do not write the same post. Fail-soft: [] on any error.
 */
async function weekAnglesAround(run: RunRow): Promise<string[]> {
  try {
    const at = Date.parse(run.scheduled_for);
    if (!Number.isFinite(at)) return [];
    const half = 3.5 * 24 * 3600 * 1000;
    const { data, error } = await supabaseAdmin()
      .from('template_runs')
      .select('angle, template_id')
      .eq('user_id', run.user_id)
      .neq('template_id', run.template_id)
      .neq('state', 'superseded')
      .not('angle', 'is', null)
      .gte('scheduled_for', new Date(at - half).toISOString())
      .lte('scheduled_for', new Date(at + half).toISOString())
      .limit(40);
    if (error) { reportError('autopilot:week-angles', error, { runId: run.id }); return []; }
    const seen = new Set<string>();
    const out: string[] = [];
    for (const r of data || []) {
      const q = String((r as { angle?: { query?: unknown } }).angle?.query || '').trim();
      if (q && !seen.has(q.toLowerCase())) { seen.add(q.toLowerCase()); out.push(q); }
    }
    return out.slice(0, 13);
  } catch (err) { reportError('autopilot:week-angles', err); return []; }
}

// Media enrichment: find the user's best matching finished clip for an angle.
// clips.result is the OpusClip webhook payload (title/text/hashtags + mp4 urls).
async function findMatchingClip(
  userId: string,
  angle: Angle,
  /** Set for a strategy or pillar-rotation run: only a clip relevant to it (lib/clip-relevance.ts). */
  topic?: PostTopic,
): Promise<{ url: string; title: string; relevant?: boolean } | null> {
  try {
    const db = supabaseAdmin();
    const { data: rows, error: rowsError } = await db
      .from('clips')
      .select('result')
      .eq('user_id', userId)
      .not('result', 'is', null)
      .order('created_at', { ascending: false })
      .limit(10);
    // Unread, a failed read looked identical to "there are no clips" and the
    // post shipped without one.
    if (rowsError) reportError('autopilot:clip-match', rowsError, { userId });
    const words = angle.query.toLowerCase().split(/\s+/).filter((w) => w.length > 3);
    let best: { url: string; title: string; score: number } | null = null;
    for (const row of rows || []) {
      const clips = (row as { result?: unknown }).result;
      if (!Array.isArray(clips)) continue;
      for (const c of clips as Record<string, unknown>[]) {
        const url = String(c.export || c.preview || '');
        if (!url) continue;
        if (topic && !clipRelevant(c, topic)) continue;
        const hay = (String(c.title || '') + ' ' + String(c.text || '') + ' ' + String(c.description || '') + ' ' + String(c.hashtags || '')).toLowerCase();
        const score = words.filter((w) => hay.includes(w)).length;
        if (score > 0 && (!best || score > best.score)) {
          best = { url, title: String(c.title || 'Clip'), score };
        }
      }
    }
    return best ? { url: best.url, title: best.title, ...(topic ? { relevant: true } : {}) } : null;
  } catch {
    return null;
  }
}

async function stepDraft(run: RunRow, template: TemplateRow, strategy: TemplateStrategy): Promise<Partial<RunRow>> {
  const db = supabaseAdmin();
  const angle = run.angle as Angle;
  if (!angle) throw new Error('run has no angle');

  // Brief for the CHOSEN query (cache-first; distinct from the seed brief).
  // Falls back to the seed-topic brief already gathered at research time so
  // the model still writes with real numbers in cache-only mode.
  //
  // NOT for a weekly-strategy slot. Its "query" is a sentence from the brand's
  // document, and the brief is a contract — "work it into the BODY 2-3 times",
  // "answer at least one of these searcher questions", "match the searcher's
  // intent", commercial terms included — which pulls an educational post back
  // toward search copy. stepResearch already refuses to let a keyword replace
  // the angle; this stops the brief doing it by the back door. '' tells the
  // generator "researched, nothing to add" rather than running its own.
  let brief: KeywordBrief | null = null;
  let hint = '';
  // The stamp the pack will carry, whichever rung answered. A strategy slot
  // keeps the lighter contract (no brief in the prompt) but still records the
  // research: no post goes out without keywords behind it.
  let keywordStamp: SemrushStamp | null = null;
  if (!usesStrategyVoice(strategy)) {
    try {
      brief = await buildKeywordBrief(angle.query);
      if (brief.source === 'semrush') hint = briefPromptFrom(brief);
      else brief = null;
    } catch { brief = null; }
    if (!brief && run.brief && run.brief.source === 'semrush') {
      brief = run.brief;
      hint = briefPromptFrom(run.brief);
    }
    if (brief) keywordStamp = stampFromBrief(brief);
    else {
      // Semrush had nothing for this angle: the ladder's fallbacks, without
      // spending another unit (lib/keyword-fallback.ts).
      const fallback = await keywordLadder(angle.query, { context: angle.seedTopic, skipSemrush: true });
      hint = fallback.hint || '';
      keywordStamp = fallback.stamp;
    }
  } else {
    keywordStamp = run.brief && run.brief.source === 'semrush'
      ? stampFromBrief(run.brief)
      : (await keywordLadder(angle.query, { context: angle.seedTopic, skipSemrush: true })).stamp;
  }

  // Brand voice.
  let brand: BrandContext | undefined;
  try {
    const { data: bp, error: brandError } = await db
      .from('brand_profiles')
      .select('*')
      .eq('user_id', run.user_id)
      .maybeSingle();
    // Unread, this generated the post with NO brand voice at all and said
    // nothing. (The catch also carried the wrong label — 'media-match' — so even
    // a thrown error was filed under another operation.)
    if (brandError) reportError('autopilot:brand-load', brandError, { runId: run.id });
    if (bp) brand = bp as BrandContext;
  } catch (err) { /* optional */ reportError('autopilot:brand-load', err); }

  // Performance hint from measured posts.
  let performanceHint: string | undefined;
  try {
    const { data: rows, error: metricsError } = await db
      .from('post_metrics')
      .select('network, external_id, text, published_at, impressions, engagement')
      .eq('user_id', run.user_id)
      .order('engagement', { ascending: false })
      .limit(5);
    if (metricsError) reportError('autopilot:performance-hint', metricsError, { runId: run.id });
    if (rows && rows.length) {
      const metrics: NormalizedMetric[] = (rows as Record<string, unknown>[]).map((r) => ({
        network: String(r.network || ''),
        externalId: (r.external_id as string) ?? null,
        text: (r.text as string) ?? null,
        publishedAt: (r.published_at as string) ?? null,
        impressions: Number(r.impressions) || 0,
        engagement: Number(r.engagement) || 0,
      }));
      performanceHint = summarizeTopPerformers(metrics) || undefined;
    }
  } catch (err) { /* optional */ reportError('autopilot:clip-lookup', err); }

  // REAL PAPERS FOR A STRATEGY POST, the way the video pipeline has them.
  //
  // Every strategy post was told to cite "one real, relevant study" with no
  // study in hand, so the writer recalled one, Crossref confirmed only that it
  // exists, and nothing ever asked whether it backs the post. Now the week's
  // angle is looked up first (PubMed, then Crossref; lib/evidence.ts), the
  // abstracts are handed to the writer, and they are kept on the draft so the
  // score step can ask whether the cited paper supports the copy. Fail-open:
  // no papers means the post is written exactly as before.
  const strategySlot = usesStrategyVoice(strategy);
  const citationPolicy = citationPolicyFor(strategy);
  let evidence: EvidenceItem[] = [];
  // Not for a slot that cites only when it makes a health claim (the
  // destination posts): handing the writer study abstracts for a travel or
  // logistics topic pushes it toward exactly the health claim the
  // policy tells it not to make just to have something to cite.
  if (strategySlot && citationPolicy === 'required') {
    try { evidence = await findEvidence(angle.query); } catch (err) { reportError('autopilot:evidence', err, { runId: run.id }); }
  }
  const evidenceHint = evidence.length ? evidenceBriefFrom(evidence) : undefined;

  // Every draft knows the competition (lib/competitive-brief.ts) — except a
  // weekly-strategy slot, whose voice keeps search copy out on purpose.
  let landscapeHint: string | undefined;
  if (!strategySlot) {
    try { landscapeHint = (await competitiveBrief(angle.query)).hint || undefined; } catch (err) { reportError('autopilot:competitive-brief', err, { runId: run.id }); }
  }
  const { provider, pack } = await generateContentPack({
    topic: topicPromptFor(angle, strategy, template.name),
    contentType: strategy.format || 'social',
    channels: template.providers,
    landscapeHint,
    // Strategy slots swap the Brand Brain's promotional guidelines for the
    // strategy's editorial direction, and skip the top-performer hint — the
    // top performers are procedure posts, and imitating them is the problem.
    brand: strategySlot ? strategyBrand(brand, { citation: citationPolicy }) : brand,
    performanceHint: strategySlot ? undefined : performanceHint,
    // Pass the prepared hint ('' = researched, nothing found) so the
    // generator does not run a second, redundant Semrush lookup — and the
    // stamp, so the pack records which rung its keywords came from.
    keywordHint: hint,
    keywordStamp,
    evidenceHint,
    citationPolicy,
    // The reader this week's occurrence is written for (lib/strategy-variety.ts);
    // other templates keep the brand's audience, as before.
    ...(strategySlot && audienceOf(angle) ? { audience: audienceOf(angle) } : {}),
  });
  if (evidence.length) {
    (pack as ContentPack & { _evidence?: EvidenceItem[] })._evidence = evidence.slice(0, MAX_CANDIDATES).map((e) => ({
      ...e,
      abstract: String(e.abstract || '').slice(0, 1200),
    }));
  }

  // Stamp autopilot provenance on the pack (same pattern as _semrush).
  (pack as ContentPack & { _autopilot?: Record<string, unknown> })._autopilot = {
    run_id: run.id,
    template_id: run.template_id,
    template_name: template.name,
    // The slot's identity, so the picture can find its pillar even after the
    // template is renamed (lib/planner-image.ts plannerImageFor).
    ...(usesStrategyVoice(strategy) ? { slot: strategy.slot || null, pillar_id: pillarForStrategy(strategy, template.name)?.id || null } : {}),
    // Which occurrence of this cover title the post is (decided at research,
    // where the history is), so a repeat of an angle — or of the pillar
    // fallback — wears a different title (lib/planner-image.ts).
    ...(angle.titleSeq ? { title_seq: angle.titleSeq } : {}),
    scheduled_for: run.scheduled_for,
    angle,
  };

  // Media enrichment: remember the best matching finished clip so approval
  // can attach it to the Metricool draft. Purely additive.
  //
  // NOT for the weekly strategy: its posts are text with a single image, the
  // brand's chosen format, so no clip is looked for at all. For other pillar
  // rotations, only a clip that shares real ground with the pillar and the
  // angle (lib/clip-relevance.ts): the loose matcher alone put an unrelated reel
  // on a sleep post. Otherwise the post keeps its own picture.
  const topic: PostTopic | undefined = usesPillarRotation(strategy)
    ? { pillar: pillarOf(strategy, template.name, angle.seedTopic), seedTopic: angle.seedTopic, query: angle.query }
    : undefined;
  const media = usesStrategyVoice(strategy) ? null : await findMatchingClip(run.user_id, angle, topic);
  const angleOut: Angle = { ...angle, media };

  // Reuse the existing draft row on regeneration so the library doesn't
  // accumulate orphans; insert on first pass.
  let draftId = run.draft_id;
  if (draftId) {
    // Carry the verified hero image across a redraft. This wrote the fresh
    // pack with no spread, so "Ask for changes" silently destroyed `_image`:
    // the review card lost its picture, the stored file was orphaned, and
    // approval regenerated from variant 0 (burning a second image credit and
    // breaking the "every reroll is a visibly different take" guarantee).
    // The angle is unchanged by a redraft, so the image stays on-topic.
    const { data: prior, error: priorError } = await db
      .from('drafts').select('pack').eq('id', draftId).eq('user_id', run.user_id).maybeSingle();
    // Unread, this dropped _image on every redraft — exactly the bug the comment
    // above says it fixes.
    if (priorError) reportError('autopilot:prior-image', priorError, { runId: run.id });
    const priorImage = (prior as { pack?: { _image?: unknown } } | null)?.pack?._image;
    const nextPack = priorImage && !(pack as { _image?: unknown })._image
      ? { ...(pack as Record<string, unknown>), _image: priorImage }
      : pack;
    const { error } = await db
      .from('drafts').update({ pack: nextPack, provider })
      .eq('id', draftId).eq('user_id', run.user_id);
    if (error) throw new Error('draft update failed: ' + error.message);
  } else {
    const { data: draft, error } = await db
      .from('drafts')
      .insert({
        user_id: run.user_id,
        topic: '[Autopilot] ' + angle.query,
        goal: strategy.goal || 'rank',
        channels: template.providers || [],
        pack,
        provider,
      })
      .select('id')
      .single();
    if (error) throw new Error('draft insert failed: ' + error.message);
    draftId = (draft as { id: string }).id;
  }

  // Learnings: log the applied keywords for the feedback loop. When the
  // chosen query has no brief of its own (cache-only mode), still record the
  // primary from the angle's data — anti-repetition and the learning view
  // both depend on this row existing.
  if (brief) {
    // Was fire-and-forget: on Vercel the lambda can freeze once the response
    // is returned, so this insert was lost non-deterministically — and it is
    // the row anti-repetition reads. The else-branch already awaited.
    await recordDraftKeywords(run.user_id, angle.query, brief);
  } else {
    try {
      await db.from('draft_keywords').insert({
        // `angle.query`, not `angle.seedTopic`. stepResearch builds its
        // anti-repeat set from the TOPIC column and compares candidate
        // `angle.query` values against it — which is what recordDraftKeywords
        // writes on the Semrush path. This branch wrote the pillar name there
        // instead, so nothing it published was ever matched: the anti-repeat
        // was inert in cache-only mode, the exact mirror of the bug the comment
        // in stepResearch describes fixing on the other path.
        topic: angle.query,
        keyword: angle.query,
        volume: angle.volume != null ? Math.round(angle.volume) : null,
        difficulty: angle.difficulty != null ? Math.round(angle.difficulty) : null,
        intent: angle.intent,
        role: 'primary',
      });
    } catch (err) { /* learnings are best-effort */ reportError('autopilot:record-learnings', err); }
  }

  // The picture, made with the post rather than at the door.
  //
  // WHY HERE. ensureDraftImage ran in exactly two places: a reviewer opening
  // the queue (app/AutopilotQueue.tsx), and approve — where it sits inside a
  // try/catch that, by design, never blocks approval. So with nobody in the
  // loop an Instagram post could reach Metricool with media: [], and Instagram
  // refuses a text-only post. Generating it here means the review card has its
  // picture without waiting for a poll, and a gate at the door can REQUIRE an
  // image rather than hope one turned up.
  //
  // Only for networks that refuse text alone (composer.ts's own set), so a
  // LinkedIn-only or blog-only template spends no image credit. Best-effort
  // like every other enrichment in this step: a failed image is a line in the
  // log, never a failed run. ensureDraftImage is idempotent, so a redraft
  // reuses the stored one unless the text checker flagged it.
  let imageNote = '';
  // The weekly article needs one too: it is its featured image on WordPress
  // and the picture on its promos, now that none of them goes to Instagram.
  const needsImage = (template.providers || []).some(
    (p) => NETWORKS_NEEDING_MEDIA.has(String(p || '').trim().toLowerCase())
  ) || wantsBlog(template.providers || []);
  if (needsImage && draftId) {
    try {
      // The brand's own photograph first (lib/draft-picture.ts): a generated
      // picture only when the library has nothing that fits this post.
      const picked = await pictureForDraft(draftId, run.user_id);
      imageNote = picked.image?.url
        ? (picked.source === 'library' ? ' — hero image: a library photograph' + (picked.image.libraryName ? ' (' + picked.image.libraryName + ')' : '') : ' — hero image ready')
        : ' — no hero image yet (images are off, or the generator returned none)';
    } catch (err) {
      // Said out loud on the card. A picture that quietly failed is how a post
      // reaches the door with nothing to show and no explanation for it.
      reportError('autopilot:draft-image', err, { runId: run.id });
      imageNote = ' — the hero image could not be generated; it can be rerolled in the queue';
    }
  }

  return {
    state: 'drafted',
    draft_id: draftId,
    angle: angleOut,
    brief: brief ?? run.brief,
    log: logLine(
      run,
      'draft',
      'Drafted via ' + provider + ' for channels: ' + (template.providers || []).join(', ') +
        (media ? ' — matched clip "' + media.title + '" will attach on approval' : '') +
        imageNote
    ),
  };
}

// ---------------------------------------------------------------------------
// Step 3: score against the rubric; one self-critique regeneration if weak.
// ---------------------------------------------------------------------------

// The rubric itself lives in lib/score-pack.ts, where it can be run by a test.

async function stepScore(run: RunRow, template: TemplateRow, strategy: TemplateStrategy): Promise<Partial<RunRow>> {
  const db = supabaseAdmin();
  const angle = run.angle as Angle;
  if (!run.draft_id || !angle) throw new Error('run has no draft to score');

  const { data: draftRow, error } = await db
    // .eq('user_id') as well as the id: draft_id is a client-writable column on
    // template_runs, so it is not on its own proof of ownership.
    .from('drafts').select('id, pack, provider').eq('id', run.draft_id).eq('user_id', run.user_id).single();
  if (error || !draftRow) throw new Error('draft not found for scoring');
  let pack = (draftRow as { pack: ContentPack }).pack;
  const strategySlot = usesStrategyVoice(strategy);
  // The openings of the recent posts, minus this draft's own (it is among the
  // recent drafts by now): a repeat is another post starting the same way.
  // Excluded by id, before de-duplicating — removing its line afterwards also
  // removed an identical line another post had opened with.
  const recentOpeners = strategySlot
    ? await recentOpenings(run.user_id, undefined, { excludeDraftId: run.draft_id })
    : [];
  let score = scorePack(pack, template.providers || [], angle, { strategySlot, recentOpenings: recentOpeners, closing: angle.closing });
  let regens = run.regens;

  // Self-critique: one bounded regeneration when below threshold — or, for a
  // strategy post, when it reads as an advert at all, whatever it scored.
  const promoted = strategySlot && (Boolean(score.promotionFlags?.length) || Boolean(score.openingRepeat));
  if ((score.total < SCORE_THRESHOLD || promoted) && regens < (strategy.max_regens ?? 1)) {
    regens++;
    try {
      const critiqueNote =
        topicPromptFor(angle, strategy, template.name) +
        ' Previous attempt scored ' + score.total + '/100. Fix exactly these issues: ' +
        score.critique.join(' ');
      // WITH the brand voice, and without suppressing the keyword brief.
      //
      // The retry passed neither, while the first pass passes both. scorePack
      // measures keyword coverage, channel completeness, hook length, CTA and
      // safety — it does NOT measure voice. So a retry that was off-brand but
      // repeated the phrase more often scored higher, won the comparison below,
      // and replaced the on-brand draft with something the rubric was blind to.
      //
      // keywordHint is left UNDEFINED rather than '': generateContentPack runs
      // its own auto-brief when the field is absent and skips it when the field
      // is an empty string, so '' was explicitly turning the research off.
      const loaded = await loadBrandContext(db, run.user_id);
      const citationPolicy = citationPolicyFor(strategy);
      const brand = strategySlot ? strategyBrand(loaded, { citation: citationPolicy }) : loaded;
      const keptEvidence = (pack as ContentPack & { _evidence?: EvidenceItem[] })._evidence;
      // A strategy slot passes '' explicitly: left undefined, the generator
      // ran its own keyword brief on this whole critique prompt and handed the
      // rewrite a Semrush contract the first draft had been kept from.
      const { pack: retry } = await generateContentPack({
        topic: critiqueNote,
        contentType: strategy.format || 'social',
        channels: template.providers,
        brand,
        ...(strategySlot ? { keywordHint: '', citationPolicy, evidenceHint: keptEvidence?.length ? evidenceBriefFrom(keptEvidence) : undefined, audience: audienceOf(angle) } : {}),
      });
      const retryScore = scorePack(retry, template.providers || [], angle, { strategySlot, recentOpenings: recentOpeners, closing: angle.closing });
      if (retryScore.total > score.total) {
        // Everything the first draft had that is not copy comes with it: the
        // provenance, the papers, and — above all — the picture. Dropping
        // `_image` made approval (or the queue) generate a second, different
        // one, and a promotion flag now triggers this rewrite often.
        const prior = pack as unknown as Record<string, unknown>;
        const next = retry as unknown as Record<string, unknown>;
        for (const k of ['_autopilot', '_image', '_imageOptions', '_semrush'] as const) {
          if (prior[k] !== undefined) next[k] = prior[k];
        }
        if (keptEvidence?.length) (retry as ContentPack & { _evidence?: EvidenceItem[] })._evidence = keptEvidence;
        const { error: saveError } = await db.from('drafts').update({ pack: retry })
          .eq('id', run.draft_id).eq('user_id', run.user_id);
        // Read, not assumed. Unread, the SCORE was persisted while the pack was
        // not: the review card showed 81 and the copy stored — and later
        // published — was the one that scored 52.
        if (saveError) {
          reportError('autopilot:regen-save', saveError, { runId: run.id });
        } else {
          pack = retry;
          score = retryScore;
        }
      }
    } catch (err) { /* keep the original pack+score */ reportError('autopilot:regen-rescore', err); }
  }

  // DOES THE CITED PAPER BACK THE POST? For a strategy post whose papers were
  // fetched at draft time. The verdict is stamped on the draft, shown on the
  // card, and read by autoScheduleVerdict (an 'unsupported' holds the post).
  if (strategySlot) {
    let stamp = await strategyClaimSupport(pack as unknown as Record<string, unknown>);
    // "Verify / fix", by default (lib/citation-autofix.ts): a citation the
    // judge did not accept is repaired NOW, before the card is shown, so the
    // reviewer sees the corrected study rather than a warning about the wrong
    // one. The stamp below is then whatever the repair concluded.
    if (stamp && stamp.status !== 'supported') {
      const p0 = pack as unknown as Record<string, unknown>;
      const fixed = await autoFixCitation({ userId: run.user_id, draftId: run.draft_id, text: String(p0.instagram || p0.facebook || ''), pack: p0, budgetMs: 60_000 });
      if (fixed.pack) pack = fixed.pack as unknown as ContentPack;
      if (fixed.swapped) {
        await db.from('template_runs').update({ log: logLine(run, 'fix', 'FIX (automatic, at draft): ' + fixed.note) }).eq('id', run.id);
        stamp = null; // already stamped and saved by the repair
      }
    }
    if (stamp) {
      (pack as ContentPack & { _claimSupport?: ClaimSupportStamp })._claimSupport = stamp;
      const { data: fresh } = await db.from('drafts').select('pack').eq('id', run.draft_id).eq('user_id', run.user_id).maybeSingle();
      const current = (fresh as { pack?: Record<string, unknown> } | null)?.pack || (pack as unknown as Record<string, unknown>);
      const { error: stampError } = await db.from('drafts').update({ pack: { ...current, _claimSupport: stamp } })
        .eq('id', run.draft_id).eq('user_id', run.user_id);
      if (stampError) reportError('autopilot:claim-support-save', stampError, { runId: run.id });
    }
  }

  return {
    state: 'ready_for_review',
    score,
    regens,
    log: logLine(
      run,
      'score',
      'Scored ' + score.total + '/100 (' +
        Object.entries(score.breakdown).map(([k, v]) => k + ' ' + v).join(', ') + ')' +
        (score.safetyFlags.length ? ' — ' + score.safetyFlags.length + ' safety flag(s) for review' : '') +
        (score.promotionFlags?.length ? ' — reads as promotion: ' + score.promotionFlags.join(', ') : '') +
        (score.openingRepeat ? ' — opening repeats a recent post' : '')
    ),
  };
}

// ---------------------------------------------------------------------------
// Sweeper: close out runs whose moment has passed.
// ---------------------------------------------------------------------------

/**
 * Mark still-active runs whose scheduled time has gone by as failed.
 *
 * Without this a run that stalled - a step that kept timing out, a template
 * that stopped being eligible - sat in `planned`/`researched` forever: past its
 * slot, excluded from the advancer, and filtered out of the queue's own listing,
 * so the post never happened and nothing told anyone. `failed` is the state the
 * UI already surfaces as "Needs attention", and `regenerateRun` accepts it, so
 * the reviewer can retry it by hand.
 */
/**
 * Rescue runs stranded in `approved`.
 *
 * `approved` is claimed BEFORE the expensive work — an image generation, media
 * normalisation and the Metricool POST. A thrown error releases the claim; a
 * PLATFORM KILL does not. And nothing else can reach the run afterwards:
 * approveRun requires ready_for_review, regenerateRun rejects it, skipRun
 * refuses it, and neither advanceRuns nor expireStaleRuns selects it. So the run
 * disappears from the queue with nothing published and no way back short of SQL.
 *
 * A run that got far enough to SEND is NOT rescued — that one really was
 * approved, and putting it back would invite a second post for the same slot.
 * "Far enough to send" is read from the run's own log, not from the `posts`
 * row: the row is the thing that is missing when the send succeeded and the
 * bookkeeping did not, which is the one case where releasing is catastrophic.
 */
export async function rescueStrandedApprovals(scopeUserId?: string): Promise<number> {
  const db = supabaseAdmin();
  // Comfortably longer than the approve path's own ceiling, so a slow-but-alive
  // approval is never interrupted by this.
  const cutoff = new Date(Date.now() - 15 * 60 * 1000).toISOString();
  let q = db
    .from('template_runs')
    // draft_id too: the check below needs it to tell a genuinely-approved run
    // from one that died before reaching Metricool.
    .select('id, log, state, updated_at, draft_id')
    .eq('state', 'approved')
    .lt('updated_at', cutoff)
    .limit(50);
  if (scopeUserId) q = q.eq('user_id', scopeUserId);
  const { data, error } = await q;
  if (error) {
    reportError('autopilot:rescue-read', error);
    return 0;
  }

  let rescued = 0;
  type Stranded = { id: string; log: RunRow['log']; state: string; draft_id: string | null };
  for (const row of (data || []) as unknown as Stranded[]) {
    // Did this one actually reach Metricool?
    //
    // THE RUN'S OWN LOG FIRST. approveRun writes a 'sent' step the moment the
    // handoff returns, before the `posts` insert — so a run carrying that step
    // published something even if the bookkeeping afterwards failed. Asking the
    // `posts` table alone was asking the one artifact that is missing in
    // precisely that case, and releasing on its absence put a second live post
    // (and, for the Monday slot, a second published article) one cron tick away.
    if ((row.log || []).some((entry) => entry.step === 'sent' || entry.step === 'approve' || entry.step === 'approve-partial')) continue;

    // Then the posts row, for runs approved before the 'sent' step existed.
    const { data: post, error: postError } = await db
      .from('posts')
      .select('id')
      .eq('draft_id', row.draft_id || '')
      .limit(1)
      .maybeSingle();
    if (postError) {
      reportError('autopilot:rescue-post-check', postError, { runId: row.id });
      continue;
    }
    if (post) continue;

    const { data: updated, error: writeError } = await db
      .from('template_runs')
      .update({
        state: 'ready_for_review',
        log: logLine(row as unknown as RunRow, 'rescued', readArticleLog(row.log)
          // The article went to WordPress before the stop; approving again
          // reuses it (lib/article-promo.ts) and only sends the promos.
          ? 'Approval stopped part-way through: the article is on WordPress, but its promo posts were not sent. This is back in your queue — approve it again to send them; the article will not be published twice.'
          : 'Approval stopped part-way through and left nothing published, so this is back in your queue. Approve it again.'),
      })
      .eq('id', row.id)
      .eq('state', 'approved')
      .select('id');
    if (writeError) {
      reportError('autopilot:rescue-write', writeError, { runId: row.id });
      continue;
    }
    if (Array.isArray(updated) && updated.length) rescued++;
  }
  return rescued;
}

/** Retire one run whose slot no longer exists, with the reason on it. Conditional on its state. */
async function supersedeRun(db: ReturnType<typeof supabaseAdmin>, run: RunRow, note: string): Promise<boolean> {
  const { data, error } = await db
    .from('template_runs')
    .update({ state: 'superseded', log: logLine(run, 'superseded', note) })
    .eq('id', run.id)
    .eq('state', run.state)
    .select('id');
  if (error) reportError('autopilot:supersede', error, { runId: run.id });
  return Array.isArray(data) && data.length > 0;
}

/**
 * Bring a template's future runs in line with the template as it now is.
 *
 * Called after every save of a template (the templates route, the planner and
 * the assistant's tools). planRuns only ever adds runs, so without this a slot
 * moved from 09:00 to 10:00 kept its 09:00 runs — some already drafted — and
 * gained 10:00 ones beside them: two posts, two angles used, and the orphan
 * published at the time the operator had removed. lib/run-reconcile.ts decides;
 * this applies it, then plans the new slots straight away.
 *
 * Best-effort: a failure is reported and the save still stands. The guards in
 * advanceRuns and approveRun catch any orphan this misses.
 */
export async function reconcileTemplateRuns(userId: string, templateId: string): Promise<{ removed: number; superseded: number }> {
  const db = supabaseAdmin();
  const out = { removed: 0, superseded: 0 };
  try {
    const { data: t, error: tError } = await db
      .from('schedule_templates').select('id, weekdays, time_of_day, active')
      .eq('id', templateId).eq('user_id', userId).maybeSingle();
    if (tError) { reportError('autopilot:reconcile-template', tError, { templateId }); return out; }
    if (!t) return out;
    const { data: runs, error: runsError } = await db
      .from('template_runs')
      .select('id, template_id, user_id, state, scheduled_for, angle, log, attempts, regens, brief, score, draft_id')
      .eq('template_id', templateId)
      .eq('user_id', userId)
      .in('state', [...RECONCILABLE_STATES, 'superseded'])
      .gt('scheduled_for', new Date().toISOString());
    if (runsError) { reportError('autopilot:reconcile-runs', runsError, { templateId }); return out; }
    const rows = (runs || []) as RunRow[];
    const plan = reconcilePlan(rows, t as { weekdays?: number[]; time_of_day?: string; active?: boolean });
    if (plan.remove.length) {
      // Planned runs have nothing spent on them: no research, no draft. And a
      // superseded run back at the template's time is cleared so its slot can
      // be planned again (lib/run-reconcile.ts).
      const { data: gone, error: delError } = await db
        .from('template_runs').delete().in('id', plan.remove).in('state', ['planned', 'superseded']).select('id');
      if (delError) reportError('autopilot:reconcile-delete', delError, { templateId });
      out.removed = Array.isArray(gone) ? gone.length : 0;
    }
    for (const id of plan.supersede) {
      const run = rows.find((r) => r.id === id);
      if (run && await supersedeRun(db, run, 'The template moved to a different day or time after this post was started, so it will not be sent. The new time gets its own post.')) out.superseded++;
    }
    if ((t as { active?: boolean }).active !== false) await planRuns(userId);
  } catch (err) {
    reportError('autopilot:reconcile', err, { templateId });
  }
  return out;
}

export async function expireStaleRuns(scopeUserId?: string): Promise<number> {
  const db = supabaseAdmin();
  // A couple of hours of grace: a slot that just passed may still be mid-tick.
  const cutoff = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
  let q = db
    .from('template_runs')
    .select('id, state, log, scheduled_for')
    .in('state', ACTIVE_STATES as unknown as string[])
    .lt('scheduled_for', cutoff)
    .limit(50);
  if (scopeUserId) q = q.eq('user_id', scopeUserId);
  const { data, error } = await q;
  if (error) throw new Error('expireStaleRuns: ' + error.message);

  let expired = 0;
  for (const row of (data || []) as RunRow[]) {
    const { data: updated, error: expireError } = await db
      .from('template_runs')
      .update({
        state: 'failed',
        log: logLine(row, 'expired', 'Its scheduled time passed before this post was ready, so nothing was sent.'),
      })
      .eq('id', row.id)
      .eq('state', row.state)
      .select('id')
      .maybeSingle();
    if (expireError) reportError('autopilot:expire', expireError, { runId: row.id });
    if (updated) expired++;
  }

  // A finished post nobody decided on. It stays in the queue as "missed" —
  // shown first, with "Approve for next free slot" — for MISSED_RETIRE_DAYS.
  // Past that it is retired to skipped, with the reason on it: a fortnight-old
  // post about this week's angle is not something to publish late, and a
  // queue that only grows is one nobody reads.
  const retireBefore = new Date(Date.now() - MISSED_RETIRE_DAYS * 24 * 60 * 60 * 1000).toISOString();
  let rq = db
    .from('template_runs')
    .select('id, state, log, scheduled_for')
    .eq('state', 'ready_for_review')
    .lt('scheduled_for', retireBefore)
    .limit(50);
  if (scopeUserId) rq = rq.eq('user_id', scopeUserId);
  const { data: stale, error: staleError } = await rq;
  if (staleError) {
    reportError('autopilot:missed-expire-read', staleError);
    return expired;
  }
  for (const row of (stale || []) as RunRow[]) {
    const { data: updated, error: retireError } = await db
      .from('template_runs')
      .update({
        state: 'skipped',
        log: logLine(row, 'missed-expired', 'Nobody approved this post within ' + MISSED_RETIRE_DAYS + ' days of its time, so it was retired. Nothing was sent.'),
      })
      .eq('id', row.id)
      .eq('state', 'ready_for_review')
      .select('id')
      .maybeSingle();
    if (retireError) reportError('autopilot:missed-expire', retireError, { runId: row.id });
    if (updated) expired++;
  }
  return expired;
}

// ---------------------------------------------------------------------------
// The engine's own Approve.
// ---------------------------------------------------------------------------

/**
 * Send a finished run without a person, when it clears every bar.
 *
 * WHAT REPLACED THE HUMAN. Until now every post this engine wrote was read by
 * somebody before it went out, and that person was the last check on four
 * things the code computed and then ignored: a Crossref verdict stamped on the
 * pack and never consulted, a score nothing ever refused a run for, a safety
 * rubric whose flags only coloured a card, and a picture that was best-effort
 * on a network that refuses posts without one. lib/autoschedule.ts is those
 * four checks, made binding. If any of them cannot be established, the run
 * waits — this is the one guard in the codebase that fails CLOSED.
 *
 * Nothing here weakens approveRun: the compliance gate, the video rule and the
 * Metricool handoff all still run inside it, and can still refuse.
 *
 * Fail-soft in the other direction too: if this function throws, the run stays
 * ready_for_review and a person can approve it by hand. A broken auto-send
 * must never lose the post.
 */
/**
 * Put the reason on the card and leave the run where it is.
 *
 * "Held" with no explanation is how a queue becomes a pile nobody trusts, and
 * there are two things that can hold a run now — the post and the week — so
 * this is one helper rather than two copies that could drift apart.
 *
 * Predicated on ready_for_review, so a reviewer who approved it in the same
 * moment does not get a hold note written over their post.
 */
async function hold(
  db: ReturnType<typeof supabaseAdmin>,
  run: RunRow,
  note: string,
): Promise<void> {
  const { error } = await db
    .from('template_runs')
    .update({ log: logLine(run, 'hold', note) })
    .eq('id', run.id)
    .eq('state', 'ready_for_review');
  if (error) reportError('autopilot:autoschedule-hold', error, { runId: run.id });
}

async function autoSchedule(
  db: ReturnType<typeof supabaseAdmin>,
  run: RunRow,
  template: TemplateRow,
): Promise<void> {
  try {
    // A slot that has already passed is a person's decision, never the
    // engine's: approveRun would refuse it anyway, and moving a post to a new
    // time is something only a reviewer asks for.
    if (isMissed(run)) {
      await hold(db, run, 'Held for you because this post\'s time has already passed. Nothing was sent. Use "Approve for next free slot" to send it at the next open time, or skip it.');
      return;
    }
    // A redraft a reviewer asked for waits for that reviewer. The !opts.runId
    // guard in advanceRuns covers a redraft that finishes inside their
    // request; this covers one a later tick finishes.
    if ((run.angle as Angle | null)?.reviewRequestedAt) {
      await hold(db, run, 'Held for you: you asked for changes, so the redraft waits for you to read it before it goes out.');
      return;
    }
    // The pack carries both signals: the Crossref verdict stamped at
    // generation time (lib/ai.ts) and the hero image stamped at draft time.
    let pack: Record<string, unknown> | null = null;
    if (run.draft_id) {
      const { data, error } = await db
        .from('drafts').select('pack').eq('id', run.draft_id).eq('user_id', run.user_id).maybeSingle();
      if (error) {
        // Unread, this would read as "no citation" and hold every post on an
        // account whose drafts table hiccuped — silently, forever.
        reportError('autopilot:autoschedule-draft', error, { runId: run.id });
        return;
      }
      pack = (data as { pack?: Record<string, unknown> } | null)?.pack || null;
    }
    const compliance = pack?._compliance as { citation?: { status?: string } } | undefined;
    const image = pack?._image as { url?: string; verification?: { textDetected?: boolean; bannedProp?: boolean; issues?: string[] } } | undefined;
    // An image the checker flagged for text or a banned prop is treated as no
    // image, exactly as the ship-point treats it (see approveRun): it can never
    // be attached, so a post that needs one does not have one.
    const hasImage = Boolean(image?.url) && !imageUnshippable(image?.verification);

    const verdict = autoScheduleVerdict({
      citation: compliance?.citation?.status ?? null,
      score: run.score?.total ?? null,
      threshold: SCORE_THRESHOLD,
      safetyFlags: run.score?.safetyFlags?.length ?? 0,
      promotionFlags: run.score?.promotionFlags?.length ?? 0,
      openingRepeat: Boolean(run.score?.openingRepeat),
      networks: template.providers || [],
      hasMedia: hasImage || Boolean(attachableClip(run.angle, template.strategy, template.name)),
      // The judge's verdict on a strategy post's citation (stepScore). Null for
      // every other post, which is what this always was.
      claimSupport: (pack?._claimSupport as { status?: string } | undefined)?.status ?? null,
    });

    if (!verdict.ok) {
      // The reason goes on the card. "Held" with no explanation is how a queue
      // becomes a pile nobody trusts.
      await hold(db, run, holdNote(verdict));
      return;
    }

    // THE WEEK, not the post. Everything above asks whether this one is fit to
    // go out; a calendar that has quietly doubled passes all of it, fifteen
    // extra times. See lib/weekly-pace.ts for why that is a live possibility
    // and not a hypothetical.
    //
    // A hold here is final until a person acts, exactly like every other hold:
    // ready_for_review is not in ACTIVE_STATES, so no later tick revisits it.
    // That is the fail-closed direction — a week that emptied out afterwards
    // costs somebody a button, a week that did not costs the brand a second
    // set of posts.
    const slotMs = Date.parse(run.scheduled_for);
    if (!Number.isFinite(slotMs)) {
      // Not reachable from a `timestamptz not null` column, but a NaN here
      // would THROW in the window arithmetic below rather than hold — and an
      // uncountable week holding is the entire point of this block.
      await hold(db, run, paceNote(weeklyPaceVerdict({ slot: run.scheduled_for, scheduled: [] })));
      return;
    }
    const edge = ROLLING_WINDOW_DAYS * 24 * 60 * 60 * 1000;
    const { data: nearby, error: paceError } = await db
      .from('posts')
      // draft_id, because a reel fanned out to three networks is three rows and
      // one post; the ceiling is counted in drafts. id as the fallback key.
      .select('id, draft_id, publication_date, status')
      .eq('user_id', run.user_id)
      // The statuses weeklyPaceVerdict would discard anyway, dropped here so
      // they do not spend the scan budget. `posts.status` is NOT NULL with a
      // default, so this cannot silently drop a row for being null — and the
      // module still filters, which keeps it right about case variants.
      .not('status', 'in', '(' + [...NOT_PUBLISHING].join(',') + ')')
      // Both sides: a seven-day window containing this slot can start a week
      // before it and end a week after, and the worst one is whichever of
      // those it is. Asking only for the past would miss a slot dropped into
      // the middle of an already-full week.
      .gte('publication_date', new Date(slotMs - edge).toISOString())
      .lte('publication_date', new Date(slotMs + edge).toISOString())
      .limit(PACE_SCAN_LIMIT + 1);
    if (paceError) {
      // Fail closed — but SAY SO. autoSchedule is only reached at the moment a
      // run turns ready_for_review, and ready_for_review is not in
      // ACTIVE_STATES, so no later tick comes back to it. Returning silently
      // therefore demoted the post to manual approval permanently, with a blank
      // card: the exact "held with no explanation" this file refuses to create.
      reportError('autopilot:autoschedule-pace', paceError, { runId: run.id });
      await hold(
        db,
        run,
        'Held for you because the calendar could not be read just now, so there was no way to tell '
          + 'whether this week already has enough posts in it. Nothing was sent. Approve it yourself if the week looks right.',
      );
      return;
    }
    const rows = (nearby || []) as {
      id?: string | null;
      draft_id?: string | null;
      publication_date?: string | null;
      status?: string | null;
    }[];
    const pace = weeklyPaceVerdict({
      slot: run.scheduled_for,
      scheduled: rows.slice(0, PACE_SCAN_LIMIT),
      ceiling: weeklyCeiling(process.env.AUTOPILOT_WEEKLY_CEILING),
      truncated: rows.length > PACE_SCAN_LIMIT,
    });
    if (!pace.ok) {
      await hold(db, run, paceNote(pace));
      return;
    }

    const result = await approveRun(run.id, run.user_id, { schedule: true });
    if (!result.ok) {
      // approveRun has already written its own explanation and put the run
      // back in the queue; this only records that it was the engine asking.
      reportError('autopilot:autoschedule-refused', new Error(result.note), { runId: run.id });
    }
  } catch (err) {
    // The run is still ready_for_review. Nothing is lost.
    reportError('autopilot:autoschedule', err, { runId: run.id });
  }
}

// ---------------------------------------------------------------------------
// The advancer: move due runs forward, one resumable step at a time.
// ---------------------------------------------------------------------------

export async function advanceRuns(opts: {
  scopeUserId?: string;
  runId?: string;
  budgetMs?: number;
  maxRuns?: number;
} = {}): Promise<{ advanced: number; ready: number; errors: number; skipped: string[] }> {
  const db = supabaseAdmin();
  const deadline = Date.now() + (opts.budgetMs ?? 40_000);

  // WHY NOTHING HAPPENED, when nothing happens.
  //
  // Every `continue` below used to end the run's turn in silence, and the
  // caller answered {ok: true, advanced: 0} — a shape indistinguishable from a
  // quiet day. For the cron tick that is merely unhelpful. For the Retry
  // button it is a lie: a reviewer presses Retry on a red card, the request
  // succeeds, and nothing whatsoever has happened, with no log line and no
  // message. The worst case is a template switched off, where Retry is a
  // PERMANENT no-op that reports success every single time.
  //
  // Sentences, not codes, because they are shown to a person verbatim. Capped
  // so a 50-run tick cannot return an essay.
  const skipped: string[] = [];
  const skip = (why: string) => { if (skipped.length < 10) skipped.push(why); };

  let q = db
    .from('template_runs')
    .select('*')
    .order('scheduled_for', { ascending: true })
    .limit(opts.maxRuns ?? 4);
  if (opts.runId) {
    // Explicit run-now: allow retrying a failed run too.
    q = q.eq('id', opts.runId).in('state', [...ACTIVE_STATES, 'failed'] as unknown as string[]);
  } else {
    q = q
      .in('state', ACTIVE_STATES as unknown as string[])
      .lt('attempts', MAX_ATTEMPTS)
      // The per-template lead window is enforced below; here just exclude
      // stale past slots (older than a day) from consideration.
      .gte('scheduled_for', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());
  }
  if (opts.scopeUserId) q = q.eq('user_id', opts.scopeUserId);
  const { data: runs, error: runsErr } = await q;
  if (runsErr) throw new Error('advanceRuns: could not read runs - ' + runsErr.message);

  let advanced = 0, ready = 0, errors = 0;
  for (const raw of (runs || []) as RunRow[]) {
    if (Date.now() > deadline) break;
    const { data: t, error: tError } = await db
      .from('schedule_templates')
      .select('id, user_id, name, providers, text, weekdays, time_of_day, active, strategy')
      .eq('id', raw.template_id)
      .maybeSingle();
    // Unread, a database blip made this `continue` — the run silently skipped
    // with no attempt and no log line, and the tick returned {advanced: 0},
    // indistinguishable from a quiet day. That is the exact complaint the tick
    // route's own header records.
    if (tError) {
      reportError('autopilot:template-read', tError, { runId: raw.id });
      errors++;
      continue;
    }
    if (!t) {
      skip('The template this occurrence belongs to no longer exists, so there is nothing to prepare from.');
      continue;
    }
    const template = t as TemplateRow;
    const strategy = normalizeStrategy(template.strategy);
    // THE PERMANENT NO-OP. Deactivating a template, or setting its mode to
    // 'off', makes Retry do nothing forever while still answering ok — which is
    // the single most likely reason a red card survives a week of retries.
    if (strategy.mode === 'off' || !template.active) {
      skip(
        'The template “' + (template.name || 'Untitled template') + '” is switched ' +
        (template.active ? 'to manual (Autopilot off)' : 'off') +
        ', so the engine will not prepare this occurrence. Turn it back on under Templates, then retry.',
      );
      continue;
    }

    // A SLOT THAT HAS MOVED. The template's day or time changed after this run
    // was planned (lib/run-reconcile.ts). Saving a template reconciles its runs,
    // but any door that does not — a direct edit, a failed reconcile — must
    // still not have its orphan prepared, sent, and counted.
    if (!(raw.angle?.redatedFrom) && !slotMatches(raw.scheduled_for, template.weekdays, template.time_of_day, SCHEDULE_TZ)) {
      await supersedeRun(db, raw, 'This occurrence was planned for a time the template no longer uses, so it will not be prepared. The new time has its own occurrence.');
      skip('The template “' + (template.name || 'Untitled template') + '” now runs at a different day or time, so this occurrence was retired in favour of the new one.');
      continue;
    }

    // Respect the lead window unless this is an explicit run-now.
    //
    // RAISED to whatever the tick can actually reach. expireStaleRuns retires
    // anything two hours past its slot, so a lead too short to fit the pipeline
    // means this `continue` fires on every tick that could still help — and the
    // run is stale and marked failed before it ever gets a pass. Every
    // occurrence, forever, with a message blaming the slot time.
    // lib/lead-window.ts works out the floor from the tick interval; honouring
    // a too-short lead is the one choice that produces a template whose posts
    // are reliably late.
    const slotAt = new Date(raw.scheduled_for);
    const effectiveLead = usableLeadHours(strategy.lead_hours ?? 24);
    const leadMs = effectiveLead * 60 * 60 * 1000;
    if (!opts.runId && slotAt.getTime() - leadMs > Date.now()) continue;

    let run = raw;
    // Explicit retry of a failed run: restart the pipeline from research.
    if (run.state === 'failed') {
      const { data: reset, error: resetError } = await db
        .from('template_runs')
        .update({ state: 'planned', attempts: 0, log: logLine(run, 'retry', 'Manual retry — restarting from research.') })
        .eq('id', run.id)
        // Predicated, so a run somebody else has already moved is left alone.
        .eq('state', 'failed')
        .select('*')
        .maybeSingle();
      // Read, not dropped. Without this a failed reset left run.state as
      // 'failed', the while-guard below (which only admits ACTIVE_STATES) never
      // fired, and "Run now" on a failed run silently did nothing while
      // returning {ok: true, advanced: 0} — indistinguishable from a quiet day.
      if (resetError) {
        reportError('autopilot:retry-reset', resetError, { runId: run.id });
        skip('This occurrence could not be reset for another attempt just now — try again in a moment.');
        errors++;
        continue;
      }
      if (!reset) {
        skip('Somebody else moved this occurrence while the retry was starting, so it was left where they put it.');
        continue;
      }
      run = reset as RunRow;
    }
    // Step until ready (or budget/attempt limits hit) so a single tick can
    // take one run all the way to review.
    while (ACTIVE_STATES.includes(run.state as (typeof ACTIVE_STATES)[number]) && Date.now() < deadline) {
      // Count the attempt BEFORE the step runs.
      //
      // `attempts` used to be incremented only in the catch below. A step that
      // exceeds the function budget is not an exception - the platform kills
      // the process - so the catch never ran, `attempts` never moved, and the
      // run stayed eligible forever. Every following tick then re-ran the same
      // step (roughly a dozen Semrush reports plus a full model call) at full
      // cost, every day, with nothing ever reaching MAX_ATTEMPTS. Claiming the
      // attempt up front makes a timeout cost exactly what a thrown error
      // costs; a successful step resets the counter to 0 in the same write
      // that advances the state.
      const startedFrom = run.state;
      const claimedAttempts = (run.attempts ?? 0) + 1;
      const { data: claimed, error: claimErr } = await db
        .from('template_runs')
        .update({ attempts: claimedAttempts })
        .eq('id', run.id)
        .eq('state', startedFrom)
        .eq('attempts', run.attempts ?? 0)
        .select('*')
        .maybeSingle();
      if (claimErr) throw new Error('advanceRuns: could not claim run - ' + claimErr.message);
      if (!claimed) {
        // Another worker holds this run. Only worth saying when nothing at all
        // happened; the caller decides, because on a busy tick this is normal.
        skip('This occurrence was already being prepared by another run of the engine.');
        break;
      }
      run = claimed as RunRow;

      try {
        let patch: Partial<RunRow>;
        if (run.state === 'planned') patch = await stepResearch(run, template, strategy);
        else if (run.state === 'researched') patch = await stepDraft(run, template, strategy);
        else patch = await stepScore(run, template, strategy);

        // Conditional on the state we started this step from. Without it, a
        // cron tick and a "Run engine now" click running concurrently both
        // advanced the same run and the second write clobbered the first,
        // leaving log/draft_id inconsistent. Now the loser's write matches
        // no row and it stops instead of corrupting the run.
        const { data: updated, error } = await db
          .from('template_runs')
          .update({ ...patch, attempts: 0 })
          .eq('id', run.id)
          .eq('state', run.state)
          .select('*')
          .maybeSingle();
        if (error) throw new Error(error.message);
        if (!updated) break; // another worker advanced this run — leave it alone
        run = updated as RunRow;
        advanced++;
        if (run.state === 'ready_for_review') {
          ready++;
          // The post is finished. With AUTOPILOT_AUTOSCHEDULE on, and only if
          // it clears every bar in lib/autoschedule.ts, the engine presses its
          // own Approve here. Off — the default — this whole block is skipped
          // and the run waits for a person exactly as it always has.
          //
          // approveRun claims ready_for_review -> approved conditionally, so a
          // reviewer pressing Approve at this same moment does not produce two
          // posts: one of the two claims wins and the other stops.
          //
          // Never for a run a person asked for by id: "Ask for changes" and
          // "Prepare now" call this with runId, and the reviewer is waiting to
          // read what comes back. Sending it before they see it would publish
          // a redraft nobody approved.
          if (autoSchedules() && !opts.runId) {
            // Sending is the longest step there is — WordPress, then one
            // Metricool post per network — and it runs inside this tick's
            // budget with nothing to stop it mid-way. With too little time left
            // a platform kill would strand the run half-sent, so it is held for
            // a person instead (a held run is never lost; it waits in the queue).
            if (deadline - Date.now() < AUTOSCHEDULE_MIN_MS) {
              await hold(db, run, 'Held for you: this post was finished late in a run of the engine, with too little time left to send it safely. Nothing was sent. Approve it yourself.');
            } else {
              await autoSchedule(db, run, template);
            }
          }
          break;
        }
      } catch (e) {
        errors++;
        // The attempt was already recorded by the claim above.
        const attempts = run.attempts ?? claimedAttempts;
        // CONDITIONAL, like every other transition in this file. This was the
        // one blind write, and it resurrected work a person had cancelled: a
        // reviewer pressing Skip during a long step sets 'skipped', then this
        // handler wrote 'drafted' straight over it — and the run advanced,
        // became approvable, and published. The same race clobbered a
        // concurrent regenerateRun, discarding the reviewer's feedback note.
        //
        // Predicated on the state this loop believes it holds, so a run that
        // somebody else has moved is left exactly where they put it.
        const { error: failError } = await db
          .from('template_runs')
          .update({
            state: attempts >= MAX_ATTEMPTS ? 'failed' : startedFrom,
            log: logLine(run, 'error', e instanceof Error ? e.message : 'step failed'),
          })
          .eq('id', run.id)
          // startedFrom, which the claim above left untouched (it writes only
          // `attempts`) and which the success path predicates on identically.
          .eq('state', startedFrom);
        if (failError) reportError('autopilot:step-error-write', failError, { runId: run.id });
        break;
      }
    }
  }
  return { advanced, ready, errors, skipped };
}

// ---------------------------------------------------------------------------
// Approval: the ONLY path that talks to the scheduler — and it stays a draft.
// ---------------------------------------------------------------------------

// The list of Metricool networks used to be written out here as well. It is in
// lib/metricool-networks.ts now — one definition, and a pure one, so the two
// other doors that send this column onward can use the same filter instead of
// casting the raw column and hoping.

export type ApproveOptions = {
  /**
   * true  → the post goes straight into Metricool's live queue and publishes
   *         at the run's slot (the reviewer pressed "Approve & schedule");
   * false → it lands in the review queue as before (the default).
   *
   * WHO SETS IT. A person, or — since AUTOPILOT_AUTOSCHEDULE existed — the
   * engine itself, from `autoSchedule` above, and only for a run that clears
   * every bar in lib/autoschedule.ts. That setting is off by default, so on an
   * account that has not turned it on this is still only ever a person.
   *
   * It does not soften anything below: the compliance gate, the video rule and
   * the Metricool handoff all run the same way whoever asked.
   */
  schedule?: boolean;
  /**
   * The reviewer pressed "Approve for next free slot" on a post whose time has
   * passed. Without it a past slot is refused: Metricool will not take a date
   * in the past, and guessing a new time for somebody is not this function's
   * call. Only a person sets it — the engine holds a missed post instead.
   */
  redate?: boolean;
};

/**
 * Move a claimed run whose slot has passed to the next free slot.
 *
 * "Free" is lib/missed-slot.ts's answer: inside posting hours in the schedule
 * time zone and an hour clear of every post already going out and every run
 * still on its way. The move is conditional on the claim still holding, and
 * the unique (template_id, scheduled_for) key is answered by trying the next
 * candidate rather than failing.
 *
 * Returns the new slot, or null after writing nothing.
 */
async function redateClaimedRun(
  db: ReturnType<typeof supabaseAdmin>,
  run: RunRow,
): Promise<string | null> {
  const now = new Date();
  const horizon = new Date(now.getTime() + 8 * 24 * 60 * 60 * 1000).toISOString();
  const [posts, runs] = await Promise.all([
    db.from('posts').select('publication_date')
      .eq('user_id', run.user_id)
      .not('status', 'in', '(' + [...NOT_PUBLISHING].join(',') + ')')
      .gte('publication_date', now.toISOString())
      .lte('publication_date', horizon)
      .limit(500),
    db.from('template_runs').select('scheduled_for')
      .eq('user_id', run.user_id)
      .in('state', [...ACTIVE_STATES, 'ready_for_review'])
      .neq('id', run.id)
      .gte('scheduled_for', now.toISOString())
      .lte('scheduled_for', horizon)
      .limit(500),
  ]);
  if (posts.error || runs.error) {
    reportError('autopilot:redate-read', posts.error || runs.error, { runId: run.id });
    return null;
  }
  const busy: Date[] = [
    ...((posts.data || []) as { publication_date?: string | null }[]).map((p) => new Date(String(p.publication_date || ''))),
    ...((runs.data || []) as { scheduled_for?: string | null }[]).map((r) => new Date(String(r.scheduled_for || ''))),
  ].filter((d) => Number.isFinite(d.getTime()));

  for (let attempt = 0; attempt < 5; attempt++) {
    const slot = nextFreeSlot({ now, busy, tz: SCHEDULE_TZ });
    if (!slot) return null;
    const iso = slot.toISOString();
    const angle = run.angle ? { ...run.angle, redatedFrom: run.angle.redatedFrom || run.scheduled_for } : run.angle;
    const { data, error } = await db
      .from('template_runs')
      .update({ scheduled_for: iso, angle })
      .eq('id', run.id)
      .eq('state', 'approved')
      .select('id');
    if (error) {
      // Another run of this template already holds that instant: take the next.
      if ((error as { code?: string }).code === '23505') { busy.push(slot); continue; }
      reportError('autopilot:redate-write', error, { runId: run.id });
      return null;
    }
    if (!Array.isArray(data) || !data.length) return null;
    return iso;
  }
  return null;
}

/**
 * Put a run that has already been CLAIMED back in the queue.
 *
 * Every early exit after the claim must come through here. `approved` is a
 * one-way trapdoor otherwise: approveRun requires ready_for_review,
 * regenerateRun rejects it, skipRun refuses it, and neither advanceRuns nor
 * expireStaleRuns selects it — so a run left there disappears from the queue
 * with nothing published and no way to reach it short of SQL.
 */
async function releaseClaim(
  db: ReturnType<typeof supabaseAdmin>,
  run: RunRow,
  step: string,
  note: string,
): Promise<void> {
  const { error } = await db
    .from('template_runs')
    .update({ state: 'ready_for_review', log: logLine(run, step, note) })
    .eq('id', run.id)
    .eq('state', 'approved');
  // Read, not assumed. A failed release is exactly the stranding this function
  // exists to prevent, and it must be visible rather than silently leaving the
  // run in `approved` while the caller reports a tidy refusal.
  if (error) reportError('autopilot:release-claim', error, { runId: run.id, step });
}

export async function approveRun(runId: string, userId: string, opts: ApproveOptions = {}): Promise<{ ok: boolean; note: string }> {
  const db = supabaseAdmin();
  const { data: r, error: readError } = await db
    .from('template_runs').select('*').eq('id', runId).eq('user_id', userId).maybeSingle();
  // supabase-js RESOLVES a failed read, so an unread error here returned
  // "run not found" for a run that exists — a lie that makes a reviewer stop
  // trying.
  if (readError) {
    reportError('autopilot:approve-read', readError, { runId });
    return { ok: false, note: 'Could not read that run just now. Nothing was sent; try again in a moment.' };
  }
  const run = r as RunRow | null;
  if (!run) return { ok: false, note: 'run not found' };
  if (run.state !== 'ready_for_review') return { ok: false, note: 'run is not ready for review' };
  if (!run.draft_id) return { ok: false, note: 'run has no draft' };

  // CLAIM FIRST. The read above and the transition at the end used to be
  // separated by up to 60s of image generation and the Metricool POST, with
  // nothing in between guarding the state — so two tabs (or a retry after an
  // edge timeout) both passed the check and both created a Metricool draft
  // and a posts row for the same slot. `posts` has no unique constraint to
  // catch it. This conditional update is the atomic claim: exactly one caller
  // can move ready_for_review -> approved, and the loser stops here having
  // spent nothing. State is set before the handoff rather than after, which
  // matches the existing semantics — a failed Metricool call already left the
  // run approved with an explanatory note.
  const { data: claimed, error: claimError } = await db
    .from('template_runs')
    .update({ state: 'approved' })
    .eq('id', run.id)
    .eq('state', 'ready_for_review')
    .select('id');
  // "Somebody else got there first" and "the write failed" are different
  // answers. Reporting the second as the first told a reviewer their post was
  // already handled when nothing had happened at all.
  if (claimError) {
    reportError('autopilot:approve-claim', claimError, { runId: run.id });
    return { ok: false, note: 'Could not take hold of that run just now. Nothing was sent; try again in a moment.' };
  }
  if (!Array.isArray(claimed) || claimed.length === 0) {
    return { ok: false, note: 'this run was already actioned' };
  }

  // A SLOT THAT HAS ALREADY GONE BY. Sending it anyway handed Metricool a
  // publication date in the past, which it refuses — after the reviewer had
  // moved on. So a missed post is either moved, because the reviewer asked for
  // exactly that, or refused here with the way forward written on the card.
  if (isMissed(run)) {
    const missedAt = slotLabel(run.scheduled_for);
    if (!opts.redate) {
      const why = 'Not sent: this post was due ' + missedAt + ' and that time has passed. ' +
        'Press "Approve for next free slot" to send it at the next open time, or skip it. Nothing was sent.';
      await releaseClaim(db, run, 'approve-refused', why);
      return { ok: false, note: why };
    }
    const moved = await redateClaimedRun(db, run);
    if (!moved) {
      const why = 'Not sent: this post missed ' + missedAt + ' and no free slot could be found in the next week. Nothing was sent; try again, or skip it.';
      await releaseClaim(db, run, 'approve-failed', why);
      return { ok: false, note: why };
    }
    // Everything below — the Metricool date, the posts row, the article —
    // reads the slot from here.
    run.angle = run.angle ? { ...run.angle, redatedFrom: run.angle.redatedFrom || run.scheduled_for } : run.angle;
    run.scheduled_for = moved;
    run.log = logLine(run, 'redated', 'Missed ' + missedAt + '; moved to ' + slotLabel(moved) + ' at the reviewer\'s request.');
  }

  // THE READ THAT COULD NOT FAIL QUIETLY.
  //
  // supabase-js resolves a failed query, so an unread error here gave `t = null`
  // and therefore `providers = []`. Everything downstream then reads as a
  // deliberate no-op: appliesTo([]) is false so the advertising-permit gate is
  // SKIPPED, `if (mcProviders.length)` is false so NOTHING is sent to Metricool,
  // handoffFailed stays false so no compensating write runs — and a posts row is
  // inserted and `{ok: true, note: 'Staged for publishing review.'}` returned.
  // The post sits on the calendar saying "waiting for your approval" and can
  // never publish. This is the exact invariant the comment below claims.
  const { data: t, error: templateError } = await db
    .from('schedule_templates').select('providers, name, strategy, weekdays, time_of_day').eq('id', run.template_id).maybeSingle();
  if (templateError) {
    reportError('autopilot:approve-template', templateError, { runId: run.id });
    await releaseClaim(db, run, 'approve-failed', 'Approval could not proceed: the template could not be read. Returned for review.');
    return { ok: false, note: 'Could not read the template for that run, so nothing was sent. It is back in your queue.' };
  }
  const providers: string[] = (t && Array.isArray((t as { providers?: string[] }).providers))
    ? ((t as { providers?: string[] }).providers as string[])
    : [];
  // A template with no usable DESTINATION is not something to stage silently.
  //
  // This used to test `providers.length`, which is not the same question. A
  // blog-only template has one provider and no Metricool network, so it sailed
  // past this guard, skipped the handoff block below (`if (mcProviders.length)`
  // is false), left `handoffFailed` false because nothing was attempted — and
  // wrote a `posts` row returning ok: true. The post then sat on the calendar
  // marked "waiting for your approval", having been sent nowhere, and could
  // never publish. Exactly the state the comment above the insert says this
  // function refuses to record.
  // THE SLOT MOVED after this post was prepared. Sending it would publish at
  // the time the operator believes they removed, beside a fresh post for the
  // new time. A re-dated run is exempt: its time is the reviewer's own choice.
  const tpl = t as { weekdays?: number[] | null; time_of_day?: string | null } | null;
  if (tpl && !run.angle?.redatedFrom && !slotMatches(run.scheduled_for, tpl.weekdays, tpl.time_of_day, SCHEDULE_TZ)) {
    const why = 'Not sent: this post was prepared for ' + slotLabel(run.scheduled_for) + ', but the slot has since moved to a different day or time. ' +
      'It has been retired, and the new time gets its own post. Nothing was sent.';
    await db.from('template_runs')
      .update({ state: 'superseded', log: logLine(run, 'superseded', why) })
      .eq('id', run.id)
      .eq('state', 'approved');
    return { ok: false, note: why };
  }
  const wantsArticle = wantsBlog(providers);
  // A weekly-strategy or pillar-rotation post carries a clip only when it is
  // relevant to the pillar and angle; a stored clip that is not is ignored
  // here rather than shipped over the post's own picture.
  const clip = attachableClip(run.angle, (t as { strategy?: TemplateStrategy | null } | null)?.strategy, (t as { name?: string } | null)?.name);
  if (!metricoolNetworks(providers).length && !wantsArticle) {
    await releaseClaim(db, run, 'approve-failed', 'Approval could not proceed: the template has no networks selected. Returned for review.');
    return { ok: false, note: 'That template has no networks selected, so there was nowhere to send it. It is back in your queue.' };
  }
  const { data: d, error: draftError } = await db.from('drafts').select('pack').eq('id', run.draft_id).eq('user_id', run.user_id).maybeSingle();
  if (draftError) {
    reportError('autopilot:approve-draft', draftError, { runId: run.id });
    await releaseClaim(db, run, 'approve-failed', 'Approval could not proceed: the draft could not be read. Returned for review.');
    return { ok: false, note: 'Could not read that draft just now, so nothing was sent. It is back in your queue.' };
  }
  let pack = (d as { pack?: ContentPack } | null)?.pack;
  if (!pack) {
    await releaseClaim(db, run, 'approve-failed', 'Approval could not proceed: the draft has no content. Returned for review.');
    return { ok: false, note: 'The draft has no content, so nothing was sent. The run is back in your queue.' };
  }

  const mcProviders = metricoolNetworks(providers);
  // ONE SEND PER NETWORK, EACH WITH ITS OWN COPY (lib/approve-plan.ts).
  //
  // This picked one text — the first network's, in practice the Instagram
  // caption — and sent it to every network in a single post. The Facebook and
  // LinkedIn copy the writer produced, the scorer graded and the review card
  // showed in their own tabs was thrown away, and LinkedIn got an Instagram
  // caption with its hashtags.
  //
  // Advertising rule (lib/compliance.ts), per network: the AVISO is
  // deterministic and is added if the pack predates the rule; a missing REF
  // cannot be invented and returns the run for review with the reason written
  // down. Every network is checked before any is sent.
  const aviso = mcProviders.length ? await avisoForUser(run.user_id) : null;
  // The weekly article's promos carry its link, which only exists once
  // WordPress has the article. They are checked here with a stand-in link of
  // realistic length, and built again around the real one after publishing.
  const refPolicy = citationPolicyFor((t as { strategy?: TemplateStrategy | null } | null)?.strategy);
  // "Verify / fix", by default (lib/citation-autofix.ts). A citation the judge
  // has not already accepted is checked against the copy and swapped for a
  // study that backs it, on every channel of the draft, BEFORE the sends are
  // planned — so what goes to Metricool is the corrected copy, and the claim
  // gate below reads a fresh stamp. Fails open; the gate still decides.
  if (mcProviders.length) {
    const p0 = pack as unknown as Record<string, unknown>;
    const caption = String(p0.instagram || p0.facebook || p0.linkedin || '');
    const fixed = await autoFixCitation({ userId: run.user_id, draftId: run.draft_id, text: caption, pack: p0, budgetMs: 60_000 });
    if (fixed.swapped && fixed.pack) {
      pack = fixed.pack as unknown as ContentPack;
      await db.from('template_runs').update({ log: logLine(run, 'fix', 'FIX (automatic, at approve): ' + fixed.note) }).eq('id', run.id);
    }
    // And keywords: a post never goes out without them (lib/keyword-guard.ts).
    const kw = await ensureKeywords({ userId: run.user_id, draftId: run.draft_id, text: caption, pack: pack as unknown as Record<string, unknown> });
    if (kw.backfilled && kw.pack) pack = kw.pack as unknown as ContentPack;
  }
  const plan = perNetworkPlan(pack as unknown as Record<string, unknown>, mcProviders, {
    aviso,
    refPolicy,
    transform: wantsArticle ? (_network, text) => withArticleLink(text, ARTICLE_LINK_PLACEHOLDER) : undefined,
  });
  if (!plan.ok) {
    await releaseClaim(db, run, 'approve-refused', 'Not sent: ' + plan.reason + ' Edit the draft, then approve again.');
    return { ok: false, note: plan.reason + ' The run is back in your queue.' };
  }
  let sends = plan.sends;

  // A CITATION CROSSREF SAID DOES NOT EXIST. The generator re-rolls a DOI
  // Crossref does not know once, then keeps the first draft and leaves "the
  // badge" to tell the reviewer — and the planner card never showed that
  // badge, so a made-up study could go out on a person's Approve. Refused
  // here instead. A DOI the reviewer has since edited in is checked now.
  const stamp = (pack as ContentPack & { _compliance?: { citation?: { status?: string | null; doi?: string | null; title?: string | null } | null } })._compliance;
  const badDoi = knownBadCitation(stamp, sends);
  if (badDoi) {
    const why = 'Not sent: Crossref has no record of the study cited in the REF line (DOI ' + badDoi + '). Replace the citation with a real study, then approve again. Nothing was sent.';
    await releaseClaim(db, run, 'approve-refused', why);
    return { ok: false, note: why };
  }
  // Every DOI is checked now, the stamped one included: the title in the REF
  // line must match the paper the DOI resolves to, and older stamps never
  // compared titles. An unreachable Crossref still passes.
  const stampedDoi = String(stamp?.citation?.doi || '').toLowerCase();
  for (const { doi, title } of citationsIn(sends)) {
    let checked = await verifyDoi(doi, { expectedTitle: title });
    if (checked.status === 'unavailable' && doi === stampedDoi && stamp?.citation?.status === 'mismatch') {
      checked = { ...checked, status: 'mismatch', title: stamp.citation.title ?? null };
    }
    if (checked.status === 'not_found') {
      const why = 'Not sent: Crossref has no record of the study cited in the REF line (DOI ' + doi + '). Replace the citation with a real study, then approve again. Nothing was sent.';
      await releaseClaim(db, run, 'approve-refused', why);
      return { ok: false, note: why };
    }
    if (checked.status === 'mismatch') {
      const why = 'Not sent: the DOI in the REF line points to a different paper: ' + (checked.title ? '"' + checked.title + '"' : 'not the study it names') +
        ' (DOI ' + doi + '). Replace the citation with the study the post means, then approve again. Nothing was sent.';
      await releaseClaim(db, run, 'approve-refused', why);
      return { ok: false, note: why };
    }
  }

  // DOES THE STUDY BACK WHAT THE POST SAYS? Asked here, at the door.
  //
  // The scorer judges this and stamps `_claimSupport` on the draft, and
  // nothing at this door ever read the stamp: a real, Crossref-verified paper
  // about something else entirely went out on Approve (the September audit —
  // a tadalafil trial under a peptides post). A draft the scorer never
  // stamped, or whose REF line the reviewer edited since, is judged NOW
  // against the paper the DOI resolves to, so the answer is about the copy
  // as it stands rather than as it was.
  {
    const stamped = (pack as ContentPack & { _claimSupport?: ClaimSupportStamp })._claimSupport;
    const cited = citationsIn(sends)[0]?.doi || '';
    let status: ClaimSupportStamp['status'] | null = stamped?.status ?? null;
    const stale = !stamped || String(stamped.doi || '').toLowerCase() !== cited.toLowerCase();
    if (cited && (stale || status === 'unchecked')) {
      try {
        const kept = (pack as ContentPack & { _evidence?: EvidenceItem[] })._evidence || [];
        const item = kept.find((i) => String(i.doi || '').toLowerCase() === cited.toLowerCase()) || (await findByDoi(cited));
        if (item) {
          const caption = String((pack as unknown as Record<string, unknown>).instagram || (pack as unknown as Record<string, unknown>).facebook || sends[0]?.text || '');
          const verdict = await judgeClaimSupport({ claim: claimFrom(caption), items: [item] });
          status = verdict.status === 'unchecked' ? 'unchecked' : (verdict.status === 'supported' ? 'supported' : 'unsupported');
          const fresh: ClaimSupportStamp = { status, doi: cited };
          (pack as ContentPack & { _claimSupport?: ClaimSupportStamp })._claimSupport = fresh;
          if (run.draft_id) await db.from('drafts').update({ pack: { ...(pack as unknown as Record<string, unknown>), _claimSupport: fresh } }).eq('id', run.draft_id).eq('user_id', run.user_id);
        }
      } catch (err) {
        // The judge or PubMed being down is not a reason to refuse a post, and
        // not a reason to pass it either: it stays whatever the stamp said.
        reportError('autopilot:approve-claim-support', err, { runId: run.id });
      }
    }
    const unsupported = claimSupportRefusal(status);
    if (unsupported) {
      await releaseClaim(db, run, 'approve-refused', unsupported);
      return { ok: false, note: unsupported + ' The run is back in your queue.' };
    }
  }

  // And the video rule, at the same door as the advertising rule above.
  //
  // The Autopilot writes its own drafts and none of them is transcribed from a
  // video, so on the ordinary path this never fires. It is here because
  // `template_runs.draft_id` is a column the RLS policy lets a user UPDATE on
  // their own row — the same hole that once made this route hand back another
  // user's pack — so a run CAN be pointed at a video-prepared draft, and with
  // `schedule: true` this function publishes LIVE. A gate that is dead on the
  // happy path and load-bearing on the one that is not is worth its four lines.
  //
  // "Has the video" here means the matched clip, not the hero image: `angle
  // .media.url` is the only video this path can attach, and the image below is
  // a picture.
  const videoRule = videoVerdict(pack as PackLike, Boolean(clip?.url));
  if (videoRule.pending) {
    await releaseClaim(db, run, 'approve-refused', 'Not sent: ' + pendingRefusal(videoRule));
    return { ok: false, note: pendingRefusal(videoRule) + ' The run is back in your queue.' };
  }

  // Image enrichment: make sure the draft carries its AI hero image before
  // the handoff, so the Metricool draft ships with a visual. Best-effort —
  // an image failure never blocks approval.
  //
  // HARD RULE at the ship-point: an image the checker flagged for text can
  // NEVER be attached to the Metricool handoff. A text-flagged stored image
  // is treated as missing (ensureDraftImage regenerates it with the next
  // composition variant), and if the regeneration still carries text, the
  // post ships with no image rather than a text-bearing one.
  // And an image showing a banned prop — a syringe, a pill, a cuff on an arm —
  // is refused the same way. It used to be only text: a banned-prop image was
  // flagged, kept as the best of three flagged candidates, and attached.
  const shippable = (img: PackImage | null): PackImage | null =>
    imageUnshippable(img?.verification) ? null : img;
  let packImage: PackImage | null = shippable(
    (pack as ContentPack & { _image?: PackImage })._image || null
  );
  if (!packImage) {
    try { packImage = shippable((await pictureForDraft(run.draft_id, run.user_id)).image); } catch { packImage = null; }
  }

  // NOTHING GOES TO INSTAGRAM WITHOUT A PICTURE. The image step above is
  // best-effort by design, so on a day the generator failed this used to send
  // `media: []` — and Instagram refuses a text-only post at Metricool, long
  // after the reviewer pressed Approve and moved on. Refuse here instead, where
  // the reviewer is standing: the run goes back to the queue with "New image"
  // one click away. (A matched clip counts as the attachment, as it always has.)
  const noMedia = mediaProblem(mcProviders, clip?.url || packImage?.url || '');
  if (noMedia) {
    const why = 'Not sent: ' + noMedia.replace(/ Attach one below, or unselect (it|them)\./, '') +
      ' The picture for this post could not be made — press "New image" on the card, then approve again. Nothing was sent anywhere.';
    await releaseClaim(db, run, 'approve-refused', why);
    return { ok: false, note: why };
  }

  // THE ARTICLE IS DECIDED BEFORE ANYTHING IS SENT.
  //
  // Everything about an article that can be refused — no WordPress configured,
  // no article in the draft, an article missing its AVISO or citation — is
  // knowable without calling anybody. Checking it here, before the Metricool
  // handoff, is what keeps a refusal a refusal instead of a half-send: the
  // first version of this ran the checks AFTER Metricool had already accepted
  // the post, so a revoked WordPress password left three promo posts live,
  // scheduled, unrecorded, and unreachable from this app — and pressing
  // Approve again sent three more.
  let article: { body: string; title: string } | null = null;
  if (wantsArticle) {
    const refuse = async (why: string) => {
      await releaseClaim(db, run, 'approve-failed', why);
      return { ok: false as const, note: why };
    };
    if (!wordpressConfigured()) {
      return refuse(
        'This template publishes a blog article, but no WordPress site is configured — so there was nowhere to send it. ' +
        'Set WORDPRESS_BASE_URL, WORDPRESS_USER and WORDPRESS_APP_PASSWORD, then approve again. Nothing was sent anywhere.',
      );
    }
    // The article's own copy, not the Instagram caption: `pack.blog` is the
    // 600-900 word piece the writer produced for exactly this.
    const raw = String((pack as unknown as Record<string, string>).blog || '').trim();
    if (!raw) {
      return refuse('This template publishes a blog article, but the draft has no article in it. Nothing was sent anywhere; the run is back in your queue.');
    }
    const articleAviso = await avisoForUser(run.user_id);
    // Opt-in permit: no number configured, no AVISO line to add.
    const body = articleAviso ? ensureAviso(raw, articleAviso) : raw;
    const articleCheck = checkCompliance(body, articleAviso);
    if (!articleCheck.ok) {
      // The gate covers articles now (lib/compliance.ts). An article is the
      // longest-lived thing the brand publishes and it used to be the one
      // format that skipped this.
      return refuse('Not published: ' + complianceMessage(articleCheck, ['blog']) + ' Edit the draft, then approve again. Nothing was sent anywhere.');
    }
    // The headline, through the same rules every published title goes through
    // (lib/post-title.ts): never a file name, never a person's name, never an
    // internal string.
    const chosen = professionalTitle({
      keyword: run.angle?.query || '',
      spoken: String((t as { name?: string } | null)?.name || ''),
    });
    article = {
      body,
      title: chosen.title || String((t as { name?: string } | null)?.name || BRAND_NAME),
    };
  }

  let note = 'Staged for publishing review.';
  // Did the Metricool handoff actually happen? The local `posts` rows exist to
  // mirror Metricool; writing one after a FAILED handoff put a post in the
  // queue and on the calendar marked "waiting for your approval" that had been
  // sent nowhere and would never publish. Every other route in this app
  // ("the two sides can never disagree") refuses to record that state — so
  // does this one now.
  let handoffFailed = false;
  /**
   * Did a Metricool call RETURN, without throwing?
   *
   * Not the same question as "did we get an id out of it". readPostId answers
   * null whenever the envelope carries no recognisable id — which a successful
   * POST can do — and the first version of this branch used the id as its proof
   * of sending. So a 200 with an unexpected body plus a WordPress refusal put
   * the run back in the queue saying "nothing was sent anywhere" while three
   * posts were live and scheduled. Whether the answer parsed is bookkeeping;
   * whether the request was accepted is the thing that must never be guessed.
   */
  let metricoolSent = false;
  /** The networks Metricool accepted, each with the copy it got and its id. */
  const sent: { network: string; text: string; postId: string | null }[] = [];
  /** A network that refused after another had already been accepted. */
  let sendFailure = '';
  // THE ARTICLE GOES FIRST, and its promos carry its link.
  //
  // It used to go last: Metricool accepted three promo posts, then WordPress
  // was asked for the article — so the promos could never contain its link,
  // and a WordPress refusal left promos live for an article that did not
  // exist. Now the article is published first; its id and link are written to
  // the run before anything else (lib/article-promo.ts), so a retry after a
  // promo failure promotes the article already there instead of publishing a
  // second one; and only then are the promos built around the real URL and
  // sent — ten minutes after the article, so the link is live when they are.
  let articleNote = '';
  let promoAt = run.scheduled_for;
  if (article) {
    const prior = readArticleLog(run.log);
    let link = '';
    let articleStatus = '';
    if (prior) {
      link = prior.url;
      articleStatus = prior.status;
      articleNote = 'The article was already on WordPress from the previous attempt (' + link + '), so it was not published again.';
    } else {
      const published = await publishArticle({
        title: article.title,
        html: article.body,
        date: run.scheduled_for,
        featuredImageUrl: packImage?.url || null,
        // A draft approval is a draft EVERYWHERE. Without this the queue's
        // "Approve" (schedule: false) sent Metricool a reviewable draft and
        // WordPress a scheduled post that publishes itself — while the calendar
        // row read "waiting for your approval".
        status: opts.schedule ? undefined : 'draft',
      });
      if (!published.ok) {
        // Nothing has gone anywhere yet: release, and a retry is safe.
        handoffFailed = true;
        note = published.message + ' Nothing was sent anywhere; the run is back in your queue.';
      } else {
        link = articleUrl(published, wordpressConfig()?.baseUrl || '');
        articleStatus = published.status;
        run.log = logLine(run, 'article', articleLogNote(published, link));
        const { error: articleLogError } = await db.from('template_runs').update({ log: run.log }).eq('id', run.id);
        if (articleLogError) reportError('autopilot:approve-article-log', articleLogError, { runId: run.id });
        articleNote = 'Article ' + (published.status === 'draft' ? 'saved to WordPress as a draft' : 'published to WordPress (' + published.status + ')') +
          (link ? ': ' + link : '') + '.' + (published.note ? ' ' + published.note : '');
      }
    }
    if (!handoffFailed && mcProviders.length) {
      const withLink = perNetworkPlan(pack as unknown as Record<string, unknown>, mcProviders, {
        aviso,
        refPolicy,
        // No link while the article is a WordPress draft: its ?p= URL leads
        // the public to a login page, and approving the promo later does not
        // publish the article.
        transform: (_network, text) => withArticleLink(text, promoLink(articleStatus, link)),
      });
      if (!withLink.ok) {
        // Not reachable in practice — the stand-in link above is at least as
        // long — but if it happens the article is live and the promos are not,
        // and a retry will not publish the article twice.
        handoffFailed = true;
        note = articleNote + ' Its promo posts could not be prepared: ' + withLink.reason + ' Approve again to send them; the article will not be published twice.';
      } else {
        sends = withLink.sends;
        promoAt = new Date(new Date(run.scheduled_for).getTime() + PROMO_DELAY_MINUTES * 60_000).toISOString();
      }
    }
    if (!handoffFailed) note = articleNote;
  }

  // Push a Metricool DRAFT (autoPublish: false) so it lands in the approval
  // queue there too. Fail-soft: missing env just means dashboard-only staging.
  if (mcProviders.length && !handoffFailed) {
    // A matched video clip wins; otherwise attach the generated hero image.
    const media = clip?.url
      ? [{ url: clip.url }]
      : packImage?.url
        ? [{ url: packImage.url }]
        : [];
    // One at a time, in order, and stop at the first refusal: a network that
    // was never attempted is one a person can still post by hand, and a
    // parallel burst would leave no way to say which ones went.
    for (const send of sends) {
      try {
        const created = await metricoolSchedulePost({
          text: send.text,
          providers: [send.network as McNetwork],
          publicationDate: promoAt,
          media,
        }, opts.schedule ? 'scheduled' : 'review');
        metricoolSent = true;
        // Keep Metricool's id on our row. Without it the queue's Approve,
        // Reschedule and Delete had nothing to address upstream, so an
        // Autopilot post could only ever be managed inside Metricool.
        const postId = readPostId(created);
        sent.push({ ...send, postId });
        // Written to the run BEFORE anything else can fail. rescueStrandedApprovals
        // decides whether an approval really happened, and its only evidence
        // used to be the `posts` row — the one artifact that is missing in
        // exactly the case where the send DID happen and the bookkeeping did
        // not. A run carrying this step is never rescued, so a failed insert
        // can no longer turn into a second live post fifteen minutes later.
        run.log = logLine(run, 'sent', 'Sent to Metricool for ' + send.network + (postId ? ' (post ' + postId + ')' : ' — it answered without a post id') + '.');
        const { error: sentError } = await db
          .from('template_runs')
          .update({ log: run.log })
          .eq('id', run.id);
        if (sentError) reportError('autopilot:approve-sent-log', sentError, { runId: run.id });
      } catch (e) {
        sendFailure = send.network + ' (' + (e instanceof Error ? e.message : 'error') + ')';
        break;
      }
    }
    if (!sent.length) {
      handoffFailed = true;
      note = articleNote
        ? articleNote + ' But its promo posts could not be sent to Metricool: ' + sendFailure + '. The run is back in your queue — press Approve again to send them; the article will not be published twice.'
        : 'Could not send this to Metricool: ' + sendFailure + '. Nothing was scheduled and the run is back in your queue — press Approve again to retry.';
    } else {
      note = (articleNote ? articleNote + ' ' : '') +
        (opts.schedule ? 'Approved and SCHEDULED in Metricool for ' : 'Sent to Metricool as a DRAFT for ') + sent.map((x) => x.network).join(', ') +
        ', each with its own copy' +
        (clip?.url
          ? ' and clip "' + (clip.title || 'video') + '" attached'
          : packImage?.url
            ? ' and the AI hero image attached'
            : '') +
        (opts.schedule ? ' — Metricool will publish it at the scheduled time.' : ' — press Approve in your queue to publish.');
    }
  }

  if (handoffFailed) {
    // Same treatment the empty-draft path above gets: the claim already moved
    // this run to `approved`, and no other transition accepts that state, so
    // leaving it there strands the run with nothing scheduled. Release it so
    // the reviewer can press Approve again once Metricool answers.
    await db
      .from('template_runs')
      .update({ state: 'ready_for_review', log: logLine(run, 'approve-failed', note) })
      .eq('id', run.id)
      .eq('state', 'approved');
    return { ok: false, note };
  }

  // One row per network that was sent, each carrying the copy that network
  // actually got and its own Metricool id — the same shape the Content
  // Generator's scheduler writes. The weekly pace ceiling counts by draft_id,
  // so three rows for one post still count as one. A blog-only run, which
  // sent nothing to Metricool, keeps its single row.
  const statusWord = opts.schedule && (mcProviders.length || wantsArticle) ? 'approved' : 'pending_review';
  const rows = sent.length
    ? sent.map((x) => ({
        user_id: userId,
        draft_id: run.draft_id,
        // What was actually SENT to Metricool, not what the template lists. A
        // row carrying `blog` is read back by the reschedule path and sent
        // onward; an entry that never went to Metricool has no business here.
        providers: [x.network],
        text: x.text,
        // The time Metricool was actually given: an article's promos go out ten
        // minutes after it, and a later reschedule or approve from the posts
        // queue re-sends this value.
        publication_date: promoAt,
        metricool_post_id: x.postId,
        // 'approved' — not 'scheduled' — is the one word /api/posts treats as
        // live. See modeOf() there: 'scheduled' is also the column default and
        // part of Metricool's own vocabulary, so it cannot mean "a person said
        // yes to this".
        status: statusWord,
      }))
    : [{
        user_id: userId,
        draft_id: run.draft_id,
        providers,
        text: article?.body || channelCopy(pack as unknown as Record<string, unknown>, 'blog'),
        publication_date: run.scheduled_for,
        metricool_post_id: null,
        // An article that WordPress accepted counts too: a blog-only run that
        // reached this line has published something, and recording it as
        // still waiting for approval is the disagreement this row avoids.
        status: statusWord,
      }];
  const { data: inserted, error: insertError } = await db.from('posts').insert(rows).select('id');
  // READ, not assumed. The Metricool posts already exist at this point — with
  // opts.schedule they are in the LIVE queue with autoPublish: true — so a
  // swallowed error here leaves posts that will publish and that this
  // dashboard has no row for: nothing to approve, reschedule or delete, and
  // `ok: true` returned. templates/apply handles this exact case correctly and
  // says so in a comment; this did not.
  let bookkeeping = '';
  if (insertError) {
    const ids = sent.map((x) => x.postId).filter(Boolean).join(',');
    reportError('autopilot:approve-posts-insert', insertError, { runId: run.id, metricoolPostId: ids });
    bookkeeping = ids
      ? ' NOTE: it is in Metricool but could not be saved to this dashboard, so it will not appear on your calendar here — manage it in Metricool.'
      : ' NOTE: it could not be saved to this dashboard.';
  }
  // A run approved straight to a live slot is also recorded on the team's
  // calendar sheet (best-effort; see lib/approval-log.ts), one line per post.
  if (opts.schedule && mcProviders.length) {
    // AWAITED, not fire-and-forget. This same file says so 500 lines earlier
    // about recordDraftKeywords: "on Vercel the lambda can freeze once the
    // response is returned, so this insert was lost non-deterministically".
    // Identical construct, same runtime — and this is the audit record for the
    // LIVE-scheduled posts specifically. recordApproval is already fail-soft
    // (it catches and returns false), so awaiting it costs nothing.
    const insertedIds = ((inserted || []) as { id?: string }[]).map((r) => String(r?.id || ''));
    for (let i = 0; i < sent.length; i++) {
      await recordApproval({
        publishDate: promoAt,
        networks: [sent[i].network],
        caption: sent[i].text,
        mediaUrl: clip?.url || packImage?.url || '',
        source: 'Autopilot · approve & schedule',
        // The run id is NOT a post id. Falling back to it silently mixed two
        // id spaces in the audit column; an empty cell is honest, a wrong id is not.
        postId: insertedIds[i] || '',
      });
    }
  }
  const { error: logError } = await db
    .from('template_runs')
    // State was already set by the claim above; this records the outcome.
    .update({ log: logLine(run, 'approve', note) })
    .eq('id', run.id);
  if (logError) reportError('autopilot:approve-log', logError, { runId: run.id });

  // A PARTIAL ACROSS NETWORKS: some were accepted, then one refused.
  //
  // Not released: the accepted posts
  // are real, recorded, and would be sent a second time by a retry. The
  // networks that did not go are named, for a person to post by hand.
  if (sendFailure && sent.length) {
    const missing = sends.map((x) => x.network).filter((n) => !sent.some((y) => y.network === n));
    const partial = note + ' BUT NOT EVERY NETWORK WENT: Metricool refused ' + sendFailure +
      (missing.length > 1 ? ', and ' + missing.slice(1).join(', ') + ' was not attempted' : '') +
      '. The posts above are scheduled and recorded; approving this run again would send them a second time, so post the ' +
      missing.join(' and ') + ' copy from the draft by hand.';
    const { error: partialError } = await db
      .from('template_runs')
      .update({ log: logLine(run, 'approve-partial', partial) })
      .eq('id', run.id);
    if (partialError) reportError('autopilot:approve-partial-log', partialError, { runId: run.id });
    return { ok: false, note: partial + bookkeeping };
  }

  return { ok: true, note: note + bookkeeping };
}

// Reviewer feedback loop: send a run back for a redraft that MUST address
// the note. The existing draft row is reused, the pipeline restarts at the
// draft step with the feedback embedded in the prompt.
// `noteLimit`: how much of the note reaches the writer. 500 for a person's
// note; FIX passes more, because its note quotes every flag it is fixing.
export async function regenerateRun(runId: string, userId: string, note?: string, opts: { noteLimit?: number } = {}): Promise<boolean> {
  const db = supabaseAdmin();
  const { data: r, error: readError } = await db
    .from('template_runs')
    .select('*')
    .eq('id', runId)
    .eq('user_id', userId)
    .maybeSingle();
  if (readError) {
    reportError('autopilot:regenerate-read', readError, { runId });
    return false;
  }
  const run = r as RunRow | null;
  if (!run || !run.angle) return false;
  if (!['ready_for_review', 'drafted', 'failed'].includes(run.state)) return false;
  // A slot that has already passed cannot be redrafted into anything: the
  // pipeline restarts at research, the tick never reaches a run more than a
  // day past its time, and expiry marks it failed — so the button turned a
  // missed post into a red card. Such a post is re-dated or skipped instead.
  if (Date.parse(run.scheduled_for) < Date.now() + MISSED_MARGIN_MS) return false;
  const angle: Angle = {
    ...run.angle,
    reviewerNote: (note || '').trim().slice(0, opts.noteLimit ?? 500) || run.angle.reviewerNote,
    reviewRequestedAt: new Date().toISOString(),
  };
  // Claim the state we READ, exactly as approveRun does. Without the predicate
  // this was a read-then-blind-write: two open tabs, one approving and one
  // regenerating, and the regenerate could rewrite `approved` back to
  // `researched` while approveRun was still inside its ~60s Drive + Metricool
  // handoff. The run then came back for review and got approved a second time -
  // two Metricool drafts and two `posts` rows for one slot, with no unique
  // constraint and no compensating path (skipRun refuses terminal runs).
  const { data: claimed, error: claimError } = await db
    .from('template_runs')
    .update({
      state: 'researched',
      attempts: 0,
      regens: 0,
      angle,
      log: logLine(run, 'regenerate', note ? 'Reviewer asked for changes: ' + note : 'Reviewer asked for a fresh take.'),
    })
    .eq('id', runId)
    .eq('user_id', userId)
    .eq('state', run.state)
    .select('id');
  if (claimError) {
    reportError('autopilot:regenerate-claim', claimError, { runId });
    return false;
  }
  // Lost the race: something else moved this run between our read and write.
  return Array.isArray(claimed) && claimed.length > 0;
}

// ---------------------------------------------------------------------------
// FIX: resolve every warning on a review card, then re-check.
// ---------------------------------------------------------------------------

export type FixResult = {
  ok: boolean;
  /** What was resolved: 'citation' | 'copy' | 'image'. */
  fixed: string[];
  /** What still needs a person, each with its reason. */
  remaining: string[];
  note: string;
};

/** How long FIX gives itself. The route allows 300s; the rest is headroom for the write-back. */
const FIX_BUDGET_MS = 250_000;
/** Fix citation keeps this much of its budget for correcting the copy (two rewrites and their re-checks); the research gets the rest. */
const CITATION_REWRITE_RESERVE_MS = 130_000;
/** Time a redraft (draft + score, with its own image step) needs to be started at all. */
const FIX_REDRAFT_MS = 75_000;
/** Time a verified image regeneration needs. */
const FIX_IMAGE_MS = 90_000;
/** Redrafts FIX will spend on the copy before handing it back. */
const FIX_REDRAFT_ATTEMPTS = 2;

const PACK_TEXT_KEYS = ['instagram', 'facebook', 'linkedin', 'tiktok', 'youtube', 'blog'] as const;

/** The paper a rewrite should be written to, when nothing found backs the copy as written. */
type ClaimHelp = { item: EvidenceItem; ref: string };

type CitationFix = {
  pack: ContentPack;
  /** The REF line now cites a verified study that backs the copy. */
  fixed: boolean;
  /** What FIX did, for the log. */
  change: string;
  /** Why it is not fixed, for the card. */
  reason: string;
  /** Set when only a rewrite of the copy can fix it. */
  claimHelp: ClaimHelp | null;
};

/** Merge the fields FIX owns into the draft as it is NOW, and return the result. */
async function saveFixedPack(db: ReturnType<typeof supabaseAdmin>, run: RunRow, fields: Record<string, unknown>): Promise<ContentPack> {
  // Re-read before writing, as every other pack writer does: the copy read at
  // the start is stale by now and a concurrent image write must survive.
  const { data: fresh, error: readError } = await db
    .from('drafts').select('pack').eq('id', run.draft_id).eq('user_id', run.user_id).maybeSingle();
  if (readError) throw new Error('fix: draft read failed: ' + readError.message);
  const current = ((fresh as { pack?: Record<string, unknown> } | null)?.pack || {}) as Record<string, unknown>;
  const next = { ...current, ...fields };
  const { error } = await db.from('drafts').update({ pack: next }).eq('id', run.draft_id).eq('user_id', run.user_id);
  if (error) throw new Error('fix: draft update failed: ' + error.message);
  return next as unknown as ContentPack;
}

/**
 * The citation rung of FIX: the same ladder the video pipeline climbs
 * (lib/video-prepare.ts) — which paper in hand backs the copy; none, so search
 * again at the claim; cite the one that does, on every channel, verified.
 * Never redrafts. When nothing backs the copy it hands back the best real
 * paper found so the redraft can be written to it.
 */
async function fixCitation(db: ReturnType<typeof supabaseAdmin>, run: RunRow, pack: ContentPack, aviso: string, extra: EvidenceItem[] = []): Promise<CitationFix> {
  const p = pack as unknown as Record<string, unknown>;
  const caption = String(p.instagram || p.facebook || '');
  const current = checkCompliance(caption, aviso);
  const citedDoi = String(current.doi || '').toLowerCase();
  const claim = claimFrom(caption) || claimFrom(String(p.linkedin || p.blog || ''));
  const doiOf = (i: EvidenceItem) => String(i.doi || '').toLowerCase();
  const dedupe = (items: EvidenceItem[]) => items.filter((i, n, all) => all.findIndex((x) => doiOf(x) === doiOf(i)) === n);
  const stampEvidence = (items: EvidenceItem[]) => items.slice(0, MAX_CANDIDATES).map((e) => ({ ...e, abstract: String(e.abstract || '').slice(0, 1200) }));
  const refPolicy = refPolicyOf(pack);
  const complianceOf = (next: Record<string, unknown>, citation: unknown) => ({
    ...((pack as ContentPack & { _compliance?: Record<string, unknown> })._compliance || {}),
    aviso,
    instagram: checkCompliance(String(next.instagram || ''), aviso, { refPolicy }),
    facebook: checkCompliance(String(next.facebook || ''), aviso, { refPolicy }),
    citation,
    refPolicy,
  });
  const claimStatus = String((pack as ContentPack & { _claimSupport?: ClaimSupportStamp })._claimSupport?.status || '');
  const claimBad = claimStatus === 'unsupported' || claimStatus === 'unchecked';

  // THE DOI AS IT STANDS, checked now — a stale 'unavailable' stamp, or a
  // DOI the reviewer edited in, is settled by Crossref rather than assumed.
  const standing = await verifyDoi(current.doi, { expectedTitle: refTitle(current.ref) });
  const doiBad = ['not_found', 'mismatch', 'no_doi'].includes(standing.status);
  if (!doiBad && !claimBad) {
    if (standing.status === 'unavailable') {
      return { pack, fixed: false, change: '', reason: 'Crossref could not be reached to verify the citation — press FIX again in a moment', claimHelp: null };
    }
    // Only the Crossref stamp was stale; the paper is real and nothing said it fails the copy.
    const saved = await saveFixedPack(db, run, { _compliance: complianceOf(p, standing) });
    return { pack: saved, fixed: true, change: 'verified the cited study with Crossref', reason: '', claimHelp: null };
  }

  const kept = (pack as ContentPack & { _evidence?: EvidenceItem[] })._evidence || [];
  let candidates: EvidenceItem[] = dedupe([...extra, ...kept]);
  // A post whose papers were never fetched (not a strategy slot) is searched at its angle first.
  if (!candidates.length && run.angle?.query) {
    try { candidates = await findEvidence(run.angle.query); } catch (err) { reportError('autopilot:fix-evidence', err, { runId: run.id }); }
  }

  // RUNG 1 — which of the papers in hand backs this claim?
  let verdict: SupportVerdict = { status: 'unchecked' };
  if (claim && candidates.length) verdict = await judgeClaimSupport({ claim, items: candidates });
  // RUNG 2 — none does (or there were none): search again AT THE CLAIM.
  if (claim && (verdict.status === 'none' || !candidates.length)) {
    const query = claimQuery(claim);
    if (query) {
      const seen = new Set(candidates.map(doiOf));
      let second: EvidenceItem[] = [];
      try { second = (await findEvidence(query)).filter((i) => !seen.has(doiOf(i))); } catch (err) { reportError('autopilot:fix-evidence', err, { runId: run.id }); }
      if (second.length) {
        const retried = await judgeClaimSupport({ claim, items: second });
        if (retried.status === 'supported') { candidates = second; verdict = retried; }
        else if (!candidates.length) candidates = second;
      }
    }
  }

  /** Put this paper's REF line on every channel, verify it, stamp it. Null when Crossref rejects it. */
  const cite = async (item: EvidenceItem, status: ClaimSupportStamp['status']) => {
    const line = refLineFrom(item);
    const same = doiOf(item) === citedDoi;
    const checked = same ? standing : await verifyDoi(item.doi, { expectedTitle: item.title });
    if (checked.status === 'not_found' || checked.status === 'mismatch') return null;
    const texts: Record<string, string> = {};
    if (!same) {
      for (const key of PACK_TEXT_KEYS) {
        const text = p[key];
        if (typeof text === 'string' && text.trim()) texts[key] = swapRefLine(text, line);
      }
    }
    const saved = await saveFixedPack(db, run, {
      ...texts,
      _claimSupport: { status, doi: item.doi } satisfies ClaimSupportStamp,
      _compliance: complianceOf({ ...p, ...texts }, checked),
      _evidence: stampEvidence(dedupe([item, ...candidates])),
    });
    return { saved, checked, same, line: line.replace(/^REF:\s*/, '') };
  };

  // RUNG 3 — cite the paper that backs it.
  const backing = supportedItem(candidates, verdict);
  if (backing) {
    const done = await cite(backing, doiOf(backing) === citedDoi ? 'supported' : 'swapped');
    if (done) {
      const unavailable = done.checked.status === 'unavailable';
      return {
        pack: done.saved,
        fixed: !unavailable,
        change: done.same ? 'confirmed the cited study backs the copy' : 'replaced the citation with ' + done.line,
        reason: unavailable ? 'the new citation could not be confirmed with Crossref just now — press FIX again in a moment' : '',
        claimHelp: null,
      };
    }
  }

  // NOTHING BACKS THE COPY AS WRITTEN. The best real paper found is what the
  // copy is rewritten to; a DOI Crossref rejected is replaced with it now, so
  // the post never keeps a citation known to be wrong.
  const best = pickCitation(candidates.filter((i) => doiOf(i) !== citedDoi)) || pickCitation(candidates);
  if (!best) {
    return { pack, fixed: false, change: '', reason: 'no real study could be found for what this post claims', claimHelp: null };
  }
  let next = pack;
  let change = '';
  if (doiBad && doiOf(best) !== citedDoi) {
    const done = await cite(best, verdict.status === 'unchecked' ? 'unchecked' : 'unsupported');
    if (done) { next = done.saved; change = 'replaced the citation with ' + done.line; }
  }
  if (verdict.status === 'unchecked') {
    return { pack: next, fixed: false, change, reason: 'the citation could not be checked against the copy (the checker did not answer)', claimHelp: null };
  }
  return { pack: next, fixed: false, change, reason: 'no study found supports the copy as written', claimHelp: { item: best, ref: refLineFrom(best) } };
}

/**
 * Resolve every warning on a review card, then re-check.
 *
 *   citation  the claim-support ladder swaps in a study that backs the copy;
 *             when none does, the copy is redrafted to what the best study
 *             shows (the "Ask for changes" path, with a targeted note).
 *   copy      compliance, promotion and opening flags: a redraft with a note
 *             quoting each flag, re-scored; up to FIX_REDRAFT_ATTEMPTS.
 *   image     a flagged picture is generated again through the verified path
 *             ("↻ New image").
 *
 * Only what is flagged is touched. The result names what was fixed and what
 * still needs a person, and the run's log says what changed.
 */
export async function fixRun(runId: string, userId: string, opts: { only?: readonly FixStep[] } = {}): Promise<FixResult> {
  // The scope this press covers. FIX on the card is the copy and the picture;
  // the citation has its own button ("Fix citation", fixCitationOnly), so a
  // citation problem never sends the whole post — and its picture — back.
  const want = (step: FixStep) => !opts.only || opts.only.includes(step);
  const db = supabaseAdmin();
  const startedAt = Date.now();
  const left = () => FIX_BUDGET_MS - (Date.now() - startedAt);
  const refuse = (note: string): FixResult => ({ ok: false, fixed: [], remaining: [], note });

  const readRun = async (): Promise<RunRow | null> => {
    const { data, error } = await db.from('template_runs').select('*').eq('id', runId).eq('user_id', userId).maybeSingle();
    if (error) { reportError('autopilot:fix-read', error, { runId }); return null; }
    return (data as RunRow | null) || null;
  };
  const readPack = async (run: RunRow): Promise<ContentPack | null> => {
    const { data, error } = await db.from('drafts').select('pack').eq('id', run.draft_id).eq('user_id', run.user_id).maybeSingle();
    if (error) { reportError('autopilot:fix-draft', error, { runId }); return null; }
    return ((data as { pack?: ContentPack } | null)?.pack as ContentPack) || null;
  };

  let run = await readRun();
  if (!run) return refuse('run not found');
  if (run.state !== 'ready_for_review') return refuse('This post is not waiting for review, so there is nothing to fix.');
  if (!run.draft_id) return refuse('This post has no draft to fix.');
  const draftId = run.draft_id;
  let pack = await readPack(run);
  if (!pack) return refuse('Could not read that draft just now. Nothing was changed; try again in a moment.');

  const fixed: string[] = [];
  const remaining: string[] = [];
  const changes: string[] = [];
  const planned = fixPlan(runFixInput({ score: run.score, pack: pack as unknown as Record<string, unknown> }));
  const initial = { ...planned, steps: planned.steps.filter(want) };
  if (!initial.steps.length) return { ok: true, fixed, remaining, note: planned.steps.length ? 'That part has no warning now. Use the other button for what is left.' : 'Nothing needed fixing — this post has no warnings.' };
  const aviso = await avisoForUser(run.user_id);
  // The step in progress goes on the run as each one starts, so the card can
  // say what FIX is doing and a kill mid-way leaves a trace of where it was.
  const onStep = (step: FixStep) => markFixStep(db, runId, userId, step, initial.steps);

  // --- CITATION, without touching the copy.
  const cit: { claimHelp: ClaimHelp | null; reason: string } = { claimHelp: null, reason: '' };
  const citationPass = async (extra: EvidenceItem[] = []) => {
    try {
      const r = await fixCitation(db, run!, pack!, aviso, extra);
      pack = r.pack;
      if (r.change) changes.push(r.change);
      cit.claimHelp = r.claimHelp;
      cit.reason = r.reason;
    } catch (err) {
      reportError('autopilot:fix-citation', err, { runId });
      cit.reason = 'the citation could not be repaired just now';
    }
  };
  let input = runFixInput({ score: run.score, pack: pack as unknown as Record<string, unknown> });
  if (want('citation') && fixPlan(input).steps.includes('citation')) { await onStep('citation'); await citationPass(); }
  input = runFixInput({ score: run.score, pack: pack as unknown as Record<string, unknown> });

  // --- COPY: the redraft path "Ask for changes" uses, with a note quoting each flag.
  let redrafted = false;
  let copyReason = '';
  for (let attempt = 0; attempt < FIX_REDRAFT_ATTEMPTS; attempt++) {
    const wantsCopy = want('copy') && fixPlan(input).steps.includes('copy');
    if (!wantsCopy && !cit.claimHelp) break;
    if (left() < FIX_REDRAFT_MS) { copyReason = 'ran out of time before the copy could be redrafted — press FIX again'; break; }
    await onStep('copy');
    const help = cit.claimHelp;
    const note = fixRedraftNote(input, help ? { title: help.item.title, year: help.item.year, abstract: help.item.abstract, ref: help.ref } : null);
    const claimed = await regenerateRun(run.id, userId, note, { noteLimit: 1400 });
    if (!claimed) {
      copyReason = Date.parse(run.scheduled_for) < Date.now() + MISSED_MARGIN_MS
        ? 'its time has passed, so the copy cannot be redrafted — approve it for the next free slot first, or skip it'
        : 'the copy could not be sent for a redraft just now';
      break;
    }
    redrafted = true;
    const result = await advanceRuns({ scopeUserId: userId, runId: run.id, budgetMs: Math.min(150_000, Math.max(30_000, left() - 20_000)), maxRuns: 1 });
    const after = await readRun();
    const afterPack = after ? await readPack(after) : null;
    if (!after || after.state !== 'ready_for_review' || !afterPack) {
      const why = result.skipped[0] || 'the redraft did not finish; the engine picks it up on its next tick';
      await db.from('template_runs').update({ log: logLine(after || run, 'fix', 'FIX: ' + [...changes, 'redrafted the copy'].join('; ') + ' — ' + why) }).eq('id', run.id);
      return { ok: true, fixed, remaining: ['the copy — ' + why], note: fixNote({ fixed, remaining: ['the copy — ' + why] }) };
    }
    run = after;
    pack = afterPack;
    changes.push('redrafted the copy (attempt ' + (attempt + 1) + ')');
    // The new copy is checked again: its REF line may be new, and the claim
    // must still be backed. The paper it was written to is among the candidates.
    input = runFixInput({ score: run.score, pack: pack as unknown as Record<string, unknown> });
    const wrote = help ? [help.item] : [];
    cit.claimHelp = null;
    cit.reason = '';
    if (want('citation') && fixPlan(input).steps.includes('citation')) await citationPass(wrote);
    input = runFixInput({ score: run.score, pack: pack as unknown as Record<string, unknown> });
  }

  // --- VERDICTS on the copy and the citation, from the stamps as they stand now.
  const finalPlan = fixPlan(input);
  if (want('copy') && finalPlan.steps.includes('copy')) {
    const still = finalPlan.reasons.filter((r) => /compliance|promotion|opens like/.test(r));
    remaining.push('the copy — ' + (copyReason || 'still flagged after ' + FIX_REDRAFT_ATTEMPTS + ' redrafts: ' + still.join(', ') + ' — edit it or ask for changes'));
  } else if (redrafted && initial.steps.includes('copy')) {
    fixed.push('copy');
  }
  if (want('citation') && finalPlan.steps.includes('citation')) {
    remaining.push('the citation — ' + (cit.reason || copyReason || finalPlan.reasons.filter((r) => /cit|DOI|study|reference/i.test(r)).join(', ')));
  } else if (initial.steps.includes('citation')) {
    fixed.push('citation');
  }

  // --- IMAGE: only a flagged picture, through the verified path.
  //
  // An AI image (a plain take, or an older one "styled after" a library
  // photo) is generated again. A library photo that went through the brand
  // filter and was flagged (a head under the title, the wrong subject) is
  // replaced by an AI image too — FIX cannot choose a photo — and the note
  // says so, so a person can pick another real one instead.
  const image = (pack as ContentPack & { _image?: PackImage })._image;
  const imageMode = want('image') ? fixImageMode(image) : null;
  if (imageMode) {
    if (left() < FIX_IMAGE_MS) {
      remaining.push('the image — ran out of time; press FIX again');
    } else {
      await onStep('image');
      const swapped = imageMode === 'library-to-ai' ? ' (the flagged library photo was replaced by an AI image — choose another library photo to keep a real one)' : '';
      try {
        // What is left of FIX's own budget, less the write-back: the retry
        // loop starts no take it cannot finish before the function ends.
        const made = await ensureDraftImage(draftId, userId, { force: true, budgetMs: left() - 20_000 });
        if (made && !imageFlagged(made)) {
          fixed.push('image' + swapped);
          changes.push('made a new hero image (verified)' + (imageMode === 'library-to-ai' ? ' in place of the flagged library photo' : ''));
        } else {
          const issues = (made?.verification?.issues || []).slice(0, 2).join('; ');
          remaining.push('the image — ' + (made ? 'the new picture was flagged too' + (issues ? ' (' + issues + ')' : '') + '; press "New image" or choose a library photo' : 'images are off, so none could be made'));
          if (made) changes.push('made a new hero image, still flagged' + (imageMode === 'library-to-ai' ? ', in place of the flagged library photo' : ''));
        }
      } catch (err) {
        reportError('autopilot:fix-image', err, { runId });
        remaining.push('the image — the new picture could not be made; press "New image" in a moment');
      }
    }
  } else if (initial.steps.includes('image')) {
    // The redraft's own image step already replaced the flagged picture.
    fixed.push('image');
  }

  const note = fixNote({ fixed, remaining });
  const { error: logError } = await db
    .from('template_runs')
    .update({ log: logLine(run, 'fix', 'FIX: ' + (changes.length ? changes.join('; ') + '. ' : 'nothing changed. ') + note) })
    .eq('id', run.id);
  if (logError) reportError('autopilot:fix-log', logError, { runId });
  return { ok: true, fixed, remaining, note };
}

/**
 * "Fix citation": the citation, and only the citation.
 *
 * FIX used to handle a citation the study did not back by sending the whole
 * post back for a redraft — a new post, and with it a new picture — so the
 * button the reviewer pressed for the citation changed the image and often
 * left the citation as it was. This never redrafts and never touches the
 * picture:
 *
 *   1. the claim-support ladder FIX already climbs (fixCitation): the papers
 *      in hand, then a search at the claim; cite the one that backs it;
 *   2. the post's own statements one at a time (fixPostCitation), the ladder
 *      the calendar's "Verify / fix" uses, which finds what (1) misses;
 *   3. nothing backs the wording: the sentences that claim more than the best
 *      real study shows are rewritten to what it reports, on every channel,
 *      and the result is judged and stamped again (lib/claim-rewrite.ts).
 */
export async function fixCitationOnly(runId: string, userId: string): Promise<FixResult> {
  const db = supabaseAdmin();
  const startedAt = Date.now();
  const left = () => FIX_BUDGET_MS - (Date.now() - startedAt);
  const refuse = (note: string): FixResult => ({ ok: false, fixed: [], remaining: [], note });
  const { data, error } = await db.from('template_runs').select('*').eq('id', runId).eq('user_id', userId).maybeSingle();
  if (error) { reportError('autopilot:fix-citation-read', error, { runId }); return refuse('Could not read that post just now. Nothing was changed; try again in a moment.'); }
  const run = data as RunRow | null;
  if (!run) return refuse('run not found');
  if (run.state !== 'ready_for_review') return refuse('This post is not waiting for review, so there is nothing to fix.');
  if (!run.draft_id) return refuse('This post has no draft to fix.');
  const readPack = async (): Promise<ContentPack | null> => {
    const { data: d, error: e } = await db.from('drafts').select('pack').eq('id', run.draft_id).eq('user_id', run.user_id).maybeSingle();
    if (e) { reportError('autopilot:fix-citation-draft', e, { runId }); return null; }
    return ((d as { pack?: ContentPack } | null)?.pack as ContentPack) || null;
  };
  let pack = await readPack();
  if (!pack) return refuse('Could not read that draft just now. Nothing was changed; try again in a moment.');
  const stillBad = (pk: ContentPack) => fixPlan(runFixInput({ score: run.score, pack: pk as unknown as Record<string, unknown> })).steps.includes('citation');
  if (!stillBad(pack)) return { ok: true, fixed: [], remaining: [], note: 'The citation has no warning — nothing to fix.' };
  const aviso = await avisoForUser(run.user_id);
  await markFixStep(db, runId, userId, 'citation', ['citation']);
  const changes: string[] = [];
  const finish = async (fixedIt: boolean, why: string): Promise<FixResult> => {
    const fixed = fixedIt ? ['citation'] : [];
    // Not fixed: say what it DID, so the card shows the research and the correction rather than one bare line.
    const remaining = fixedIt ? [] : ['the citation — ' + why + (changes.length ? ' (what it did: ' + changes.join('; ') + ')' : '')];
    const note = fixNote({ fixed, remaining });
    const { error: logError } = await db.from('template_runs')
      .update({ log: logLine(run, 'fix', 'Fix citation: ' + (changes.length ? changes.join('; ') + '. ' : 'nothing changed. ') + note) })
      .eq('id', run.id);
    if (logError) reportError('autopilot:fix-citation-log', logError, { runId });
    return { ok: true, fixed, remaining, note };
  };

  // RUNG 1 — the ladder FIX climbs: the papers in hand, then a search at the claim.
  let help: ClaimHelp | null = null;
  let reason = '';
  try {
    const r = await fixCitation(db, run, pack, aviso);
    pack = r.pack;
    if (r.change) changes.push(r.change);
    help = r.claimHelp;
    reason = r.reason;
  } catch (err) {
    reportError('autopilot:fix-citation', err, { runId });
    reason = 'the citation could not be repaired just now';
  }
  if (!stillBad(pack)) return finish(true, '');

  // RUNG 2 — the post's own statements, one at a time: the research.
  // It gets what is left MINUS the time the correction needs, so the search
  // can never eat the rewrite (it did: the card came back "no study found
  // supports the copy as written" with the rewrite never attempted).
  const researchMs = left() - CITATION_REWRITE_RESERVE_MS;
  if (researchMs >= 40_000) {
    try {
      const p = pack as unknown as Record<string, unknown>;
      const caption = String(p.instagram || p.facebook || p.linkedin || p.blog || '');
      const out = await fixPostCitation({ text: caption, pack: p, aviso, budgetMs: Math.min(120_000, researchMs) });
      if (out.swapped && Object.keys(out.packPatch).length) {
        const texts: Record<string, unknown> = {};
        if (out.ref) for (const key of PACK_TEXT_KEYS) { const t = p[key]; if (typeof t === 'string' && t.trim()) texts[key] = swapRefLine(t, out.ref); }
        pack = await saveFixedPack(db, run, { ...texts, ...out.packPatch });
        changes.push('found and cited ' + (out.ref || 'a study that backs the post'));
        // The swapped study is verified and judged again by the ladder, so the stamps agree.
        const again = await fixCitation(db, run, pack, aviso);
        pack = again.pack;
        if (!stillBad(pack)) return finish(true, '');
      } else {
        changes.push('searched the post statement by statement; no study backs the wording as written');
      }
    } catch (err) {
      reportError('autopilot:fix-citation-claims', err, { runId });
    }
  }

  // RUNG 3 — CORRECT THE COPY to the best real study: only what claims too
  // much is rewritten, on every channel at once, then judged again. A second,
  // stricter pass when the checker still disagrees: every health statement
  // says only what the study reports, or becomes advice that claims nothing.
  if (help) {
    const study = { title: help.item.title, year: help.item.year, abstract: help.item.abstract, ref: help.ref };
    const label = help.ref.replace(/^REF:\s*/, '');
    for (const strict of [false, true]) {
      if (left() < 45_000) { reason = 'ran out of time before the copy could be corrected — press Fix citation again'; break; }
      const p = pack as unknown as Record<string, unknown>;
      const keys = PACK_TEXT_KEYS.filter((k) => typeof p[k] === 'string' && String(p[k]).trim());
      const timeout = Math.min(45_000, left() - 25_000);
      const rewritten = await Promise.all(keys.map((k) => rewriteClaimToStudy(String(p[k]), study, timeout, { strict })));
      const texts: Record<string, string> = {};
      keys.forEach((k, i) => { const t = rewritten[i]; if (t) texts[k] = t; });
      if (!Object.keys(texts).length) {
        reason = 'the copy could not be corrected to the study just now — press Fix citation again, or edit the sentence';
        continue;
      }
      pack = await saveFixedPack(db, run, texts);
      changes.push((strict ? 'corrected every health statement to' : 'rewrote the claim to') + ' what ' + label + ' reports (' + Object.keys(texts).join(', ') + ')');
      try {
        const r = await fixCitation(db, run, pack, aviso, [help.item]);
        pack = r.pack;
        if (r.change) changes.push(r.change);
        reason = r.reason || reason;
        if (r.claimHelp) help = r.claimHelp;
      } catch (err) {
        reportError('autopilot:fix-citation-recheck', err, { runId });
      }
      if (!stillBad(pack)) return finish(true, '');
    }
  }
  return finish(false, reason || 'no real study could be found for what this post claims — edit the claim or the REF line');
}

/** Write the step FIX is on to `angle.fix`. Best-effort: a failed stamp never stops the repair. */
async function markFixStep(db: ReturnType<typeof supabaseAdmin>, runId: string, userId: string, step: FixStep, steps: readonly FixStep[]): Promise<void> {
  const { data, error } = await db.from('template_runs').select('angle').eq('id', runId).eq('user_id', userId).maybeSingle();
  if (error || !data) { if (error) reportError('autopilot:fix-step', error, { runId }); return; }
  const angle = ((data as { angle?: Angle | null }).angle || {}) as Partial<Angle>;
  if (angle.fix?.state !== 'running') return;
  const fix: FixStatus = { ...angle.fix, step, steps: [...steps] };
  const { error: writeError } = await db.from('template_runs').update({ angle: { ...angle, fix } }).eq('id', runId).eq('user_id', userId);
  if (writeError) reportError('autopilot:fix-step', writeError, { runId });
}

/**
 * The tick's sweep for FIXes that started and never wrote a result — the
 * platform stopped the function, or the process died. The stamp is closed
 * as failed with the card's own wording, so the run's log says what happened
 * and the button is live again whichever screen reads it.
 */
export async function expireStaleFixes(scopeUserId?: string): Promise<number> {
  const db = supabaseAdmin();
  let q = db.from('template_runs').select('id, user_id, angle, log').eq('state', 'ready_for_review').not('angle', 'is', null);
  if (scopeUserId) q = q.eq('user_id', scopeUserId);
  const { data, error } = await q;
  if (error) { reportError('autopilot:fix-expire', error); return 0; }
  let closed = 0;
  for (const row of (data || []) as { id: string; user_id: string; angle: Angle | null; log: RunRow['log'] }[]) {
    const fix = row.angle?.fix;
    if (!fixStale(fix)) continue;
    const ended: FixStatus = { ...(fix as FixStatus), state: 'failed', endedAt: new Date().toISOString(), note: FIX_STALLED_NOTE, remaining: [] };
    const { error: writeError } = await db
      .from('template_runs')
      .update({ angle: { ...row.angle, fix: ended }, log: logLine(row as unknown as RunRow, 'fix', 'FIX: ' + FIX_STALLED_NOTE + (fix?.step ? ' (it was on the ' + fix.step + ')' : '')) })
      .eq('id', row.id).eq('user_id', row.user_id);
    if (writeError) reportError('autopilot:fix-expire', writeError, { runId: row.id });
    else closed++;
  }
  return closed;
}

/**
 * Start FIX: mark the run as being fixed, so the card can show it and a
 * second press is refused while it works. The route then runs
 * fixRunInBackground after answering (next/server `after`).
 */
export async function startFix(runId: string, userId: string, steps?: readonly FixStep[]): Promise<{ ok: true } | { ok: false; note: string }> {
  const db = supabaseAdmin();
  const { data, error } = await db.from('template_runs').select('id, state, draft_id, angle').eq('id', runId).eq('user_id', userId).maybeSingle();
  if (error) { reportError('autopilot:fix-start', error, { runId }); return { ok: false, note: 'Could not read that post just now. Nothing was changed; try again in a moment.' }; }
  const run = data as { state: string; draft_id: string | null; angle: Angle | null } | null;
  if (!run) return { ok: false, note: 'run not found' };
  if (run.state !== 'ready_for_review') return { ok: false, note: 'This post is not waiting for review, so there is nothing to fix.' };
  if (!run.draft_id) return { ok: false, note: 'This post has no draft to fix.' };
  if (fixRunning(run.angle)) return { ok: false, note: 'FIX is already working on this post.' };
  const fix: FixStatus = { state: 'running', startedAt: new Date().toISOString(), step: null, ...(steps?.length ? { steps: [...steps] } : {}) };
  const { data: claimed, error: claimError } = await db
    .from('template_runs')
    .update({ angle: { ...(run.angle || {}), fix } })
    .eq('id', runId).eq('user_id', userId).eq('state', 'ready_for_review')
    .select('id');
  if (claimError) { reportError('autopilot:fix-start', claimError, { runId }); return { ok: false, note: 'FIX could not be started just now. Try again in a moment.' }; }
  if (!Array.isArray(claimed) || !claimed.length) return { ok: false, note: 'This post changed while FIX was starting. Refresh and try again.' };
  return { ok: true };
}

/**
 * Run FIX and write its result onto the run (`angle.fix`), whatever happens.
 * Called after the response, so nothing waits on it; the card polls the run.
 */
export async function fixRunInBackground(runId: string, userId: string, scope: 'citation' | 'image' | 'copy' | 'general' = 'general'): Promise<void> {
  let result: FixResult;
  try {
    result = scope === 'citation' ? await fixCitationOnly(runId, userId)
      : await fixRun(runId, userId, { only: scope === 'general' ? ['copy', 'image'] : [scope] });
  } catch (err) {
    reportError('autopilot:fix', err, { runId });
    result = { ok: false, fixed: [], remaining: [], note: 'FIX stopped on an error; what it finished is saved. Press FIX again.' };
  }
  const db = supabaseAdmin();
  // Re-read: the redraft rewrote the angle while FIX worked.
  const { data, error } = await db.from('template_runs').select('angle').eq('id', runId).eq('user_id', userId).maybeSingle();
  if (error) { reportError('autopilot:fix-record', error, { runId }); return; }
  const angle = ((data as { angle?: Angle | null } | null)?.angle || {}) as Partial<Angle>;
  const fix: FixStatus = {
    state: result.ok ? 'done' : 'failed',
    startedAt: angle.fix?.startedAt || new Date().toISOString(),
    endedAt: new Date().toISOString(),
    step: null,
    ...(angle.fix?.steps ? { steps: angle.fix.steps } : {}),
    note: result.note,
    remaining: result.remaining,
  };
  const { error: writeError } = await db.from('template_runs').update({ angle: { ...angle, fix } }).eq('id', runId).eq('user_id', userId);
  if (writeError) reportError('autopilot:fix-record', writeError, { runId });
}

/**
 * Move an Autopilot run to another instant — "Reschedule" on a missed (or any
 * waiting) draft. The run keeps its draft and its state; only its time moves.
 *
 * `angle.redatedFrom` is set, the same marker "Approve for next free slot"
 * leaves, so the reconcile pass (lib/run-reconcile.ts) never retires the run
 * for no longer sitting on its template's slot. A run that has been approved,
 * skipped or superseded cannot be moved; a slot the template already has a
 * run on is refused rather than doubled.
 */
export async function rescheduleRun(runId: string, userId: string, iso: string): Promise<{ ok: true } | { ok: false; note: string }> {
  const at = new Date(iso);
  if (!Number.isFinite(at.getTime())) return { ok: false, note: 'That is not a date.' };
  const db = supabaseAdmin();
  const { data: r, error: readError } = await db
    .from('template_runs').select('id, template_id, log, state, angle, scheduled_for').eq('id', runId).eq('user_id', userId).maybeSingle();
  if (readError) { reportError('autopilot:reschedule-read', readError, { runId }); return { ok: false, note: 'The draft could not be read just now.' }; }
  if (!r) return { ok: false, note: 'That draft could not be found.' };
  const row = r as RunRow;
  if (row.state === 'approved' || row.state === 'skipped' || row.state === 'superseded' || row.state === 'failed') {
    return { ok: false, note: 'This draft has already been ' + row.state + ', so it cannot be moved.' };
  }
  const { data: clash } = await db.from('template_runs').select('id').eq('template_id', row.template_id).eq('scheduled_for', at.toISOString()).neq('id', runId).limit(1);
  if (Array.isArray(clash) && clash.length) return { ok: false, note: 'This template already has a post at that time. Pick another time.' };
  const angle = { ...((row.angle as Record<string, unknown> | null) || {}), redatedFrom: row.scheduled_for, redatedAt: new Date().toISOString() };
  const { data: moved, error } = await db
    .from('template_runs')
    .update({ scheduled_for: at.toISOString(), angle, log: logLine(row, 'reschedule', 'Moved by reviewer from ' + row.scheduled_for + ' to ' + at.toISOString() + '.') })
    .eq('id', runId)
    // Conditional write, like skip: an approval from another tab wins.
    .eq('state', row.state)
    .select('id');
  if (error) { reportError('autopilot:reschedule', error, { runId }); return { ok: false, note: 'The draft could not be moved just now.' }; }
  if (!Array.isArray(moved) || !moved.length) return { ok: false, note: 'This draft changed in another tab; reload and try again.' };
  return { ok: true };
}

export async function skipRun(runId: string, userId: string): Promise<boolean> {
  const db = supabaseAdmin();
  const { data: r, error: readError } = await db
    .from('template_runs').select('id, log, state').eq('id', runId).eq('user_id', userId).maybeSingle();
  if (readError) {
    reportError('autopilot:skip-read', readError, { runId });
    return false;
  }
  if (!r) return false;
  // `state` was selected and then never checked, so a stale second tab could
  // skip a run that had ALREADY been approved — the dashboard then reported
  // the post as cancelled while the Metricool draft and the posts row still
  // existed and still shipped. Nothing in the app compensates for that, so
  // refuse instead: a terminal run cannot be skipped.
  const priorState = (r as RunRow).state;
  if (priorState === 'approved' || priorState === 'skipped' || priorState === 'superseded') return false;
  const { data: skipped, error } = await db
    .from('template_runs')
    .update({ state: 'skipped', log: logLine(r as RunRow, 'skip', 'Skipped by reviewer.') })
    .eq('id', runId)
    // Conditional write: if another tab approved it between the read and
    // here, this matches nothing rather than clobbering the approval.
    .eq('state', priorState)
    .select('id');
  // AND THE RESULT IS RETURNED. The compare-and-swap above was written
  // correctly and then thrown away: `return true` regardless meant that when
  // another tab had already approved the run — the precise case the CAS exists
  // to catch — the reviewer was told "Skipped" for a post that was in Metricool
  // and would ship. A guard whose outcome nobody reads is not a guard.
  if (error) {
    reportError('autopilot:skip', error, { runId });
    return false;
  }
  return Array.isArray(skipped) && skipped.length > 0;
}

// The advertising rule is enforced at three doors and shown in two panels;
// they all call these functions, so this is where the rule itself is pinned.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  appliesTo,
  citationRequirement,
  avisoLine,
  avisoNumberFor,
  checkCompliance,
  ensureAviso,
  complianceMessage,
  complianceNetworksLabel,
} from './compliance.ts';

// A made-up permit number. The notice is opt-in, so every test of the
// configured rule passes it explicitly; the blank-permit tests pass nothing.
const PERMIT = 'TEST0000PERMIT';
// The strict citation mode, for the tests that pin the REF/DOI logic itself.
const ALWAYS = { requireCitations: 'always' } as const;

// No ambient configuration leaks into the default-behaviour tests.
delete process.env.AVISO_PUBLICIDAD;
delete process.env.REQUIRE_CITATIONS;
delete process.env.NEXT_PUBLIC_REQUIRE_CITATIONS;

const GOOD =
  'Before thinking about supplements, look at your plate.\n\n#yourbrand #nutrition\n\n' +
  'REF: Djuricic, I., & Calder, P.C. (2021). "Beneficial Outcomes of Omega-6 and Omega-3 Polyunsaturated Fatty Acids on Human Health." Nutrients, 13(7), 2421. DOI: 10.3390/nu13072421\n\n' +
  'AVISO DE PUBLICIDAD: ' + PERMIT;

test('the rule applies to every network the brand advertises on', () => {
  assert.equal(appliesTo(['instagram']), true);
  assert.equal(appliesTo(['facebook', 'linkedin']), true);
  assert.equal(appliesTo('instagram'), true);
  // LinkedIn and TikTok were outside this set, so the gate answered "does not apply" for
  // the two networks the video pipeline actually publishes to. Advertising does not stop
  // being advertising because the post is on LinkedIn.
  assert.equal(appliesTo(['linkedin']), true);
  assert.equal(appliesTo(['tiktok']), true);
  // A therapeutic claim in a video description is still advertising.
  assert.equal(appliesTo(['youtube']), true);
  // And the blog, which used to be outside the set and was therefore the ONE
  // format that skipped the AVISO and the citation — while being the
  // longest-lived thing the brand publishes, on its own domain, indexed, long
  // after a post has scrolled away. Same reasoning as LinkedIn's, one format
  // later: an 800-word article making a health claim is advertising.
  assert.equal(appliesTo(['blog']), true);
  assert.equal(appliesTo(['blog', 'instagram']), true);
  // Twitter stays outside it: the brand does not advertise there, and adding
  // a channel to this set without also stamping its copy (lib/ai.ts) is how a
  // format arrives missing the line it is about to be refused for.
  assert.equal(appliesTo(['twitter']), false);
  assert.equal(appliesTo([]), false);
  assert.equal(appliesTo(null), false);
});

test('a caption with both lines passes, and the DOI is extracted from the REF line', () => {
  const c = checkCompliance(GOOD, PERMIT, ALWAYS);
  assert.equal(c.ok, true);
  assert.deepEqual(c.missing, []);
  assert.equal(c.avisoFound, PERMIT);
  assert.equal(c.doi, '10.3390/nu13072421');
  assert.match(c.ref || '', /^Djuricic/);
});

test('each missing line is named; a bare "REF:" label does not count as a citation', () => {
  const noAviso = checkCompliance(GOOD.replace(/\n\nAVISO.*$/, ''), PERMIT, ALWAYS);
  assert.deepEqual(noAviso.missing, ['aviso']);
  const noRef = checkCompliance('Great tips.\n\nAVISO DE PUBLICIDAD: ' + PERMIT, PERMIT, ALWAYS);
  assert.deepEqual(noRef.missing, ['ref']);
  const bareRef = checkCompliance('Great tips.\n\nREF:\n\nAVISO DE PUBLICIDAD: ' + PERMIT, PERMIT, ALWAYS);
  assert.deepEqual(bareRef.missing, ['ref']);
  const neither = checkCompliance('Great tips.', PERMIT, ALWAYS);
  assert.deepEqual(neither.missing, ['aviso', 'ref']);
  assert.match(complianceMessage(neither), /advertising notice/);
  assert.match(complianceMessage(neither), /scientific reference/);
});

test('the wrong permit number is a mismatch, not compliance', () => {
  const c = checkCompliance(GOOD.replace(PERMIT, '9999999999X00001'), PERMIT, ALWAYS);
  assert.equal(c.ok, false);
  assert.equal(c.avisoMismatch, true);
  assert.deepEqual(c.missing, ['aviso']);
  assert.match(complianceMessage(c), /different permit number/);
});

test('ensureAviso appends once, corrects a wrong number, and leaves a correct line alone', () => {
  const base = 'Hello world.\n\nREF: Some study (2020). Journal. DOI: 10.1000/xyz';
  const once = ensureAviso(base, PERMIT);
  assert.equal(once, base + '\n\nAVISO DE PUBLICIDAD: ' + PERMIT);
  assert.equal(ensureAviso(once, PERMIT), once);
  const fixed = ensureAviso(once.replace(PERMIT, 'WRONG0000001'), PERMIT);
  assert.equal(fixed, once);
  assert.equal(ensureAviso('', PERMIT), avisoLine(PERMIT));
});

test('the permit number resolves Brand Brain → environment → none', () => {
  const prev = process.env.AVISO_PUBLICIDAD;
  delete process.env.AVISO_PUBLICIDAD;
  assert.equal(avisoNumberFor(null), '', 'no built-in permit: a fresh deployment has none');
  process.env.AVISO_PUBLICIDAD = 'envnumber0001';
  assert.equal(avisoNumberFor(''), 'ENVNUMBER0001');
  assert.equal(avisoNumberFor('brandnum00002'), 'BRANDNUM00002');
  if (prev === undefined) delete process.env.AVISO_PUBLICIDAD; else process.env.AVISO_PUBLICIDAD = prev;
});

test('the AVISO line is recognised with a full-width colon and extra spaces', () => {
  // A DOI-shaped DOI: '10.1/abc' never matched DOI_RE (which wants 4-9 digits after the
  // '10.'), so this fixture only passed while a REF without a usable DOI still counted.
  const c = checkCompliance('x\n\nREF: A real study (2021). Journal, 1(1), 1. DOI: 10.1080/00332747.1974.11023785\nAVISO  DE  PUBLICIDAD： ' + PERMIT, PERMIT, ALWAYS);
  assert.equal(c.ok, true);
});

test('a REF line with no DOI is reported as a DOI problem, not a missing line', () => {
  // THE MESSAGE THAT SENT PEOPLE HUNTING. A caption with a perfectly good REF
  // line and no DOI used to report 'ref' — "add a REF line" — while the line
  // was already sitting there in front of them.
  const withRef = 'A claim about therapy.\n\nAVISO DE PUBLICIDAD: ' + PERMIT
    + '\nREF: Smith, A.B. (2024). A study of something. Journal of Things, 12(3), 45-60.';
  const check = checkCompliance(withRef, PERMIT, ALWAYS);
  assert.equal(check.ok, false);
  assert.ok(check.missing.includes('doi'), 'the DOI is what is missing');
  assert.ok(!check.missing.includes('ref'), 'the REF line is present and must not be reported as absent');
  assert.ok(check.ref, 'the line itself was found');
  assert.equal(check.doi, null);
});

test('no REF line at all is still reported as a missing line', () => {
  const noRef = 'A claim.\n\nAVISO DE PUBLICIDAD: ' + PERMIT;
  const check = checkCompliance(noRef, PERMIT, ALWAYS);
  assert.ok(check.missing.includes('ref'));
  assert.ok(!check.missing.includes('doi'), 'one problem, one name — never both');
});

test('a REF line with a DOI passes', () => {
  const good = 'A claim.\n\nAVISO DE PUBLICIDAD: ' + PERMIT
    + '\nREF: Smith, A.B. (2024). A study. Journal, 12(3), 45-60. DOI: 10.1016/j.example.2024.01.001';
  const check = checkCompliance(good, PERMIT, ALWAYS);
  assert.deepEqual(check.missing, []);
  assert.equal(check.ok, true);
  assert.equal(check.doi, '10.1016/j.example.2024.01.001');
});

test('the refusal names the networks the rule actually covers', () => {
  // The assertion that keeps the wording honest the next time SOCIAL_NETWORKS
  // changes. Every id in the set must be nameable, or a message will quietly
  // omit the network somebody is actually posting to.
  for (const id of ['instagram', 'facebook', 'linkedin', 'tiktok', 'youtube']) {
    assert.ok(appliesTo([id]), id + ' is covered by the rule');
    const named = complianceNetworksLabel([id]);
    assert.ok(named && named !== 'These', id + ' has no proper name in the label');
  }
  assert.equal(complianceNetworksLabel(['linkedin', 'youtube', 'tiktok']), 'LinkedIn, YouTube and TikTok');
  assert.equal(complianceNetworksLabel(['linkedin']), 'LinkedIn');
  // A network outside the rule contributes nothing to the sentence.
  assert.equal(complianceNetworksLabel(['twitter']), 'These');
  assert.match(complianceNetworksLabel(), /Instagram/);
  assert.match(complianceNetworksLabel(), /YouTube/);
});

test('the refused sentence names the selected networks, not two it is not about', () => {
  const noRef = checkCompliance('A claim.\n\nAVISO DE PUBLICIDAD: ' + PERMIT, PERMIT, ALWAYS);
  const said = complianceMessage(noRef, ['linkedin', 'youtube', 'tiktok']);
  assert.match(said, /^LinkedIn, YouTube and TikTok posts/);
  assert.doesNotMatch(said, /Instagram/, 'it must not name a network the person is not posting to');
});

test('with no permit configured the notice is neither required, appended nor offered', () => {
  const prev = process.env.AVISO_PUBLICIDAD;
  delete process.env.AVISO_PUBLICIDAD;
  try {
    assert.equal(avisoNumberFor(null), '');
    assert.equal(avisoNumberFor('   '), '');
    assert.equal(avisoLine(null), '', 'no line to offer');
    assert.equal(avisoLine(''), '');
    // Not appended: ensureAviso is a no-op, the text comes back as it was.
    const body = 'Hello world.\n\nREF: Some study (2020). Journal. DOI: 10.1000/xyz\n';
    assert.equal(ensureAviso(body), body);
    assert.equal(ensureAviso(body, ''), body);
    assert.equal(ensureAviso('', null), '');
    // Not required: a cited post with no AVISO line passes.
    const cited = GOOD.replace(/\n\nAVISO.*$/, '');
    const c = checkCompliance(cited, '', ALWAYS);
    assert.equal(c.ok, true);
    assert.deepEqual(c.missing, []);
    assert.equal(c.avisoFound, null);
    // A notice somebody pasted by hand is not held against the post either.
    const pasted = checkCompliance(GOOD.replace(PERMIT, 'ANYOTHER00001'), null, ALWAYS);
    assert.equal(pasted.ok, true);
    assert.equal(pasted.avisoMismatch, false);
    // And the refusal for a missing citation does not mention a notice.
    const uncited = checkCompliance('Great tips.', '', ALWAYS);
    assert.deepEqual(uncited.missing, ['ref']);
    assert.doesNotMatch(complianceMessage(uncited), /advertising notice/);
    assert.match(complianceMessage(uncited), /scientific reference/);
  } finally {
    if (prev === undefined) delete process.env.AVISO_PUBLICIDAD; else process.env.AVISO_PUBLICIDAD = prev;
  }
});

test('a permit set in the environment is enforced even by callers that pass none', () => {
  const prev = process.env.AVISO_PUBLICIDAD;
  process.env.AVISO_PUBLICIDAD = PERMIT.toLowerCase();
  try {
    assert.deepEqual(checkCompliance(GOOD.replace(/\n\nAVISO.*$/, ''), undefined, ALWAYS).missing, ['aviso']);
    assert.equal(checkCompliance(GOOD, undefined, ALWAYS).ok, true);
    assert.equal(ensureAviso('Hi.'), 'Hi.\n\nAVISO DE PUBLICIDAD: ' + PERMIT);
    assert.equal(avisoLine(null), 'AVISO DE PUBLICIDAD: ' + PERMIT);
  } finally {
    if (prev === undefined) delete process.env.AVISO_PUBLICIDAD; else process.env.AVISO_PUBLICIDAD = prev;
  }
});

test('REQUIRE_CITATIONS: health-claims by default, always, or off', () => {
  const prev = process.env.REQUIRE_CITATIONS;
  const claim = 'Omega-3 supports heart health.';
  const plain = 'Our new spring menu is out — come and try it this weekend.';
  try {
    delete process.env.REQUIRE_CITATIONS;
    assert.equal(citationRequirement(), 'health-claims');
    // Default: a post with no health claim needs no REF; one with a claim does.
    const p = checkCompliance(plain);
    assert.equal(p.ok, true);
    assert.equal(p.refWaived, true);
    assert.deepEqual(checkCompliance(claim).missing, ['ref']);
    // A REF that is present is still checked for its DOI.
    assert.deepEqual(checkCompliance(plain + '\n\nREF: Smith, A.B. (2024). A study of something. Journal, 1(1), 1-2.').missing, ['doi']);

    process.env.REQUIRE_CITATIONS = 'always';
    assert.equal(citationRequirement(), 'always');
    assert.deepEqual(checkCompliance(plain).missing, ['ref'], 'every post cites');
    // The per-draft relaxed policy still applies under 'always'.
    assert.equal(checkCompliance(plain, undefined, { refPolicy: 'if-health-claim' }).ok, true);

    process.env.REQUIRE_CITATIONS = 'off';
    assert.equal(citationRequirement(), 'off');
    assert.equal(checkCompliance(claim).ok, true, 'no citation is ever required');
    assert.equal(checkCompliance(plain + '\n\nREF: A study without a DOI, 2024, Journal.').ok, true);
    // ...but a configured permit is still enforced: the two parts are independent.
    assert.deepEqual(checkCompliance(claim, PERMIT).missing, ['aviso']);

    process.env.REQUIRE_CITATIONS = 'nonsense';
    assert.equal(citationRequirement(), 'health-claims', 'anything unknown is the default');
    // The per-call override wins over the environment.
    assert.deepEqual(checkCompliance(plain, undefined, { requireCitations: 'always' }).missing, ['ref']);
  } finally {
    if (prev === undefined) delete process.env.REQUIRE_CITATIONS; else process.env.REQUIRE_CITATIONS = prev;
  }
});

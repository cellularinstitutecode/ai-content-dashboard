// supabase/setup.sql is the one-paste bundle of every setup file. It is
// generated, so it can only go stale — this says when it has.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
// @ts-expect-error — a plain .mjs script, imported for its pure builder
import { SETUP_FILES, buildSetupSql } from '../scripts/build-setup-sql.mjs';

const dir = new URL('../supabase/', import.meta.url);
const read = (f: string) => readFileSync(new URL(f, dir), 'utf8');

test('setup.sql is up to date with its parts (run: node scripts/build-setup-sql.mjs)', () => {
  assert.equal(read('setup.sql'), buildSetupSql(read));
});

test('every setup file is in the bundle, and the clean-up script is not', () => {
  const onDisk = readdirSync(dir).filter((f) => f.endsWith('.sql') && f !== 'setup.sql' && f !== 'maintenance.sql').sort();
  assert.deepEqual([...SETUP_FILES].sort(), onDisk);
  assert.equal(SETUP_FILES[0], 'schema.sql', 'the core schema runs first');
});

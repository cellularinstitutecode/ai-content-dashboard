import { test } from 'node:test';
import assert from 'node:assert/strict';
import { renderBrandCard, cardElement, loadFonts, pngSize, setStoredFontReader } from './brand-card.ts';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { DEFAULT_VISUAL } from './brand-visual.ts';

// These render real PNGs through next/og (satori + resvg), with the stand-in
// fonts shipped in public/fonts/standin — no network, no keys.

test('a portrait card renders to a 1080×1350 PNG', async () => {
  const out = await renderBrandCard({
    spec: { headline: 'What is a sourdough starter?', body: 'A starter is flour and water kept alive by wild yeast, fed daily so the bread can rise on its own.', kicker: 'Baking basics', size: 'portrait', ground: 'paper', index: 1, total: 3, aviso: '0000000000X00000', standIn: false },
    visual: DEFAULT_VISUAL,
  });
  assert.deepEqual(pngSize(out.png), { width: 1080, height: 1350 });
  assert.ok(out.png.length > 20_000, 'a painted card is not a blank: ' + out.png.length + ' bytes');
});

test('square and landscape sizes come out at their own dimensions', async () => {
  const sq = await renderBrandCard({ spec: { headline: 'Sterility is not assumed: it is verified.', size: 'square', ground: 'accent', index: 1, total: 1, standIn: false } });
  assert.deepEqual(pngSize(sq.png), { width: 1080, height: 1080 });
  const ls = await renderBrandCard({ spec: { headline: 'The cost of being always on', size: 'landscape', ground: 'dark', index: 2, total: 2, standIn: false } });
  assert.deepEqual(pngSize(ls.png), { width: 1200, height: 630 });
});

test('without licensed brand fonts the card is marked as stand-in type', async () => {
  const fonts = await loadFonts();
  // The repo ships only the open stand-ins; a deployment with its own headline
  // and body files uploaded in Brand Brain flips this to false and drops the corner note.
  assert.equal(fonts.standIn, true);
  const out = await renderBrandCard({ spec: { headline: 'x', size: 'square', ground: 'light', index: 1, total: 1, standIn: false } });
  assert.equal(out.standIn, true);
});

function walkCard(el: unknown): { text: string[]; svgs: number } {
  const text: string[] = [];
  let svgs = 0;
  const walk = (n: any) => {
    if (n == null || typeof n === 'boolean') return;
    if (typeof n === 'string' || typeof n === 'number') { text.push(String(n)); return; }
    if (Array.isArray(n)) { n.forEach(walk); return; }
    if (n.type === 'svg') svgs++;
    const c = n.props?.children;
    if (c !== undefined) walk(c);
  };
  walk(el);
  return { text, svgs };
}

test('the card tree carries the words exactly, the slide count and the permit line', async () => {
  const fonts = await loadFonts();
  const el = cardElement({
    spec: { headline: 'Not all naps are the same.', body: 'Their effect depends on how long they last.', kicker: 'Important', size: 'portrait', ground: 'light', index: 3, total: 8, aviso: '0000000000X00000', standIn: true },
    visual: DEFAULT_VISUAL,
  }, fonts);
  const { text, svgs } = walkCard(el);
  assert.ok(text.includes('Not all naps are the same.'));
  assert.ok(text.includes('Their effect depends on how long they last.'));
  assert.ok(text.includes('IMPORTANT'), 'the kicker is set in caps');
  assert.ok(text.includes('3/8'));
  assert.ok(text.includes('AVISO DE PUBLICIDAD: 0000000000X00000'));
  assert.ok(text.some((t) => /^stand-in .*type · add /.test(t)), 'the corner note names the stand-in role and what to add');
  assert.equal(svgs, 0, 'the template ships no logo, so no mark is drawn');
  // Light ground → the darkest palette colour on the headline.
  const headline = JSON.stringify(el).match(/"color":"(#[0-9A-F]{6})","letterSpacing"/i);
  assert.equal(headline?.[1], '#222222');
});

test('no permit number, no permit line', async () => {
  const fonts = await loadFonts();
  for (const aviso of [undefined, null, '', '   ']) {
    const { text } = walkCard(cardElement({ spec: { headline: 'x', size: 'square', ground: 'paper', index: 1, total: 1, aviso, standIn: false } }, fonts));
    assert.ok(!text.some((t) => /AVISO/.test(t)), 'blank permit: ' + JSON.stringify(aviso));
  }
});

test('a brand that adds its logo paths gets brandmark, watermark and wordmark', async () => {
  const fonts = await loadFonts();
  const square = { viewBox: '0 0 10 10', paths: ['M0 0H10V10H0Z'] };
  const el = cardElement({
    spec: { headline: 'x', size: 'portrait', ground: 'paper', index: 1, total: 2, standIn: false },
    marks: { wordmark: { viewBox: '0 0 70 10', paths: ['M0 0H70V10H0Z'] }, brandmark: square },
  }, fonts);
  assert.equal(walkCard(el).svgs, 3, 'brandmark top, watermark, wordmark bottom');
  const out = await renderBrandCard({ spec: { headline: 'x', size: 'square', ground: 'dark', index: 1, total: 1, standIn: false }, marks: { brandmark: square } });
  assert.deepEqual(pngSize(out.png), { width: 1080, height: 1080 });
});

test('a photo cover puts the picture on top and the words on a paper panel', async () => {
  // A 1×1 JPEG is enough to exercise the photo path.
  const jpeg = Buffer.from('/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAAAAAAAAAAAAAAC//EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AVN//2Q==', 'base64');
  const out = await renderBrandCard({
    spec: { headline: 'Sleep and focus', size: 'portrait', ground: 'photo', index: 1, total: 4, standIn: false },
    photo: { bytes: jpeg, contentType: 'image/jpeg' },
  });
  assert.deepEqual(pngSize(out.png), { width: 1080, height: 1350 });
  const fonts = await loadFonts();
  const el = cardElement({ spec: { headline: 'x', size: 'portrait', ground: 'photo', index: 1, total: 1, standIn: false }, photo: { bytes: jpeg, contentType: 'image/jpeg' } }, fonts);
  const s = JSON.stringify(el);
  assert.match(s, /"type":"img"/);
  assert.doesNotMatch(s, /"opacity":0\.07/, 'no watermark behind a photograph');
});

test('a face uploaded for a role sets that role; the other stays on the stand-in', async () => {
  const bytes = readFileSync(path.join(process.cwd(), 'public', 'fonts', 'standin', 'InstrumentSerif-Regular.ttf'));
  const data = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
  setStoredFontReader(async () => [
    { name: 'headline--Brandserif-Regular.ttf', data },
    { name: 'Unlabelled-Regular.ttf', data },
  ]);
  try {
    const fonts = await loadFonts();
    assert.equal(fonts.headlineFamily, 'Brandserif');
    assert.deepEqual(fonts.standInFaces, ['body']);
    assert.deepEqual(fonts.sources, ['headline--Brandserif-Regular.ttf'], 'a file with no role is not used');
    const out = await renderBrandCard({ spec: { headline: 'Set in the brand face', size: 'square', ground: 'paper', index: 1, total: 1, standIn: false } });
    assert.equal(out.standIn, true);
    assert.deepEqual(out.standInFaces, ['body']);
  } finally {
    setStoredFontReader(null);
  }
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { draftDefect } from './draft-defect.ts';

test('a draft with a citation and no names is publishable', () => {
  assert.equal(draftDefect('Smith et al., Nature (2024). https://doi.org/10.1000/x', []), null);
});

test('a missing citation is a defect, and the writer is told it is mandatory', () => {
  const d = draftDefect('', []);
  assert.equal(d?.kind, 'no_citation');
  assert.match(String(d?.corrective), /no REF line/);
  assert.match(String(d?.corrective), /cannot be published without one/);
});

test('whitespace is not a citation', () => {
  assert.equal(draftDefect('   ', [])?.kind, 'no_citation');
});

test('a leaked name is a defect, and the rule sent back is categorical', () => {
  const d = draftDefect('Smith et al. https://doi.org/10.1000/x', ['Avery']);
  assert.equal(d?.kind, 'named_a_person');
  assert.match(String(d?.corrective), /never attribute a quote/i);
});

test('the corrective never repeats the banned name back into the prompt', () => {
  // Putting it back is how the model came to write "As our patient Avery
  // shares:" in the first place — the file name was in the prompt. Telling a
  // model to avoid a token is a well-known way to make it produce that token,
  // and the rule is categorical, so the name is not needed to state it.
  for (const d of [draftDefect('ref', ['Avery']), draftDefect('', ['Avery', 'Jordan'])]) {
    assert.ok(!/Avery/i.test(String(d?.corrective)), 'leaked the banned name back');
    assert.ok(!/Jordan/i.test(String(d?.corrective)), 'leaked the banned name back');
  }
});

test('several leaked names still read as plural', () => {
  assert.match(String(draftDefect('ref', ['Avery', 'Jordan'])?.corrective), /named people/);
});

test('both problems are corrected in one attempt, not traded for each other', () => {
  const d = draftDefect('', ['Avery']);
  // The name outranks the citation for which refusal this becomes...
  assert.equal(d?.kind, 'named_a_person');
  // ...but the writer is told about both, so one more draft can fix both.
  assert.match(String(d?.corrective), /named a person/);
  assert.match(String(d?.corrective), /no REF line/);
});

test('a repeated opening asks for another draft but never refuses the video', () => {
  const d = draftDefect('Smith 2020 doi:10/x', [], true);
  assert.equal(d?.kind, 'repeats_opening');
  // The whole point: one more attempt, and publish either way. A caption that
  // opens like last week's is a matter of style, not a reason to hold a video.
  assert.equal(d?.blocking, false);
  assert.match(String(d?.corrective), /throw it away/i);
});

test('the opening corrective never quotes the sentence it is correcting', () => {
  // Same lesson as nameCorrective: handing a model a sentence and saying "not
  // that one" is how you get that one back with the nouns swapped — which is
  // the exact failure being corrected.
  const d = draftDefect('Smith 2020 doi:10/x', [], true);
  assert.ok(!/safety in regenerative medicine/i.test(String(d?.corrective)));
  assert.match(String(d?.corrective), /CONCRETE/);
});

test('a real defect alongside a repeated opening still blocks, and fixes both', () => {
  const d = draftDefect('', [], true);
  assert.equal(d?.kind, 'no_citation');
  assert.equal(d?.blocking, true);
  // Both correctives ride along, so one more attempt can fix both rather than
  // trading one for the other.
  assert.match(String(d?.corrective), /REF/);
  assert.match(String(d?.corrective), /throw it away/i);

  const named = draftDefect('Smith 2020 doi:10/x', ['Avery'], true);
  assert.equal(named?.kind, 'named_a_person');
  assert.equal(named?.blocking, true);
});

test('a clean draft is still clean when nothing repeats', () => {
  assert.equal(draftDefect('Smith 2020 doi:10/x', [], false), null);
  assert.equal(draftDefect('Smith 2020 doi:10/x', []), null, 'the third argument is optional');
});

test('a citation that backs nothing the post says is a defect that BLOCKS', () => {
  // Since the September audit: a real, verified paper about something else
  // entirely went out under three posts. Flagging it was not enough; nothing
  // read the flag.
  const d = draftDefect('Smith 2020 doi:10/x', [], false, true);
  assert.equal(d?.kind, 'unsupported_citation');
  assert.equal(d?.blocking, true);
  assert.match(String(d?.corrective), /does not actually show/);
  // Not "find another study" — use the ones already retrieved and checked.
  assert.match(String(d?.corrective), /Do not go looking/);
  // A missing citation still outranks it: that is the worse thing to say.
  assert.equal(draftDefect('', [], false, true)?.kind, 'no_citation');
  assert.equal(draftDefect('ref', ['Avery'], false, true)?.kind, 'named_a_person');
});

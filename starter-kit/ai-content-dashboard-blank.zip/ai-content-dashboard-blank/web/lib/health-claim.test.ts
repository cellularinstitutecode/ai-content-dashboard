import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { makesHealthClaim } from './health-claim.ts';
import { checkCompliance, refPolicyOf } from './compliance.ts';
import { citationPolicyFor, strategyBrand } from './strategy-voice.ts';

// A made-up permit number: the advertising notice is opt-in, so it is passed explicitly.
const PERMIT = 'TEST0000PERMIT';
const AVISO = 'AVISO DE PUBLICIDAD: ' + PERMIT;
const ALWAYS = { requireCitations: 'always' } as const;
const src = (p: string) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('a destination or logistics post makes no health claim', () => {
  for (const t of [
    'There are direct flights from many cities, so getting here is simple.',
    'Plenty of hotels sit a short drive from our studio, from quiet boutique stays to family resorts.',
    'Travelling with someone? Your companion can explore the old town or the beach while you are with us.',
    'Plan your open days: a boat trip, a museum, a slow lunch by the water.',
  ]) assert.equal(makesHealthClaim(t), false, t);
});

test('anything that sounds like a health claim counts, when unsure yes', () => {
  for (const t of [
    'Warm weather and rest can help the body recover after treatment.',
    'Studies show sea air reduces stress.',
    'Gentle walks on the beach support circulation.',
    'HBOT sessions fit easily into an open day.',
  ]) assert.equal(makesHealthClaim(t), true, t);
});

test('the REF line is waived only under the policy AND with no claim in the text', () => {
  const trip = 'There are direct flights from many cities.\n\n' + AVISO;
  assert.equal(checkCompliance(trip, PERMIT, ALWAYS).ok, false, 'the strict policy still requires it');
  const waived = checkCompliance(trip, PERMIT, { ...ALWAYS, refPolicy: 'if-health-claim' });
  assert.equal(waived.ok, true);
  assert.equal(waived.refWaived, true);
  const claim = 'Warm weather helps the body recover faster.\n\n' + AVISO;
  const held = checkCompliance(claim, PERMIT, { ...ALWAYS, refPolicy: 'if-health-claim' });
  assert.equal(held.ok, false, 'a claim under the relaxed policy still needs its citation');
  assert.deepEqual(held.missing, ['ref']);
  // And a configured AVISO is required under every policy.
  assert.equal(checkCompliance('Direct flights from Toronto.', PERMIT, { refPolicy: 'if-health-claim' }).ok, false);
  // The default REQUIRE_CITATIONS ('health-claims') behaves like the relaxed policy everywhere.
  const prev = process.env.REQUIRE_CITATIONS;
  delete process.env.REQUIRE_CITATIONS;
  try {
    assert.equal(checkCompliance(trip, PERMIT).ok, true);
    assert.deepEqual(checkCompliance(claim, PERMIT).missing, ['ref']);
  } finally {
    if (prev !== undefined) process.env.REQUIRE_CITATIONS = prev;
  }
});

test('the policy is read from the draft, and anything unknown is "required"', () => {
  assert.equal(refPolicyOf({ _compliance: { refPolicy: 'if-health-claim' } }), 'if-health-claim');
  assert.equal(refPolicyOf({ _compliance: { refPolicy: 'whatever' } }), 'required');
  assert.equal(refPolicyOf(null), 'required');
});

test('a hand-written template is never relaxed; the strategy wording follows the policy', () => {
  assert.equal(citationPolicyFor({ slot: 'thu-2' }), 'required', 'a hand-written template is never relaxed');
  assert.equal(citationPolicyFor(null), 'required');
  assert.match(String(strategyBrand({ guidelines: '' } as Record<string, unknown>, { citation: 'if-health-claim' }).guidelines), /only if the post makes a health claim/);
  assert.match(String(strategyBrand({ guidelines: '' } as Record<string, unknown>).guidelines), /cite one real, relevant study\.$/);
});

test('wiring: every gate that re-checks stored copy reads the draft\'s policy', () => {
  assert.match(src('app/api/posts/route.ts'), /complianceGate\(user\.id, String\(existing\.text \|\| ''\), metricoolNetworks\(existing\.providers\), \{ refPolicy: refPolicyOf\(draftPack\), claimSupport: claimSupportOf\(draftPack\) \}\)/);
  assert.match(src('app/api/metricool/schedule/route.ts'), /complianceGate\(user\.id, text, network, \{ refPolicy: draftRefPolicy, claimSupport: draftClaimSupport \}\)/);
  const ap = src('lib/autopilot.ts');
  assert.match(ap, /refPolicy,\n/, 'approveRun plans each network under the template\'s policy');
  assert.match(ap, /claimSupport: \(pack\?\._claimSupport as \{ status\?: string \} \| undefined\)\?\.status \?\? null/, 'the judge\'s verdict reaches autoschedule');
  assert.doesNotMatch(ap, /claimSupport: null,/);
  assert.match(src('lib/ai.ts'), /citationPolicy === 'if-health-claim' \? REF_IF_CLAIM_INSTRUCTION : REF_INSTRUCTION/);
});

test('the brand\'s own name is not a health claim', () => {
  // A name with a body word in it matched the body-word list, so a logistics
  // post naming the team lost its waiver and was refused at approval.
  const name = 'Healing Hands Studio';
  assert.equal(makesHealthClaim(name + ' will meet you at the airport.'), true, 'unknown, the name reads as a claim');
  assert.equal(makesHealthClaim(name + ' will meet you at the airport.', { brandName: name }), false);
  assert.equal(makesHealthClaim('The healing  hands studio team is in town. Direct flights from Toronto.', { brandName: name }), false, 'case and spacing do not matter');
  assert.equal(makesHealthClaim(name + ' helps your joints heal.', { brandName: name }), true, 'only the name is ignored, not the claim');
  assert.equal(makesHealthClaim('Your cells repair overnight.'), true);
  assert.equal(makesHealthClaim('Supports cellular health.'), true);
});

test('a strategy slot under the relaxed policy is not handed study abstracts to cite', () => {
  assert.match(src('lib/autopilot.ts'), /if \(strategySlot && citationPolicy === 'required'\) \{\s*try \{ evidence = await findEvidence/);
});

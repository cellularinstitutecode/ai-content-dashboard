// web/lib/semrush-domain.ts
// Semrush Domain Intelligence: everything the SEO panel shows about the
// brand's own domain (and any competitor domain typed into the panel).
//
// Built on the same principles as lib/semrush.ts (the keyword "brain"):
// - cache-first via the shared Supabase semrush_cache table,
// - budget-guarded (never drains the fixed unit pool),
// - degrades gracefully to link-out when the key/plan is missing.
//
// Reports used (Standard Analytics API, semicolon-CSV responses):
//   domain_ranks            10 u/line  — rank, organic/paid keywords+traffic
//   domain_organic          10 u/line  — top ranking keywords w/ positions
//   domain_organic_organic  40 u/line  — organic competitors
//   backlinks_overview      40 u/req   — authority score, backlinks, ref domains
// Projects API (JSON, 100 u/request, needs SEMRUSH_PROJECT_ID):
//   /reports/v1/projects/{id}/siteaudit/info      — site health, errors, warnings
//   /reports/v1/projects/{id}/tracking/ (reports) — position-tracking visibility
//
// Domain metrics move slowly, so domain reports default to a 24h cache TTL
// (SEMRUSH_DOMAIN_CACHE_TTL_HOURS) instead of the 30-day keyword TTL.

import {
  UNIT_COST,
  budgetDecision,
  refusalReason,
  cacheGet,
  cachePut,
  db,
  decodeIntents,
  getUnitsBalance,
  keywordCapability,
  logUsage,
  semrushRequest,
  type KeywordCapability,
  type SemReportResult,
  type SemSource,
} from '@/lib/semrush';
import { reasonForCode, reasonForHttpStatus } from '@/lib/semrush-reason';
import { healthCachePhrase, parseAuditHealth, parseAuditInfo, unwrapEnvelope } from './semrush-audit.ts';
import { supabaseAdmin } from '@/lib/supabase-admin';
import { BRAND_WEBSITE } from '@/lib/brand-identity';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type SectionMeta = {
  ok: boolean;
  source: SemSource;
  reason: SemReportResult['reason'];
  note?: string;
  unitsSpent: number;
};

export type DomainOverview = {
  domain: string;
  rank: number | null; // Semrush Rank
  organicKeywords: number | null;
  organicTraffic: number | null;
  organicCost: number | null;
  paidKeywords: number | null;
  paidTraffic: number | null;
  paidCost: number | null;
};

export type BacklinksOverview = {
  authorityScore: number | null;
  backlinksTotal: number | null;
  refDomains: number | null;
  refUrls: number | null;
  refIps: number | null;
  follows: number | null;
  nofollows: number | null;
  texts: number | null;
  images: number | null;
};

export type OrganicKeywordRow = {
  keyword: string;
  position: number | null;
  prevPosition: number | null;
  positionDiff: number | null;
  volume: number | null;
  cpc: number | null;
  url: string;
  trafficPct: number | null;
  difficulty: number | null;
  intents: string[];
};

export type CompetitorRow = {
  domain: string;
  competitionLevel: number | null; // 0..1
  commonKeywords: number | null;
  organicKeywords: number | null;
  organicTraffic: number | null;
  organicCost: number | null;
};

export type SiteAuditSnapshot = {
  configured: boolean;
  status: string | null;
  health: number | null; // 0..100 (quality.value)
  healthDelta: number | null;
  errors: number | null;
  warnings: number | null;
  notices: number | null;
  pagesCrawled: number | null;
  pagesHealthy: number | null;
  pagesWithIssues: number | null;
  lastAudit: string | null; // ISO date
};

export type TrackingPoint = { date: string; visibility: number | null };

export type TrackingSummary = {
  configured: boolean;
  visibility: number | null; // latest visibility %
  visibilityDelta: number | null; // vs first point in window
  avgPosition: number | null;
  trend: TrackingPoint[];
};

export type SnapshotRow = {
  date: string; // YYYY-MM-DD
  authorityScore: number | null;
  semrushRank: number | null;
  organicTraffic: number | null;
  organicKeywords: number | null;
  paidKeywords: number | null;
  backlinksTotal: number | null;
  refDomains: number | null;
};

export type DomainBundle = {
  domain: string;
  isPrimaryDomain: boolean;
  overview: DomainOverview | null;
  overviewMeta: SectionMeta;
  backlinks: BacklinksOverview | null;
  backlinksMeta: SectionMeta;
  topKeywords: OrganicKeywordRow[];
  topKeywordsMeta: SectionMeta;
  competitors: CompetitorRow[];
  competitorsMeta: SectionMeta;
  // Daily metric history captured by this app (see semrush-domain.sql) —
  // powers the trend charts without paying for Semrush historical units.
  history: SnapshotRow[];
  balance: number | null;
  unitsSpent: number;
  /**
   * Whether the automatic keyword research that stamps every draft would run
   * live right now. The panel's "Active on every draft" badge used to be a
   * constant; it said "active" while the status banner said "paused".
   */
  keywordResearch: { ok: boolean; reason: KeywordCapability['reason']; transport: KeywordCapability['transport'] };
};

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------


/**
 * The deployment's own domain: SEMRUSH_DOMAIN, else the host of BRAND_WEBSITE.
 * Blank when neither is set — there is no built-in default, and every domain
 * report then answers with NO_DOMAIN_NOTE instead of querying Semrush.
 */
export function primaryDomain(): string {
  return normalizeDomain(process.env.SEMRUSH_DOMAIN || '') || normalizeDomain(BRAND_WEBSITE);
}

/** What a domain report says when no domain is configured or typed. */
export const NO_DOMAIN_NOTE =
  'No domain configured. Set SEMRUSH_DOMAIN (or BRAND_WEBSITE) in the environment, or type a domain to analyse.';

function noDomainMeta(): SectionMeta {
  return { ok: false, source: 'none', reason: 'empty', note: NO_DOMAIN_NOTE, unitsSpent: 0 };
}

export function projectId(): string {
  return (process.env.SEMRUSH_PROJECT_ID || '').trim();
}

function domainCacheTtlMs(): number {
  const h = parseInt(process.env.SEMRUSH_DOMAIN_CACHE_TTL_HOURS || '24', 10);
  return (Number.isFinite(h) && h > 0 ? h : 24) * 60 * 60 * 1000;
}

export function normalizeDomain(raw: string): string {
  return (raw || '')
    .trim()
    .replace(/^https?:\/\//, '')
    .replace(/^www\./, '')
    .replace(/\/.*$/, '')
    .toLowerCase();
}

function num(v: unknown): number | null {
  const n = typeof v === 'string' ? parseFloat(v) : (v as number);
  return Number.isFinite(n) ? n : null;
}

// ---------------------------------------------------------------------------
// Low-level fetch (CSV endpoints). Mirrors lib/semrush.ts runReport but with
// arbitrary query params (domain reports use `domain=`/`target=`, not `phrase=`).
// ---------------------------------------------------------------------------

type RawResult = {
  ok: boolean;
  body?: string;
  rowsCached?: any[];
  source: SemSource;
  reason: SemReportResult['reason'];
  note?: string;
  unitsSpent: number;
};

async function rawCsvReport(
  report: string,
  cachePhrase: string,
  params: Record<string, string>,
  opts: { estLines: number; path?: string; timeoutMs?: number; ttlMs?: number }
): Promise<RawResult> {
  const database = db();

  // 0) nothing to ask about: no domain configured and none typed.
  if ('domain' in params || 'target' in params) {
    if (!String(params.domain ?? params.target ?? '').trim()) {
      return { ok: false, source: 'none', reason: 'empty', note: NO_DOMAIN_NOTE, unitsSpent: 0 };
    }
  }

  // 1) cache
  const cached = await cacheGet(report, database, cachePhrase, opts.ttlMs ?? domainCacheTtlMs());
  if (cached) {
    void logUsage(report, cachePhrase, 0, 'cache');
    return { ok: true, rowsCached: cached, source: 'cache', reason: 'ok', unitsSpent: 0 };
  }

  // 2) live — only with a key and inside budget
  const key = process.env.SEMRUSH_API_KEY;
  if (!key) return { ok: false, source: 'none', reason: 'no_token', note: 'SEMRUSH_API_KEY not set', unitsSpent: 0 };

  const estUnits = (UNIT_COST[report] ?? 40) * Math.max(1, opts.estLines);
  const decision = await budgetDecision(estUnits);
  if (!decision.allow) {
    return { ok: false, source: 'none', ...refusalReason(decision), unitsSpent: 0 };
  }

  try {
    const { status, text } = await semrushRequest(report, params, { path: opts.path, timeoutMs: opts.timeoutMs ?? 10000 });
    if (/^ERROR\s+\d+/i.test(text)) {
      const code = parseInt(text.replace(/^ERROR\s+/i, ''), 10);
      const reason = reasonForCode(code);
      if (reason === 'empty') return { ok: true, body: '', source: 'live', reason: 'ok', unitsSpent: 0 };
      return { ok: false, source: 'none', reason, note: text.slice(0, 120), unitsSpent: 0 };
    }
    if (status < 200 || status >= 300) {
      const reason = reasonForHttpStatus(status);
      return { ok: false, source: 'none', reason, note: 'HTTP ' + status, unitsSpent: 0 };
    }
    return { ok: true, body: text, source: 'live', reason: 'ok', unitsSpent: estUnits };
  } catch (e: any) {
    return { ok: false, source: 'none', reason: 'network', note: e?.name || 'fetch failed', unitsSpent: 0 };
  }
}

// Generic semicolon-CSV → array of objects keyed by header cell.
export function parseCsvRows(body: string): Record<string, string>[] {
  const lines = (body || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (lines.length < 2) return [];
  const headers = lines[0].split(';').map((h) => h.trim());
  return lines.slice(1).map((line) => {
    const cells = line.split(';');
    const row: Record<string, string> = {};
    headers.forEach((h, i) => (row[h] = (cells[i] ?? '').trim()));
    return row;
  });
}

function meta(r: RawResult, unitsSpent: number): SectionMeta {
  return { ok: r.ok, source: r.source, reason: r.reason, note: r.note, unitsSpent };
}

// ---------------------------------------------------------------------------
// Domain overview (domain_ranks)
// ---------------------------------------------------------------------------

export async function domainOverview(domain: string): Promise<{ data: DomainOverview | null; meta: SectionMeta }> {
  const r = await rawCsvReport(
    'domain_ranks',
    domain,
    { domain, database: db(), export_columns: 'Db,Dn,Rk,Or,Ot,Oc,Ad,At,Ac' },
    { estLines: 1 }
  );
  const finish = (rows: Record<string, string>[], units: number, src: RawResult): { data: DomainOverview | null; meta: SectionMeta } => {
    const row = rows[0];
    if (!row) return { data: null, meta: { ...meta(src, units), ok: false, reason: src.reason === 'ok' ? 'empty' : src.reason } };
    return {
      data: {
        domain,
        rank: num(row['Rank']),
        organicKeywords: num(row['Organic Keywords']),
        organicTraffic: num(row['Organic Traffic']),
        organicCost: num(row['Organic Cost']),
        paidKeywords: num(row['Adwords Keywords']),
        paidTraffic: num(row['Adwords Traffic']),
        paidCost: num(row['Adwords Cost']),
      },
      meta: meta(src, units),
    };
  };
  if (r.rowsCached) return finish(r.rowsCached as Record<string, string>[], 0, r);
  if (!r.ok) return { data: null, meta: meta(r, 0) };
  const rows = parseCsvRows(r.body || '');
  const units = rows.length * UNIT_COST.domain_ranks;
  if (rows.length) {
    void cachePut('domain_ranks', db(), domain, rows, units);
    void logUsage('domain_ranks', domain, units, 'live');
  }
  return finish(rows, units, r);
}

// ---------------------------------------------------------------------------
// Backlinks overview (authority score, backlinks, ref domains)
// ---------------------------------------------------------------------------

export async function backlinksOverview(domain: string): Promise<{ data: BacklinksOverview | null; meta: SectionMeta }> {
  const r = await rawCsvReport(
    'backlinks_overview',
    domain,
    {
      target: domain,
      target_type: 'root_domain',
      export_columns: 'ascore,total,domains_num,urls_num,ips_num,follows_num,nofollows_num,texts_num,images_num',
    },
    { estLines: 1, path: '/analytics/v1/' }
  );
  const finish = (rows: Record<string, string>[], units: number, src: RawResult): { data: BacklinksOverview | null; meta: SectionMeta } => {
    const row = rows[0];
    if (!row) return { data: null, meta: { ...meta(src, units), ok: false, reason: src.reason === 'ok' ? 'empty' : src.reason } };
    return {
      data: {
        authorityScore: num(row['ascore']),
        backlinksTotal: num(row['total']),
        refDomains: num(row['domains_num']),
        refUrls: num(row['urls_num']),
        refIps: num(row['ips_num']),
        follows: num(row['follows_num']),
        nofollows: num(row['nofollows_num']),
        texts: num(row['texts_num']),
        images: num(row['images_num']),
      },
      meta: meta(src, units),
    };
  };
  if (r.rowsCached) return finish(r.rowsCached as Record<string, string>[], 0, r);
  if (!r.ok) return { data: null, meta: meta(r, 0) };
  const rows = parseCsvRows(r.body || '');
  const units = UNIT_COST.backlinks_overview; // billed per request
  if (rows.length) {
    void cachePut('backlinks_overview', db(), domain, rows, units);
    void logUsage('backlinks_overview', domain, units, 'live');
  }
  return finish(rows, rows.length ? units : 0, r);
}

// ---------------------------------------------------------------------------
// Top organic keywords with positions (domain_organic)
// ---------------------------------------------------------------------------

export async function topOrganicKeywords(
  domain: string,
  limit = 15
): Promise<{ rows: OrganicKeywordRow[]; meta: SectionMeta }> {
  const lim = Math.max(1, Math.min(limit, 30));
  const r = await rawCsvReport(
    'domain_organic',
    domain + ':top:' + lim,
    {
      domain,
      database: db(),
      display_limit: String(lim),
      display_sort: 'tr_desc',
      export_columns: 'Ph,Po,Pp,Pd,Nq,Cp,Ur,Tr,Kd,In',
    },
    { estLines: lim }
  );
  const toRows = (rows: Record<string, string>[]): OrganicKeywordRow[] =>
    rows
      .map((row) => {
        const pos = num(row['Position']);
        const prev = num(row['Previous Position']);
        return {
          keyword: row['Keyword'] || '',
          position: pos,
          prevPosition: prev,
          positionDiff: num(row['Position Difference']),
          volume: num(row['Search Volume']),
          cpc: num(row['CPC']),
          url: row['Url'] || '',
          trafficPct: num(row['Traffic (%)'] ?? row['Traffic']),
          difficulty: num(row['Keyword Difficulty Index'] ?? row['Keyword Difficulty']),
          intents: decodeIntents(row['Intents'] ?? row['Intent']),
        } as OrganicKeywordRow;
      })
      .filter((k) => k.keyword.length > 0);
  if (r.rowsCached) return { rows: toRows(r.rowsCached as Record<string, string>[]), meta: meta(r, 0) };
  if (!r.ok) return { rows: [], meta: meta(r, 0) };
  const parsed = parseCsvRows(r.body || '');
  const units = parsed.length * UNIT_COST.domain_organic;
  if (parsed.length) {
    void cachePut('domain_organic', db(), domain + ':top:' + lim, parsed, units);
    void logUsage('domain_organic', domain, units, 'live');
  }
  return { rows: toRows(parsed), meta: meta(r, units) };
}

// ---------------------------------------------------------------------------
// Keyword movers: recent ranking changes (domain_organic + display_positions).
// Four small cached reports — new / lost / improved (rise) / declined (fall).
// ---------------------------------------------------------------------------

export type MoverRow = {
  keyword: string;
  position: number | null;
  prevPosition: number | null;
  positionDiff: number | null;
  volume: number | null;
  difficulty: number | null;
  url: string;
};

export type KeywordMovers = {
  newKeywords: MoverRow[];
  lostKeywords: MoverRow[];
  improved: MoverRow[];
  declined: MoverRow[];
  meta: SectionMeta;
};

async function moverReport(domain: string, kind: 'new' | 'lost' | 'rise' | 'fall', limit = 6): Promise<{ rows: MoverRow[]; meta: SectionMeta }> {
  const lim = Math.max(1, Math.min(limit, 10));
  const r = await rawCsvReport(
    'domain_organic',
    domain + ':mv:' + kind + ':' + lim,
    {
      domain,
      database: db(),
      display_limit: String(lim),
      display_positions: kind,
      display_sort: 'nq_desc',
      export_columns: 'Ph,Po,Pp,Pd,Nq,Kd,Ur',
    },
    { estLines: lim }
  );
  const toRows = (rows: Record<string, string>[]): MoverRow[] =>
    rows
      .map((row) => ({
        keyword: row['Keyword'] || '',
        position: num(row['Position']),
        prevPosition: num(row['Previous Position']),
        positionDiff: num(row['Position Difference']),
        volume: num(row['Search Volume']),
        difficulty: num(row['Keyword Difficulty Index'] ?? row['Keyword Difficulty']),
        url: row['Url'] || '',
      }))
      .filter((k) => k.keyword.length > 0);
  if (r.rowsCached) return { rows: toRows(r.rowsCached as Record<string, string>[]), meta: meta(r, 0) };
  if (!r.ok) return { rows: [], meta: meta(r, 0) };
  const parsed = parseCsvRows(r.body || '');
  const units = parsed.length * UNIT_COST.domain_organic;
  if (parsed.length) {
    void cachePut('domain_organic', db(), domain + ':mv:' + kind + ':' + lim, parsed, units);
    void logUsage('domain_organic', domain + ' (' + kind + ')', units, 'live');
  }
  return { rows: toRows(parsed), meta: meta(r, units) };
}

export async function keywordMovers(rawDomain?: string): Promise<KeywordMovers> {
  const domain = normalizeDomain(rawDomain || '') || primaryDomain();
  const [nw, lost, rise, fall] = await Promise.all([
    moverReport(domain, 'new'),
    moverReport(domain, 'lost'),
    moverReport(domain, 'rise'),
    moverReport(domain, 'fall'),
  ]);
  // Overall meta: ok if any leg succeeded; carry the most informative failure.
  const legs = [nw.meta, lost.meta, rise.meta, fall.meta];
  const okLeg = legs.find((m) => m.ok);
  return {
    newKeywords: nw.rows,
    lostKeywords: lost.rows,
    improved: rise.rows,
    declined: fall.rows,
    meta: okLeg
      ? { ok: true, source: legs.some((m) => m.source === 'live') ? 'live' : 'cache', reason: 'ok', unitsSpent: legs.reduce((s, m) => s + m.unitsSpent, 0) }
      : legs[0],
  };
}

// ---------------------------------------------------------------------------
// Organic competitors (domain_organic_organic)
// ---------------------------------------------------------------------------

export async function organicCompetitors(
  domain: string,
  limit = 5
): Promise<{ rows: CompetitorRow[]; meta: SectionMeta }> {
  const lim = Math.max(1, Math.min(limit, 10));
  const r = await rawCsvReport(
    'domain_organic_organic',
    domain + ':comp:' + lim,
    {
      domain,
      database: db(),
      display_limit: String(lim),
      display_sort: 'np_desc',
      export_columns: 'Dn,Cr,Np,Or,Ot,Oc',
    },
    { estLines: lim }
  );
  const toRows = (rows: Record<string, string>[]): CompetitorRow[] =>
    rows
      .map((row) => ({
        domain: row['Domain'] || '',
        competitionLevel: num(row['Competitor Relevance'] ?? row['Competition Level']),
        commonKeywords: num(row['Common Keywords']),
        organicKeywords: num(row['Organic Keywords']),
        organicTraffic: num(row['Organic Traffic']),
        organicCost: num(row['Organic Cost']),
      }))
      .filter((c) => c.domain.length > 0);
  if (r.rowsCached) return { rows: toRows(r.rowsCached as Record<string, string>[]), meta: meta(r, 0) };
  if (!r.ok) return { rows: [], meta: meta(r, 0) };
  const parsed = parseCsvRows(r.body || '');
  const units = parsed.length * UNIT_COST.domain_organic_organic;
  if (parsed.length) {
    void cachePut('domain_organic_organic', db(), domain + ':comp:' + lim, parsed, units);
    void logUsage('domain_organic_organic', domain, units, 'live');
  }
  return { rows: toRows(parsed), meta: meta(r, units) };
}

// ---------------------------------------------------------------------------
// Projects API (JSON): Site Audit + Position Tracking. Requires
// SEMRUSH_PROJECT_ID. Billed 100 units/request → cached 12h by default.
// ---------------------------------------------------------------------------

const PROJECT_TTL_MS = 12 * 60 * 60 * 1000;

async function projectJson(
  cacheReport: 'siteaudit_info' | 'siteaudit_history' | 'tracking_report',
  cachePhrase: string,
  projectId: string,
  path: string,
  params: Record<string, string>,
  ttlMs: number = PROJECT_TTL_MS,
): Promise<{ json: any | null; meta: SectionMeta }> {
  const cached = await cacheGet(cacheReport, 'proj', cachePhrase, ttlMs);
  if (cached && cached[0]) {
    void logUsage(cacheReport, cachePhrase, 0, 'cache');
    return { json: cached[0], meta: { ok: true, source: 'cache', reason: 'ok', unitsSpent: 0 } };
  }
  const key = process.env.SEMRUSH_API_KEY;
  if (!key) return { json: null, meta: { ok: false, source: 'none', reason: 'no_token', unitsSpent: 0 } };
  const est = UNIT_COST[cacheReport] ?? UNIT_COST.siteaudit_info;
  const decision = await budgetDecision(est);
  if (!decision.allow) {
    return { json: null, meta: { ok: false, source: 'none', ...refusalReason(decision), unitsSpent: 0 } };
  }
  try {
    const { status, text } = await semrushRequest(cacheReport, params, { path, projectId, accept: 'application/json', timeoutMs: 12000 });
    if (/^ERROR\s+\d+/i.test(text)) {
      // The MCP transport reports a missing entitlement the v3 way.
      const reason = reasonForCode(parseInt(text.replace(/^ERROR\s+/i, ''), 10));
      return { json: null, meta: { ok: false, source: 'none', reason: reason === 'empty' ? 'plan' : reason, note: text.slice(0, 120), unitsSpent: 0 } };
    }
    if (status < 200 || status >= 300) {
      // 404 on a project report means "not enabled for this project", which
      // belongs with the other plan/entitlement states rather than 'http'.
      const reason = status === 404 ? 'plan' : reasonForHttpStatus(status);
      return { json: null, meta: { ok: false, source: 'none', reason, note: 'HTTP ' + status, unitsSpent: 0 } };
    }
    let json: any = null;
    try { json = JSON.parse(text); } catch { /* not JSON - an expected branch, not a fault */ }
    // The MCP transport wraps every report as { data, metadata }; the readers
    // below expect the v3 body. Unwrapped once, here, for every project report.
    json = unwrapEnvelope(json);
    if (json == null) return { json: null, meta: { ok: false, source: 'none', reason: 'http', note: 'unexpected response', unitsSpent: 0 } };
    void cachePut(cacheReport, 'proj', cachePhrase, [json], est);
    void logUsage(cacheReport, cachePhrase, est, 'live');
    return { json, meta: { ok: true, source: 'live', reason: 'ok', unitsSpent: est } };
  } catch (e: any) {
    return { json: null, meta: { ok: false, source: 'none', reason: 'network', note: e?.name || 'fetch failed', unitsSpent: 0 } };
  }
}

export async function siteAudit(): Promise<{ data: SiteAuditSnapshot; meta: SectionMeta }> {
  const id = projectId();
  const empty: SiteAuditSnapshot = {
    configured: Boolean(id), status: null, health: null, healthDelta: null,
    errors: null, warnings: null, notices: null,
    pagesCrawled: null, pagesHealthy: null, pagesWithIssues: null, lastAudit: null,
  };
  if (!id) return { data: empty, meta: { ok: false, source: 'none', reason: 'no_token', note: 'SEMRUSH_PROJECT_ID not set', unitsSpent: 0 } };
  const { json, meta: m } = await projectJson('siteaudit_info', id, id, `/reports/v1/projects/${encodeURIComponent(id)}/siteaudit/info`, {});
  if (!json) return { data: empty, meta: m };
  const info = parseAuditInfo(json);

  // THE HEALTH SCORE. Not in `info`: it is the audit history's quality value,
  // billed at 10,000 units. It only changes when an audit finishes (about
  // monthly), so it is kept under that audit's finish time and fetched once
  // per audit — a refresh costs nothing, a new audit costs one fetch.
  let health = info.health;
  let healthDelta = info.healthDelta;
  let units = m.unitsSpent;
  const phrase = healthCachePhrase(id, info.lastAuditMs);
  if (health == null && phrase) {
    const h = await projectJson(
      'siteaudit_history', phrase, id,
      `/reports/v1/projects/${encodeURIComponent(id)}/siteaudit/history`, { limit: '1' },
      400 * 24 * 60 * 60 * 1000,
    );
    if (h.json) {
      const parsed = parseAuditHealth(h.json);
      health = parsed.health;
      healthDelta = parsed.healthDelta;
    }
    units += h.meta.unitsSpent;
  }
  return {
    data: {
      configured: true,
      status: info.status,
      health,
      healthDelta,
      errors: info.errors,
      warnings: info.warnings,
      notices: info.notices,
      pagesCrawled: info.pagesCrawled,
      pagesHealthy: info.pagesHealthy,
      pagesWithIssues: info.pagesWithIssues,
      lastAudit: info.lastAudit,
    },
    meta: { ...m, unitsSpent: units },
  };
}

// Recursively hunt for numeric fields in unfamiliar JSON shapes (the tracking
// report format varies by campaign type — parse defensively, never throw).
function deepFindNumbers(obj: any, key: string, out: number[] = [], depth = 0): number[] {
  if (!obj || typeof obj !== 'object' || depth > 6) return out;
  for (const [k, v] of Object.entries(obj)) {
    if (k.toLowerCase() === key.toLowerCase()) {
      const n = num(v as any);
      if (n != null) out.push(n);
    }
    if (v && typeof v === 'object') deepFindNumbers(v, key, out, depth + 1);
  }
  return out;
}

export async function trackingSummary(domain: string): Promise<{ data: TrackingSummary; meta: SectionMeta }> {
  const id = projectId();
  const empty: TrackingSummary = { configured: Boolean(id), visibility: null, visibilityDelta: null, avgPosition: null, trend: [] };
  if (!id) return { data: empty, meta: { ok: false, source: 'none', reason: 'no_token', note: 'SEMRUSH_PROJECT_ID not set', unitsSpent: 0 } };
  if (!normalizeDomain(domain || '')) return { data: empty, meta: noDomainMeta() };

  const end = new Date();
  const begin = new Date(end.getTime() - 29 * 24 * 60 * 60 * 1000);
  const fmt = (d: Date) => d.toISOString().slice(0, 10).replace(/-/g, '');
  const { json, meta: m } = await projectJson(
    'tracking_report',
    id + ':' + fmt(begin).slice(0, 6),
    id,
    `/reports/v1/projects/${encodeURIComponent(id)}/tracking/`,
    {
      action: 'report',
      type: 'tracking_visibility_organic',
      date_begin: fmt(begin),
      date_end: fmt(end),
      url: '*.' + domain + '/*',
    }
  );
  if (!json) return { data: empty, meta: m };

  // Expected shape: { data: { "YYYYMMDD": { Vi: ..., Av: ... }, ... } } — but
  // tolerate variations by walking whatever came back.
  const trend: TrackingPoint[] = [];
  const data = json.data && typeof json.data === 'object' ? json.data : json;
  if (data && typeof data === 'object') {
    for (const [k, v] of Object.entries(data)) {
      if (/^\d{8}$/.test(k) && v && typeof v === 'object') {
        const vi = deepFindNumbers(v, 'Vi')[0] ?? deepFindNumbers(v, 'visibility')[0] ?? null;
        trend.push({ date: k.slice(0, 4) + '-' + k.slice(4, 6) + '-' + k.slice(6, 8), visibility: vi });
      }
    }
  }
  trend.sort((a, b) => a.date.localeCompare(b.date));
  const withVis = trend.filter((t) => t.visibility != null);
  const latest = withVis.length ? withVis[withVis.length - 1].visibility : null;
  const first = withVis.length ? withVis[0].visibility : null;
  const avgPos = deepFindNumbers(json, 'Av')[0] ?? null;
  return {
    data: {
      configured: true,
      visibility: latest,
      visibilityDelta: latest != null && first != null ? Math.round((latest - first) * 100) / 100 : null,
      avgPosition: avgPos,
      trend,
    },
    meta: m,
  };
}

// ---------------------------------------------------------------------------
// Daily snapshots: this app records one row per domain per day so the panel
// can chart real trends without Semrush historical-data unit costs.
// Fail-open: DB trouble (e.g. semrush-domain.sql not run yet) never blocks.
// ---------------------------------------------------------------------------

async function recordSnapshot(domain: string, ov: DomainOverview | null, bl: BacklinksOverview | null): Promise<void> {
  if (!ov && !bl) return;
  // Write ONLY the columns whose source actually reported.
  //
  // The upsert used to send every column on either leg succeeding, so when the
  // overview call failed but backlinks succeeded - two 24h caches expiring at
  // different times, a 10s timeout, an ERROR nn, the budget floor - it replaced
  // the day's row and nulled organic_traffic, organic_keywords, semrush_rank and
  // the rest. This table is the app's only source of trend history, so a day of
  // real measurements disappeared and every delta shifted with it.
  const row: Record<string, unknown> = {
    domain,
    captured_on: new Date().toISOString().slice(0, 10),
  };
  if (ov) {
    row.semrush_rank = ov.rank ?? null;
    row.organic_traffic = ov.organicTraffic ?? null;
    row.organic_keywords = ov.organicKeywords ?? null;
    row.organic_cost = ov.organicCost ?? null;
    row.paid_keywords = ov.paidKeywords ?? null;
    row.paid_traffic = ov.paidTraffic ?? null;
  }
  if (bl) {
    row.authority_score = bl.authorityScore ?? null;
    row.backlinks_total = bl.backlinksTotal ?? null;
    row.ref_domains = bl.refDomains ?? null;
  }
  try {
    // A partial upsert still replaces the whole row on conflict, so merge with
    // whatever today already holds before writing.
    const db = supabaseAdmin();
    const { data: existing } = await db
      .from('semrush_domain_snapshots')
      .select('*')
      .eq('domain', domain)
      .eq('captured_on', row.captured_on as string)
      .maybeSingle();
    await db
      .from('semrush_domain_snapshots')
      .upsert({ ...(existing || {}), ...row }, { onConflict: 'domain,captured_on' });
  } catch {
    // ignore — history is best-effort
  }
}

async function snapshotHistory(domain: string, days = 90): Promise<SnapshotRow[]> {
  try {
    const { data } = await supabaseAdmin()
      .from('semrush_domain_snapshots')
      .select('captured_on, authority_score, semrush_rank, organic_traffic, organic_keywords, paid_keywords, backlinks_total, ref_domains')
      .eq('domain', domain)
      .order('captured_on', { ascending: false })
      .limit(days);
    if (!Array.isArray(data)) return [];
    return (data as any[])
      .map((r) => ({
        date: String(r.captured_on),
        authorityScore: num(r.authority_score),
        semrushRank: num(r.semrush_rank),
        organicTraffic: num(r.organic_traffic),
        organicKeywords: num(r.organic_keywords),
        paidKeywords: num(r.paid_keywords),
        backlinksTotal: num(r.backlinks_total),
        refDomains: num(r.ref_domains),
      }))
      .reverse();
  } catch {
    return [];
  }
}

// ---------------------------------------------------------------------------
// The bundle: one call powers the whole panel.
// ---------------------------------------------------------------------------

export async function domainBundle(rawDomain?: string): Promise<DomainBundle> {
  const domain = normalizeDomain(rawDomain || '') || primaryDomain();
  if (!domain) {
    // No domain to analyse: say so, spend nothing, and record no snapshot.
    const [balance, cap] = await Promise.all([getUnitsBalance(), keywordCapability()]);
    const m = noDomainMeta();
    return {
      domain: '',
      isPrimaryDomain: true,
      overview: null,
      overviewMeta: m,
      backlinks: null,
      backlinksMeta: m,
      topKeywords: [],
      topKeywordsMeta: m,
      competitors: [],
      competitorsMeta: m,
      history: [],
      balance,
      unitsSpent: 0,
      keywordResearch: { ok: cap.ok, reason: cap.reason, transport: cap.transport },
    };
  }
  const [ov, bl, kw, comp, balance, cap] = await Promise.all([
    domainOverview(domain),
    backlinksOverview(domain),
    topOrganicKeywords(domain, 30),
    organicCompetitors(domain, 5),
    getUnitsBalance(),
    keywordCapability(),
  ]);
  // Record today's snapshot, then read the accumulated history for charts.
  await recordSnapshot(domain, ov.data, bl.data);
  const history = await snapshotHistory(domain);
  return {
    domain,
    isPrimaryDomain: domain === primaryDomain(),
    overview: ov.data,
    overviewMeta: ov.meta,
    backlinks: bl.data,
    backlinksMeta: bl.meta,
    topKeywords: kw.rows,
    topKeywordsMeta: kw.meta,
    competitors: comp.rows,
    competitorsMeta: comp.meta,
    history,
    balance,
    unitsSpent: ov.meta.unitsSpent + bl.meta.unitsSpent + kw.meta.unitsSpent + comp.meta.unitsSpent,
    keywordResearch: { ok: cap.ok, reason: cap.reason, transport: cap.transport },
  };
}

// ---------------------------------------------------------------------------
// Keyword-research activity: which AI drafts passed through the Semrush
// filter (draft_keywords is written by every generation path). Powers the
// "automatic keyword research" feed in the panel.
// ---------------------------------------------------------------------------

export type ResearchActivityRow = {
  topic: string;
  keyword: string;
  volume: number | null;
  difficulty: number | null;
  role: string;
  createdAt: string;
};

export async function keywordResearchActivity(userId: string, limit = 12): Promise<ResearchActivityRow[]> {
  try {
    const { data } = await supabaseAdmin()
      .from('draft_keywords')
      .select('topic, keyword, volume, difficulty, role, created_at')
      .eq('user_id', userId)
      .eq('role', 'primary')
      .order('created_at', { ascending: false })
      .limit(limit);
    if (!Array.isArray(data)) return [];
    return (data as any[]).map((r) => ({
      topic: String(r.topic || ''),
      keyword: String(r.keyword || ''),
      volume: num(r.volume),
      difficulty: num(r.difficulty),
      role: String(r.role || 'primary'),
      createdAt: String(r.created_at || ''),
    }));
  } catch {
    return [];
  }
}

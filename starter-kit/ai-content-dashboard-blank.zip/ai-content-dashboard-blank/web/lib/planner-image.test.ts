import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { PILLARS } from './content-strategy.ts';
import { BLOG_SLOT } from './strategy-seed.ts';
import { FALLBACK_OBJECTS, MAX_ANGLE_TITLE, MAX_COVER_TITLE, PILLAR_SCENES, PLAN_LENGTH, SHOTS, SHOT_COUNT, TITLES, TITLE_FRAMINGS, cleanTopic, familyAt, isLifestylePillar, kindOf, plannerImageFor, plannerPromptLines, onTopicCheck, sceneSetFor, scienceAllowed, scienceOffered, scienceScore, shotFor, titleCase, titleFor, titleSeq, variedTitle } from './planner-image.ts';
import type { PlannerImage } from './planner-image.ts';

const pack = (template_name: string, query: string) => ({ _autopilot: { template_name, angle: { query, seedTopic: query } } });

// The strategy's pillars are the deployment's own, so these tests take
// whatever pillars lib/content-strategy.ts ships rather than naming any.
const P0 = PILLARS[0];
const firstAngle = (p: { angles: string[] }) => p.angles[0] || 'An angle';
const img = (p = P0, angle = firstAngle(P0)) => plannerImageFor(pack(p.name, angle))!;

/** A synthetic planner image for a kind, so kind-level rules are tested without any particular pillar. */
const synth = (pillarId: string, extra: Partial<PlannerImage> = {}): PlannerImage => ({
  pillarId,
  pillarName: pillarId,
  kind: kindOf(pillarId),
  subject: 'A subject',
  title: 'A Title',
  ...sceneSetFor({ id: pillarId, name: pillarId }),
  size: '1024x1536',
  ...extra,
});

test('every strategy pillar gets at least three scenes and an on-topic cue, unknown ones the general set', () => {
  for (const p of PILLARS) {
    const s = sceneSetFor(p);
    assert.ok(s && s.scenes.length >= 3, p.id);
    assert.ok(s.mustShow.length > 20, p.id);
  }
  assert.equal(sceneSetFor({ id: 'zz-unknown', name: 'Qwerty' }), PILLAR_SCENES.general);
  assert.equal(sceneSetFor(null), PILLAR_SCENES.general);
  for (const [k, s] of Object.entries(PILLAR_SCENES)) assert.ok(s.scenes.length >= 3 && s.mustShow.length > 20, k);
});

test('a pillar is read for the kind of picture it suits', () => {
  assert.equal(kindOf('nutrition'), 'food');
  assert.equal(kindOf('recipes', 'Weekly recipes'), 'food');
  assert.equal(kindOf('behind-the-scenes'), 'craft');
  assert.equal(kindOf('product-spotlight'), 'product');
  assert.equal(kindOf('customer-stories'), 'people');
  assert.equal(kindOf('tips', 'Tips and how-tos'), 'expertise');
  assert.equal(kindOf('active-living'), 'lifestyle');
  assert.equal(kindOf('sleep-stress'), 'rest');
  assert.equal(kindOf('local', 'Our neighbourhood'), 'place');
  assert.equal(kindOf('p7', 'Something else'), 'general');
  assert.equal(kindOf('rest'), 'rest', 'a kind is its own kind');
});

test('an entry under a pillar\'s exact id wins over its kind', () => {
  const own = { mustShow: 'a very particular thing on the table', scenes: ['a', 'b', 'c'] };
  PILLAR_SCENES['my-own-pillar'] = own;
  try {
    assert.equal(sceneSetFor({ id: 'my-own-pillar', name: 'Nutrition' }), own);
  } finally {
    delete PILLAR_SCENES['my-own-pillar'];
  }
});

test('cover titles: a written one wins, a short angle is its own title, a long one falls back to the pillar', () => {
  assert.deepEqual(Object.keys(TITLES), [], 'the template ships no hand-written titles');
  assert.equal(titleFor('the role of protein in recovery', 'Nutrition'), 'The Role of Protein in Recovery');
  assert.equal(titleFor('[Autopilot] Simple ways to stay active', 'Movement'), 'Simple Ways to Stay Active');
  const long = 'Why the right plan depends on the person and not only on the goal they bring';
  assert.ok(long.length > MAX_ANGLE_TITLE);
  assert.equal(titleFor(long, 'Planning'), 'Planning');
  assert.equal(titleFor(long, 'industry news and insights'), 'Industry News and Insights');
  assert.equal(titleFor('Is this a question?', 'Planning'), 'Planning');
  assert.equal(titleFor(long, ''), 'Worth Knowing');
  TITLES['the role of protein in recovery'] = 'Protein and Recovery';
  try {
    assert.equal(titleFor('The role of protein in recovery', 'Nutrition'), 'Protein and Recovery');
  } finally {
    delete TITLES['the role of protein in recovery'];
  }
  assert.equal(titleCase('a guide to the basics.'), 'A Guide to the Basics');
  assert.equal(titleCase('Using SEO in practice'), 'Using SEO in Practice');
});

test('a planner draft is pictured in one of the shots, with its objects, craft and title', () => {
  const p = img();
  assert.ok(p);
  assert.equal(p.pillarId, P0.id);
  assert.equal(p.kind, kindOf(P0.id, P0.name));
  assert.equal(p.size, '1024x1536');
  assert.equal(p.title, titleFor(firstAngle(P0), P0.name));
  const lines = plannerPromptLines(p, 0).join(' ');
  assert.ok(lines.startsWith(`Subject: a photograph for an educational post titled "${p.title}"`), lines.slice(0, 120));
  assert.match(lines, /SHOT: /);
  assert.match(lines, /TITLE SPACE: the upper third/);
  assert.match(lines, /CRAFT: /);
  assert.match(onTopicCheck(p), /onTopic/);
  // The fallback objects of the pillar's kind reach the conversation shot.
  const food = plannerPromptLines(synth('nutrition'), 0).join(' ');
  assert.match(food, /balanced plate of fresh food/);
});

test('nothing in a prompt names a particular business, place or offer', () => {
  for (const id of ['nutrition', 'behind-the-scenes', 'local', 'p1', 'recovery', 'product']) {
    for (let i = 0; i < PLAN_LENGTH; i++) {
      const lines = plannerPromptLines(synth(id, { science: true }), i).join(' ') + onTopicCheck(synth(id));
      assert.doesNotMatch(lines, /cancun|cancún|caribbean|clinic\b|physician|patient|regenerative|stem cell therapy|exosome/i, id + ' ' + i);
    }
  }
});

test('a place theme looks out at the local view', () => {
  const lines = plannerPromptLines(synth('local'), 0, null, 'consult').join(' ');
  assert.match(lines, /local (streets|landscape)/);
});

test('different posts get different shots, and a reroll moves to the next one', () => {
  const a = { ...synth('nutrition'), title: 'Protein and Recovery' };
  const b = { ...synth('sleep'), title: 'What Happens While We Sleep' };
  const shotOf = (lines: string[]) => lines.find((l) => l.startsWith('SHOT:'));
  assert.notEqual(shotOf(plannerPromptLines(a, 0)), shotOf(plannerPromptLines(b, 0)));
  assert.notEqual(shotOf(plannerPromptLines(a, 0)), shotOf(plannerPromptLines(a, 1)));
  assert.equal(SHOT_COUNT, SHOTS.length);
  assert.ok(SHOTS.some((s) => !s.people), 'at least one shot has no people in it at all');
});

test('a team direction replaces the scene but keeps the title space and the look', () => {
  const lines = plannerPromptLines(img(), 0, 'a couple at the table').join(' ');
  assert.match(lines, /Direction from the team.*a couple at the table/);
  assert.match(lines, /TITLE SPACE/);
});

test('the weekly article borrows the scenes of the pillar its angle came from', () => {
  const src = PILLARS.find((p) => p.angles.length) || P0;
  const p = plannerImageFor(pack(BLOG_SLOT.name, firstAngle(src)));
  assert.equal(p?.pillarId, 'article');
  if (src.angles.length) {
    assert.equal(p?.scenes, sceneSetFor(src).scenes);
    assert.equal(p?.title, titleFor(firstAngle(src), src.name));
  }
  // An angle that belongs to no pillar is pictured with the general set.
  const loose = plannerImageFor(pack(BLOG_SLOT.name, 'A loose angle of our own'));
  assert.equal(loose?.scenes, PILLAR_SCENES.general.scenes);
  assert.equal(loose?.title, 'A Loose Angle of Our Own');
});

test('drafts without planner provenance are left alone', () => {
  assert.equal(plannerImageFor({ instagram: 'x' }), null);
  assert.equal(plannerImageFor(null), null);
  assert.equal(plannerImageFor(pack('My own template that is not a pillar', 'x')), null);
});

test('scenes rotate, the prefix is stripped', () => {
  const p = plannerImageFor(pack(P0.name, '[Autopilot] ' + firstAngle(P0)))!;
  assert.equal(p.subject, firstAngle(P0));
  assert.notEqual(plannerPromptLines(p, 0)[1], plannerPromptLines(p, 1)[1]);
  assert.equal(cleanTopic('[Autopilot] Sleep'), 'Sleep');
});

test('a brief written from the post replaces the fixed scene and the on-topic cue', () => {
  const base = { ...synth('nutrition'), title: 'Hydration and Health' };
  const p = { ...base, dynamic: { scene: 'The host pours a glass of water from a carafe with cucumber slices for the customer.', props: ['glass carafe of water', 'cucumber slices'], mustShow: 'water being poured' } };
  const lines = plannerPromptLines(p, 0).join(' ');
  assert.match(lines, /pours a glass of water|glass carafe of water/);
  assert.match(lines, /cucumber slices/);
  assert.match(lines, /must clearly show water being poured/);
  assert.match(lines, /post titled "Hydration and Health"/);
  assert.doesNotMatch(lines, /balanced plate of fresh food/);
  assert.match(onTopicCheck(p), /water being poured/);
});

// --- THE SAME TITLE AGAIN ------------------------------------------------------------
//
// "It's been giving me the same titles." The second post on an angle — or a
// second long angle of a pillar, which shares the fallback — wore the same
// cover as the first. The occurrence is counted at research and the title
// varies from the second one on; the first keeps the written one.

test('the first occurrence keeps the written title; later ones wear a different framing each time', () => {
  assert.equal(variedTitle('Protein and Recovery', 0), 'Protein and Recovery');
  const seen = new Set<string>();
  for (let i = 1; i <= TITLE_FRAMINGS.length; i++) {
    const t = variedTitle('Protein and Recovery', i);
    assert.notEqual(t, 'Protein and Recovery', 'occurrence ' + i);
    assert.match(t, /Protein and Recovery/, 'the words are still the angle’s');
    assert.ok(t.length <= MAX_COVER_TITLE, t);
    seen.add(t);
  }
  assert.equal(seen.size, TITLE_FRAMINGS.length, 'every framing is different');
  assert.equal(variedTitle('', 2), '');
  // A framing that would run past the cover is skipped for a shorter one.
  const long = 'Compare Evaluations, Not Just Offers and Everything Else Too';
  assert.ok(variedTitle(long, 1).length <= MAX_COVER_TITLE);
});

test('the occurrence is counted by cover title, so the pillar fallback repeats are caught too', () => {
  const longA = 'Why the right plan depends on the person and not only on the goal';
  const longB = 'How small, steady habits add up over a year more than a big push does';
  const history = [
    { query: 'The role of protein in recovery' },
    { query: 'Nutrition and inflammation' },
    { query: '[Autopilot] The role of protein in recovery' },
    null,
    { query: longA },
  ];
  assert.equal(titleSeq('The role of protein in recovery', 'Nutrition', history), 2);
  assert.equal(titleSeq('Hydration and health', 'Nutrition', history), 0);
  // Two different long angles share the pillar's own name as their cover.
  assert.equal(titleSeq(longB, 'Nutrition', history), 1);
  assert.equal(titleSeq('x', 'Nutrition', []), 0);
});

test('a planner draft stamped as a repeat is pictured with the varied title, wherever the stamp sits', () => {
  const angle = firstAngle(P0);
  const first = img();
  const again = plannerImageFor({ _autopilot: { template_name: P0.name, title_seq: 1, angle: { query: angle } } })!;
  assert.equal(again.title, variedTitle(first.title, 1));
  const onAngle = plannerImageFor({ _autopilot: { template_name: P0.name, angle: { query: angle, titleSeq: 2 } } })!;
  assert.equal(onAngle.title, variedTitle(first.title, 2));
  assert.notEqual(again.title, onAngle.title);
  // Same for the article, which borrows the pillar's title.
  const art = plannerImageFor({ _autopilot: { template_name: BLOG_SLOT.name, title_seq: 1, angle: { query: angle } } })!;
  assert.equal(art.title, variedTitle(titleFor(angle, P0.name), 1));
});

test('the engine stamps the occurrence at research, where the template’s history is', () => {
  const src = readFileSync(new URL('../lib/autopilot.ts', import.meta.url), 'utf8');
  assert.match(src, /titleSeq: titleSeq\(seedTopic, pillarName, angleHistory\)/);
  assert.match(src, /title_seq: angle\.titleSeq/);
});

// --- NOTES AFTER THE PICTURE EXISTS ---------------------------------------------------

test('the team’s notes reach the prompt and the on-topic check judges against them', () => {
  const base = { ...synth('nutrition'), subject: 'The role of protein in recovery' };
  const p = { ...base, direction: 'two women at a table, no lab coat, warmer light, show fresh vegetables' };
  const lines = plannerPromptLines(p, 0, p.direction).join(' ');
  assert.match(lines, /Direction from the team \(follow this closely[^)]*\): two women at a table, no lab coat/);
  const check = onTopicCheck(p);
  assert.match(check, /the team asked for this picture in their own words — "two women at a table/);
  assert.match(check, /still plausibly illustrates "The role of protein in recovery"/);
  assert.doesNotMatch(check, /must clearly show the food or drink/, 'the pillar’s fixed cue no longer fails a picture that followed the notes');
  assert.match(check, /anatomical model/, 'the banned-prop and title-band defects still stand');
  // Without notes, the check is as before.
  assert.match(onTopicCheck(base), /must clearly show the food or drink/);
});

test('a cover with its title turned off is still briefed from its subject', () => {
  const p = { ...synth('sleep'), subject: 'Sleep and recovery', title: '' };
  const lines = plannerPromptLines(p, 0).join(' ');
  assert.match(lines, /post titled "Sleep and recovery"/);
  assert.match(lines, /TITLE SPACE/);
});

test('teaching props are a blocking defect and are banned from the craft notes', () => {
  const p = synth('sleep');
  const lines = plannerPromptLines(p, 0).join(' ');
  assert.match(lines, /no anatomical models/i);
  assert.match(lines, /skeletons|mannequins/i);
  assert.match(onTopicCheck(p), /anatomical model|teaching prop/i);
});

test('slot 0 is always a conversation, whatever the pillar', () => {
  for (const id of ['nutrition', 'movement', 'recovery', 'sleep', 'tips', 'unknown-pillar']) {
    assert.equal(familyAt({ pillarId: id, science: true }, 0), 'consult', id);
  }
});

test('the science slot is offered only when the post earned it', () => {
  for (const id of ['recovery', 'sleep', 'nutrition', 'movement', 'tips']) {
    assert.equal(familyAt({ pillarId: id, science: true }, 2), 'science', id);
    assert.notEqual(familyAt({ pillarId: id, science: false }, 2), 'science', id);
  }
  const p = { pillarId: 'recovery', science: true };
  const offered = [0, 1, 2, 3].map((i) => familyAt(p, i));
  assert.ok(offered.includes('science'), offered.join(','));
  // Same pillar, a post that never mentions science: the science slot becomes something else.
  const q = { pillarId: 'recovery', science: false };
  const fallback = [0, 1, 2, 3].map((i) => familyAt(q, i));
  assert.ok(!fallback.includes('science'), fallback.join(','));
  // Only the science slot changes; the rest of the run is identical.
  assert.deepEqual(fallback.filter((_, i) => offered[i] !== 'science'), offered.filter((f) => f !== 'science'));
});

test('the living themes lead with the outcome, the everyday themes with the objects', () => {
  assert.equal(familyAt({ pillarId: 'movement', science: false }, 1), 'active');
  assert.equal(familyAt({ pillarId: 'active-living', science: false }, 1), 'active');
  assert.equal(familyAt({ pillarId: 'customer-stories', science: false }, 1), 'active');
  assert.equal(familyAt({ pillarId: 'nutrition', science: false }, 1), 'still');
  assert.equal(familyAt({ pillarId: 'sleep', science: false }, 1), 'still');
  assert.equal(familyAt({ pillarId: 'tips', science: false }, 1), 'still');
  assert.equal(familyAt({ pillarId: 'p9', science: false }, 1), 'still', 'an unknown pillar gets the default order');
  // A stamped kind wins over the id.
  assert.equal(familyAt({ pillarId: 'p9', kind: 'lifestyle', science: false }, 1), 'active');
});

test('a walking post never unlocks a microscope, a post about the biology does', () => {
  assert.equal(scienceAllowed('A ten-minute walk after dinner helps you wind down for the evening.'), false);
  assert.equal(scienceAllowed('Sleep is when tissue repair happens and inflammation settles.'), true);
  assert.equal(scienceAllowed('Microbes in the starter break down molecules in the flour.'), true);
});

test('every family has at least two shots, so a repeat is always a new picture', () => {
  for (const family of ['consult', 'science', 'active', 'still'] as const) {
    assert.ok(SHOTS.filter((s) => s.family === family).length >= 2, family);
  }
  assert.equal(SHOT_COUNT, SHOTS.length);
});

test('within a family a later take is a different shot', () => {
  for (const seed of [0, 5, 77, 1234]) {
    assert.notEqual(shotFor(seed, 0, 'consult').id, shotFor(seed, 1, 'consult').id, `seed ${seed}`);
    assert.notEqual(shotFor(seed, 0, 'science').id, shotFor(seed, 1, 'science').id, `seed ${seed}`);
  }
});

test('the science frame is checked as a real laboratory photograph, not for the post\'s objects', () => {
  const p = synth('tips', { science: true, shotFamily: 'science' });
  const check = onTopicCheck(p);
  assert.match(check, /real laboratory photograph|microscope field/i);
  assert.match(check, /rendered or illustrated cells|glowing/i);
  assert.doesNotMatch(check, /must clearly show/);
});

test('the active frame must be life outdoors, never a clinical setting', () => {
  const check = onTopicCheck(synth('movement', { shotFamily: 'active' }));
  assert.match(check, /outdoors in daylight/i);
  assert.match(check, /any clinical room, equipment, uniform or procedure/i);
});

test('science and active frames do not inherit the post\'s objects', () => {
  const p = synth('tips', { science: true, dynamic: { quote: 'Repair happens overnight.', scene: 'The host sets a glass of water down while explaining.', props: ['a glass of water', 'a folded towel'], mustShow: 'a glass of water' } });
  const science = [0, 1, 2, 3].find((i) => familyAt(p, i) === 'science')!;
  const lines = plannerPromptLines(p, science).join(' ');
  assert.match(lines, /do not add the objects the post names/i);
  assert.doesNotMatch(lines, /a folded towel/);
  // The consult slot still does carry them.
  const consult = plannerPromptLines(p, 0).join(' ');
  assert.match(consult, /a folded towel|glass of water/);
});

test('renders are banned in the craft notes', () => {
  const lines = plannerPromptLines(img(), 0).join(' ');
  assert.match(lines, /No 3D renders/i);
  assert.match(lines, /no lens flare/i);
});

test('two of every four takes are the conversation', () => {
  for (const id of ['nutrition', 'movement', 'recovery', 'sleep', 'p1']) {
    const four = [0, 1, 2, 3].map((i) => familyAt({ pillarId: id, science: true }, i));
    assert.equal(four.filter((f) => f === 'consult').length, 2, `${id}: ${four.join(',')}`);
    assert.equal(four.filter((f) => f === 'science').length, 1, `${id}: ${four.join(',')}`);
  }
});

test('the plan wraps, so a much-rerolled draft still reaches every slot', () => {
  // The bug this guards: options advance the draft's running variant, and a
  // draft rerolled a dozen times walked off the end of its own plan — no
  // outcome shot, no science slot, just conversations and still lifes.
  const p = { pillarId: 'movement', science: true };
  for (let step = 0; step < 24; step += 1) {
    assert.equal(familyAt(p, step), familyAt(p, step % PLAN_LENGTH), `step ${step}`);
  }
  assert.equal(familyAt(p, 4), 'consult');
  assert.equal(familyAt(p, 5), 'active');
  assert.equal(familyAt(p, 6), 'science');
  assert.equal(familyAt(p, 13), familyAt(p, 1));
});

test('slots 1 to 3 always cover the pillar shot, the science slot and the room', () => {
  for (const id of ['movement', 'sleep', 'nutrition', 'recovery', 'tips']) {
    const three = [1, 2, 3].map((i) => familyAt({ pillarId: id, science: true }, i));
    assert.equal(three[1], 'science', id);
    assert.equal(three[2], 'consult', id);
    assert.notEqual(three[0], 'consult', id);
  }
});

test('the science slot needs the post to be about the science, not to mention it once', () => {
  // The bug this guards: a post about a daily walk that happened to say
  // "muscle" came back as a microscope field.
  assert.equal(scienceAllowed('A ten-minute walk after dinner is enough to start with.'), false);
  assert.equal(scienceAllowed('Gentle movement supports muscle repair as you age.'), false);
  assert.equal(scienceAllowed('Deep sleep is when tissue repair happens and inflammation settles.'), true);
  assert.ok(scienceScore('cells, tissue, mitochondria and collagen') >= 4);
});

test('the microscopy frame is briefed as a photograph, never a render', () => {
  const lines = plannerPromptLines(synth('tips', { science: true }), 2, null, 'science').join(' ');
  if (/photomicrograph/i.test(lines)) {
    assert.match(lines, /phase-contrast/i);
    assert.match(lines, /NOT A PICTURE OF CELLS/i);
    assert.match(lines, /no embossed|no 3D rendering/i);
  } else {
    assert.match(lines, /laminar-flow|culture plate/i);
  }
});

test('nothing is worn by or connected to anyone in the frame', () => {
  const lines = plannerPromptLines(img(), 0).join(' ');
  assert.match(lines, /NOTHING ATTACHED TO ANYONE/);
  assert.match(lines, /blood-pressure cuff on an arm/i);
  assert.match(lines, /never a procedure/i);
  assert.match(lines, /rest ON THE TABLE, unused/i);
});

test('no planner brief asks for a picture the image check would fail', async () => {
  const { BANNED_PROP_RE } = await import('./image-verdict.ts');
  for (const [id, set] of Object.entries(PILLAR_SCENES)) {
    assert.doesNotMatch(set.mustShow, BANNED_PROP_RE, id + ' mustShow');
    for (const scene of set.scenes) assert.doesNotMatch(scene, BANNED_PROP_RE, id + ': ' + scene);
  }
  for (const [id, fb] of Object.entries(FALLBACK_OBJECTS)) {
    for (const t of [...fb.table, fb.foreground, fb.action]) assert.doesNotMatch(t, BANNED_PROP_RE, id + ': ' + t);
  }
  // Every kind has its own scenes, fallback objects and family order.
  for (const k of ['general', 'expertise', 'craft', 'product', 'people', 'lifestyle', 'food', 'rest', 'place']) {
    assert.ok(PILLAR_SCENES[k], k);
    assert.ok(FALLBACK_OBJECTS[k], k);
  }
});

test('the stamped pillar wins over the template name', () => {
  const p = PILLARS[PILLARS.length - 1];
  const got = plannerImageFor({ _autopilot: { template_name: p.name + ' (Tuesday AM)', slot: 'tue-1', pillar_id: p.id, angle: { query: firstAngle(p) } } });
  assert.equal(got?.pillarId, p.id, 'a renamed slot keeps its picture');
  const legacy = plannerImageFor({ _autopilot: { template_name: P0.name, angle: { query: firstAngle(P0) } } });
  assert.equal(legacy?.pillarId, P0.id);
});

test('a lifestyle theme flags a laboratory scene as off-topic and prefers the everyday picture', () => {
  for (const id of ['sleep', 'sleep-stress', 'nutrition', 'customer-stories', 'local']) {
    const p = synth(id);
    assert.ok(isLifestylePillar(p.pillarId), p.pillarId);
    for (const family of ['consult', 'still', 'active'] as const) {
      const check = onTopicCheck({ ...p, shotFamily: family });
      assert.match(check, /DEFECT for this lifestyle theme: a laboratory scene — a microscope, cells or a microscope field, pipettes/, family);
      assert.match(check, /bright, warm-neutral conversation or everyday moment/, family);
      assert.match(check, /"onTopic": false/, family);
    }
  }
  // A know-how theme keeps its science frame, and no lab rule.
  const t = synth('tips');
  assert.equal(isLifestylePillar(t.pillarId), false);
  assert.doesNotMatch(onTopicCheck({ ...t, shotFamily: 'consult' }), /laboratory scene/);
});

test('a lifestyle post never earns a science frame, however much biology it mentions', () => {
  const text = 'Sleep is when tissue repair happens and inflammation settles.';
  assert.equal(scienceAllowed(text), true);
  for (const id of ['sleep-stress', 'sleep', 'stress', 'nutrition', 'movement', 'recovery', 'active-living', 'travel']) {
    assert.equal(scienceOffered(id, text), false, id);
  }
  assert.equal(scienceOffered('tips', text), true);
  assert.equal(scienceOffered('p1', text), true);
});

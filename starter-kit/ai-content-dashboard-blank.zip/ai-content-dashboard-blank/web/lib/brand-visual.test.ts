import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_VISUAL, PAPER, normalizeVisual, textColorOn, contrast, roleOf, visualPromptBlock, brandFitRubric, paletteCharacter,
} from './brand-visual.ts';

test('the default visual is brand-free: a neutral palette and nothing else', () => {
  assert.ok(DEFAULT_VISUAL.palette.length >= 3);
  for (const role of ['dark', 'accent', 'light'] as const) {
    assert.ok(DEFAULT_VISUAL.palette.some((c) => c.role === role), 'a ' + role + ' colour so cards can pair text and ground');
  }
  assert.equal(paletteCharacter(DEFAULT_VISUAL.palette), 'neutral, low-saturation');
  assert.equal(DEFAULT_VISUAL.materials, '');
  assert.equal(DEFAULT_VISUAL.photography, '');
  assert.deepEqual(DEFAULT_VISUAL.never, []);
  assert.deepEqual(DEFAULT_VISUAL.fonts, { headline: '', body: '' });
});

test('an empty or missing visual falls back to the neutral default, not to nothing', () => {
  for (const raw of [undefined, null, {}, 'junk', 42, { palette: 'not-an-array' }]) {
    const v = normalizeVisual(raw);
    assert.deepEqual(v.palette, DEFAULT_VISUAL.palette);
    assert.equal(v.materials, '');
    assert.equal(v.photography, '');
    assert.deepEqual(v.fonts, { headline: '', body: '' });
  }
});

test('what a profile saved is kept as written', () => {
  const v = normalizeVisual({ materials: ' oak and linen ', photography: 'eye level', never: ['neon', ''], fonts: { headline: 'Lora', body: 'Inter' } });
  assert.equal(v.materials, 'oak and linen');
  assert.equal(v.photography, 'eye level');
  assert.deepEqual(v.never, ['neon']);
  assert.deepEqual(v.fonts, { headline: 'Lora', body: 'Inter' });
});

test('colours that are not real hex codes are dropped, and one survivor is not a palette', () => {
  const v = normalizeVisual({ palette: [{ name: 'Teal', hex: '#0A6B6B' }, { name: 'bad', hex: 'red' }, { hex: '#12345' }] });
  // A single valid colour cannot pair text with ground, so the default palette stands in.
  assert.deepEqual(v.palette, DEFAULT_VISUAL.palette);
  const ok = normalizeVisual({ palette: [{ name: 'Ink', hex: '#111111' }, { hex: '#eeeeee' }] });
  assert.deepEqual(ok.palette.map((c) => c.hex), ['#111111', '#EEEEEE']);
  assert.equal(ok.palette[1].name, '#EEEEEE', 'a nameless colour is named by its hex');
});

test('roles are inferred from lightness when the profile does not say', () => {
  assert.equal(roleOf('#222222'), 'dark');
  assert.equal(roleOf('#D9D9D9'), 'light');
  assert.equal(roleOf('#8A8A8A'), 'accent');
  for (const c of DEFAULT_VISUAL.palette) assert.equal(roleOf(c.hex), c.role, c.name + ' is labelled as it measures');
  const v = normalizeVisual({ palette: [{ hex: '#222222' }, { hex: '#D9D9D9', role: 'accent' }] });
  assert.equal(v.palette[1].role, 'accent', 'an explicit role is kept');
});

test('free text is capped so a profile can never blow up a prompt', () => {
  const v = normalizeVisual({ materials: 'x'.repeat(5000), never: Array.from({ length: 20 }, (_, i) => 'rule ' + i) });
  assert.ok(v.materials.length <= 400);
  assert.equal(v.never.length, 8);
});

test('text colour on a ground is always the highest-contrast palette colour', () => {
  assert.equal(textColorOn('#8A8A8A'), '#222222');
  assert.equal(textColorOn('#222222'), '#D9D9D9');
  assert.equal(textColorOn('#D9D9D9'), '#222222');
  assert.equal(textColorOn(PAPER), '#222222');
  const custom = [{ name: 'Ink', hex: '#101010', role: 'dark' as const }, { name: 'Teal', hex: '#0A6B6B', role: 'accent' as const }, { name: 'Sand', hex: '#F1E7D0', role: 'light' as const }];
  assert.equal(textColorOn('#0A6B6B', custom), '#F1E7D0');
  for (const ground of DEFAULT_VISUAL.palette.map((c) => c.hex).concat(PAPER)) {
    // Cards set display-size type; 3:1 is the WCAG AA floor for large text.
    assert.ok(contrast(ground, textColorOn(ground)) >= 3, ground + ' must reach large-text AA contrast');
  }
});

test('the palette character is measured, never assumed', () => {
  assert.equal(paletteCharacter([{ name: 'a', hex: '#B5562A', role: 'accent' }, { name: 'b', hex: '#E0B080', role: 'light' }]).split(',')[0], 'warm');
  assert.equal(paletteCharacter([{ name: 'a', hex: '#1E4D9F', role: 'accent' }, { name: 'b', hex: '#80B0E0', role: 'light' }]).split(',')[0], 'cool');
  assert.equal(paletteCharacter([]), '');
});

test('the prompt block names every colour with its hex and leaves out what is blank', () => {
  const block = visualPromptBlock(DEFAULT_VISUAL);
  for (const c of DEFAULT_VISUAL.palette) assert.ok(block.includes(c.hex), 'missing ' + c.hex);
  assert.match(block, /accent grey \(#8A8A8A\)/);
  assert.match(block, /neutral, low-saturation/);
  assert.doesNotMatch(block, /Materials|Photography|Never/, 'blank fields are not sent as empty sentences');
  const full = visualPromptBlock(normalizeVisual({ materials: 'oak and linen', photography: 'eye level', never: ['stock-photo smiles'] }));
  assert.match(full, /Materials and light: oak and linen\./);
  assert.match(full, /Photography: eye level\./);
  assert.match(full, /Never: stock-photo smiles\./);
});

test('the brand-fit rubric is advisory language and names the palette', () => {
  const r = brandFitRubric(DEFAULT_VISUAL);
  assert.match(r, /advisory/);
  assert.match(r, /Charcoal, Slate, Accent Grey, Light Grey/);
  assert.match(r, /0-100/);
  assert.doesNotMatch(r, /Materials\/light|Photography:/);
  assert.match(brandFitRubric(normalizeVisual({ materials: 'oak' })), /Materials\/light: oak\./);
});

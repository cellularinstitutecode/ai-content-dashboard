// Browser end-to-end test for the dashboard.
//
// Prereqs (both running): node e2e/mock-supabase.cjs  (:54321)
//                         next start -p 3100          (built with e2e .env.local)
// Run: node e2e/browser-e2e.cjs
//
// What it proves, in a real Chromium:
//   1. A signed-in dashboard renders every panel from live API data.
//   2. Boot shows only the hairline top bar (with a percentage) — never an
//      overlay; drafting raises a panel-scoped percentage loader that covers
//      exactly the Content Generator and clears when the work ends.
//   3. The content-image rule is visible: ✓ verified badges on clean images,
//      the red ✗ text badge on a text-flagged image (Image Studio + Autopilot).
//   4. Interconnection: an announce('drafts') from ANY panel makes the others
//      refetch /api/drafts with no reload.
//   5. Calendar / Templates / Brand pages render.
//   6. Zero unexpected console errors or page crashes anywhere.
const fs = require('fs');
const { chromium } = require('playwright-core');

const BASE = 'http://127.0.0.1:3100';
const results = [];
let failed = 0;
function check(name, ok, detail) {
  results.push({ name, ok, detail: detail || '' });
  console.log((ok ? '  ✓ ' : '  ✗ ') + name + (ok || !detail ? '' : '  — ' + detail));
  if (!ok) failed++;
}

(async () => {

  const cookieValue = decodeURIComponent(
    fs.readFileSync('/tmp/cookie.txt', 'utf8').replace(/^sb-127-auth-token=/, '')
  );

  const browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium',
    args: ['--no-sandbox'],
  });
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 2000 } });
  await ctx.addCookies([{ name: 'sb-127-auth-token', value: encodeURIComponent(cookieValue), url: BASE }]);

  const page = await ctx.newPage();
  const consoleErrors = [];
  const pageErrors = [];
  const apiRequests = [];
  const failedRequests = [];
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
  page.on('pageerror', (e) => pageErrors.push(String(e)));
  page.on('request', (r) => { const u = new URL(r.url()); if (u.pathname.startsWith('/api/')) apiRequests.push(u.pathname + u.search); });
  page.on('requestfailed', (r) => failedRequests.push(r.url() + ' :: ' + (r.failure() ? r.failure().errorText : '?')));

  // Record every percentage the loading UI ever paints, from inside the page —
  // a MutationObserver never misses a frame the way external polling can.
  await page.addInitScript(() => {
    window.__pctLog = [];
    const scan = (root) => {
      const text = root && root.textContent ? root.textContent : '';
      const m = /(\d{1,3})%/.exec(text);
      if (m) window.__pctLog.push(parseInt(m[1], 10));
    };
    window.__overlayLog = [];
    const scanOverlay = () => {
      if (document.querySelector('[data-testid="global-loading-screen"]')) window.__overlayLog.push('full-screen');
      if (document.querySelector('[data-testid="panel-loading-screen"]')) window.__overlayLog.push('panel');
    };
    const mo = new MutationObserver((muts) => {
      scanOverlay();
      for (const mu of muts) {
        scan(mu.target);
        mu.addedNodes && mu.addedNodes.forEach((n) => scan(n));
      }
    });
    document.addEventListener('DOMContentLoaded', () => {
      mo.observe(document.body, { childList: true, subtree: true, characterData: true });
    });
  });

  // Slow /api responses slightly so the loading screen has real work to show.
  await page.route('**/api/**', async (route) => {
    await new Promise((r) => setTimeout(r, 700));
    await route.continue();
  });

  // ---- 2: loading screen with a percentage (in-page MutationObserver) ------
  await page.goto(BASE + '/draft', { waitUntil: 'networkidle', timeout: 60000 });
  const percentSamples = await page.evaluate(() => window.__pctLog || []);

  check('the Draft workspace renders (signed in, no redirect to /sign-in)', !page.url().includes('sign-in'), page.url());
  check('hairline top bar showed a live percentage while panels loaded', percentSamples.length > 0, 'samples: ' + percentSamples.join(','));
  const bootOverlays = await page.evaluate(() => window.__overlayLog || []);
  check('sign-in/boot never raised a full-screen loading overlay', !bootOverlays.includes('full-screen'), bootOverlays.join(','));
  check('sign-in/boot never raised a panel loading overlay either', !bootOverlays.includes('panel'), bootOverlays.join(','));
  check('percentage stayed sane (0-100) and progressed', percentSamples.every((p) => p >= 0 && p <= 100) && (percentSamples.length < 2 || percentSamples[percentSamples.length - 1] >= percentSamples[0]), percentSamples.join(','));

  const body = await page.evaluate(() => document.body.innerText);
  // ---- 1: every creation panel present on /draft, fed by the API -----------
  for (const [name, needle] of [
    ['AI Image Studio panel', 'AI Image Studio'],
    ['Content Generator panel', 'Content Generator'],
    ['Publishing panel', 'Publishing'],
    ['Recent Drafts library', 'Recent Drafts'],
    ['drafts from the API render in the library', 'Mobility training for joint recovery'],
  ]) check(name, body.includes(needle));
  check('the Draft page carries no Autopilot queue or SEO panel (those live on the overview)', !/Run engine now/.test(body) && !/Semrush Intelligence/.test(body));

  // Panels must follow the workflow order — now READING order, because they sit
  // two across: down the rows, and left to right within a row. The old check
  // demanded a strictly increasing top edge, which only held while every panel
  // had a row to itself; it earned its keep the moment the layout changed, by
  // catching a dense-packed grid that had pulled Autopilot up ahead of
  // Publishing. (Autopilot now lives on the overview, so it is not in this list.)
  const order = await page.evaluate(() => {
    const ids = ['section-create', 'section-images', 'section-repurpose', 'section-publish', 'section-library'];
    const boxes = ids.map((id) => {
      const el = document.getElementById(id);
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return { id, top: Math.round((r.top + window.scrollY) / 8) * 8, left: Math.round(r.left) };
    });
    if (boxes.some((b) => !b)) return { ok: false, seen: 'a panel is missing' };
    const reading = [...boxes].sort((a, b) => (a.top - b.top) || (a.left - b.left)).map((b) => b.id);
    return { ok: reading.join(',') === ids.join(','), seen: reading.join(','), rows: boxes.map((b) => b.id + '@' + b.top + ',' + b.left).join(' ') };
  });
  check('panels read in workflow order: Create → Images → Repurpose → Schedule → Library', order.ok, order.seen + '  [' + (order.rows || '') + ']');

  // ---- 1c: Image Studio → Brand cards. Open the first gallery image, draw a
  // carousel from the draft's caption through the real route, and see the strip.
  // Image Studio is a drawer, shut by default; the same event the "How this
  // works" cards use opens it so the gallery is in the document.
  await page.evaluate(() => window.dispatchEvent(new CustomEvent('section:open', { detail: 'section-images' })));
  const galleryBtn = page.locator('#section-images button[title]').first();
  await galleryBtn.waitFor({ state: 'visible', timeout: 15000 });
  await galleryBtn.click();
  await page.waitForSelector('#brand-cards', { timeout: 10000 });
  const cardUi = await page.evaluate(() => {
    const el = document.getElementById('brand-cards');
    const buttons = [...el.querySelectorAll('button')].map((b) => b.innerText.trim());
    const grounds = [...el.querySelectorAll('select[aria-label="Card colour"] option')].map((o) => o.value);
    return { text: el.innerText, buttons, grounds };
  });
  check('the lightbox offers brand cards in every palette colour plus a photo cover', cardUi.buttons.includes('Make carousel from the caption') && cardUi.buttons.includes('Cover card as post image') && ['paper', 'light', 'accent', 'accent2', 'dark2', 'dark', 'photo'].every((g) => cardUi.grounds.includes(g)), JSON.stringify(cardUi.grounds));
  const cardRes = page.waitForResponse((r) => r.url().includes('/api/drafts/card'), { timeout: 60000 });
  await page.locator('#brand-cards').getByRole('button', { name: 'Make carousel from the caption' }).click();
  const cardR = await cardRes;
  check('drawing a carousel calls the card route and succeeds', cardR.ok(), String(cardR.status()));
  await page.waitForFunction(() => document.querySelectorAll('#brand-cards a img').length > 0, null, { timeout: 15000 });
  const strip = await page.evaluate(() => ({ n: document.querySelectorAll('#brand-cards a img').length, note: (document.querySelector('#brand-cards [role="status"]') || {}).innerText || '' }));
  check('the cards appear as a strip under the image, and the stand-in type is disclosed', strip.n >= 1 && /stand-in type/.test(strip.note), JSON.stringify(strip));
  await page.keyboard.press('Escape').catch(() => undefined);
  await page.locator('#brand-cards').locator('..').locator('..').getByRole('button', { name: 'Close' }).click().catch(() => undefined);
  await page.waitForLoadState('networkidle').catch(() => undefined);

  // The overview (/) keeps the stats, the queue, Autopilot and SEO — and no composer.
  const overviewPage = await ctx.newPage();
  await overviewPage.goto(BASE + '/', { waitUntil: 'networkidle', timeout: 60000 });
  const overview = await overviewPage.evaluate(() => {
    const t = document.body.innerText;
    const buttons = [...document.querySelectorAll('button')].map((b) => b.innerText.trim());
    return {
      stats: /Drafts/.test(t) && /Scheduled posts/.test(t),
      autopilot: /Autopilot/.test(t) && /strength training for knees/.test(t) && /84\/100/.test(t),
      autopilotButtons: buttons.includes('Approve & schedule') && buttons.includes('Approve as draft'),
      composer: Boolean(document.getElementById('composer-text')),
      queueApprove: buttons.includes('Approve'),
      draftLink: [...document.querySelectorAll('a')].some((a) => a.getAttribute('href') === '/draft'),
      text: t,
    };
  });
  check('stat cards render from /api/stats on the overview', overview.stats);
  check('the overview shows the Autopilot queue with its researched angle and score', overview.autopilot);
  check('the Autopilot card offers Approve & schedule alongside Approve as draft', overview.autopilotButtons);
  check('the overview keeps the approval queue but has no composer', overview.queueApprove && !overview.composer);
  check('the sidebar links to Draft', overview.draftLink);
  await overviewPage.close();

  // The reviewer's yes lives on the dashboard now. A post waiting for review
  // must show Approve and Publish now; the Autopilot card must offer
  // "Approve & schedule"; and the old "open Metricool to approve" copy is gone.
  const approveUi = await page.evaluate(() => {
    const t = document.body.innerText;
    const buttons = [...document.querySelectorAll('button')].map((b) => b.innerText.trim());
    return {
      approve: buttons.includes('Approve'),
      publishNow: buttons.includes('Publish now'),
      oldCopy: /approval yourself inside Metricool|approve it there to publish/i.test(t),
    };
  });
  check('a post waiting for review offers Approve', approveUi.approve);
  check('and Publish now', approveUi.publishNow);
  check('nothing on screen still sends the reviewer into Metricool to approve', !approveUi.oldCopy);

  // ---- 3: content-image verification badges -------------------------------
  check('✓ verified badge on machine-verified text-free images', body.includes('✓ verified') || body.includes('verified'));
  // The flagged image sits on an Autopilot run, which lives on the overview.
  const redBadge = overview.text.includes('✗ text');
  check('red ✗ text badge on the text-flagged image (hard rule visible in the Autopilot queue)', redBadge);
  const galleryImgs = await page.evaluate(() => Array.from(document.querySelectorAll('img')).filter((i) => i.src.includes('content-images')).length);
  check('Image Studio gallery renders stored images', galleryImgs >= 2, galleryImgs + ' imgs');

  // ---- 3b: text-flagged images never reach the scheduler ------------------
  // Prefilling the Publishing composer from a draft must attach a clean,
  // machine-verified hero image — and must NEVER attach one the checker
  // flagged for text (the reviewer rerolls it in the Image Studio first).
  async function prefillFromLibrary(topicNeedle) {
    return page.evaluate((needle) => {
      const lib = document.getElementById('section-library');
      if (!lib) return 'no library';
      // The tightest wrapper holding both the topic text and an Edit button
      // is the card itself (outer containers match too, but are longer).
      const card = Array.from(lib.querySelectorAll('li, div'))
        .filter((el) => el.querySelector && el.querySelector('button[aria-label="Edit draft"]') && el.textContent.includes(needle))
        .sort((a, b) => a.textContent.length - b.textContent.length)[0];
      if (!card) return 'no card for ' + needle;
      card.querySelector('button[aria-label="Edit draft"]').click();
      return 'clicked';
    }, topicNeedle);
  }
  const composerMedia = () =>
    page.evaluate(() => {
      const pub = document.getElementById('section-publish');
      return pub ? pub.innerText.includes('AI hero image') : false;
    });
  const r1 = await prefillFromLibrary('Mobility training for joint recovery');
  await page.waitForTimeout(400);
  const cleanAttached = await composerMedia();
  check('prefilling from a clean draft attaches its verified hero image', r1 === 'clicked' && cleanAttached, r1);
  const r2 = await prefillFromLibrary('strength training for knees');
  await page.waitForTimeout(400);
  const flaggedAttached = await composerMedia();
  check('a TEXT-FLAGGED image is never prefilled into the scheduler (hard rule at the ship-point)', r2 === 'clicked' && !flaggedAttached, r2 + (flaggedAttached ? ' — flagged image leaked into composer' : ''));

  // ---- 4: interconnection — announce() → cross-panel refetch --------------
  const before = apiRequests.filter((u) => u.startsWith('/api/drafts?')).length;
  await page.evaluate(() => {
    window.dispatchEvent(new CustomEvent('cs:refresh', { detail: { scopes: ['drafts', 'images'] } }));
  });
  await page.waitForTimeout(2500);
  const after = apiRequests.filter((u) => u.startsWith('/api/drafts?')).length;
  check('announce(drafts) makes panels refetch /api/drafts live (no reload)', after > before, before + ' → ' + after);

  // ---- 4b: generation covers ONLY its own panel, with a percentage --------
  await page.evaluate(() => {
    window.__genDone = false;
    fetch('/api/generate', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ topic: 'e2e loading probe', provider: 'anthropic', model: 'claude-sonnet-4-5', type: 'social' }),
    }).catch(() => {}).finally(() => { window.__genDone = true; });
  });
  await page.waitForTimeout(600);
  const genState = await page.evaluate(() => {
    const panel = document.querySelector('[data-testid="panel-loading-screen"]');
    return {
      panelVisible: Boolean(panel),
      scope: panel ? panel.getAttribute('data-scope') : null,
      insideCreate: Boolean(document.querySelector('#section-create [data-testid="panel-loading-screen"]')),
      fullScreen: Boolean(document.querySelector('[data-testid="global-loading-screen"]')),
      pct: (document.querySelector('[data-testid="panel-loading-percent"]') || {}).textContent || '',
    };
  });
  check('drafting raises the loading screen INSIDE the Content Generator panel', genState.panelVisible && genState.insideCreate, JSON.stringify(genState));
  check('the drafting loader is scoped to "create" and shows a percentage', genState.scope === 'create' && /[0-9]/.test(genState.pct), JSON.stringify(genState));
  check('no full-screen overlay during drafting', !genState.fullScreen);
  await page.waitForFunction(() => window.__genDone, { timeout: 60000 }).catch(() => {});
  await page.waitForTimeout(1200);
  const stillCovered = await page.evaluate(() => Boolean(document.querySelector('[data-testid="panel-loading-screen"]')));
  check('the panel loader clears when generation ends', !stillCovered);

  await page.screenshot({ path: '/tmp/e2e-dashboard.png', fullPage: false });
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.screenshot({ path: '/tmp/e2e-dashboard-top.png', fullPage: false });

  // ---- 5: the other pages render ------------------------------------------
  for (const [path, needle] of [
    ['/calendar', 'Publishing list'],
    ['/draft', 'Content Generator'],
    ['/templates', 'emplate'],
    ['/brand', 'Brand Brain'],
    ['/sources/calendar', 'Social Calendar'],
    ['/sources/videos', 'Video Library'],
    ['/sources/images', 'Image Library'],
  ]) {
    await page.goto(BASE + path, { waitUntil: 'networkidle', timeout: 60000 });
    const t = await page.evaluate(() => document.body.innerText);
    check(path + ' page renders', !page.url().includes('sign-in') && t.toLowerCase().includes(String(needle).toLowerCase()), page.url());
  }
  await page.screenshot({ path: '/tmp/e2e-brand.png', fullPage: false });
  // Brand Brain carries the visual identity the image pipeline reads: the default
  // palette colours as swatches, the materials and photography direction.
  await page.goto(BASE + '/brand', { waitUntil: 'networkidle', timeout: 60000 });
  await page.waitForFunction(() => /Visual identity/.test(document.body.innerText), null, { timeout: 20000 }).catch(() => undefined);
  const brandVisual = await page.evaluate(() => {
    const t = document.body.innerText;
    const swatches = document.querySelectorAll('[aria-label="palette preview"] > div');
    return { section: /Visual identity/.test(t), swatches: swatches.length, hexes: [...swatches].map((s) => s.innerText.trim()), photography: /Photography direction/.test(t), materials: /Materials & light/.test(t), fonts: /Brand typeface files/.test(t), upload: Boolean(document.querySelector('#brand-fonts input[type="file"]')), body: (document.querySelector('[data-testid="font-body"]') || {}).innerText || '' };
  });
  check('Brand Brain shows the visual identity: the default palette swatches with their hex codes, materials and photography direction', brandVisual.section && brandVisual.swatches === 4 && brandVisual.hexes.includes('#8A8A8A') && brandVisual.hexes.includes('#D9D9D9') && brandVisual.photography && brandVisual.materials, JSON.stringify(brandVisual));
  check('and a place to upload the licensed typefaces, reporting which face is still a stand-in', brandVisual.fonts && brandVisual.upload && /Body:/.test(brandVisual.body), JSON.stringify({ fonts: brandVisual.fonts, upload: brandVisual.upload, body: brandVisual.body }));

  // ---- 5a: Sources reads the team's documents and hands a video to the composer
  // Put the Google documents back to their seeded state first. The API suite
  // EDITS those sheets now — that is the point of it — and this suite asserts
  // on the seeded text. Reseeding the mock is not enough on its own: the route
  // caches each read for a minute, so ask for each one fresh to clear it.
  await fetch('http://127.0.0.1:54325/__reseed', { method: 'POST' }).catch(() => undefined);
  for (const kind of ['calendar', 'videos', 'images']) {
    await page.request.get(BASE + '/api/sources?kind=' + kind + '&fresh=1').catch(() => undefined);
  }
  await page.goto(BASE + '/sources/calendar', { waitUntil: 'networkidle', timeout: 60000 });
  await page.waitForFunction(() => /Mobility training: what the evidence says/.test(document.body.innerText), null, { timeout: 20000 }).catch(() => undefined);
  const calText = await page.evaluate(() => document.body.innerText);
  check('Social Calendar shows what is coming up on the sheet', /Mobility training: what the evidence says/.test(calText), calText.slice(0, 200));
  // The sheet panel is an iframe, and WHICH Google URL it points at decides
  // whether it paints at all: Google serves the /edit editor with
  // X-Frame-Options: DENY, so an /edit embed is the browser's broken-page box
  // however the document is shared. Nothing else on the page can show this —
  // the "coming up" list beside it comes from the API and renders either way.
  const sheetFrames = await page.evaluate(() => [...document.querySelectorAll('iframe')].map((f) => f.src).filter((u) => /docs\.google\.com/.test(u)));
  check('the sheet panel embeds the document, not the editor Google refuses to frame',
    sheetFrames.length === 1 && /\/preview$/.test(sheetFrames[0]) && !/\/edit/.test(sheetFrames[0]), JSON.stringify(sheetFrames));
  check('and editing is still one click away',
    /Open in Google Sheets/.test(calText), calText.slice(0, 200));
  await page.goto(BASE + '/sources/videos', { waitUntil: 'networkidle', timeout: 60000 });
  await page.waitForFunction(() => /Recovery coaching guided by certified trainers/.test(document.body.innerText), null, { timeout: 20000 });
  const useBtns = page.getByRole('button', { name: 'Use in post' });
  check('every video has a "Use in post" button', (await useBtns.count()) >= 2, String(await useBtns.count()));
  await useBtns.last().click();
  await page.waitForURL(/\/draft(#section-publish)?$/, { timeout: 20000 });
  await page.waitForFunction(() => {
    const ta = document.getElementById('composer-text');
    return ta && /Recovery coaching guided by certified trainers/.test(ta.value);
  }, null, { timeout: 20000 });
  check('"Use in post" lands the video copy in the Publishing composer', true);
  await page.waitForLoadState('networkidle').catch(() => undefined);
  await page.goto(BASE + '/sources/images', { waitUntil: 'networkidle', timeout: 60000 });
  await page.waitForFunction(() => /ALE02947\.jpg/.test(document.body.innerText), null, { timeout: 20000 });
  check('the Image Library shows the Drive photos', true);

  // ---- 5d: Calendar / Publishing — the ordered list beside the month grid
  await page.goto(BASE + '/calendar', { waitUntil: 'networkidle', timeout: 60000 });
  await page.waitForFunction(() => /Scheduled: recovery stories/.test(document.body.innerText), null, { timeout: 20000 }).catch(() => undefined);
  const pubList = await page.evaluate(() => {
    const aside = document.getElementById('publishing-list');
    const text = aside ? aside.innerText : '';
    const items = Array.from(aside ? aside.querySelectorAll('li') : []).map((li) => li.innerText);
    return { present: Boolean(aside), text, items };
  });
  check('the Calendar / Publishing page has the Publishing list beside the grid', pubList.present && /Publishing list/i.test(pubList.text), pubList.text.slice(0, 120));
  check('the list is in date order: the post 2 days out comes before the one 4 days out', pubList.items.findIndex((t) => /mobility training explainer/.test(t)) < pubList.items.findIndex((t) => /recovery stories/.test(t)), pubList.items.join(' | ').slice(0, 300));
  check('a post waiting for review shows its state and an Approve button in the list', /Waiting for approval/.test(pubList.text) && /Approve/.test(pubList.text), '');
  check('every item offers +1 day and Delete', pubList.items.length >= 2 && pubList.items.every((t) => /\+1 day/.test(t) && /Delete/.test(t)), pubList.items.join(' | ').slice(0, 300));

  // ---- 5e: Weekly planner — a Tuesday theme saved as a fresh-angle template
  await page.goto(BASE + '/templates', { waitUntil: 'networkidle', timeout: 60000 });
  await page.waitForFunction(() => /Weekly planner/.test(document.body.innerText), null, { timeout: 20000 });
  const plannerBefore = await page.evaluate(() => document.body.innerText);
  check('the existing Monday/Wednesday template appears under both days of the planner', /Weekly knees series|strength training for knees/.test(plannerBefore), '');
  const addButtons = page.getByRole('button', { name: '+ Add theme' });
  check('every weekday offers "+ Add theme"', (await addButtons.count()) === 7, String(await addButtons.count()));
  await addButtons.nth(1).click(); // Tuesday
  await page.fill('#planner-topic', 'Client questions about recovery time');
  const tplPosts = page.waitForResponse((r) => r.url().includes('/api/templates') && r.request().method() === 'POST', { timeout: 20000 });
  await page.getByRole('button', { name: 'Save slot' }).click();
  const tplRes = await tplPosts;
  const tplReq = JSON.parse(tplRes.request().postData() || '{}');
  check('saving a Tuesday theme creates a template on weekday 2 with a fixed topic and a fresh angle each time', tplRes.ok() && tplReq.weekdays && tplReq.weekdays.join() === '2' && tplReq.strategy?.mode === 'fixed_topic' && tplReq.strategy?.topic === 'Client questions about recovery time' && /^Tuesday · /.test(tplReq.name), JSON.stringify(tplReq).slice(0, 300));
  await page.waitForFunction(() => /Client questions about recovery time/.test(document.body.innerText), null, { timeout: 20000 });
  const tueSlot = await page.evaluate(() => Array.from(document.querySelectorAll('section')).map((s) => s.innerText).find((t) => /Weekly planner/.test(t)) || '');
  check('the new slot shows in the planner as "fresh angle weekly"', /Client questions about recovery time[\s\S]*fresh angle weekly/.test(tueSlot), '');
  // The save announces a refresh; let the follow-up reload land before leaving the page.
  await page.waitForTimeout(1500);
  await page.waitForLoadState('networkidle').catch(() => undefined);

  // ---- 5f: Video Library → Prepare: transcript → keywords → copy → Metricool
  await page.goto(BASE + '/sources/videos', { waitUntil: 'networkidle', timeout: 60000 });
  await page.waitForFunction(() => /How Our Medical Evaluation Process Works/.test(document.body.innerText), null, { timeout: 20000 });
  const prepBtns = page.locator('table').getByRole('button', { name: 'Prepare', exact: true });
  check('a video with a YouTube link offers Prepare (the Drive-only one does not)', (await prepBtns.count()) === 1, String(await prepBtns.count()));
  await prepBtns.first().click();
  await page.waitForFunction(() => (document.getElementById('video-url') || {}).value === 'https://www.youtube.com/watch?v=capt0000001', null, { timeout: 10000 });
  const prepRes = page.waitForResponse((r) => r.url().includes('/api/videos/prepare'), { timeout: 60000 });
  await page.locator('#video-prepare').getByRole('button', { name: 'Prepare' }).click();
  check('Prepare calls the pipeline and succeeds', (await prepRes).ok(), String((await prepRes).status()));
  await page.waitForFunction(() => /Transcript · YouTube captions/.test(document.body.innerText), null, { timeout: 20000 });
  const prepUi = await page.evaluate(() => ({
    text: document.getElementById('video-prepare').innerText,
    linkedin: (document.getElementById('video-linkedin') || {}).value || '',
    tiktok: (document.getElementById('video-tiktok') || {}).value || '',
  }));
  check('the badges show transcript source, keyword source and citation status', /Transcript · YouTube captions · en/.test(prepUi.text) && /Keywords/.test(prepUi.text) && /itation/.test(prepUi.text), prepUi.text.slice(0, 300));
  check('the LinkedIn copy is editable and ends with the video link', /Watch: https:\/\/www\.youtube\.com\/watch\?v=capt0000001/.test(prepUi.linkedin), prepUi.linkedin.slice(-80));
  check('the TikTok caption carries REF + AVISO', /REF:/.test(prepUi.tiktok) && /AVISO DE PUBLICIDAD/.test(prepUi.tiktok), prepUi.tiktok.slice(0, 200));
  await page.fill('#video-linkedin', prepUi.linkedin.replace('In our latest video', 'In this week\'s video'));
  const sendRes = page.waitForResponse((r) => r.url().includes('/api/metricool/schedule'), { timeout: 30000 });
  await page.getByRole('button', { name: 'Send LinkedIn to Metricool for review' }).click();
  const sendR = await sendRes;
  await sendR.finished().catch(() => undefined);
  const sendReq = JSON.parse(sendR.request().postData() || '{}');
  check('the edited LinkedIn text is what goes to Metricool, as LinkedIn, for review', sendR.ok() && sendReq.network === 'linkedin' && /In this week's video/.test(sendReq.text), String(sendR.status()) + ' ' + JSON.stringify(sendReq).slice(0, 200));
  await page.waitForFunction(() => Boolean(document.querySelector('#video-prepare [role="status"]')), null, { timeout: 10000 }).catch(() => undefined);
  const sentMsg = await page.evaluate(() => (document.querySelector('#video-prepare [role="status"]') || {}).innerText || '');
  check('and the page confirms it is in the queue waiting for Approve', /press Approve/.test(sentMsg), sentMsg);
  await page.waitForLoadState('networkidle').catch(() => undefined);

  // ---- 5c: the composer states the advertising rule for Instagram/Facebook
  await page.goto(BASE + '/draft', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('#composer-text', 'A caption with neither line.');
  await page.waitForFunction(() => /must carry two lines/.test(document.body.innerText), null, { timeout: 15000 });
  const ruleText = await page.evaluate(() => document.body.innerText);
  check('the composer explains the AVISO + REF rule for a Facebook post', /AVISO DE PUBLICIDAD: 1234567890A00000/.test(ruleText) && /REF:/.test(ruleText), '');
  await page.getByRole('button', { name: 'add it now' }).click();
  const withAviso = await page.$eval('#composer-text', (el) => el.value);
  check('"add it now" appends the AVISO line', /AVISO DE PUBLICIDAD: 1234567890A00000$/.test(withAviso.trim()), withAviso);
  const sendBtn = page.getByRole('button', { name: 'Send to Metricool for review' });
  check('send stays disabled until the REF line is there too', await sendBtn.isDisabled());

  // ---- 5b: a failed load must not look like an empty account ---------------
  //
  // Every panel used to do `if (!r.ok) return;`, so a 401, a 429 or a dropped
  // connection left the dashboard in its EMPTY state: "Nothing in the queue
  // yet", "No drafts yet", "No Autopilot runs yet". A coordinator whose session
  // had lapsed was told, in effect, that her work had vanished. Prove that a
  // broken backend now SAYS it is broken.
  const failPage = await ctx.newPage();
  await failPage.route('**/api/**', (route) => {
    const p = new URL(route.request().url()).pathname;
    if (p === '/api/posts' || p === '/api/stats' || p === '/api/drafts' || p === '/api/autopilot/runs') {
      return route.fulfill({
        status: 401,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'unauthenticated', message: 'Your session has expired. Sign in again.' }),
      });
    }
    return route.continue();
  });
  await failPage.goto(BASE + '/', { waitUntil: 'networkidle', timeout: 90000 });
  await failPage.waitForTimeout(1500);
  const failText = await failPage.evaluate(() => document.body.innerText);
  check('a failed load says the session expired instead of showing an empty dashboard',
    /session has expired/i.test(failText), failText.slice(0, 160).replace(/\s+/g, ' '));
  check('and it does NOT claim the publishing queue is empty',
    !/Nothing in the queue yet/i.test(failText));
  check('and it does NOT claim there are no drafts',
    !/No drafts yet/i.test(failText));
  check('and it does NOT send the user off to fix a healthy Autopilot template',
    !/No Autopilot runs yet/i.test(failText));
  await failPage.screenshot({ path: '/tmp/e2e-failed-load.png', fullPage: false });
  await failPage.close();

  // ---- 6: console hygiene --------------------------------------------------
  // Failures from EXTERNAL hosts (Google Fonts etc.) are sandbox-proxy
  // artifacts, not app bugs; anything failing against 127.0.0.1 is real.
  const localFailures = failedRequests.filter((u) => u.includes('127.0.0.1') && !/realtime|websocket/i.test(u));
  check('no failed requests against the app itself', localFailures.length === 0, localFailures.slice(0, 3).join(' | '));
  const realErrors = consoleErrors.filter((e) =>
    !/realtime|websocket|wss?:\/\//i.test(e) && // no realtime server in the mock env
    !/favicon/i.test(e) &&
    !/net::ERR_ABORTED|net::ERR_TUNNEL_CONNECTION_FAILED|net::ERR_CONNECTION_RESET|net::ERR_NAME_NOT_RESOLVED/i.test(e) && // external hosts blocked by the sandbox proxy
    // Degraded integrations answer with handled errors. 502 is in this list
    // because an unreachable upstream (Metricool/Opus/Semrush/the model APIs,
    // none of which exist in the mock env) is now reported as a gateway error
    // rather than as a 500 — a failure OUTSIDE the app is not the app's fault,
    // and the distinction is what lets the UI say "the service is unavailable"
    // instead of "something went wrong".
    !/Failed to load resource.*(404|500|502|503)/i.test(e)
  );
  check('zero unexpected console errors across all pages', realErrors.length === 0, realErrors.slice(0, 3).join(' | '));
  if (failedRequests.length) console.log('  (external request failures, sandbox-only: ' + failedRequests.filter((u) => !u.includes('127.0.0.1')).length + ')');
  check('zero uncaught page exceptions', pageErrors.length === 0, pageErrors.slice(0, 2).join(' | '));

  await browser.close();
  console.log('\n' + results.filter((r) => r.ok).length + '/' + results.length + ' browser E2E checks passed');
  if (consoleErrors.length) console.log('(console errors observed, filtered as expected-in-mock: ' + consoleErrors.length + ')');
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('E2E crashed:', e); process.exit(1); });

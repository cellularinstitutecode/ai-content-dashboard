// web/app/api/templates/apply/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { complianceGate, gateRefusal } from '@/lib/compliance-gate';
import { supabaseServer } from '@/lib/supabase';
import { SCHEDULE_TZ, upcomingSlots } from '@/lib/timezone';
import { metricoolConfigured, metricoolSchedulePost, metricoolNetworks, readPostId } from '@/lib/metricool';
import { reportError } from '@/lib/report';
import { isAllowedEmail } from '@/lib/access';
import { checkRateLimit } from '@/lib/rate-limit';

export const runtime = 'nodejs';
// Each slot is one upstream Metricool call now, so the default 10s is too tight.
export const maxDuration = 60;

// The most slots one click may create. A template can describe up to 12 weeks x
// 7 weekdays; sending 84 posts to Metricool from one request would outrun the
// function budget and half-finish. Ask for a smaller window instead.
const MAX_SLOTS = 40;
// Leave room to answer before the platform kills the function.
const TIME_BUDGET_MS = 45_000;

// POST /api/templates/apply
// Body: { id: string, weeks?: number }
//
// Creates the template's upcoming posts for the next N weeks (default 4), in
// the brand's schedule timezone, AND schedules each one in Metricool as a draft.
//
// This route used to insert rows into the local `posts` table and stop there.
// Nothing else in the codebase ever sent those rows anywhere, so they rendered
// as blue "Scheduled" chips on the dashboard and the calendar and then simply
// never published - a team could believe a month of content was queued while
// nothing had been handed to any channel. Two smaller faults rode along: a
// second click duplicated every slot, and an AI/pillars template (whose `text`
// is empty by design) produced a run of blank posts.
export async function POST(req: NextRequest) {
  const sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  // This route now writes into the brand's shared Metricool account, so it
  // carries the same allowlist gate as every other route that does - the
  // repo's own route-policy test enforces this.
  if (!isAllowedEmail(user.email)) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }
  // One click can create dozens of scheduled posts upstream. Cap it like every
  // other route that spends a shared resource.
  const rl = await checkRateLimit(user.id, 'schedule');
  if (!rl.ok) {
    return NextResponse.json(
      { error: 'rate_limited', limit: rl.limit },
      { status: 429, headers: { 'Retry-After': String(rl.retryAfterSec) } },
    );
  }

  const body = await req.json().catch(() => ({} as any));
  const id = body && body.id;
  if (!id) return NextResponse.json({ error: 'id is required' }, { status: 400 });

  const weeks = Math.min(Math.max(Number(body.weeks) || 4, 1), 12);

  if (!metricoolConfigured()) {
    return NextResponse.json(
      {
        error: 'metricool_not_configured',
        message: 'Metricool is not connected, so these posts could not be scheduled anywhere. Nothing was created.',
      },
      { status: 503 },
    );
  }

  const { data: tpl, error: tErr } = await sb
    .from('schedule_templates')
    .select('*')
    .eq('id', id)
    .eq('user_id', user.id)
    .maybeSingle();
  if (tErr) return NextResponse.json({ error: tErr.message }, { status: 500 });
  if (!tpl) return NextResponse.json({ error: 'template not found' }, { status: 404 });

  const weekdays: number[] = Array.isArray(tpl.weekdays) ? tpl.weekdays : [];
  const providers: string[] = Array.isArray(tpl.providers) ? tpl.providers : [];
  if (weekdays.length === 0) {
    return NextResponse.json({ error: 'template has no weekdays selected' }, { status: 400 });
  }
  if (providers.length === 0) {
    return NextResponse.json({ error: 'template has no providers selected' }, { status: 400 });
  }
  // The channels Metricool can actually take. This route used to cast the raw
  // column — which the templates UI lets a person put `blog` into — straight to
  // Provider[], and one unknown entry can fail the whole multi-network call and
  // take the real networks down with it. `blog` is an article, and this route
  // schedules the template's fixed text; an article is written by the engine
  // and published by approveRun, so there is nothing for this door to do with
  // it beyond leaving it alone.
  const mcProviders = metricoolNetworks(providers);
  if (mcProviders.length === 0) {
    return NextResponse.json(
      {
        error: 'no_social_networks',
        message: providers.includes('blog')
          ? 'This template only publishes a blog article, which is written and published by the Autopilot rather than scheduled from here.'
          : 'None of this template’s channels is a network this app can post to.',
      },
      { status: 400 },
    );
  }

  // An AI template carries no fixed text - Autopilot writes each post the day
  // it is due. Materialising it here would schedule empty posts.
  const text = String(tpl.text || '').trim();
  if (!text) {
    return NextResponse.json(
      {
        error: 'template_has_no_text',
        message: 'This template writes each post with AI, so there is nothing to schedule ahead of time. Autopilot prepares these for you - review them in the Autopilot queue.',
      },
      { status: 400 },
    );
  }

  // Template times are wall-clock times in the schedule timezone
  // (SCHEDULE_TZ, UTC unless configured) - build the instants through the
  // shared timezone helper so a 09:00 template lands at 09:00 local, not
  // 09:00 UTC.
  const slots = upcomingSlots(weekdays, tpl.time_of_day || '09:00', weeks * 7, SCHEDULE_TZ);
  if (slots.length === 0) {
    return NextResponse.json({ created: 0, skipped: 0, failed: 0, posts: [] });
  }
  if (slots.length > MAX_SLOTS) {
    return NextResponse.json(
      {
        error: 'too_many_slots',
        message: 'That would create ' + slots.length + ' posts in one go. Apply a shorter window (' + MAX_SLOTS + ' posts or fewer) and repeat it later.',
      },
      { status: 400 },
    );
  }

  // Idempotency. `posts` has no unique constraint, so a second click used to
  // duplicate every slot. Anything this user already has at the same instant
  // with the same text is treated as already applied.
  const first = slots[0].toISOString();
  const last = slots[slots.length - 1].toISOString();
  // Refuse rather than guess. supabase-js RESOLVES a failed read, so ignoring
  // `error` turned "I could not check" into "nothing is scheduled" — and this
  // read is the ONLY thing standing between a second click and a duplicate of
  // every slot in the range. Failing closed costs a retry; failing open costs
  // up to forty duplicate posts in the brand's live queue.
  const { data: existing, error: existingError } = await sb
    .from('posts')
    .select('publication_date, text')
    .eq('user_id', user.id)
    .gte('publication_date', first)
    .lte('publication_date', last);
  if (existingError) {
    reportError('templates:apply-existing', existingError);
    return NextResponse.json(
      {
        error: 'schedule_unreadable',
        message: 'We could not check what is already scheduled, so nothing was created — applying now could duplicate every slot. Try again in a moment.',
      },
      { status: 503 },
    );
  }
  const taken = new Set(
    (existing || [])
      .filter((row: any) => String(row.text || '').trim() === text)
      .map((row: any) => new Date(row.publication_date).getTime()),
  );

  // The advertising rule, before anything is created. Every slot carries the
  // SAME text, so a non-compliant template would put N identical breaches into
  // Metricool's review queue — where the dashboard would then refuse to
  // approve any of them, but a person working inside Metricool could still
  // publish them. Refuse up front rather than half-create.
  // Gated on what this route actually SENDS, not on the raw column. Since the
  // gate started covering articles, gating on the raw list meant a template
  // carrying `blog` alongside a non-gated network was refused for missing an
  // AVISO and a DOI — naming a channel this route never touches, on copy that
  // was only going to that other network.
  const gate = await complianceGate(user.id, text, mcProviders as string[]);
  if (!gate.ok) {
    return NextResponse.json(
      { ...gateRefusal(gate), message: gate.message + ' Edit the template text, then apply it again.' },
      { status: 422 },
    );
  }

  // No video gate here, for the same reason lib/batch-draft.ts records: every
  // post this route creates carries the TEMPLATE's own text and no draft_id at
  // all, so there is no draft pack to be video-derived and nothing for the rule
  // to read. The gate lives on the paths that can reach a video-prepared draft
  // — /api/posts PATCH and approveRun.
  const started = Date.now();
  const created: any[] = [];
  const failures: string[] = [];
  let skipped = 0;
  let notAttempted = 0;

  for (const slot of slots) {
    if (taken.has(slot.getTime())) { skipped++; continue; }
    if (Date.now() - started > TIME_BUDGET_MS) { notAttempted++; continue; }

    let metricoolId: string | null = null;
    try {
      const res = await metricoolSchedulePost({
        text,
        providers: mcProviders,
        publicationDate: slot.toISOString(),
      });
      metricoolId = readPostId(res);
    } catch (e) {
      reportError('templates/apply:metricool', e);
      failures.push(slot.toISOString());
      continue;
    }

    const { data: row, error } = await sb
      .from('posts')
      .insert({
        user_id: user.id,
        // What was actually SENT, not what the template lists. The row exists
        // to mirror Metricool, and a rescheduled post reads this column back
        // and sends it again — so an entry that never went out must not be in
        // it.
        providers: mcProviders,
        text,
        publication_date: slot.toISOString(),
        metricool_post_id: metricoolId,
        // Same vocabulary the interactive scheduler uses: it is in Metricool,
        // waiting for a human to approve it there.
        status: 'pending_review',
      })
      .select('*')
      .single();
    if (error) {
      // The post IS in Metricool; only our bookkeeping row failed. Say so
      // rather than reporting a clean success.
      reportError('templates/apply:insert', error);
      failures.push(slot.toISOString());
      continue;
    }
    created.push(row);
  }

  const parts: string[] = [];
  parts.push(created.length === 1 ? 'Sent 1 post to Metricool for review.' : 'Sent ' + created.length + ' posts to Metricool for review.');
  if (skipped) parts.push(skipped + ' already existed and were left alone.');
  if (failures.length) parts.push(failures.length + ' could not be scheduled — try again.');
  if (notAttempted) parts.push(notAttempted + ' were not attempted (ran out of time) — apply again to finish.');

  return NextResponse.json({
    created: created.length,
    skipped,
    failed: failures.length,
    notAttempted,
    message: parts.join(' '),
    posts: created,
  }, { status: failures.length && !created.length ? 502 : 200 });
}

// web/app/api/templates/strategy/route.ts
// "Load the weekly strategy" — the written calendar, written into the database.
//
// WHY THIS IS A ROUTE AND NOT FIFTEEN CLICKS. POST /api/templates is rate
// limited per user (it makes the org-wide Autopilot spend AI and Semrush
// credit), so a client loop writing fifteen templates would be refused
// somewhere around the fourth and leave a half-built calendar behind. One
// request, one rate-limit bucket, all fifteen or none of them.
//
// WHAT IT CANNOT DO. It cannot make anything publish. A seeded template
// produces drafts that wait in the review queue exactly like every other
// template; whether the engine may approve its own work is a separate setting
// that this route does not read, set or care about.
//
// The rules about WHICH rows to write, and what to do about ones that already
// exist, are in lib/strategy-seed.ts, where they are unit-tested without a
// database.
import { NextResponse } from 'next/server';
import { requireAllowlistedUser } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { normalizeStrategy } from '@/lib/autopilot';
import { planSeed, seedSummary, type ExistingTemplate, type SeedRow, type SeedUpdate } from '@/lib/strategy-seed';
import { supabaseServer } from '@/lib/supabase';
import { reportError } from '@/lib/report';

export const runtime = 'nodejs';

type Row = Record<string, unknown>;

function dbRow(userId: string, row: SeedRow, now: string): Row {
  const out: Row = {
    user_id: userId,
    name: row.name,
    providers: row.providers,
    // `text` is NOT NULL on this table and is the static Apply flow's copy.
    // A pillars template writes its own text every week, so this stays empty.
    text: '',
    weekdays: row.weekdays,
    time_of_day: row.time_of_day,
    active: row.active,
    // Through the engine's own normaliser, so this route cannot write a
    // strategy shape the engine would refuse to read.
    strategy: normalizeStrategy(row.strategy),
    updated_at: now,
  };
  return out;
}

/**
 * A slot the seed already owns: ONLY its strategy is written — the angle
 * bank, the rule, the mark and the slot's identity (lib/strategy-seed.ts
 * SEED_OWNED), merged into what is there. Its name, days, time, channels and
 * on/off state are the operator's; this used to rewrite them all, so a second
 * press moved every edited slot back and switched paused ones on again.
 */
function updateRow(row: SeedUpdate, now: string): Row {
  const out: Row = { strategy: normalizeStrategy(row.strategy), updated_at: now };
  // Present only for the article row still on the seed's own old channel list.
  if (row.providers) out.providers = row.providers;
  return out;
}

export async function POST() {
  const auth = await requireAllowlistedUser();
  if (!auth.ok) return auth.response;
  const rl = await checkRateLimit(auth.userId, 'templates');
  if (!rl.ok) return NextResponse.json({ error: 'rate_limited' }, { status: 429 });

  const sb = await supabaseServer();
  const userId = auth.userId;

  // What is already here. Read, not assumed: pressing this twice must leave
  // fifteen templates, not thirty, and this table has no unique key to fall
  // back on.
  //
  // `strategy` as well as the name: the mark inside it is what says a row
  // belongs to this seed and may be overwritten. Without it the seed would be
  // matching on name alone, which is how somebody's own "Practical tips" template
  // got absorbed.
  const { data: existing, error: readError } = await sb
    .from('schedule_templates')
    // Day and time too: a slot written before slot keys existed and since
    // renamed is recognised by them rather than duplicated.
    .select('id, name, strategy, weekdays, time_of_day, providers')
    .eq('user_id', userId);
  if (readError) {
    // Fail closed. Writing without knowing what is there is exactly how the
    // calendar doubles.
    reportError('templates:strategy-read', readError);
    return NextResponse.json(
      {
        error: 'unverified',
        message: 'Your existing templates could not be read just now, and loading the strategy without them could duplicate your week. Nothing was changed — try again in a moment.',
      },
      { status: 503 },
    );
  }

  const plan = planSeed((existing || []) as ExistingTemplate[]);
  const now = new Date().toISOString();
  const fresh = plan.create.map((r) => dbRow(userId, r, now));
  const existingRows = plan.update.map((r) => ({ id: r.id, patch: updateRow(r, now) }));

  /**
   * INSERT and UPSERT are two calls, deliberately.
   *
   * PostgREST takes the union of the keys in a batch and sends the missing
   * ones as NULL rather than letting the column default fill them — so one
   * mixed batch would try to insert the new templates with `id: null` and be
   * refused by the primary key. Splitting them is what makes a first press and
   * a second press both work.
   *
   * WHICH LEGS HAVE ALREADY RUN. A retry used to re-enter this function and
   * re-run the INSERT leg with it — so an insert that succeeded followed by an
   * upsert that failed with any message containing "strategy" wrote fifteen
   * brand-new templates on top of the fifteen just written, and answered
   * `ok: true`. Thirty templates, thirty posts a week, at full model and
   * Semrush cost, from the one route whose whole purpose is to make a second
   * press safe.
   *
   * Nothing re-enters `write` today (the degrade path is gone), but the flags
   * stay: the next person to add a retry gets the safe behaviour for free.
   */
  let inserted = false;
  let updated = false;

  async function write(withStrategy: boolean): Promise<{ message: string } | null> {
    const strip = (rows: Row[]) =>
      withStrategy
        ? rows
        : rows.map((r) => {
            const copy = { ...r };
            delete copy.strategy;
            return copy;
          });
    if (fresh.length && !inserted) {
      const { error } = await sb.from('schedule_templates').insert(strip(fresh)).select('id');
      if (error) return { message: error.message };
      inserted = true;
    }
    if (existingRows.length && !updated) {
      // One UPDATE per row, of the strategy alone — never an upsert of the
      // whole row, which is what put back the seed's time, channels and
      // `active: true` over the operator's own.
      for (const { id, patch } of existingRows) {
        const next = withStrategy ? patch : { updated_at: patch.updated_at, ...(patch.providers ? { providers: patch.providers } : {}) };
        const { error } = await sb.from('schedule_templates').update(next).eq('id', id).eq('user_id', userId).select('id');
        if (error) return { message: error.message };
      }
      updated = true;
    }
    return null;
  }

  const failure = await write(true);
  if (failure) {
    reportError('templates:strategy-write', new Error(failure.message));
    // NO DEGRADE PATH HERE, deliberately, and this used to have one.
    //
    // Writing the rows without their `strategy` — which is what a database
    // missing the autopilot migration forces — produces fifteen templates that
    // are inert (`mode` defaults to 'off', so they write nothing) AND unmarked,
    // so the next press cannot recognise them and creates fifteen more. A
    // calendar that does nothing and doubles on retry is worse than a refusal
    // that names the migration.
    // "Nothing was changed" is only true if NOTHING was written. The insert leg
    // runs first, so a mixed press — some slots new, some to update — can have
    // committed up to fifteen rows before the upsert failed, and saying
    // otherwise sends somebody looking in the wrong place.
    const partial = inserted || updated;
    // And the migration can only be the explanation when the leg that carries
    // `strategy` had not yet succeeded. If the insert wrote rows WITH a
    // strategy column and the upsert then failed mentioning it, the column
    // plainly exists and this is a policy or constraint problem — telling the
    // operator to run a migration they already have wastes the one piece of
    // information they were given.
    const migrationMissing = /strategy/i.test(failure.message) && !inserted;
    return NextResponse.json(
      {
        error: migrationMissing ? 'migration_missing' : 'write_failed',
        message: (migrationMissing
          ? 'This database has not had the Autopilot migration run yet, so the rotation has nowhere to be stored — and slots written without it would do nothing. Run web/supabase/autopilot.sql (GO-LIVE.md, step 2), then press this again.'
          : 'The weekly strategy could not be written: ' + failure.message)
          + (partial
            ? ' Some slots were already created before this failed — press the button again once it is fixed, and they will be brought up to date rather than duplicated.'
            : ' Nothing was changed.'),
      },
      { status: migrationMissing ? 409 : 500 },
    );
  }

  return NextResponse.json({
    ok: true,
    created: plan.create.length,
    updated: plan.update.length,
    duplicates: plan.duplicates,
    collisions: plan.collisions,
    message: seedSummary(plan),
  });
}

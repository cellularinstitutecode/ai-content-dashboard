// web/app/api/templates/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabase';
import { normalizeStrategy, reconcileTemplateRuns } from '@/lib/autopilot';
import { cleanTime, cleanWeekdays } from '@/lib/template-input';
import { requireAllowlistedUser } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { reportError } from '@/lib/report';

export const runtime = 'nodejs';

// Templates are not just the user's own data: every active one is picked up by
// the org-wide Autopilot tick, which then spends AI and Semrush credit on it
// without anyone else clicking. That puts this route in the same class as
// /api/templates/apply and /api/generate — a shared, paid resource — so it
// carries the same allowlist check they do, and a cap on how fast templates
// can be written. Middleware and row-level security still apply; this is the
// copy that stays correct if the middleware exemption list ever widens.

// A schedule template: what to post and on which weekly cadence.
type TemplateInput = {
  id?: string;
  name?: string;
  providers?: string[];
  text?: string;
  weekdays?: number[]; // 0=Sun .. 6=Sat
  time_of_day?: string; // "HH:MM"
  active?: boolean;
  // Autopilot: how the engine should treat each occurrence of this template.
  strategy?: unknown;
};

// GET /api/templates — list the user's templates.
export async function GET() {
  const auth = await requireAllowlistedUser();
  if (!auth.ok) return auth.response;
  const sb = await supabaseServer();
  const user = { id: auth.userId };

  const { data, error } = await sb
    .from('schedule_templates')
    .select('*')
    .eq('user_id', user.id)
    .order('updated_at', { ascending: false });
  if (error) {
    // If the schedule_templates table hasn't been created yet, treat it as no templates
    // rather than surfacing a 500 to the UI.
    const code = (error as any)?.code;
    const msg = String((error as any)?.message || '');
    const missingTable = code === '42P01' || code === 'PGRST205' || /schema cache|does not exist|could not find the table/i.test(msg);
    if (missingTable) return NextResponse.json({ templates: [] });
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json({ templates: data ?? [] });
}

// POST /api/templates — create or update a template (upsert when id is present).
export async function POST(req: NextRequest) {
  const auth = await requireAllowlistedUser();
  if (!auth.ok) return auth.response;
  const rl = await checkRateLimit(auth.userId, 'templates');
  if (!rl.ok) return NextResponse.json({ error: 'rate_limited' }, { status: 429 });
  const sb = await supabaseServer();
  const user = { id: auth.userId };

  const body: TemplateInput = await req.json().catch(() => ({}));

  const row: any = {
    user_id: user.id,
    name: (body.name ?? '').toString().slice(0, 200) || 'Untitled template',
    providers: Array.isArray(body.providers) ? body.providers.map((p) => p.toString()) : [],
    text: (body.text ?? '').toString(),
    weekdays: cleanWeekdays(body.weekdays),
    time_of_day: cleanTime(body.time_of_day),
    active: body.active === false ? false : true,
    updated_at: new Date().toISOString(),
  };
  // Only persist a strategy when the client sent one, so older clients (and
  // databases without the column yet) keep working unchanged.
  if (body.strategy !== undefined) row.strategy = normalizeStrategy(body.strategy);
  if (body.id) row.id = body.id;

  // An id from the request, upserted on the id as conflict key, is an
  // "INSERT … ON CONFLICT DO UPDATE" against whatever row holds it — somebody
  // else's template included. RLS should refuse that (schema.sql's
  // "templates: owner update" policy), so this is the belt to that brace, and
  // the only write in the app keyed on a request id with no ownership check
  // anywhere. Its sibling DELETE below has always done this.
  if (row.id) {
    const { data: owned, error: ownerError } = await sb
      .from('schedule_templates')
      .select('id')
      .eq('id', row.id)
      .eq('user_id', user.id)
      .maybeSingle();
    // Checked, not ignored: supabase-js resolves a failed read, and treating
    // "I could not tell" as "not yours" is the safe direction here.
    if (ownerError) {
      reportError('templates:owner-check', ownerError);
      return NextResponse.json(
        { error: 'unverified', message: 'We could not confirm that template belongs to you. Nothing was saved — try again in a moment.' },
        { status: 503 },
      );
    }
    if (!owned) {
      return NextResponse.json(
        { error: 'not_found', message: 'That template does not exist in your workspace.' },
        { status: 404 },
      );
    }
  }

  let { data, error } = await sb
    .from('schedule_templates')
    .upsert(row)
    .select()
    .maybeSingle();
  // Graceful degrade: if the autopilot migration hasn't been run yet the
  // strategy column is missing — save the template without it instead of
  // failing the whole request.
  if (error && row.strategy !== undefined && /strategy/i.test(String(error.message || ''))) {
    delete row.strategy;
    ({ data, error } = await sb.from('schedule_templates').upsert(row).select().maybeSingle());
  }
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  // Runs already planned for this template's OLD day or time are retired, and
  // the new slots are planned now (lib/run-reconcile.ts). Otherwise a moved
  // slot kept its old runs and published at the time just removed.
  const savedId = (data as { id?: string } | null)?.id;
  if (savedId) await reconcileTemplateRuns(user.id, savedId);
  return NextResponse.json({ template: data });
}

// DELETE /api/templates?id=... — remove a template the user owns.
export async function DELETE(req: NextRequest) {
  const auth = await requireAllowlistedUser();
  if (!auth.ok) return auth.response;
  const sb = await supabaseServer();
  const user = { id: auth.userId };

  const id = req.nextUrl.searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'id is required' }, { status: 400 });

  const { error } = await sb
    .from('schedule_templates')
    .delete()
    .eq('id', id)
    .eq('user_id', user.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}

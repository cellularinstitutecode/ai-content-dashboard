// web/app/api/posts/route.ts
import { complianceGate, gateRefusal } from '@/lib/compliance-gate';
import { refPolicyOf } from '@/lib/compliance';
import { claimSupportOf } from '@/lib/citation-gate';
import { fixPostCitation } from '@/lib/post-citation-fix';
import { autoFixCitation } from '@/lib/citation-autofix';
import { ensureKeywords } from '@/lib/keyword-guard';
import { avisoForUser } from '@/lib/compliance-gate';
import { videoVerdict, pendingRefusal, videoSourceOf, type PackLike } from '@/lib/video-required';
import { ensureShareableVideo } from '@/lib/media-library';
import { recordApproval } from '@/lib/approval-log';
import { NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabase';
import { isAllowedEmail } from '@/lib/access';
import { checkRateLimit } from '@/lib/rate-limit';
import { metricoolDeletePost, metricoolReplacePost, metricoolNetworks, metricoolSchedulePost, normalizeMediaList, readPostId } from '@/lib/metricool';
import { wantsBlog } from '@/lib/metricool-networks';
import { normalizeFailure } from '@/lib/media-normalize-reason';
import { youtubeDataFor } from '@/lib/youtube-meta';
import { tiktokDataFor } from '@/lib/tiktok-meta';
import { cachedPublicCopy } from '@/lib/transcript-cache';
import { redact, reportError } from '@/lib/report';
import { deleteDriveFile } from '@/lib/drive';
import { deleteBucketVideo, isBucketVideoKey } from '@/lib/video-bucket';
import { forgetPublicCopy } from '@/lib/transcript-cache';
import { freshCopyUrl } from '@/lib/media-library';
import { isStreamCopyId, mediaVideoUrl, parseStreamCopyId } from '@/lib/media-url';
import { isMetricoolCopyId } from '@/lib/metricool-upload-parse';
import { publicBase } from '@/lib/public-base';
import { modeOfStatus, videoPending, APPROVED_STATUS } from '@/lib/post-mode';
import { tabGid } from '@/lib/google-sources';
import type { PostSource } from '@/lib/sheet-link';
import { supabaseAdmin } from '@/lib/supabase-admin';
import { resolvePostSources, type RegisterEntryLike, type RunLike } from '@/lib/post-source';
import { imageUnshippable } from '@/lib/image-verdict';

/** The draft's own public title, when the pack carries one. */
function packTitleOf(pack: unknown): string | null {
  const t = (pack && typeof pack === 'object' ? (pack as Record<string, unknown>).title : null);
  return typeof t === 'string' && t.trim() ? t.trim() : null;
}

/** The draft's hero image, for the publishing list's preview. */
function packImageOf(pack: unknown): string | null {
  const img = (pack && typeof pack === 'object' ? (pack as Record<string, unknown>)._image : null) as
    | { url?: unknown }
    | null;
  const u = img && typeof img === 'object' ? img.url : null;
  return typeof u === 'string' && u.trim() ? u.trim() : null;
}

/** The primary keyword the research settled on for this draft, if any. */
function packKeywordOf(pack: unknown): string | null {
  const stamp = (pack && typeof pack === 'object' ? (pack as Record<string, unknown>)._semrush : null) as
    | { primary?: unknown }
    | null;
  const k = stamp && typeof stamp === 'object' ? stamp.primary : null;
  return typeof k === 'string' && k.trim() ? k.trim() : null;
}

export const runtime = 'nodejs';
// Both mutating paths now make an upstream Metricool call before they touch the
// local row, so the default 10s budget is too tight.
// Two sequential Metricool calls now — normalise, then replace — each with its
// own timeout. 30 was the budget for one.
// 300, not 60: attaching a video now streams the file into the app's bucket
// and verifies it before Metricool is asked to take it.
export const maxDuration = 300;

/**
 * A valid session is the weaker question here.
 *
 * This route APPROVES posts into the brand's live Metricool queue and DELETES
 * files from its Drive — the two most consequential things the app can do — and
 * it was the only route touching that shared account with no allowlist check
 * of its own. Every sibling carries one as a second copy of the middleware
 * rule, precisely because the middleware exemption has gone wrong before
 * (see lib/machine-auth.ts). Someone removed from ALLOWED_EMAILS but still
 * holding a live cookie could publish to the brand's channels.
 *
 * Worse, the guard test built to catch exactly this
 * (lib/route-policy.test.ts) missed it: its "reaches the shared Metricool
 * account" pattern did not name metricoolReplacePost or metricoolDeletePost,
 * so this file passed a net designed around it. Both are in the pattern now.
 */
async function requireAllowedUser(sb: Awaited<ReturnType<typeof supabaseServer>>) {
  const { data: { user } } = await sb.auth.getUser();
  if (!user) {
    return { ok: false as const, response: NextResponse.json({ error: 'unauthorized' }, { status: 401 }) };
  }
  if (!isAllowedEmail(user.email)) {
    return {
      ok: false as const,
      response: NextResponse.json(
        { error: 'forbidden', message: 'This account is not authorized for this workspace.' },
        { status: 403 },
      ),
    };
  }
  return { ok: true as const, user };
}

// GET /api/posts
// Returns the current user's scheduled posts, most recent publication first.
export async function GET() {
  const sb = await supabaseServer();
  const auth = await requireAllowedUser(sb);
  if (!auth.ok) return auth.response;
  const user = auth.user;
  // Capped in its own bucket: this is a read of the account's own rows, and
  // counting it with PATCH and DELETE below (which reach Metricool) blanked
  // every screen that shows posts once a busy hour passed 120 reads.
  const rl = await checkRateLimit(user.id, 'posts-read');
  if (!rl.ok) {
    return NextResponse.json(
      { error: 'rate_limited', limit: rl.limit },
      { status: 429, headers: { 'Retry-After': String(rl.retryAfterSec) } },
    );
  }

  // The oldest 200 used to be the whole page: once the table passed 200 rows,
  // the NEWEST drafts — the ones just made — fell off the end, the queue did
  // not show them, and every "does this row already have drafts" decision
  // on the client failed open into making more. Recent and upcoming instead:
  // the last fortnight onward, and room for five hundred.
  const since = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString();
  const { data, error } = await sb
    .from('posts')
    .select('*')
    .eq('user_id', user.id)
    .gte('publication_date', since)
    .order('publication_date', { ascending: true })
    .limit(500);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  // `videoPending` — the PENDING chip's whole input.
  //
  // ONE extra query for the page, not one per post. Provenance lives in
  // drafts.pack (there is no column for it anywhere), so the packs behind this
  // page's posts are fetched in a single `in(...)` and matched up in memory.
  // Whether the post has the video is answered by media_drive_file_id, which is
  // already on the row — so no Drive call and no Metricool call happen here.
  //
  // That is a slightly weaker question than the gate in PATCH asks: PATCH also
  // has to RESOLVE the copy through Drive, so a row pointing at a copy someone
  // has since deleted shows no chip here and is still refused there. The two
  // errors are not symmetric and this is the safe side of them — the chip can
  // be missing from a post that cannot go out, never present on one that can.
  const posts = (data ?? []) as Record<string, unknown>[];
  const draftIds = Array.from(
    new Set(posts.map((p) => String(p.draft_id || '')).filter(Boolean)),
  );
  const packs: Record<string, PackLike> = {};
  let packsUnavailable = false;
  if (draftIds.length) {
    const { data: ds, error: packErr } = await sb
      .from('drafts').select('id, pack').in('id', draftIds).eq('user_id', user.id);
    if (packErr) {
      // Said out loud rather than swallowed. Without the packs nothing can be
      // known to be video-derived, so every chip would be absent — which reads
      // as "nothing is pending" and is the opposite of the truth. The approve
      // gate in PATCH is unaffected either way; it reads the pack itself.
      reportError('posts:pack-read', packErr, { userId: user.id });
      packsUnavailable = true;
    }
    for (const d of ds || []) {
      packs[String((d as { id: string }).id)] = (d as { pack: PackLike }).pack ?? null;
    }
  }

  // WHICH ROW OF WHICH TAB this post was written from.
  //
  // Every post in the publishing list came from a specific row of the sheet,
  // and the app has always known which: video_runs records spreadsheet_id, tab
  // and row_number — refreshed on every sweep precisely so the copy can be
  // written back to it — and its draft_id is the same draft posts.draft_id
  // points at. That join alone left every composer post, every pasted-link
  // post and every batch post without a row. lib/post-source.ts resolves the
  // rest from what is read here: the user's runs (by draft, then by video),
  // the public copy → source video map, and the register's own row lines.
  // Three reads for the whole page, each best-effort: a failure is reported
  // and that tier is skipped; the queue itself never depends on them.
  const copyIds = Array.from(new Set(posts.map((p) => String(p.media_drive_file_id || '')).filter(Boolean)));

  let runs: RunLike[] = [];
  {
    const { data, error: runErr } = await sb
      .from('video_runs')
      .select('draft_id, spreadsheet_id, tab, row_number, video_title, video_link, updated_at')
      .eq('user_id', user.id)
      .order('updated_at', { ascending: false })
      .limit(1000);
    if (runErr) reportError('posts:source-read', runErr, { userId: user.id });
    runs = (data || []) as RunLike[];
  }

  const copyToVideo: Record<string, string> = {};
  // The URL each post's video actually lives at, so a draft can be OPENED in
  // the panel and not just approved. Without it "Continue" would load the copy
  // and the time but no video, and sending would strip the video off a draft
  // that had one — worse than the refusal it replaced.
  const copyToMedia: Record<string, string> = {};
  if (copyIds.length) {
    // video_transcripts has no user column and no read policy: admin, scoped
    // by the copy ids just read from this user's own posts (the same shape
    // forgetPublicCopy uses).
    const { data, error: copyErr } = await supabaseAdmin()
      .from('video_transcripts')
      .select('video_id, public_copy_id, public_copy_url')
      .in('public_copy_id', copyIds)
      .then((x) => x, (e: unknown) => ({ data: null, error: e as { message?: string } }));
    if (copyErr) reportError('posts:copy-read', copyErr, { userId: user.id });
    for (const r of (data || []) as { video_id?: string; public_copy_id?: string; public_copy_url?: string }[]) {
      if (r.public_copy_id && r.video_id) copyToVideo[String(r.public_copy_id)] = String(r.video_id);
      // Re-minted on the way out when it is one of ours: a streamed video's URL
      // carries an expiry, and handing the panel a stale one would fail the
      // media check on send.
      if (r.public_copy_id && r.public_copy_url) {
        copyToMedia[String(r.public_copy_id)] = freshCopyUrl(String(r.public_copy_id), String(r.public_copy_url), String(r.video_id || ''));
      }
    }
  }

  let register: RegisterEntryLike[] = [];
  {
    const { data, error: regErr } = await sb
      .from('video_register')
      .select('video_key, title, link, event, detail, created_at')
      .eq('user_id', user.id)
      .in('event', ['first_seen', 'queued', 'prepared', 'video_attached'])
      .order('created_at', { ascending: false })
      .limit(3000)
      .then((x) => x, (e: unknown) => ({ data: null, error: e as { message?: string } }));
    if (regErr) reportError('posts:register-read', regErr, { userId: user.id });
    register = ((data || []) as { video_key?: string; title?: string | null; link?: string | null; event?: string; detail?: Record<string, unknown> | null; created_at?: string }[])
      .map((e) => ({ videoKey: e.video_key, title: e.title, link: e.link, event: e.event, detail: e.detail, created_at: e.created_at }));
  }

  const resolved = resolvePostSources({
    posts: posts.map((p) => ({ id: p.id, draft_id: p.draft_id, media_drive_file_id: p.media_drive_file_id })),
    packs,
    runs,
    copyToVideo,
    register,
  });
  // Resolve each tab's gid once, not once per post: gids never change, and
  // lib/google-sources caches them for an hour. Failure yields null and the
  // button still opens the right document.
  const gids = new Map<string, number | null>();
  const sources: Record<string, PostSource> = {};
  for (const [postId, src] of resolved) {
    if (src.gid == null && src.spreadsheetId && src.tab) {
      const gidKey = src.spreadsheetId + '\u0000' + src.tab;
      if (!gids.has(gidKey)) gids.set(gidKey, await tabGid(src.spreadsheetId, src.tab));
      sources[postId] = { ...src, gid: gids.get(gidKey) ?? null };
    } else {
      sources[postId] = src;
    }
  }

  return NextResponse.json({
    posts: posts.map((p) => ({
      ...p,
      videoPending: packsUnavailable
        ? false
        : videoPending(p.status, packs[String(p.draft_id || '')] ?? null, Boolean(p.media_drive_file_id)),
      source: sources[String(p.id || '')] ?? null,
      mediaUrl: p.media_drive_file_id ? (copyToMedia[String(p.media_drive_file_id)] ?? null) : null,
      // The draft's own title and the keyword its research settled on.
      //
      // Both are already in the pack that was fetched above for the pending
      // chip, and both were stopping here. Continuing a draft then had to
      // rebuild the title from the media label — which is the FILENAME, and is
      // how "Video_PartnerxBrandName_Uploader.mp4" ended up as
      // the title on YouTube and TikTok.
      packTitle: packTitleOf(packs[String(p.draft_id || '')] ?? null),
      packKeyword: packKeywordOf(packs[String(p.draft_id || '')] ?? null),
      imageUrl: packImageOf(packs[String(p.draft_id || '')] ?? null),
    })),
    ...(packsUnavailable ? { packsUnavailable: true } : {}),
  });
}

// PATCH /api/posts
//
// Three things a reviewer can do to a post, all of them in Metricool FIRST and
// in our own row only if Metricool agreed — so the two sides can never disagree:
//
//   { id, publication_date }        move it (stays in whichever queue it is in)
//   { id, action: 'approve' }       review queue → live queue; Metricool
//                                   publishes it at its publication_date
//   { id, action: 'publish_now' }   same, dated a couple of minutes from now
//   { id, action: 'sync_media' }    re-send the post with the linked draft's
//                                   CURRENT hero image (the Publishing list's
//                                   image controls changed it); same date,
//                                   same queue
//
// `approve` is the only path in the whole app by which a post goes out, and it
// is reachable only from a button a signed-in reviewer pressed after reading
// the post. Every automated path (generator, calendar, templates, assistant,
// Autopilot) still ends in the review queue.
//
// Metricool's update is a REPLACE: the post's text, networks AND media have to
// be sent back with every change. Media is not on our `posts` row; it is the
// hero image on the linked draft, so it is looked up there — the reschedule
// path used to omit it, and a moved post silently lost its picture.
const PUBLISH_NOW_LEAD_MS = 2 * 60 * 1000;

// Which queue a post is in, and therefore whether a replace may carry
// draft:false/autoPublish:true. One rule, one home, one test — see
// lib/post-mode.ts for why 'scheduled' is not it.

export async function PATCH(req: Request) {
  const sb = await supabaseServer();
  const auth = await requireAllowedUser(sb);
  if (!auth.ok) return auth.response;
  const user = auth.user;
  // Reaches Metricool and Drive. Every other route that leaves the building is
  // capped; this one, which publishes and deletes, was not.
  const rl = await checkRateLimit(user.id, 'posts');
  if (!rl.ok) {
    return NextResponse.json(
      { error: 'rate_limited', limit: rl.limit },
      { status: 429, headers: { 'Retry-After': String(rl.retryAfterSec) } },
    );
  }

  let body: any = null;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'invalid json body' }, { status: 400 });
  }

  const id = body && body.id;
  const action: string = typeof body?.action === 'string' ? body.action : 'reschedule';
  const publicationDate = body && body.publication_date;
  if (!id || typeof id !== 'string') {
    return NextResponse.json({ error: 'id is required' }, { status: 400 });
  }
  if (!['reschedule', 'approve', 'publish_now', 'attach_video', 'sync_media', 'fix_citation'].includes(action)) {
    return NextResponse.json({ error: 'invalid_request', message: 'That is not something a post can do.' }, { status: 400 });
  }
  if (action === 'reschedule') {
    if (!publicationDate || typeof publicationDate !== 'string') {
      return NextResponse.json({ error: 'publication_date is required' }, { status: 400 });
    }
    if (isNaN(new Date(publicationDate).getTime())) {
      return NextResponse.json({ error: 'publication_date must be a valid ISO date' }, { status: 400 });
    }
  }

  const { data: existing, error: findErr } = await sb
    .from('posts')
    .select('id, metricool_post_id, text, providers, publication_date, status, draft_id, media_drive_file_id')
    .eq('id', id)
    .eq('user_id', user.id)
    .maybeSingle();
  if (findErr) return NextResponse.json({ error: findErr.message }, { status: 500 });
  if (!existing) return NextResponse.json({ error: 'post not found' }, { status: 404 });

  // --- the linked draft, read ONCE -----------------------------------------
  //
  // Three things need this row and it used to be fetched twice: the hero image
  // that travels with every replace (a replace REPLACES — whatever is not sent
  // is removed from the post), the provenance that says whether this copy was
  // transcribed from a video, and the source link the attach button fetches
  // from. Two reads of one row can disagree; one cannot.
  let draftPack: Record<string, unknown> | null = null;
  let heroImage = '';
  if (existing.draft_id) {
    // The error is checked because a replace REPLACES. supabase-js RESOLVES a
    // failed read, so an ignored `error` gave `d = null`, an empty media list,
    // and a post published with its picture deleted — indistinguishable from a
    // draft that never had one. A video survives this through the
    // media_drive_file_id fallback below; an image has no second source, so
    // for images the failure was silent and permanent.
    const { data: d, error: draftError } = await sb
      .from('drafts').select('pack').eq('id', existing.draft_id).eq('user_id', user.id).maybeSingle();
    if (draftError) {
      reportError('posts:draft-media-read', draftError, { id });
      return NextResponse.json(
        {
          error: 'media_unreadable',
          message: 'We could not read this post’s draft, and going ahead now would send it without its picture or its video. Nothing was changed — try again in a moment.',
        },
        { status: 503 },
      );
    }
    draftPack = (d as any)?.pack ?? null;
    const url = (d as any)?.pack?._image?.url;
    // Text or a banned prop: a picture that may never be attached (lib/image-verdict.ts).
    const textInImage = imageUnshippable((d as any)?.pack?._image?.verification);
    if (typeof url === 'string' && url && !textInImage) heroImage = url;
  }

  // --- attach_video: what the PENDING chip does ------------------------------
  //
  // Makes the world-readable copy the post needs and records it, then falls
  // through to the ordinary replace below so the video actually reaches
  // Metricool. Separate from `approve` on purpose: attaching is not approving,
  // and somebody fixing a post should be able to do the first without being
  // committed to the second.
  if (action === 'attach_video') {
    // No draft at all, or a draft that has forgotten its video: one refusal for
    // both, because from here they are the same thing — there is nothing to
    // fetch. (This is why the read above is not conditional on the action:
    // `.eq('id', '')` against a uuid column is a database ERROR, so a post that
    // simply never had a draft would have come back to a person as "we could
    // not read your draft".)
    const source = videoSourceOf(draftPack);
    if (!source) {
      return NextResponse.json(
        {
          error: 'no_source',
          message: 'This post’s draft does not record which video it came from, so there is nothing to attach. Re-prepare that row from the Video Library.',
        },
        { status: 422 },
      );
    }
    // The primitive already exists: rate-limited, allowlisted, budgeted, and it
    // writes copy_made / copy_failed to the video register either way.
    const made = await ensureShareableVideo(source, String((draftPack as { title?: unknown } | null)?.title ?? ''), {
      userId: user.id,
      actor: 'button',
    });
    if (!made.ok) {
      // copyFailureAdvice tells Google's five causes apart, and while the copies
      // folder is not in a Shared Drive this is where a person finally reads
      // that — per post, rather than as one global banner.
      return NextResponse.json({ error: made.code || 'copy_failed', message: made.message }, { status: 502 });
    }
    const { error: linkError } = await sb
      .from('posts')
      .update({ media_drive_file_id: made.fileId })
      .eq('id', id)
      .eq('user_id', user.id);
    if (linkError) {
      reportError('posts:attach-link', linkError, { id });
      return NextResponse.json(
        { error: 'not_linked', message: 'The copy was made, but we could not attach it to this post. Try again in a moment.' },
        { status: 503 },
      );
    }
    // Read back through the same field the rest of this handler uses, so the
    // replace below picks the video up exactly as an approve would.
    (existing as { media_drive_file_id?: string | null }).media_drive_file_id = made.fileId;
  }

  // --- fix_citation: what the "Verify / fix" button does ---------------------
  //
  // Does the study in the REF line back what this post says (lib/post-citation-fix.ts)?
  // If not, the citation is replaced with one that does — on the post's text, on
  // every channel of its draft, and in Metricool through the ordinary replace
  // below, at the same date and in the same queue. It is not an approval. When
  // no study backs the copy, nothing is swapped and the post is stamped
  // 'unsupported', which the approve door refuses.
  let citationNote: string | null = null;
  let citationSwapped = false;
  if (action === 'fix_citation') {
    let fix: Awaited<ReturnType<typeof fixPostCitation>>;
    try {
      fix = await fixPostCitation({ text: String(existing.text || ''), pack: draftPack, aviso: await avisoForUser(user.id) });
    } catch (e) {
      reportError('posts:fix-citation', e, { id });
      return NextResponse.json(
        { error: 'fix_failed', message: 'The citation could not be checked just now. Nothing was changed — try again in a moment.' },
        { status: 502 },
      );
    }
    citationNote = fix.note;
    citationSwapped = fix.swapped;
    if (existing.draft_id && Object.keys(fix.packPatch).length) {
      // Merged over a fresh read, like every other pack writer: the copy read
      // above may be stale by now and a concurrent image write must survive.
      const { data: fresh } = await sb.from('drafts').select('pack').eq('id', existing.draft_id).eq('user_id', user.id).maybeSingle();
      const currentPack = ((fresh as { pack?: Record<string, unknown> } | null)?.pack || draftPack || {}) as Record<string, unknown>;
      const nextPack = { ...currentPack, ...fix.packPatch };
      const { error: packError } = await sb.from('drafts').update({ pack: nextPack }).eq('id', existing.draft_id).eq('user_id', user.id);
      if (packError) {
        reportError('posts:fix-citation-draft', packError, { id });
        return NextResponse.json({ error: 'draft_update_failed', message: 'The check ran, but the draft could not be updated. Nothing was changed — try again in a moment.' }, { status: 503 });
      }
      draftPack = nextPack;
    }
    if (fix.swapped) {
      const { error: textError } = await sb.from('posts').update({ text: fix.text }).eq('id', id).eq('user_id', user.id);
      if (textError) {
        reportError('posts:fix-citation-text', textError, { id });
        return NextResponse.json({ error: 'post_update_failed', message: 'The new citation was saved on the draft, but not on this post. Try again in a moment.' }, { status: 503 });
      }
      // Read back through the same field the rest of this handler uses, so the
      // replace below carries the corrected copy to Metricool.
      (existing as { text?: string | null }).text = fix.text;
    } else {
      // Nothing to send to Metricool: the post reads exactly as it did.
      return NextResponse.json({ fixed: false, status: fix.status, note: fix.note, ref: fix.ref });
    }
  }

  // --- approve: "Verify / fix" runs by itself first ---------------------------
  //
  // The button above is the safety net; this is the default. Before an approve
  // reaches the compliance gate, a citation the judge has not already accepted
  // is checked and, if a study that backs the copy is found, swapped in — on
  // the row, on the draft, and (through the replace below) in Metricool.
  // Fails open (lib/citation-autofix.ts): the gate still decides.
  if (action === 'approve' || action === 'publish_now') {
    const fixed = await autoFixCitation({ userId: user.id, draftId: existing.draft_id, text: String(existing.text || ''), pack: draftPack, budgetMs: 90_000 });
    if (fixed.swapped) {
      const { error: textError } = await sb.from('posts').update({ text: fixed.text }).eq('id', id).eq('user_id', user.id);
      if (textError) reportError('posts:autofix-text', textError, { id });
      else (existing as { text?: string | null }).text = fixed.text;
    }
    if (fixed.pack) draftPack = fixed.pack;
    // And keywords: a post never goes out without them (lib/keyword-guard.ts).
    const kw = await ensureKeywords({ userId: user.id, draftId: existing.draft_id, text: String(existing.text || ''), pack: draftPack });
    if (kw.pack) draftPack = kw.pack;
  }

  // Only the linked draft's IMAGE was ever looked up for this, so approving a
  // video post stripped the video — the one thing the post existed to carry.
  // The video's world-readable copy is recoverable from the row's own
  // media_drive_file_id, which video-publish writes for exactly this reason.
  let media: string[] = [];
  // Did the post resolve to THE VIDEO, as opposed to some attachment? The video
  // rule below needs that exact question answered and no looser one.
  let videoAttached = false;
  // THE VIDEO FIRST, and the order matters.
  //
  // media_drive_file_id only ever holds the world-readable copy of a video —
  // lib/video-publish.ts writes it, and so does attach_video above; no image
  // path touches that column. So when a row carries one, that is the thing the
  // post exists to deliver, and a hero image must not be sent in front of it.
  //
  // This used to read image-first, with the video as a fallback for posts that
  // had no image. That was correct only by accident: video-prepared packs carry
  // no _image today because ensureDraftImage is called from the Autopilot path
  // alone. The day a video draft acquired one — a regeneration, a merge, a hand
  // edit — approving it would have published the picture and silently dropped
  // the video, which is the exact failure the rule above exists to prevent.
  if (existing.media_drive_file_id) {
    try {
      // A streamed video needs no lookup at all: its recorded id carries the
      // source video's own Drive id, and the URL is derived from that. Fresh
      // by construction, so an approve weeks after the draft was written can
      // never hand Metricool an expired link.
      const streamed = parseStreamCopyId(String(existing.media_drive_file_id));
      const url = streamed ? mediaVideoUrl(streamed, publicBase()) : (await cachedPublicCopy(String(existing.media_drive_file_id)))?.url;
      if (url) {
        media = [url];
        videoAttached = true;
      }
    } catch (e) {
      // Losing the video on an approve is bad; failing the approve is worse.
      // The gate below still refuses the post, so this degrades to PENDING
      // rather than to a video-less publish.
      reportError('posts:media-lookup', e);
    }
  }
  if (!media.length && heroImage) media = [heroImage];
  // Metricool discards a media URL it has not normalised, silently and with a
  // 200 — so a list that skipped this step is the same as no list at all.
  if (media.length) {
    const norm = await normalizeMediaList(media);
    media = norm.media;
    if (norm.degraded) {
      // Refused, not warned about. A replace whose media Metricool did not
      // take would leave the post looking finished with no video in it.
      //
      // And refused WITH THE REASON. The same sentence used to cover a 403, a
      // 413, a 502 and a transfer that ran out of time — see
      // lib/media-normalize-reason.ts.
      const failure = normalizeFailure({ status: norm.failure?.status ?? null, error: norm.failure?.error ?? null, shape: norm.failure?.shape ?? null, attempts: norm.failure?.attempts ?? null, echoed: norm.failure?.echoed ?? null });
      reportError('posts:normalize-refused', new Error(failure.message), { reason: failure.reason, status: String(failure.status ?? '') });
      return NextResponse.json(
        {
          error: 'media_unverified',
          reason: failure.reason,
          status: failure.status,
          message: failure.message + ' The post was left exactly as it was.',
        },
        { status: 502 },
      );
    }
  }

  // YouTube's own fields have to be re-sent for the same reason the media does.
  // From the draft's pack, where the first hand-off stamped the sheet's
  // FORMATO and YOUTUBE cells: rebuilding from the text alone turned every
  // approved Short back into type: 'video'.
  const providersLower = ((existing.providers || []) as string[]).map((p) => String(p).toLowerCase());
  const isYoutube = providersLower.includes('youtube');
  const packMeta = (draftPack || {}) as { format?: unknown; sheetYoutube?: unknown; title?: unknown };
  const youtubeData = isYoutube
    ? youtubeDataFor({
        title: typeof packMeta.title === 'string' ? packMeta.title : null,
        body: String(existing.text || ''),
        format: typeof packMeta.format === 'string' ? packMeta.format : null,
        sheetYoutube: typeof packMeta.sheetYoutube === 'string' ? packMeta.sheetYoutube : null,
        defaultPrivacy: process.env.YOUTUBE_DEFAULT_PRIVACY,
      })
    : null;
  const tiktokData = providersLower.includes('tiktok')
    ? tiktokDataFor({ title: typeof packMeta.title === 'string' ? packMeta.title : null, body: String(existing.text || '') })
    : null;

  // What the post will look like after this call.
  let nextDate: string = String(existing.publication_date || '');
  let nextStatus: string | null = null;
  let mode: 'review' | 'scheduled' = modeOfStatus(existing.status);

  if (action === 'reschedule') {
    nextDate = publicationDate;
  } else if (action === 'fix_citation') {
    // The corrected copy goes to Metricool at the same date, in the same
    // queue. A post Metricool does not have yet is simply saved here.
    if (!existing.metricool_post_id) {
      return NextResponse.json({ fixed: true, status: 'swapped', note: citationNote + ' This post is not in Metricool yet: the new citation goes with it when it is next sent.', text: existing.text });
    }
  } else if (action === 'attach_video') {
    // Attaching is NOT approving. The replace below carries the video to
    // Metricool and the post stays exactly where it was in the queue, waiting
    // for a person — which is the whole point of the rule.
    // A blog row is not a Metricool post that went missing — it is an article,
    // and this route has no way to publish one. Saying "send it for review
    // first" points at an action that does not exist, in a system that is not
    // the one holding the article.
    if (!existing.metricool_post_id && wantsBlog(existing.providers)) {
      return NextResponse.json(
        {
          error: 'article_not_here',
          message: 'This is a blog article, not a Metricool post. It is already in WordPress — publish it there. '
            + 'Nothing in this dashboard can publish it for you.',
        },
        { status: 409 },
      );
    }
    if (!existing.metricool_post_id) {
      return NextResponse.json(
        { error: 'not_in_metricool', message: 'This post was never sent to Metricool, so there is nothing to attach the video to. Send it for review first.' },
        { status: 409 },
      );
    }
  } else if (action === 'sync_media') {
    // Not an approval and not a move: the replace below carries whatever the
    // draft's picture is NOW, at the same date and in the same queue. A video
    // post keeps its video (media was resolved video-first above).
    if (!existing.metricool_post_id) {
      return NextResponse.json(
        { error: 'not_in_metricool', message: 'This post is not in Metricool yet. The new picture is saved and goes with the post when it is next sent.' },
        { status: 409 },
      );
    }
    if (!media.length) {
      return NextResponse.json(
        { error: 'no_media', message: 'This post has no usable picture to send — the draft has none, or its picture failed the text check.' },
        { status: 409 },
      );
    }
  } else {
    if (mode === 'scheduled') {
      return NextResponse.json(
        { error: 'already_scheduled', message: 'This post is already approved and scheduled.' },
        { status: 409 },
      );
    }
    if (!existing.metricool_post_id) {
      return NextResponse.json(
        { error: 'not_in_metricool', message: 'This post was never sent to Metricool, so there is nothing to approve. Send it for review first.' },
        { status: 409 },
      );
    }
    if (action === 'publish_now') {
      nextDate = new Date(Date.now() + PUBLISH_NOW_LEAD_MS).toISOString();
    } else if (new Date(nextDate).getTime() <= Date.now()) {
      // Metricool refuses a past date, and would say so in its own words.
      // Say it in ours, before spending the call.
      return NextResponse.json(
        { error: 'date_passed', message: 'That date has already passed. Reschedule the post first, then approve it.' },
        { status: 409 },
      );
    }
    // The last door before a live post: Instagram / Facebook copy must carry
    // the advertising notice and a scientific reference.
    // Gated on the channels this route will actually send to. The raw column
    // can hold `blog`, which the gate covers now — so a legacy row going only
    // to Instagram was refused with a message naming an article. The same
    // defect, in the same shape, as the one fixed in templates/apply.
    // Under the policy the draft was written with: a weekly-strategy
    // destination post needs a REF only when its text makes a health claim.
    // And under the judge's verdict on its citation: a REF line the judge
    // said backs nothing in the post is refused here, not flagged.
    const gate = await complianceGate(user.id, String(existing.text || ''), metricoolNetworks(existing.providers), { refPolicy: refPolicyOf(draftPack), claimSupport: claimSupportOf(draftPack) });
    if (!gate.ok) return NextResponse.json(gateRefusal(gate), { status: 422 });

    // And the video rule, at the same door rather than in a mechanism of its
    // own. Copy transcribed from a video may not go out without that video.
    //
    // `videoAttached`, not `media.length` — an image is an attachment and is not
    // the video, and asking the looser question would wave through precisely the
    // post this rule exists to stop.
    const verdict = videoVerdict(draftPack, videoAttached);
    if (verdict.pending) {
      return NextResponse.json(
        { error: 'video_pending', message: pendingRefusal(verdict), sourceUrl: verdict.sourceUrl },
        { status: 422 },
      );
    }
    mode = 'scheduled';
    nextStatus = APPROVED_STATUS;
  }

  if (existing.metricool_post_id) {
    // Filtering can empty the list — a legacy row naming a network this app no
    // longer recognises. metricoolReplacePost throws on an empty list, and the
    // catch below would report that local refusal as "Metricool did not accept
    // the approval", which sends somebody to look at the wrong system.
    const rowNetworks = metricoolNetworks(existing.providers);
    if (!rowNetworks.length) {
      return NextResponse.json(
        {
          error: 'no_known_networks',
          message: 'This post lists no network this app can post to, so it cannot be '
            + (action === 'reschedule' ? 'moved' : 'approved')
            + ' from here. Open it in Metricool, or recreate it from the draft.',
        },
        { status: 409 },
      );
    }
    try {
      await metricoolReplacePost(String(existing.metricool_post_id), {
        text: String(existing.text || ''),
        // Filtered, not cast. `posts.providers` is whatever the row was
        // created with, and older rows (and any template carrying `blog`) can
        // hold a channel Metricool has never heard of — one of those in the
        // list can fail the whole multi-network call and leave the post where
        // it was, with a message about Metricool rather than about the entry.
        providers: rowNetworks,
        publicationDate: nextDate,
        media,
        mode,
        youtubeData,
        tiktokData,
      });
    } catch (e) {
      reportError(action === 'reschedule' ? 'posts:metricool-reschedule' : action === 'sync_media' ? 'posts:metricool-sync-media' : action === 'fix_citation' ? 'posts:metricool-fix-citation' : 'posts:metricool-approve', e);
      const said = redact(e instanceof Error ? e.message : String(e)).slice(0, 300);
      // A 404 means Metricool no longer has the post at all — deleted there, or
      // gone from its scheduler — and every later approve or move would meet
      // the same 404: the row was stranded, with "Approve" on its chip and no
      // way through. So a post whose slot is still ahead is SENT AGAIN, in the
      // queue this action wants it in: for review on a move or a fix, live on
      // an approve — a person is looking at the post and has pressed Approve,
      // which is exactly the decision that puts a post in the live queue.
      const gone = /^Metricool 404\b/.test(e instanceof Error ? e.message : String(e));
      let resent = false;
      if (gone && new Date(nextDate).getTime() > Date.now()) {
        try {
          const created = await metricoolSchedulePost({
            text: String(existing.text || ''),
            providers: rowNetworks,
            publicationDate: nextDate,
            media: media.map((url) => ({ url })),
            youtubeData,
            tiktokData,
          }, mode);
          const newId = readPostId(created);
          if (newId) {
            const { error: relinkError } = await sb.from('posts').update({ metricool_post_id: newId }).eq('id', id).eq('user_id', user.id);
            if (relinkError) reportError('posts:metricool-resend-link', relinkError, { id, newId });
            (existing as { metricool_post_id?: string | null }).metricool_post_id = newId;
            resent = true;
          }
        } catch (again) {
          reportError('posts:metricool-resend', again, { id });
        }
      }
      if (action === 'fix_citation') {
        // The citation IS saved — on the post and on the draft — so this is not
        // a failure of the button; it is Metricool's copy that is behind. Said
        // so, with a 200, and the preview reloads the corrected text.
        return NextResponse.json({
          fixed: true, status: 'swapped', text: existing.text, ...(resent ? { resent: true } : { metricool: gone ? 'not_found' : 'refused' }),
          note: citationNote + (resent
            ? ' Metricool no longer had this post, so it was sent again for review with the new citation.'
            : gone
              ? ' Metricool no longer has this post (it answered 404: it was deleted or published there), so its copy could not be updated. The new citation is saved here.'
              : ' The new citation is saved here, but Metricool did not take it; it goes with the post the next time it is approved or moved. Metricool said: ' + said),
        });
      }
      if (!resent) {
        return NextResponse.json(
          {
            error: 'metricool_update_failed',
            message: gone
              ? 'Metricool no longer has this post (it answered 404: it was deleted or published there)'
                + (new Date(nextDate).getTime() > Date.now()
                  ? ', and sending it again did not work just now. Try again in a moment.'
                  : ', and its date has passed, so it cannot be sent again as it is. Move it to a future date first, then try again.')
              : action === 'reschedule'
                ? 'We could not move this post in Metricool, so it has been left where it was. Open it in Metricool to change the time there.'
                : action === 'sync_media'
                  ? 'The new picture is saved here, but Metricool did not take it. It goes with the post the next time it is approved or moved.'
                  : 'Metricool did not accept the approval, so the post is still waiting for review. Nothing was scheduled. '
                    // Metricool's own answer, on screen instead of only in the server log.
                    + 'Metricool said: ' + said,
          },
          { status: 502 },
        );
      }
      // Re-sent: the post is in Metricool again, in the queue this action wanted.
      // Carry on below exactly as if the replace had succeeded.
    }
  }

  const patch: Record<string, unknown> = { publication_date: nextDate };
  if (nextStatus) patch.status = nextStatus;
  const { data, error } = await sb
    .from('posts')
    .update(patch)
    .eq('id', id)
    .eq('user_id', user.id)
    .select('*')
    .single();
  // PGRST116 = "no (or multiple) rows returned": the post belongs to someone
  // else or was deleted. The calendar used to report this as a 500.
  if (error && (error as any).code === 'PGRST116') {
    return NextResponse.json({ error: 'post not found' }, { status: 404 });
  }
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  // An approved post is also written to the team's calendar sheet, so the
  // sheet stays the record without anyone retyping. Best-effort: the post is
  // already approved in Metricool, so a sheet hiccup is reported, not fatal.
  if (nextStatus) {
    // Awaited, for the reason lib/autopilot.ts records: on Vercel the lambda
    // can freeze once the response is returned, so a fire-and-forget insert is
    // lost non-deterministically. recordApproval is already fail-soft, so this
    // costs nothing. (The same construct was fixed in approveRun; leaving the
    // sibling half-done is how one of the two gates stays broken.)
    await recordApproval({
      publishDate: nextDate,
      networks: (existing.providers || []) as string[],
      caption: String(existing.text || ''),
      mediaUrl: media[0] || '',
      source: action === 'publish_now' ? 'Dashboard · publish now' : 'Dashboard · approve',
      postId: id,
    });
  }
  return NextResponse.json({
    post: data,
    // So the caller can tell the two apart without inspecting the row: an
    // attach leaves the post exactly where it was, waiting for a person.
    ...(action === 'attach_video' ? { attached: true, mediaUrl: media[0] || null } : {}),
    ...(action === 'fix_citation' ? { fixed: citationSwapped, status: 'swapped', note: citationNote, text: existing.text } : {}),
  });
}

// DELETE /api/posts?id=...
//
// There was no delete at all, which is how a single mis-click on "Apply
// template" could put weeks of posts on the calendar that no screen in the app
// could remove. Deleting removes the Metricool copy first (a post Metricool no
// longer has counts as already deleted) and only then drops the local row, so a
// failure here never leaves an orphan live in Metricool.
export async function DELETE(req: Request) {
  const sb = await supabaseServer();
  const auth = await requireAllowedUser(sb);
  if (!auth.ok) return auth.response;
  const user = auth.user;
  // Reaches Metricool and Drive. Every other route that leaves the building is
  // capped; this one, which publishes and deletes, was not.
  const rl = await checkRateLimit(user.id, 'posts');
  if (!rl.ok) {
    return NextResponse.json(
      { error: 'rate_limited', limit: rl.limit },
      { status: 429, headers: { 'Retry-After': String(rl.retryAfterSec) } },
    );
  }

  const id = new URL(req.url).searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'id is required' }, { status: 400 });

  const { data: existing, error: findErr } = await sb
    .from('posts')
    .select('id, metricool_post_id, media_drive_file_id')
    .eq('id', id)
    .eq('user_id', user.id)
    .maybeSingle();
  if (findErr) return NextResponse.json({ error: findErr.message }, { status: 500 });
  if (!existing) return NextResponse.json({ error: 'post not found' }, { status: 404 });

  if (existing.metricool_post_id) {
    try {
      await metricoolDeletePost(String(existing.metricool_post_id));
    } catch (e) {
      reportError('posts:metricool-delete', e);
      return NextResponse.json(
        {
          error: 'metricool_delete_failed',
          message: 'We could not remove this post from Metricool, so nothing was deleted. Try again, or delete it in Metricool.',
        },
        { status: 502 },
      );
    }
  }

  const { data: removed, error } = await sb
    .from('posts')
    .delete()
    .eq('id', id)
    .eq('user_id', user.id)
    .select('id');
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  // RLS refuses a delete by returning zero rows, not an error. Without the
  // "posts: owner delete" policy from supabase/schema.sql this route would
  // report success while deleting nothing - say so instead of lying.
  if (!removed || removed.length === 0) {
    return NextResponse.json(
      {
        error: 'delete_blocked',
        message: 'The database refused the delete. Re-run supabase/schema.sql so the posts delete policy exists, then try again.',
      },
      { status: 500 },
    );
  }
  // The public Drive copy, once nothing needs it.
  //
  // A video attached to a post is copied into the app's folder and that copy is opened to
  // ANYONE with the link. One copy backs every network of a run, so deleting it with the
  // first post would break the others — hence the count. And deliberately AFTER the row
  // is gone: the handler above can delete the Metricool post and then fail to delete the
  // row, and destroying the file in that window would strand a post that still exists.
  //
  // Best-effort, and never fatal: an orphaned file is a tidiness problem, while a 500
  // here would tell a person their post was not deleted when it was.
  const copyId = (existing as { media_drive_file_id?: string | null }).media_drive_file_id;
  if (copyId) {
    try {
      const { count, error: countErr } = await sb
        .from('posts')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('media_drive_file_id', copyId);
      // Only when the answer is a confident zero. A failed count must leave the file
      // alone: guessing wrong here breaks a post that is still queued.
      if (!countErr && (count ?? 1) === 0) {
        // The recorded id is one of three things, and only two of them are a
        // file this app made: a Drive copy (older posts), an object in the
        // app's own video bucket, or a STREAM MARKER wrapping the source
        // video's own id. That last one names the brand's original footage —
        // the streamed path copies nothing — so it is tested for first and
        // nothing is deleted for it. The old `else` reached deleteDriveFile
        // with anything that was not a bucket key, which under the new path
        // would have been a delete of the master.
        if (isStreamCopyId(String(copyId))) {
          // Nothing of ours exists to remove, and nothing to forget: the
          // mapping is still true and re-minting it costs one HMAC.
        } else if (isMetricoolCopyId(String(copyId))) {
          // The bytes live in Metricool's own storage now (lib/metricool-upload.ts)
          // and are not this app's to remove. The record is forgotten so the
          // next attach uploads afresh rather than trusting a file Metricool
          // may have cleared out.
          await forgetPublicCopy(String(copyId));
        } else if (isBucketVideoKey(String(copyId))) {
          await deleteBucketVideo(String(copyId));
          await forgetPublicCopy(String(copyId));
        } else {
          await deleteDriveFile(String(copyId));
          await forgetPublicCopy(String(copyId));
        }
      }
    } catch (e) {
      reportError('posts:drive-copy-delete', e);
    }
  }

  return NextResponse.json({ ok: true, id });
}

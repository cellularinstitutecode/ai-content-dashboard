// web/app/api/generate/route.ts
// Thin route — delegates to lib/ai.ts so we can swap providers.
import { isAllowedEmail } from '@/lib/access';
import { NextRequest, NextResponse } from 'next/server';
import { generateContentPack, NoKeywordsError, type Provider, type ContentType } from '@/lib/ai';
import { loadBrandContext } from '@/lib/brand-context';
import { reviewPack } from '@/lib/safety';
import { supabaseServer } from '@/lib/supabase';
import { supabaseAdmin } from '@/lib/supabase-admin';
import { summarizeTopPerformers, type NormalizedMetric } from '@/lib/performance';
import { checkRateLimit } from '@/lib/rate-limit';
import { recordDraftKeywords } from '@/lib/semrush';
import { competitiveBrief } from '@/lib/competitive-brief';
import { writerFailure } from '@/lib/writer-failure';
import { reportError } from '@/lib/report';

export const runtime = 'nodejs';
// 300, like every other route that writes a post. At 60 the Content Generator
// was the one door with a sixty-second clock in front of a step that now
// researches keywords, reads the competition, writes with retries and
// verifies the citation — so it died mid-write on an ordinary social post
// and the page said only "Generation failed. Please try again."
export const maxDuration = 300;

const ALLOWED_TYPES: ContentType[] = ['social', 'blog', 'email', 'video', 'ad'];

const ALLOWED_MODELS: Record<Provider, string[]> = {
  anthropic: ['claude-sonnet-4-5', 'claude-opus-4-1', 'claude-haiku-4-5'],
  openai: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo'],
};

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    // Accept both { topic } and the dashboard's { prompt } naming.
    const rawTopic = body?.topic ?? body?.prompt;
    const { audience, tone, channels, provider, model, type } = body || {};
    // `topic` used to be checked for truthiness only, then interpolated straight
    // into the prompt. A non-string arrived as "[object Object]" instead of a
    // 400, and an arbitrarily long one went to a paid model unbounded. Sibling
    // paths already clamp (researchTopic 2000, transform 8000); match them.
    if (typeof rawTopic !== 'string' || !rawTopic.trim()) {
      return NextResponse.json({ error: 'topic required' }, { status: 400 });
    }
    const topic = rawTopic.trim().slice(0, 2000);
    const allowed: Provider[] = ['anthropic', 'openai'];
    const p: Provider | undefined =
      provider && allowed.includes(provider) ? provider : undefined;

    const contentType: ContentType | undefined =
      type && ALLOWED_TYPES.includes(type) ? type : undefined;

    // Only forward a model if it's a known model for the resolved provider.
    const resolvedProvider: Provider =
      p || (process.env.AI_PROVIDER === 'openai' ? 'openai' : 'anthropic');
    const safeModel =
      typeof model === 'string' && ALLOWED_MODELS[resolvedProvider].includes(model)
        ? model
        : undefined;

    // Require an authenticated user before spending AI credits.
    const sb = await supabaseServer();
    const { data: { user } } = await sb.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
    }
    // Spends the brand's shared AI and Semrush budget, so the allowlist applies.
    if (!isAllowedEmail(user.email)) {
      return NextResponse.json(
        { error: 'forbidden', message: 'This account is not authorized for this workspace.' },
        { status: 403 },
      );
    }


    // Rate limit before spending AI credits (fails open if usage_events is absent).
    const rl = await checkRateLimit(user.id, 'generate');
    if (!rl.ok) {
      return NextResponse.json(
        { error: 'rate_limited', limit: rl.limit },
        { status: 429, headers: { 'Retry-After': String(rl.retryAfterSec) } }
      );
    }

    // Load the signed-in user's Brand Brain profile (optional).
    // Shared with the assistant, which used to load nothing at all.
    const brand = await loadBrandContext(sb, user.id);

    // Load the user's recent top-performing posts to bias generation (optional).
    let performanceHint: string | undefined;
    try {
      const { data: rows } = await supabaseAdmin()
        .from('post_metrics')
        .select('network, external_id, text, published_at, impressions, engagement')
        .eq('user_id', user.id)
        .order('engagement', { ascending: false })
        .limit(5);
      if (rows && rows.length) {
        const metrics: NormalizedMetric[] = rows.map((r: any) => ({
          network: r.network,
          externalId: r.external_id ?? null,
          text: r.text ?? null,
          publishedAt: r.published_at ?? null,
          impressions: r.impressions ?? 0,
          engagement: r.engagement ?? 0,
        }));
        performanceHint = summarizeTopPerformers(metrics) || undefined;
      }
    } catch {
      // ignore performance-load failures; generation proceeds without the hint.
    }

    // Semrush pre-filter: generateContentPack() now runs the Keyword Brief
    // itself (cache-first, budget-guarded, never blocking) and stamps the pack
    // with `_semrush` provenance — this route just surfaces the result.
    // Every draft knows the competition (lib/competitive-brief.ts): the top
    // three for the subject, mirrored in the Brand Brain's voice.
    const rivals = await competitiveBrief(topic);
    const { provider: used, pack, keywordBrief, semrush } = await generateContentPack({
      topic,
      audience,
      tone,
      channels,
      provider: p,
      model: safeModel,
      contentType,
      brand,
      performanceHint,
      landscapeHint: rivals.hint || undefined,
      // The writer's retry plan is sized to this rather than to a fixed 3 x 30s.
      budgetMs: 200_000,
    });
    const keywordSource: string = semrush?.source ?? 'none';
    const keywordsApplied: string[] = semrush?.keywords ?? [];
    // WHY the lookup produced nothing, so the dashboard can say the true
    // reason instead of guessing "the API key is not set" — which was wrong
    // every time the real cause was the unit floor, an unentitled key or an
    // empty result. The mapping lives in lib/semrush-reason.ts.
    const keywordReason: string = semrush?.reason ?? 'ok';
    // Advisory content-safety review (medical domain). Never blocks generation.
    let safetyAdvisory: { code: string; message: string }[] = [];
    try {
      safetyAdvisory = reviewPack(pack as unknown as Record<string, unknown>);
    } catch {
      // ignore review failures; content is returned regardless.
    }
    // Learnings: log which keywords this draft applied (best-effort).
    if (keywordBrief) {
      void recordDraftKeywords(user.id, topic, keywordBrief);
    }
    return NextResponse.json(
      safetyAdvisory.length
        ? { provider: used, pack, safetyAdvisory, keywordsApplied, keywordSource, keywordReason, keywordBrief }
        : { provider: used, pack, keywordsApplied, keywordSource, keywordReason, keywordBrief }
    );
  } catch (e: any) {
    // The provider helpers throw with the upstream response body attached
    // (`anthropic 429: {...}`), which carries account and quota detail. Log it,
    // return a generic message - /api/metricool/schedule already does this.
    reportError('generate', e);
    // No keywords, no post — said as such (lib/keyword-fallback.ts): this is a
    // refusal by rule, not a failure to retry.
    if (e instanceof NoKeywordsError) {
      return NextResponse.json(
        { error: 'Not written: no keywords could be researched for this idea, and every post is written around researched keywords. Give the idea a clearer subject and try again.' },
        { status: 422 },
      );
    }
    // The cause, in plain words and without the provider's body
    // (lib/writer-failure.ts): a timeout, a refused key, an empty wallet and
    // a busy minute each read differently and want different things done.
    return NextResponse.json(
      { error: 'The post could not be written: ' + writerFailure(e) + '.' },
      { status: 502 }
    );
  }
}

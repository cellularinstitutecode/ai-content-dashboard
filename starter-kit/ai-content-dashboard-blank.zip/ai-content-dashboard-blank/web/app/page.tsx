'use client';

import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useLiveContent } from "@/components/LiveContentProvider";
import SemrushPanel from "./SemrushPanel";
import AutopilotQueue from "./AutopilotQueue";
import ImageStudio from "./ImageStudio";
import CollapsibleSection from "@/components/CollapsibleSection";
import SystemStatus from "@/components/SystemStatus";
import ProcessTracker, { makeSteps, stepActive, stepError, stepSkip, stepsDone, type ProcessStep } from "@/components/ProcessTracker";
import { announce, onRefresh, fetchDrafts, fetchPosts } from "@/components/refreshBus";
import { tightestLimit, networkLabel, parseVideoUrl, draftLabel, PUBLISH_NETWORKS, DEFAULT_VIDEO_NETWORKS, mediaProblem } from "@/lib/composer";
import { filterQueue, matchesQueueSearch } from "@/lib/queue-search";
import MediaPicker from "@/components/MediaPicker";
import SchedulePack from "@/components/SchedulePack";
import HeroImagePicker, { downscale } from "@/components/HeroImagePicker";
import { MAX_IDEA_PICTURES, topicFromPicture, type PictureBrief } from "@/lib/picture-brief";
import HeroImageControls from "@/components/HeroImageControls";
import YouTubeStats from "@/components/YouTubeStats";
import QueueCalendar from "@/components/QueueCalendar";
import { cursorOf, defaultDay, groupByDay, type MonthCursor } from "@/lib/queue-calendar";
import StrategyDrop from "@/components/StrategyDrop";
import { useWorkspace } from "@/components/workspace";
import { appliesTo as complianceApplies, checkCompliance, complianceNetworksLabel, ensureAviso } from "@/lib/compliance";
import { BRAND_NAME } from "@/lib/brand-identity";
import { PanelLoader } from "@/components/LoadingScreen";
import Link from 'next/link';
import { friendlyError, friendlyErrorFromResponse, friendlyImageError } from '@/lib/friendly-error';
import { METRICOOL_BLOG_ID, METRICOOL_USER_ID, metricoolPlannerUrl } from '@/lib/metricool-links';
import { postStatusMeta, isAwaitingApproval } from '@/lib/post-mode';
import { mapLimit } from '@/lib/map-limit';
import { findDuplicatePosts } from '@/lib/duplicate-posts';
import { sheetRowUrl, sheetRowLabel, sheetRowTitle } from '@/lib/sheet-link';
import { semrushDraftNote } from '@/lib/semrush-reason';
import { keywordSourceNote } from '@/lib/keyword-fallback';
import { looksInternal, professionalTitle } from '@/lib/post-title';
import { imageUnshippable } from '@/lib/image-verdict';
import { fmtScheduleDateTime, fmtScheduleTime, scheduleDateKey, scheduleTzLabel, schedulePresetValue, scheduleInputValue, scheduleInstantFromInput } from '@/lib/schedule-clock';

// The visible pipeline every manual generation walks through. Steps light up
// as the real calls behind them start/finish so the viewer can follow the
// process live instead of staring at a spinner.
const GEN_STEPS = [
  { id: 'research', label: 'Keyword research', detail: 'Checking live search volumes and difficulty…' },
  { id: 'draft', label: 'AI drafting', detail: 'Writing your multi-channel content pack…' },
  { id: 'save', label: 'Saving to library', detail: 'Storing the draft so nothing is lost…' },
  { id: 'image', label: 'Hero image', detail: 'Generating an on-brand visual with the OpenAI image pipeline…' },
  { id: 'verify', label: 'Machine verification', detail: 'Confirming the image is a text-free content image (no words/letters, no warped anatomy, no logos) — text triggers an automatic regeneration…' },
];

type Provider = 'anthropic' | 'openai';
type ContentType = 'social' | 'blog' | 'email' | 'video' | 'ad';

const PROVIDERS: { id: Provider; label: string; models: { id: string; label: string }[] }[] = [
{ id: 'anthropic', label: 'Claude (Anthropic)', models: [
{ id: 'claude-sonnet-4-5', label: 'Claude Sonnet 4.5' },
{ id: 'claude-opus-4-1', label: 'Claude Opus 4.1' },
{ id: 'claude-haiku-4-5', label: 'Claude Haiku 4.5' },
]},
{ id: 'openai', label: 'OpenAI', models: [
{ id: 'gpt-4o', label: 'GPT-4o' },
{ id: 'gpt-4o-mini', label: 'GPT-4o mini' },
{ id: 'gpt-4-turbo', label: 'GPT-4 Turbo' },
]},
];

const CONTENT_TYPES: { id: ContentType; label: string; hint: string }[] = [
{ id: 'social', label: 'Social Post', hint: 'Short caption with hashtags for Instagram/X/LinkedIn/Facebook.' },
{ id: 'blog', label: 'Blog Article', hint: 'Long-form SEO-friendly article with H2/H3 structure.' },
{ id: 'email', label: 'Email Campaign', hint: 'Subject line + preview text + body for newsletter.' },
{ id: 'video', label: 'Video Script', hint: 'Hook + scenes + CTA for short-form video (Reels/TikTok/Shorts).' },
{ id: 'ad', label: 'Ad Copy', hint: 'Headline variations + body + CTA for Meta/Google Ads.' },
];

// Onboarding steps shown in the dismissible "How this works" strip so a
// first-time viewer understands the create -> repurpose -> schedule flow.
const ONBOARD_STEPS: { title: string; body: string }[] = [
{ title: '1 · Create', body: 'Describe your idea and generate a ready-to-post content pack for every channel.' },
{ title: '2 · Images', body: 'Every AI visual is generated and machine-verified text-free in the Image Studio.' },
{ title: '3 · Repurpose', body: 'Paste a long YouTube or Vimeo URL and OpusClip turns it into short vertical clips.' },
{ title: '4 · Schedule', body: 'Send posts for review, then press Approve in your queue — Metricool publishes them for you.' },
{ title: '5 · Library', body: 'Everything you make is saved under Recent Drafts so you can edit, play, or reuse it.' },
];
const ONBOARD_KEY = 'chi_onboarding_dismissed_v1';

// The channel list, its per-network character ceilings and the "this feed needs
// a video" rule all live in lib/composer.ts now. This file kept its own copy of
// the list — as did app/calendar/page.tsx — so YouTube and TikTok stayed
// unpickable for months while Metricool had both connected and
// /api/metricool/schedule had both mapped.

// Seed topics for the Trending topics panel. These are a generic starting set
// the team replaces with its own — NOT scraped live — and only ever pre-fill the
// generator prompt for a human to review. Editable in the UI and remembered per
// browser via localStorage.
const DEFAULT_TRENDING: string[] = [
'The question customers ask us most',
'A common myth in our field, explained',
'Behind the scenes: how we work',
'Three tips to get more from what we offer',
'What to look for when choosing a provider',
'A customer story worth sharing',
];
const TRENDING_KEY = 'trending_topics_v1';

// Where a Metricool brand's planner lives, so we can deep-link a queued post
// straight to the place it gets approved. The DEFAULT brand; the Publishing
// panel's brand switcher overrides it everywhere via activeBlogId.
//
// Moved to lib/metricool-links.ts, unchanged, once the Video Library's sheet
// toolbar needed the same link: two copies of a URL that must carry both ids
// is exactly how the version WITHOUT userId came to exist, and that one landed
// on Metricool's "There was an error that prevented loading the page".

// Deep-link into the Semrush Keyword Magic Tool for keyword research, pre-filled
// with the topic the user is working on. Opens in a new tab; no credentials involved.
function semrushUrl(keyword: string): string {
  const kw = (keyword || '').trim();
  const base = 'https://www.semrush.com/analytics/keywordmagic/';
  return kw ? (base + '?q=' + encodeURIComponent(kw) + '&db=us') : (base + '?db=us');
}


function metricoolMetrics(a: any): { label: string; value: any }[] {
if (!a || typeof a !== 'object') return [];
const found: { label: string; value: any }[] = [];
const seen = new Set<string>();
const wanted: [string, RegExp][] = [
['Followers', /followers|fans|subscribers/i],
['Reach', /reach/i],
['Impressions', /impressions|views/i],
['Engagement', /engagement|interactions/i],
];
const walk = (obj: any, depth: number) => {
if (!obj || depth > 4 || typeof obj !== 'object') return;
for (const k of Object.keys(obj)) {
const v = obj[k];
if (typeof v === 'number' && isFinite(v)) {
for (const [label, re] of wanted) {
if (!seen.has(label) && re.test(k)) { found.push({ label, value: v }); seen.add(label); }
}
} else if (v && typeof v === 'object') {
walk(v, depth + 1);
}
}
};
walk(a, 0);
return found.slice(0, 4);
}

// A finished Opus clip (mirrors OpusClip in lib/opus.ts).
type Clip = { id: string; title: string; text: string; description: string; hashtags: string; durationMs: number; preview: string; export: string };

// The format picker that used to live here was removed. It set local state,
// echoed the chosen ratio back under "This run" as if it had been applied, and
// was never sent to Opus - clipVideo() posts { videoUrl, title, language } and
// nothing in lib/opus.ts or the clip route has ever read an aspect ratio. A
// control that reports a setting it does not apply is worse than no control.
// Opus uses the ratio configured on the project in its own dashboard.

function clipsOf(d: any): Clip[] {
const c = d && d.pack && d.pack.clips;
return Array.isArray(c) ? c : [];
}

function fmtDuration(ms: number): string {
const s = Math.round((Number(ms) || 0) / 1000);
const m = Math.floor(s / 60);
const r = s % 60;
return m + ':' + String(r).padStart(2, '0');
}

// Friendly date/time for a scheduled post, e.g. "Sep 1, 9:00 AM".
//
// Always rendered on the SCHEDULE clock, never the browser's. The composer
// promises "times are in <schedule zone>" and the server schedules that way; when this
// used to render in the viewer's zone, a coordinator two zones away was shown
// 9:00 AM in the composer and 7:00 AM in the queue for the very same post.
const fmtDateTime = fmtScheduleDateTime;

function toArray(x: any): any[] {
if (Array.isArray(x)) return x;
if (x && Array.isArray(x.data)) return x.data;
if (x && Array.isArray(x.drafts)) return x.drafts;
if (x && Array.isArray(x.rows)) return x.rows;
if (x && Array.isArray(x.items)) return x.items;
return [];
}


export default function Dashboard({ mode = 'overview' }: { mode?: 'overview' | 'draft' } = {}) {
const isDraft = mode === 'draft';
const { output, setOutput, drafts, setDrafts, stats, setStats } = useLiveContent();
const workspace = useWorkspace();
const [provider, setProvider] = useState<Provider>('anthropic');
const [model, setModel] = useState<string>('claude-sonnet-4-5');
const [type, setType] = useState<ContentType>('social');
const [prompt, setPrompt] = useState('');
/**
 * PICTURES AS THE IDEA, ALONGSIDE THE PROMPT. Dropped on the zone beside the
 * idea box (or picked, or pasted into the box), each read by the vision model
 * (app/api/generate/see): what it shows and the post it suggests. What is
 * typed in the box is never overwritten — the pictures and the words go to
 * the writer together (lib/picture-brief.ts topicFromPicture): keywords, the
 * competition, the brand's voice, the citation check, as for a typed idea.
 * The first picture becomes the post's picture instead of one being picked
 * or made; the others set the scene.
 */
type IdeaImage = { key: string; dataUrl: string; name: string; brief: PictureBrief };
const [ideaImages, setIdeaImages] = useState<IdeaImage[]>([]);
/** How many pictures are being read right now. */
const [ideaImageBusy, setIdeaImageBusy] = useState(0);
const [ideaDrag, setIdeaDrag] = useState(false);
const [copied, setCopied] = useState(false);
const [loading, setLoading] = useState(false);
const [err, setErr] = useState<string | null>(null);
// A failed load used to leave every panel in its EMPTY state, so a 401, a 429
// or a dropped connection all read as "you have no drafts / nothing queued".
// These two carry the difference: loadError is "we could not read your data",
// actionMsg is "the thing you just clicked did not happen".
const [loadError, setLoadError] = useState<string | null>(null);
const [actionMsg, setActionMsg] = useState<string | null>(null);
const [keywordsApplied, setKeywordsApplied] = useState<string[]>([]);
const [keywordSource, setKeywordSource] = useState<string>('none');
// WHY there was no live keyword data, straight from /api/generate. Held so the
// note under the output can state the true reason instead of assuming one.
const [keywordReason, setKeywordReason] = useState<string | undefined>(undefined);
const [approvingId, setApprovingId] = useState<string | null>(null);
// The post whose video is being fetched right now. Separate from
// approvingId because attaching is NOT approving — the post stays exactly
// where it is in the queue, waiting for a person.
const [attachingId, setAttachingId] = useState<string | null>(null);
/** Recent Drafts: the ones ticked for "Delete selected". */
const [pickedDrafts, setPickedDrafts] = useState<Set<string>>(() => new Set());
/** What the last bulk delete did — shown IN the Recent Drafts panel, beside the buttons, not at the top of the page. */
const [draftsMsg, setDraftsMsg] = useState<{ text: string; bad: boolean } | null>(null);
const [bulkDeleting, setBulkDeleting] = useState(false);
/**
 * The pack as the writer returned it — each channel's own words.
 *
 * `output` is the FORMATTED string: one block of text for a person to read. It
 * cannot be scheduled, because scheduling means sending Instagram its caption
 * and LinkedIn its post, and by then the two are one string. So the pack is
 * kept as well, and lib/pack-schedule.ts turns it into one post per channel.
 */
const [genPack, setGenPack] = useState<Record<string, unknown> | null>(null);
/** Where the generator's picture came from, and why, for the note under the image controls. */
const [genImageFrom, setGenImageFrom] = useState<{ source: string; notes: string[] } | null>(null);
const [genImage, setGenImage] = useState<{ url: string; alt?: string; model?: string; prompt?: string; verification?: { status?: string; score?: number | null; issues?: string[]; advisory?: string[]; textDetected?: boolean } } | null>(null);
const [genImageLoading, setGenImageLoading] = useState(false);
const [lastDraftId, setLastDraftId] = useState<string | null>(null);
const [modalImgBusy, setModalImgBusy] = useState(false);

// Live process pipeline for the Content Generator (see GEN_STEPS above).
const [proc, setProc] = useState<ProcessStep[] | null>(null);
const procTimers = useRef<any[]>([]);
// Monotonic run id: late responses from a superseded generation (e.g. its
// hero image resolving after the user hit Generate again) are discarded
// instead of scrambling the new run's tracker/image.
const genRun = useRef(0);
function clearProcTimers() { procTimers.current.forEach((t) => clearTimeout(t)); procTimers.current = []; }
function procAdvanceLater(id: string, ms: number) {
  procTimers.current.push(setTimeout(() => setProc((p) => (p ? stepActive(p, id) : p)), ms));
}
useEffect(() => () => clearProcTimers(), []);

// Interconnection: refetch whatever another panel (Image Studio, Autopilot,
// assistant) announces it changed, so this page never shows stale data.
useEffect(() => {
  return onRefresh((scopes) => {
    if (scopes.includes('drafts')) refreshDrafts(0, false);
    if (scopes.includes('stats')) refreshStats();
    if (scopes.includes('posts')) refreshPosts();
    // The Metricool panels sit directly under the Schedule button and used to
    // stay stale after it was pressed, so they refresh on a posts change too.
    if (scopes.includes('insights') || scopes.includes('posts')) loadInsights(activeBlogId);
    if (scopes.includes('insights')) loadAnalytics(true);
  });
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, []);

// The shared topic: whatever Semrush, Keyword Intelligence, the Image Studio,
// the calendar or the templates page is working on lands in the generator's
// prompt, and anything typed here travels back out to them.
useEffect(() => {
  const incoming = (workspace.topic || '').trim();
  if (incoming && incoming !== prompt.trim()) setPrompt(incoming);
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, [workspace.topic]);

// Every research finding is actionable: clicking one loads it into the
// generator prompt and shares it with every other panel. They used to be
// inert text.
const applyIdea = (text: string, source = 'research') => {
  const v = (text || '').trim();
  if (!v) return;
  setPrompt(v);
  publishTopic(v, source);
  if (typeof document !== 'undefined') {
    document.getElementById('content-generator')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
};

const publishTopic = (value: string, source = 'generator') => {
  const v = value.trim();
  if (v && v !== (workspace.topic || '').trim()) workspace.setTopic(v, { source });
};

const [mLoading, setMLoading] = useState(false);
const [mAnalytics, setMAnalytics] = useState<any>(null);
const [mNetworks, setMNetworks] = useState<string[]>(["facebook"]);
const toggleNetwork = (n: string) => setMNetworks((prev) => prev.includes(n) ? prev.filter((x) => x !== n) : [...prev, n]);
const [mText, setMText] = useState('');
// THE TITLE, which used to be the file's name.
//
// schedulePost sent the media label as the title — the line under the video —
// so YouTube and TikTok were handed
// "Video_PartnerxBrandName_Uploader.mp4" as the name of the
// post. There was no way to see it before sending and no way to change it.
const [mTitle, setMTitle] = useState('');
/**
 * The draft this post is continuing, when it is one.
 *
 * Carried so "Write the title" can read that draft's transcript — the words the
 * speaker actually said are what make the title about the video rather than
 * about the caption.
 */
const [mDraftId, setMDraftId] = useState<string>('');
/** The keyword research behind this post: from the draft, or run from here. */
const [mKeyword, setMKeyword] = useState<{ primary: string; volume: number | null } | null>(null);
const [mKwBusy, setMKwBusy] = useState(false);
const [mDate, setMDate] = useState('');
const [mStatus, setMStatus] = useState<string | null>(null);
const [mBusy, setMBusy] = useState(false);
// What was last sent, so the same text is not sent twice by a second press —
// and so the text can STAY in the box after a send. It used to be cleared on
// success, with the confirmation in grey below the button: the person saw
// their post vanish and an amber "Write the post first." take its place.
const [mSent, setMSent] = useState<{ key: string; networks: string[] } | null>(null);
  // Auto-publish was removed deliberately. The dashboard's contract is that
  // nothing reaches a live channel without a human approving it inside
  // Metricool, and a "Publish now" button in this composer contradicted that
  // promise three lines below where the promise is made. Everything now goes
  // out as a Metricool draft; approval happens there.

  // --- Composer validation -------------------------------------------------
  // Everything the Send button depends on is derived here so the button state,
  // the counter and the inline messages can never disagree with each other.
  const [nowTick, setNowTick] = useState<Date | null>(null);
  useEffect(() => {
    setNowTick(new Date());
    const id = setInterval(() => setNowTick(new Date()), 30_000);
    return () => clearInterval(id);
  }, []);

  // The advertising rule (lib/compliance.ts): covered posts need a REF
  // citation when they make a health claim, and the AVISO line only when a
  // permit number is configured. The permit comes from Brand Brain ('' = none:
  // no AVISO line is required, shown or offered). `j.aviso`, when the brand
  // route provides it, is the server's resolved number (Brand Brain, then the
  // AVISO_PUBLICIDAD environment variable).
  const [avisoNumber, setAvisoNumber] = useState<string>('');
  // The display name: Brand Brain's, else the deployment's NEXT_PUBLIC_BRAND_NAME.
  const [brandName, setBrandName] = useState<string>(BRAND_NAME);
  useEffect(() => {
    let alive = true;
    fetch('/api/brand').then((r) => (r.ok ? r.json() : null)).then((j) => {
      const n = String(j?.aviso || j?.brand?.aviso_publicidad || '').trim();
      if (alive && n) setAvisoNumber(n.toUpperCase());
      const nm = String(j?.brand?.name || '').trim();
      if (alive && nm) setBrandName(nm);
    }).catch(() => undefined);
    return () => { alive = false; };
  }, []);
  const mCompliance = complianceApplies(mNetworks) && mText.trim() ? checkCompliance(mText, avisoNumber) : null;
  // A post handed over from the Sources section (a video's copy, a Drive
  // photo as the hero image). Consumed once, then cleared.
  const handoffSeen = useRef(0);
  useEffect(() => {
    const nonce = workspace.handoffNonce || 0;
    if (!nonce || nonce === handoffSeen.current) return;
    handoffSeen.current = nonce;
    if (workspace.handoffText) setMText(workspace.handoffText);
    if (workspace.handoffMedia) { setMMedia(workspace.handoffMedia); setMMediaLabel(workspace.handoffMediaLabel || 'Image from Drive'); }
    // THE TITLE AND THE DRAFT ARE PART OF THE HAND-OFF, AND ARE ALWAYS SET.
    //
    // Not "set when present": a hand-off that carries no title must CLEAR the
    // one in the box. They did not survive review otherwise — a post about
    // one subject sat under the title of another ("<Topic> at <Brand>"),
    // left behind by the draft opened before it, and that title is
    // what YouTube and TikTok would have published.
    const handedTitle = workspace.handoffTitle || '';
    setMTitle(handedTitle);
    setMDraftId(workspace.handoffDraftId || '');
    setMKeyword(null);
    setMSent(null);
    // WRITTEN ON ARRIVAL, not on a button press.
    //
    // "Use in post with video should extract the title automatically on the
    // draft without us having to click on it." A draft prepared before the
    // titles were written from the video carries its FILE NAME, and a draft
    // from the sheet carries nothing — so the box would sit there holding
    // "Reel_TopicName_Uploader.mp4", or empty, waiting to be noticed.
    //
    // Only when there is nothing usable: a title somebody wrote, or one this
    // app already wrote from the transcript, is never overwritten by this.
    if (!handedTitle || looksInternal(handedTitle, {})) {
      const draftId = workspace.handoffDraftId || '';
      const text = workspace.handoffText || '';
      if (draftId || text.trim()) {
        setMKwBusy(true);
        void fetch('/api/title', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text, draftId: draftId || undefined }),
        })
          .then((r) => (r.ok ? r.json() : null))
          .then((j) => { const t = String(j?.title || '').trim(); if (t) setMTitle(t); })
          .catch(() => undefined)
          .finally(() => setMKwBusy(false));
      }
    }
    setMSource(workspace.handoffTab && workspace.handoffRow >= 2 ? { tab: workspace.handoffTab, row: workspace.handoffRow, link: workspace.handoffLink, format: workspace.handoffFormat || '' } : null);
    // THE CHANNELS COME WITH IT.
    //
    // The hand-off carried the copy, the video and the sheet row, and said
    // nothing about where it should go — so a reel arrived with the composer's
    // cold-start default of Facebook ticked and YouTube, LinkedIn and TikTok
    // all off. Every video sent by hand had its channels re-picked, and a
    // missed one went out on the wrong network entirely.
    //
    // The SHEET ROW is the signal, not the format. Only the Video Library's
    // video hand-off carries a tab and row (SourcesView `sendToComposer`); a
    // Drive photo and a calendar caption carry neither, and those keep whatever
    // is already ticked. handoffFormat is NOT usable here — it holds the
    // sheet's FORMATO ("Vertical 9:16"), a different vocabulary from the
    // generator's "video"/"blog"/"email", so platformsForFormat would read a
    // reel as Instagram and Facebook: the exact channels this is fixing.
    if (workspace.handoffTab && workspace.handoffRow >= 2) setMNetworks(DEFAULT_VIDEO_NETWORKS);
    setMStatus(null);
    workspace.patch({ handoffText: '', handoffTitle: '', handoffDraftId: '', handoffMedia: '', handoffMediaLabel: '', handoffTab: '', handoffRow: 0, handoffLink: '', handoffFormat: '' });
    try { scrollToPublisher(); } catch { /* not mounted yet */ }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workspace.handoffNonce]);
  // Declared above the send gate on purpose: mProblem reads mMedia, and a
  // `const` used before its declaration is a temporal-dead-zone crash, not a
  // warning.
  const [mMedia, setMMedia] = useState<string>("");
  const [mMediaLabel, setMMediaLabel] = useState<string>("");
  // The sheet row the video was handed over from, sent with the post so the
  // queue can name it. Cleared with the media.
  const [mSource, setMSource] = useState<{ tab: string; row: number; link: string; format: string } | null>(null);
  // The next free planner slots (on the schedule timezone), from the server: the
  // time chips and the box's default. Not "tomorrow 9 AM" on the browser's clock.
  const [mSlots, setMSlots] = useState<string[]>([]);
  useEffect(() => {
    let alive = true;
    fetch('/api/schedule/next-slots?n=3').then((r) => r.ok ? r.json() : null).then((j) => {
      const list = j && Array.isArray(j.slots) ? j.slots.map((s: unknown) => String(s || '')).filter(Boolean) : [];
      if (!alive || !list.length) return;
      setMSlots(list);
      setMDate((prev) => prev || scheduleInputValue(list[0]));
    }).catch(() => undefined);
    return () => { alive = false; };
  }, []);
  /** Is a video-only channel selected? Drives the picker's hint. */
  const mNeedsMedia = Boolean(mediaProblem(mNetworks, ''));
  const mChars = mText.trim().length;
  const mLimit = tightestLimit(mNetworks);
  const mOverBy = mLimit ? mChars - mLimit.limit : 0;
  const mTooLong = mOverBy > 0;
  // `min` is only applied once we know the browser's clock, so the server-rendered
  // HTML never ships a stale floor.
  // Both on the SCHEDULE clock. localDateTimeValue and new Date(box value)
  // were the browser's clock, so a UTC machine offered "14:18" as now and
  // sent it as 2:18 PM on the schedule clock.
  const mMinDateTime = nowTick ? scheduleInputValue(nowTick) : undefined;
  const mInstant = mDate ? scheduleInstantFromInput(mDate) : null;
  const mDateInPast = Boolean(mDate && nowTick && mInstant && Date.parse(mInstant) < nowTick.getTime());
  // WHICH networks, and WHAT is actually wrong.
  //
  // This said "Instagram and Facebook posts need a REF line citing a scientific
  // study" for every failure — while the rule had covered LinkedIn, TikTok and
  // YouTube for a week, and while a caption that HAD a REF line and was only
  // missing its DOI got the same words. So somebody with LinkedIn, YouTube and
  // TikTok ticked and a REF line already written was told to add a REF line for
  // two networks they were not posting to.
  const complianceRefusal = (check: { missing: readonly string[] }, networks: readonly string[]): string => {
    const who = complianceNetworksLabel(networks);
    if (check.missing.includes('doi')) return 'Your REF line has no DOI. ' + who + ' posts need one \u2014 add something like 10.1016/j.example.2024.01.001 to that line.';
    if (check.missing.includes('ref')) return who + ' posts need a REF line citing a scientific study, with a DOI.';
    return 'Add the AVISO DE PUBLICIDAD line before sending.';
  };

  const mProblem =
    !mNetworks.length ? 'Pick at least one channel.'
    : !mText.trim() ? 'Write the post first.'
    : mTooLong && mLimit ? networkLabel(mLimit.network) + ' allows ' + mLimit.limit.toLocaleString() + ' characters. Trim ' + mOverBy.toLocaleString() + '.'
    : !mDate ? 'Pick the date and time it should go out.'
    : mDateInPast ? 'That time has already passed. Pick a future time.'
    : mediaProblem(mNetworks, mMedia) ? mediaProblem(mNetworks, mMedia)
    : mCompliance && !mCompliance.ok ? complianceRefusal(mCompliance, mNetworks)
    : null;
  // The composer as one string: the same post, to the same channels, at the
  // same time, with the same video. Change any of it and Send is live again.
  const mKey = JSON.stringify([mText.trim(), [...mNetworks].sort(), mDate, mMedia]);
  const mAlreadySent = mSent !== null && mSent.key === mKey;
  const mCanSend = !mProblem && !mBusy && !mAlreadySent;
  function platformsForFormat(fmt: string): string[] {
    // A video draft went to Instagram and Facebook — the two channels that are
    // not what the brand's video work is for. Same default the sweep uses.
    if (fmt === "video") return DEFAULT_VIDEO_NETWORKS;
    if (fmt === "blog" || fmt === "email") return ["linkedin", "facebook"];
    return ["instagram", "facebook", "linkedin"];
  }
  function scrollToPublisher() {
    if (typeof document !== "undefined") { const el = document.getElementById("section-publish"); if (el) el.scrollIntoView({ behavior: "smooth", block: "start" }); }
  }
  // ?draft=<id>: the link every "Open draft" the assistant gives, and the
  // "Continue in Draft" chip. It was never read — the parameter sat in the
  // address bar and nothing opened — so on the Dashboard the draft is opened
  // in Recent Drafts, and on the Draft page it lands in the writer.
  const handedOff = useRef(false);
  useEffect(() => {
    if (handedOff.current || typeof window === 'undefined') return;
    const id = new URLSearchParams(window.location.search).get('draft');
    if (!id) return;
    handedOff.current = true;
    (async () => {
      try {
        const r = await fetch('/api/drafts?id=' + encodeURIComponent(id));
        if (!r.ok) return;
        const j = await r.json().catch(() => null);
        const d = j && (j.draft || (j.id ? j : null));
        if (!d) return;
        if (isDraft) {
          prefillComposerFromDraft(d);
          document.getElementById('section-create')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } else {
          await openDraft(d);
        }
        // Read once: a refresh must not reopen it.
        const url = new URL(window.location.href); url.searchParams.delete('draft');
        window.history.replaceState(null, '', url.pathname + (url.search || '') + url.hash);
      } catch { /* the draft stays where it is */ }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDraft]);

  function prefillComposerFromDraft(d: any) {
    try {
      const fmt = String((d && d.pack && d.pack.format) || (d && d.format) || "social");
      const secs = formatSections(d && d.pack);
      const body = secs.length ? secs.map((s: any) => s.text).join("\n\n") : (typeof (d && d.pack) === "string" ? d.pack : "");
      if (body) setMText(body);
      // HARD RULE at the ship-point: never prefill the scheduler with an
      // image the checker flagged for text — reroll it in the Image Studio
      // first. Content images must be text-free wherever they publish.
      const heroImg = d && d.pack && d.pack._image;
      // Text, or a banned prop in frame: never attachable (lib/image-verdict.ts).
      const heroHasText = Boolean(heroImg && imageUnshippable(heroImg.verification));
      const heroUrl = heroImg && heroImg.url && !heroHasText ? String(heroImg.url) : "";
      if (heroUrl) { setMMedia(heroUrl); setMMediaLabel("AI hero image"); }
      else { setMMedia(""); setMMediaLabel(""); setMSource(null); }
      setMNetworks(platformsForFormat(fmt).filter((n) => PUBLISH_NETWORKS.some((p) => p.id === n)));
      setMStatus(null);
      setSelectedDraft(null); setEditingDraft(false);
      scrollToPublisher();
    } catch {}
  }
  function prefillComposerFromClip(c: any) {
    try {
      const caption = cleanCaption(String((c && c.description) || (c && c.text) || ""));
      const tags = String((c && c.hashtags) || "").trim();
      const media = String((c && c.export) || (c && c.preview) || "");
      setMText([caption, tags].filter(Boolean).join("\n\n"));
      setMMedia(media);
      setMMediaLabel(String((c && c.title) || "Clip video"));
      setMNetworks(["instagram", "facebook"].filter((n) => PUBLISH_NETWORKS.some((p) => p.id === n)));
      setMStatus(null);
      setSelectedDraft(null); setEditingDraft(false);
      scrollToPublisher();
    } catch {}
  }
  // --- Comprehensive Publishing panel state (brand switcher + live insights) ---
  // The default Metricool brand: NEXT_PUBLIC_METRICOOL_BLOG_ID ('' until configured).
  const [activeBlogId, setActiveBlogId] = useState<string>(METRICOOL_BLOG_ID);
  const [insights, setInsights] = useState<any>(null);
  const [insightsLoading, setInsightsLoading] = useState(false);
  async function loadInsights(blogId: string) {
    try {
      setInsightsLoading(true);
      const r = await fetch('/api/metricool/insights?blogId=' + encodeURIComponent(blogId));
      // Without this check the error BODY was stored as the insights object, so
      // a rate-limited or expired request rendered as "No recent post data yet".
      if (!r.ok) {
        setInsights(null);
        setLoadError(await friendlyErrorFromResponse(r, 'We could not load your channel numbers.'));
        return;
      }
      const j = await r.json().catch(() => null);
      setInsights(j);
    } catch (e) {
      setInsights(null);
      setLoadError(friendlyError(e, 'We could not reach Metricool just now.'));
    } finally {
      setInsightsLoading(false);
    }
  }

  // --- AI Research & Draft Copilot state ---
  const [researchTopicText, setResearchTopicText] = useState('');
  // Two topic inputs on one page used to drift apart; both now read the same
  // shared value.
  useEffect(() => {
    const incoming = (workspace.topic || '').trim();
    if (incoming && incoming !== researchTopicText.trim()) setResearchTopicText(incoming);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workspace.topic]);
  const [researchNetwork, setResearchNetwork] = useState('instagram');
  const [research, setResearch] = useState<any>(null);
  const [researchLoading, setResearchLoading] = useState(false);
  const [researchError, setResearchError] = useState<string | null>(null);

  async function runResearch() {
    const topic = researchTopicText.trim();
    if (!topic || researchLoading) return;
    setResearchLoading(true);
    setResearchError(null);
    const doFetch = () => fetch('/api/metricool/ai-research', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ topic, provider, network: researchNetwork }),
    });
    try {
      let res = await doFetch();
      if (res.status >= 500) {
        await new Promise((r) => setTimeout(r, 1500));
        res = await doFetch();
      }
      const j = await res.json().catch(() => ({}));
      if (!res.ok) {
        setResearch(null);
        setResearchError(j && j.error === 'unauthorized' ? 'Please sign in to run AI research.' : ((j && j.error) || 'Research is taking longer than usual. Please try again in a moment.'));
      } else {
        setResearch(j);
        workspace.setTopic(topic, { source: 'research' });
      }
    } catch {
      setResearch(null);
      setResearchError('Research failed. Please check your connection and try again.');
    } finally {
      setResearchLoading(false);
    }
  }


// Scheduled / pending-review queue, backed by GET /api/posts. Surfacing this
// is what makes "sent for review" concrete: the post shows up here with its
// status and a link to approve it in Metricool.
const [posts, setPosts] = useState<any[]>([]);
// Several at once. The per-post Approve stays; this ticks posts and sends the
// selection through the same PATCH, one call each, one confirmation for all.
const [selectMode, setSelectMode] = useState(false);
// What is typed in the queue's search box. The TICKS ARE NOT DERIVED FROM IT:
// selectedPosts is keyed by post id and survives a change of search, so a tick
// made under one search is not silently dropped by the next. The bar says how
// many of them the current search is hiding, and the delete confirm names
// every row, so nothing goes without being seen.
const [queueQ, setQueueQ] = useState('');
const [selectedPosts, setSelectedPosts] = useState<Set<string>>(new Set());
const [bulkBusy, setBulkBusy] = useState(false);
// The queue is a month now (components/QueueCalendar.tsx): the day picked on
// it, and the month on screen. Both null until someone picks — the page then
// opens on today, or the next day with something scheduled.
const [queueDay, setQueueDay] = useState<string | null>(null);
const [queueMonth, setQueueMonth] = useState<MonthCursor | null>(null);
const [postsLoading, setPostsLoading] = useState(false);
// The queue is showing posts, but it could not read the drafts behind them —
// so it cannot know which are waiting on a video, and every "Pending video"
// chip is missing. Said out loud, because a missing chip reads as "nothing is
// pending" and that is the opposite of what is known.
const [packsWarning, setPacksWarning] = useState(false);
const [rescheduleId, setRescheduleId] = useState<string | null>(null);
const [rescheduleAt, setRescheduleAt] = useState('');
// The queue post open in the preview: the whole caption, the picture or
// video, the channels and the time — what will actually go out — before
// anyone presses Approve on a two-line excerpt.
const [previewPostId, setPreviewPostId] = useState<string | null>(null);
// The preview's Edit section: the picture editor (new AI image, library photo,
// the title, and notes/prompt for a regeneration). Held as the id of the post
// being edited, so opening another post's preview starts closed.
const [previewEditingId, setPreviewEditingId] = useState<string | null>(null);
const previewEditing = previewPostId != null && previewEditingId === previewPostId;
useEffect(() => {
  if (!previewPostId) return;
  const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setPreviewPostId(null); };
  window.addEventListener('keydown', onKey);
  return () => window.removeEventListener('keydown', onKey);
}, [previewPostId]);

// Trending topics: a curated, editable list (not scraped) that only
// pre-fills the generator prompt for a human to review before anything is made.
const [trending, setTrending] = useState<string[]>(DEFAULT_TRENDING);
const [newTrend, setNewTrend] = useState('');

const [opUrl, setOpUrl] = useState('');
const [opStatus, setOpStatus] = useState<string | null>(null);
const [opBusy, setOpBusy] = useState(false);

// --- Repurpose validation --------------------------------------------------
// Parsed up front so the button, the ring colour and the helper line all agree,
// and so an unusable link can never start a billable Opus job.
const opParsed = parseVideoUrl(opUrl);
const opValid = opParsed.ok;
const opError = !opParsed.ok && opUrl.trim() ? opParsed.reason : '';
const [opTitle, setOpTitle] = useState('');
const [opLang, setOpLang] = useState('en');

const [selectedDraft, setSelectedDraft] = useState<any>(null);
const [editingDraft, setEditingDraft] = useState(false);
const [editTitle, setEditTitle] = useState('');
const [editBody, setEditBody] = useState('');
const [savingEdit, setSavingEdit] = useState(false);

// "How this works" onboarding strip — collapsible. The header stays
// visible so viewers can always reopen it; the collapsed/expanded
// preference is remembered per browser via localStorage.
  const [onboardOpen, setOnboardOpen] = useState(true);
  useEffect(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage.getItem(ONBOARD_KEY) === '0') setOnboardOpen(false);
      // Nothing remembered and a narrow screen: the tour starts folded. One tap opens it.
      else if (typeof window !== 'undefined' && window.localStorage.getItem(ONBOARD_KEY) == null && window.innerWidth < 1024) setOnboardOpen(false);
    } catch {}
  }, []);
  function toggleOnboard() {
    setOnboardOpen((open) => {
      const next = !open;
      try { if (typeof window !== 'undefined') window.localStorage.setItem(ONBOARD_KEY, next ? '1' : '0'); } catch {}
      return next;
    });
  }

// Load any saved trending topics on mount.
useEffect(() => {
try {
if (typeof window === 'undefined') return;
const raw = window.localStorage.getItem(TRENDING_KEY);
if (raw) { const arr = JSON.parse(raw); if (Array.isArray(arr) && arr.length) setTrending(arr.map(String)); }
} catch {}
}, []);
function persistTrending(next: string[]) {
setTrending(next);
try { if (typeof window !== 'undefined') window.localStorage.setItem(TRENDING_KEY, JSON.stringify(next)); } catch {}
}
function addTrend() {
const t = newTrend.trim();
if (!t) return;
if (trending.some((x) => x.toLowerCase() === t.toLowerCase())) { setNewTrend(''); return; }
persistTrending([t, ...trending].slice(0, 24));
setNewTrend('');
}
function removeTrend(t: string) { persistTrending(trending.filter((x) => x !== t)); }
function applyTrend(t: string) {
  publishTopic(t, 'trending');
setPrompt(t);
setType('social');
try { if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'smooth' }); } catch {}
}

  // Smooth-scroll the "How this works" cards to the matching section below,
  // and briefly highlight it so the viewer sees where they landed.
  const STEP_ANCHORS = ['section-create', 'section-images', 'section-repurpose', 'section-publish', 'section-library'];
  function scrollToStep(i: number) {
    try {
      // Sections that arrive folded must unfold before we scroll to them —
      // otherwise the card lands the viewer on a closed header.
      window.dispatchEvent(new CustomEvent('section:open', { detail: STEP_ANCHORS[i] }));
      const el = typeof document !== 'undefined' ? document.getElementById(STEP_ANCHORS[i]) : null;
      // Only the Dashboard's copy can miss: every anchor above renders on
      // Draft, so there the element is always found and this never fires.
      if (!el && !isDraft) { window.location.href = '/draft#' + STEP_ANCHORS[i]; return; }
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        el.classList.add('ring-2', 'ring-accent');
        setTimeout(() => { el.classList.remove('ring-2', 'ring-accent'); }, 1600);
      }
    } catch {}
  }

// Manual "Refresh clips" affordance so the viewer can pull the latest Opus
// render status on demand instead of waiting for the 15s poll.
const [refreshingClips, setRefreshingClips] = useState(false);
async function refreshClips() {
setRefreshingClips(true);
try { await refreshDrafts(0, false); await refreshStats(); } finally { setRefreshingClips(false); }
}

// Draft pagination
const PAGE_SIZE = 10;
const [draftsOffset, setDraftsOffset] = useState(0);
const [draftsTotal, setDraftsTotal] = useState(0);
const [loadingMore, setLoadingMore] = useState(false);

useEffect(() => {
const first = PROVIDERS.find(p => p.id === provider)!;
if (!first.models.some(m => m.id === model)) setModel(first.models[0].id);
}, [provider]);

// On mount: load drafts, stats, the scheduled-posts queue, and (best-effort)
// the latest analytics so the Publishing panel is populated without a click.
useEffect(() => { refreshDrafts(); refreshStats(); refreshPosts(); loadAnalytics(true); warmClips(); }, []);


// Poll clip drafts that are still processing until Opus finishes rendering.
// The webhook is the fast path; this poll is the fallback / live-refresh so a
// user watching the dashboard sees processing -> ready without reloading.
const pollRef = useRef<any>(null);
useEffect(() => {
const pending = (Array.isArray(drafts) ? drafts : []).filter(
(d: any) => d && d.pack && d.pack.kind === 'clip' && d.pack.projectId && d.pack.status !== 'ready' && d.pack.status !== 'failed'
);
if (pending.length === 0) { if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; } return; }
if (pollRef.current) return; // already polling
// setInterval does NOT await its callback. Each tick fetches every pending
// clip job, and the server side of that downloads multi-MB MP4s and uploads
// them to Drive - routinely more than 5s. Ticks therefore overlapped, and
// each concurrent request saw an un-updated draft row (knownClips empty), so
// every one of them re-uploaded the whole set as fresh public Drive files.
// A re-entrancy guard makes a tick that is still running skip the next slot.
let tickInFlight = false;
pollRef.current = setInterval(async () => {
if (tickInFlight) return;
tickInFlight = true;
try {
const current = (Array.isArray(drafts) ? drafts : []).filter(
(d: any) => d && d.pack && d.pack.kind === 'clip' && d.pack.projectId && d.pack.status !== 'ready' && d.pack.status !== 'failed'
);
let changed = false;
for (const d of current) {
try {
const r = await fetch('/api/opus/clip?projectId=' + encodeURIComponent(d.pack.projectId));
if (!r.ok) continue;
const j = await r.json().catch(() => null);
if (j && j.status === 'ready' && Array.isArray(j.clips) && j.clips.length > 0) changed = true;
} catch {}
}
if (changed) refreshDrafts(0, false);
} finally { tickInFlight = false; }
}, 5000);
return () => { if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; } };
}, [drafts]);

  // Keep the open draft detail in sync as drafts refresh, so clips appear the
  // instant Opus finishes rendering without needing to close and reopen.
  useEffect(() => {
    if (!selectedDraft) return;
    const list = Array.isArray(drafts) ? drafts : [];
    const key = (x: any) => (x && (x.id ?? x._id));
    const fresh = list.find((d: any) => d && key(d) === key(selectedDraft));
    if (fresh && fresh !== selectedDraft && JSON.stringify(fresh) !== JSON.stringify(selectedDraft)) {
      setSelectedDraft(fresh);
    }
  }, [drafts]);

  // Open a draft and, if it is a still-rendering clip job, immediately check
  // Opus once instead of waiting for the next poll tick.
  async function openDraft(d: any) {
    setSelectedDraft(d);
    setEditingDraft(false);
    try {
      if (d && d.pack && d.pack.kind === 'clip' && d.pack.projectId && d.pack.status !== 'ready' && d.pack.status !== 'failed') {
        const r = await fetch('/api/opus/clip?projectId=' + encodeURIComponent(d.pack.projectId));
        if (r.ok) {
          const j = await r.json().catch(() => null);
          if (j && j.status === 'ready' && Array.isArray(j.clips) && j.clips.length > 0) refreshDrafts(0, false);
        }
      }
    } catch {}
  }

  // Pre-warm every real clip job on load so opening a draft is instant. We fetch
  // the current drafts directly (not state, which may be empty at mount) and, for
  // each clip draft with an Opus projectId that isn't ready yet, ask the API once
  // in parallel; the API persists the clips onto the draft for an instant open.
  async function warmClips() {
    try {
      // Shares the Image Studio's identical mount-time request rather than
      // firing a second copy of it.
      const lj: any = await fetchDrafts(50, 0).catch(() => null);
      if (!lj) return;
      const list = Array.isArray(lj) ? lj : (lj && (lj.drafts || lj.data || lj.rows)) || [];
      const pending = list.filter(
        (d: any) => d && d.pack && d.pack.kind === 'clip' && d.pack.projectId && d.pack.status !== 'ready' && d.pack.status !== 'failed'
      );
      if (pending.length === 0) return;
      let any = false;
      await Promise.all(
        pending.map(async (d: any) => {
          try {
            const r = await fetch('/api/opus/clip?projectId=' + encodeURIComponent(d.pack.projectId));
            if (!r.ok) return;
            const j = await r.json().catch(() => null);
            if (j && j.status === 'ready' && Array.isArray(j.clips) && j.clips.length > 0) any = true;
          } catch {}
        })
      );
      if (any) refreshDrafts(0, false);
    } catch {}
  }

async function refreshStats() {
try {
const r = await fetch('/api/stats');
if (!r.ok) { setLoadError(await friendlyErrorFromResponse(r, 'We could not load your numbers just now.')); return; }
const j = await r.json().catch(() => null);
if (j) { setStats(j); setLoadError(null); }
} catch (e) { setLoadError(friendlyError(e, 'We could not reach the server. Check your connection.')); }
}

async function refreshDrafts(offset = 0, append = false) {
try {
if (append) setLoadingMore(true);
const r = await fetch('/api/drafts?limit=' + PAGE_SIZE + '&offset=' + offset);
// A lapsed session now answers 401 instead of quietly handing back the
// sign-in page, so say so rather than rendering an empty list.
if (!r.ok) { setLoadError(await friendlyErrorFromResponse(r, 'We could not load your drafts.')); return; }
const ct = r.headers.get('content-type') || '';
if (!ct.includes('application/json')) { setLoadError('We got an unexpected answer from the server. Try reloading the page.'); return; }
setLoadError(null);
const j = await r.json().catch(() => null);
const rows = toArray(j);
if (j && typeof j.total === 'number') setDraftsTotal(j.total);
setDraftsOffset(offset);
setDrafts((prev: any) => append ? [...(Array.isArray(prev) ? prev : []), ...rows] : rows);
} catch (e) { setLoadError(friendlyError(e, 'We could not reach the server. Check your connection.')); } finally { setLoadingMore(false); }
}

// Pull the current user's scheduled posts (GET /api/posts). Ordered soonest
// first by the API; we keep that order for the queue.
async function refreshPosts() {
setPostsLoading(true);
try {
const r = await fetchPosts();
if (!r.ok) { setLoadError(await friendlyErrorFromResponse(r, 'We could not load your publishing queue.')); return; }
const j = await r.json().catch(() => null);
const rows = (j && Array.isArray(j.posts)) ? j.posts : toArray(j);
setPosts(Array.isArray(rows) ? rows : []);
setPacksWarning(j?.packsUnavailable === true);
setLoadError(null);
} catch (e) { setLoadError(friendlyError(e, 'We could not reach the server. Check your connection.')); } finally { setPostsLoading(false); }
}

// Reschedule a queued post via PATCH /api/posts (updates publication_date).
async function saveReschedule(id: string) {
if (!id || !rescheduleAt) return;
let iso = rescheduleAt;
try { const d = new Date(rescheduleAt); if (!isNaN(d.getTime())) iso = d.toISOString(); } catch {}
try {
const r = await fetch('/api/posts', {
method: 'PATCH',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ id, publication_date: iso }),
});
if (!r.ok) {
// The server refuses the local move when it could not move the post in
// Metricool, so the two can never drift apart. Say which it was.
setActionMsg(await friendlyErrorFromResponse(r, 'We could not move that post.'));
return;
}
setActionMsg(null);
setRescheduleId(null); setRescheduleAt(''); refreshPosts(); announce('posts', 'stats', 'insights');
} catch (e) { setActionMsg(friendlyError(e, 'We could not move that post.')); }
}

// Remove a queued post — from Metricool first, then from here.
async function deletePost(id: string) {
if (!id) return;
if (typeof window !== 'undefined' && !window.confirm('Delete this scheduled post? It will be removed from Metricool too. This cannot be undone.')) return;
try {
const r = await fetch('/api/posts?id=' + encodeURIComponent(id), { method: 'DELETE' });
if (!r.ok) { setActionMsg(await friendlyErrorFromResponse(r, 'We could not delete that post.')); return; }
setActionMsg(null);
refreshPosts(); announce('posts', 'stats', 'insights');
} catch (e) { setActionMsg(friendlyError(e, 'We could not delete that post.')); }
}

// The preview's picture changed (Edit). A post already in Metricool gets the
// new picture there too, the same sync the Calendar's preview uses; then the
// queue re-reads so the preview shows it.
async function afterQueueImageChanged(p: any) {
try {
if (p?.id && p?.metricool_post_id && !p?.mediaUrl) {
const r = await fetch('/api/posts', {
method: 'PATCH',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ id: p.id, action: 'sync_media' }),
});
if (!r.ok) setActionMsg(await friendlyErrorFromResponse(r, 'The new picture is saved here, but Metricool did not take it. It goes with the post the next time it is approved or moved.'));
}
} catch (e) { setActionMsg(friendlyError(e, 'The new picture is saved here, but Metricool could not be updated just now.')); }
finally { refreshPosts(); announce('posts', 'images', 'drafts'); }
}

// The reviewer's yes. This is the only control in the app that makes a post
// go out, so it reads back exactly what will happen before it does anything.
async function approvePost(p: any, now = false) {
const id = String(p?.id || '');
if (!id) return;
const nets = (p?.providers || []).map((n: string) => networkLabel(n)).join(', ') || 'the selected channels';
const when = now ? 'in the next couple of minutes' : 'on ' + fmtDateTime(p?.publication_date) + ' (' + scheduleTzLabel() + ' time)';
if (typeof window !== 'undefined' && !window.confirm('Approve this post?\n\nIt will be published to ' + nets + ' ' + when + '. Metricool does the publishing; you will not need to open it.')) return;
setApprovingId(id);
try {
const r = await fetch('/api/posts', {
method: 'PATCH',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ id, action: now ? 'publish_now' : 'approve' }),
});
if (!r.ok) { setActionMsg(await friendlyErrorFromResponse(r, 'We could not approve that post.')); return; }
setActionMsg(null);
refreshPosts(); announce('posts', 'stats', 'insights');
} catch (e) { setActionMsg(friendlyError(e, 'We could not approve that post.')); }
finally { setApprovingId(null); }
}

// Approve (or publish now) every ticked post — the same route, one call per
// post, so each still passes the AVISO/REF gate and the video gate on its
// own. One confirmation for the lot; failures are named, the rest go ahead.
// The queue's duplicates — the same row (or video, or text) on the same
// network more than once, all waiting for approval. One press removes the
// extras and keeps the earliest per network. Each removal goes through
// DELETE /api/posts, which deletes the Metricool draft first and the local
// row only after; nothing is published.
async function removeDuplicates() {
const dupes = findDuplicatePosts(safePosts as any[]);
const extras = dupes.extras as any[];
if (!extras.length || bulkBusy) return;
const lines = dupes.groups.map((g: any) => (g.keep?.source?.row ? 'row ' + g.keep.source.row : 'one video') + ' \u00b7 ' + g.network + ' \u00d7 ' + (g.extras.length + 1)).join('\n');
if (typeof window !== 'undefined' && !window.confirm('Remove ' + extras.length + ' duplicate draft' + (extras.length === 1 ? '' : 's') + ', keeping one per network?\n\n' + lines + '\n\nThey are removed from Metricool too. Nothing is published.')) return;
setBulkBusy(true);
const failures: string[] = [];
let ok = 0;
await mapLimit(extras, 4, async (p: any) => {
try {
const r = await fetch('/api/posts?id=' + encodeURIComponent(String(p.id)), { method: 'DELETE' });
if (r.ok) ok++; else failures.push((p?.source?.row ? 'row ' + p.source.row + ' ' : '') + '(' + ((p?.providers || []).join('/') || 'post') + '): ' + await friendlyErrorFromResponse(r, 'could not be removed'));
} catch (e) { failures.push((p?.source?.row ? 'row ' + p.source.row + ' ' : '') + '(' + ((p?.providers || []).join('/') || 'post') + '): ' + friendlyError(e, 'could not be removed')); }
});
setActionMsg(failures.length ? (ok + ' of ' + extras.length + ' duplicates removed. Not done: ' + failures.join('; ')) : ok + ' duplicate draft' + (ok === 1 ? '' : 's') + ' removed \u2014 one per network kept.');
setBulkBusy(false);
announce('posts', 'stats');
}
/**
 * Delete every ticked draft — from the queue and from Metricool.
 *
 * Select mode used to offer Approve and Publish now and nothing else, while
 * the only bulk delete in the app ("Remove N duplicates") lived in the other
 * branch of the same bar and VANISHED the moment you started ticking. So the
 * answer to "row 183 already has a draft waiting, delete it there first" was a
 * screen with no way to delete anything but one row at a time.
 *
 * Same shape as removeDuplicates: one DELETE per post, four at a time, because
 * each call also removes the post from Metricool and cleans up the shared video
 * copy when nothing else references it. A bulk endpoint would have to repeat
 * all of that care.
 *
 * The confirm NAMES EVERY ROW rather than counting them, because a tick can be
 * hidden by the current search and this is the one action that cannot be undone.
 */
/**
 * Pull a waiting draft back into the panel so it can be finished.
 *
 * The queue could approve a draft, move it, or delete it — never open it. So a
 * draft that was nearly right had to be deleted and rewritten from scratch,
 * and the copy the writer had already produced went in the bin.
 *
 * Nothing is removed from the queue by pressing this: the draft stays exactly
 * where it is, and pressing Send updates it in place (the server adopts it
 * rather than making a second one). If you change your mind, walk away — the
 * draft is untouched.
 */
function continueDraft(p: any) {
  setMText(String(p?.text || ''));
  setMDate(p?.publication_date ? scheduleInputValue(p.publication_date) : '');
  const networks = (Array.isArray(p?.providers) ? p.providers : []).map((n: unknown) => String(n || '').toLowerCase()).filter(Boolean);
  if (networks.length) setMNetworks(networks);
  // THE VIDEO COMES BACK TOO, or the person is told it did not.
  //
  // /api/posts resolves each post's media URL from the copy id it stores
  // (re-minted if it is one of our expiring stream links). Loading the copy
  // and the time but not the video would mean pressing Send strips the video
  // off a draft that had one — the opposite of continuing it.
  const media = String(p?.mediaUrl || '');
  setMMedia(media);
  const label = media ? (p?.source?.title || 'Video on this draft') : '';
  setMMediaLabel(label);
  // The draft already knows both of these: prepareVideo titles the pack from
  // the keyword search it ran (lib/post-title.ts), and /api/posts now passes
  // them through instead of stopping at the route.
  setMDraftId(String(p?.draft_id || ''));
  const keyword = p?.packKeyword ? String(p.packKeyword) : '';
  setMKeyword(keyword ? { primary: keyword, volume: null } : null);
  // env: {} on purpose — the strip list is a server setting, and the browser
  // must fall back to the default rather than reach for process.env.
  setMTitle(professionalTitle({ supplied: p?.packTitle || p?.source?.title, keyword, filename: label, env: {} }).title);
  const src = p?.source || null;
  setMSource(src?.tab && Number(src?.row) >= 2 ? { tab: String(src.tab), row: Number(src.row), link: String(src.link || ''), format: '' } : null);
  setMSent(null);
  setMStatus(
    p?.media_drive_file_id && !media
      ? 'Continuing this draft \u2014 but its video could not be found, so sending now would leave the post without one. Re-attach it below first.'
      : 'Continuing the draft already in your queue. Sending updates that one \u2014 it will not make a second.',
  );
  try { scrollToPublisher(); } catch { /* not mounted yet */ }
}

async function deleteSelected() {
  const chosen = safePosts.filter((p: any) => selectedPosts.has(String(p?.id || '')) && isAwaitingApproval(p?.status));
  if (!chosen.length || bulkBusy) return;
  const lines = chosen.map((p: any) => '\u2022 ' + (p?.source?.row ? 'row ' + p.source.row : 'a post') + ' \u00b7 ' + ((p?.providers || []).join('/') || 'post')).join('\n');
  if (typeof window !== 'undefined' && !window.confirm('Delete ' + chosen.length + ' draft' + (chosen.length === 1 ? '' : 's') + '?\n\n' + lines + '\n\nThey are removed from Metricool too. This cannot be undone.')) return;
  setBulkBusy(true);
  const failures: string[] = [];
  let ok = 0;
  await mapLimit(chosen, 4, async (p: any) => {
    try {
      const r = await fetch('/api/posts?id=' + encodeURIComponent(String(p.id)), { method: 'DELETE' });
      if (r.ok) ok++; else failures.push((p?.source?.row ? 'row ' + p.source.row + ' ' : '') + '(' + ((p?.providers || []).join('/') || 'post') + '): ' + await friendlyErrorFromResponse(r, 'could not be removed'));
    } catch (e) { failures.push((p?.source?.row ? 'row ' + p.source.row + ' ' : '') + '(' + ((p?.providers || []).join('/') || 'post') + '): ' + friendlyError(e, 'could not be removed')); }
  });
  setActionMsg(failures.length ? (ok + ' of ' + chosen.length + ' deleted. Not done: ' + failures.join('; ')) : ok + ' draft' + (ok === 1 ? '' : 's') + ' deleted \u2014 removed from Metricool too.');
  setSelectedPosts(new Set());
  setBulkBusy(false);
  refreshPosts();
  announce('posts', 'stats');
}

async function approveSelected(now = false) {
const chosen = safePosts.filter((p: any) => selectedPosts.has(String(p?.id || '')) && isAwaitingApproval(p?.status) && p?.videoPending !== true);
const ids = chosen.map((p: any) => String(p.id));
// A failure names its row before its network — "row 183 (youtube): …".
const which = (p: any) => (typeof p?.source?.row === 'number' ? 'row ' + p.source.row + ' (' : '(') + ((p?.providers || []).join('/') || 'post') + ')';
if (!ids.length || bulkBusy) return;
const when = now ? 'in the next couple of minutes' : 'each at its scheduled time';
if (typeof window !== 'undefined' && !window.confirm((now ? 'Publish ' : 'Approve ') + ids.length + ' post' + (ids.length === 1 ? '' : 's') + (now ? ' now' : '') + '?\n\nThey will go out ' + when + '. Metricool does the publishing.')) return;
setBulkBusy(true);
const failures: string[] = [];
let ok = 0;
await mapLimit(chosen, 4, async (p: any) => {
const id = String(p.id);
try {
const r = await fetch('/api/posts', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, action: now ? 'publish_now' : 'approve' }) });
if (r.ok) ok++; else failures.push(which(p) + ': ' + await friendlyErrorFromResponse(r, 'could not be approved'));
} catch (e) { failures.push(which(p) + ': ' + friendlyError(e, 'could not be approved')); }
});
setActionMsg(failures.length ? (ok + ' of ' + ids.length + ' approved. Not done: ' + failures.join('; ')) : null);
setBulkBusy(false);
setSelectedPosts(new Set());
setSelectMode(false);
refreshPosts(); announce('posts', 'stats', 'insights');
}

// What the "Pending video" chip does.
//
// The post's copy was written from a video, so it may not go out without one.
// This makes the world-readable copy of that video and attaches it. It does not
// approve anything: the post stays in the review queue and somebody still has
// to read it and press Approve.
//
// While the copies folder is not in a Shared Drive this will fail every time,
// and that is the intended behaviour of the chip today — the refusal it shows
// names the Google cause and says clearing space will not help, which is more
// use per post than one banner at the top of the page.
async function attachVideo(p: any) {
const id = String(p?.id || '');
if (!id) return;
setAttachingId(id);
try {
const r = await fetch('/api/posts', {
method: 'PATCH',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ id, action: 'attach_video' }),
});
if (!r.ok) { setActionMsg(await friendlyErrorFromResponse(r, 'We could not attach the video to that post.')); return; }
// No success banner: actionMsg is "the thing you just clicked did not
// happen". The chip disappearing is the confirmation.
setActionMsg(null);
refreshPosts(); announce('posts');
} catch (e) { setActionMsg(friendlyError(e, 'We could not attach the video to that post.')); }
finally { setAttachingId(null); }
}

async function deleteDraft(id: string) {
if (!id) return;
if (typeof window !== 'undefined' && !window.confirm('Delete this draft? This cannot be undone.')) return;
try {
const r = await fetch('/api/drafts?id=' + encodeURIComponent(id), { method: 'DELETE' });
if (!r.ok) { setActionMsg(await friendlyErrorFromResponse(r, 'We could not delete that draft.')); return; }
setActionMsg(null);
setPickedDrafts((prev) => { if (!prev.has(id)) return prev; const next = new Set(prev); next.delete(id); return next; });
announce('drafts', 'stats', 'images');
} catch (e) { setActionMsg(friendlyError(e, 'We could not delete that draft.')); }
}

function togglePickedDraft(id: string) {
if (!id) return;
setPickedDrafts((prev) => { const next = new Set(prev); if (next.has(id)) next.delete(id); else next.add(id); return next; });
}

/** Every ticked draft, in one request; the list reloads with whatever is left. */
/** The route takes at most this many ids per request; a bigger selection goes in rounds. */
const BULK_DELETE_CHUNK = 100;

/**
 * Delete the ticked drafts. 'keep-approved' leaves every draft a person has
 * approved (its post said yes, or went out) and says how many; 'all' deletes
 * them too. A selection over a hundred goes in rounds — one request of 141
 * was refused whole, and the page said only "could not delete".
 */
async function deleteSelectedDrafts(mode: 'keep-approved' | 'all') {
const ids = Array.from(pickedDrafts).filter(Boolean);
if (!ids.length || bulkDeleting) return;
// Drafts a person has approved (the list marks them): kept by 'keep-approved'.
const approvedDraftIds = new Set<string>((Array.isArray(drafts) ? drafts : []).filter((d: any) => d && d.approved).map((d: any) => String(d.id || d._id || '')));
const approvedCount = ids.filter((id) => approvedDraftIds.has(id)).length;
const ask = mode === 'all'
? 'Delete ' + ids.length + (ids.length === 1 ? ' draft' : ' drafts') + (approvedCount ? ', including ' + approvedCount + ' approved' : '') + '? This cannot be undone.'
: 'Delete ' + (ids.length - approvedCount) + (ids.length - approvedCount === 1 ? ' draft' : ' drafts') + (approvedCount ? ' and keep the ' + approvedCount + ' approved' : '') + '? This cannot be undone.';
if (typeof window !== 'undefined' && !window.confirm(ask)) return;
setBulkDeleting(true);
setDraftsMsg(null);
const deleted: string[] = []; const failed: { id: string; error: string }[] = []; const kept: string[] = [];
try {
for (let i = 0; i < ids.length; i += BULK_DELETE_CHUNK) {
const chunk = ids.slice(i, i + BULK_DELETE_CHUNK);
const r = await fetch('/api/drafts?ids=' + encodeURIComponent(chunk.join(',')) + (mode === 'keep-approved' ? '&keepApproved=1' : ''), { method: 'DELETE' });
const j = await r.json().catch(() => ({}));
if (!r.ok && !Array.isArray(j?.deleted)) { failed.push(...chunk.map((id) => ({ id, error: 'not deleted' }))); setDraftsMsg({ text: await friendlyErrorFromResponse(r, 'We could not delete those drafts.'), bad: true }); break; }
deleted.push(...(Array.isArray(j?.deleted) ? j.deleted.map(String) : []));
failed.push(...(Array.isArray(j?.failed) ? j.failed : []));
kept.push(...(Array.isArray(j?.kept) ? j.kept.map(String) : []));
}
// Only what the server could not delete stays ticked, so a second press retries exactly those.
setPickedDrafts(new Set(failed.map((f) => String(f.id))));
const parts = [deleted.length + (deleted.length === 1 ? ' draft' : ' drafts') + ' deleted.'];
if (kept.length) parts.push(kept.length + ' approved kept.');
if (failed.length) parts.push(failed.length + ' could not be deleted — still selected; try again in a moment.');
setDraftsMsg({ text: parts.join(' '), bad: failed.length > 0 });
announce('drafts', 'stats', 'images');
} catch (e) { setDraftsMsg({ text: friendlyError(e, 'We could not delete those drafts.'), bad: true }); }
finally { setBulkDeleting(false); }
}

function cleanCaption(s: string): string {
    return String(s || "").replace(/__\w+/g, " ").replace(/\s+/g, " ").trim();
  }
  // Delegates to the shared mapper so every panel says the same thing about the
  // same failure. The old local copy tested /unauthor/, which does NOT match
  // the "unauthenticated" the middleware returns - so an expired session was
  // reported to the user as a rejected AI API key.
  function friendlyGenError(msg: string): string {
    return friendlyError(msg, "We could not finish that. Try again in a moment.");
  }

  async function editDraft(d: any) {
const current = (d && (d.topic || d.title || d.name)) || '';
const next = typeof window !== 'undefined' ? window.prompt('Edit draft name', String(current)) : null;
if (next == null) return;
const topic = next.trim();
if (!topic || topic === current) return;
try {
const r = await fetch('/api/drafts', {
method: 'PATCH',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ id: d.id || d._id, topic }),
});
if (r.ok) announce('drafts', 'images');
} catch {}
}


function primaryBodyKey(pack: any): string {
if (!pack || typeof pack !== 'object') return 'content';
for (const k of ['blog', 'instagram', 'text', 'content', 'body', 'facebook', 'linkedin']) {
if (typeof pack[k] === 'string') return k;
}
for (const k of Object.keys(pack)) {
if (typeof pack[k] === 'string') return k;
}
return 'content';
}

// Format-aware rendering. Generation always returns the same 4 pack keys
// (instagram/facebook/linkedin/blog); the MEANING of the primary field changes
// per format. formatMeta maps the stored pack.format to the right primary key,
// a human label, and a one-line description so email/video/ad render faithfully
// instead of being mislabeled as INSTAGRAM/BLOG.
function formatMeta(pack: any): { key: string; label: string; lead: string } {
  const f = pack && typeof pack === 'object' ? String(pack.format || '') : '';
  if (f === 'email') return { key: 'blog', label: 'EMAIL CAMPAIGN', lead: 'Subject line, preview text and body' };
  if (f === 'video') return { key: 'blog', label: 'VIDEO SCRIPT', lead: 'Hook, scenes and call-to-action' };
  if (f === 'ad') return { key: 'blog', label: 'AD COPY', lead: 'Headline variations, primary text and CTA' };
  if (f === 'blog') return { key: 'blog', label: 'BLOG ARTICLE', lead: 'Long-form article' };
  return { key: '', label: '', lead: '' };
}
function formatSections(pack: any): { label: string; text: string }[] {
  if (!pack || typeof pack !== 'object') return [];
  if (pack.kind === 'video') {
    // A prepared video: the two channel texts, then the transcript it was written from.
    const v: { label: string; text: string }[] = [];
    if (typeof pack.linkedin === 'string' && pack.linkedin.trim()) v.push({ label: 'LINKEDIN', text: String(pack.linkedin) });
    if (typeof pack.tiktok === 'string' && pack.tiktok.trim()) v.push({ label: 'TIKTOK CAPTION', text: String(pack.tiktok) });
    if (typeof pack.transcript === 'string' && pack.transcript.trim()) v.push({ label: 'TRANSCRIPT \u00b7 ' + (pack.transcriptSource === 'youtube' ? 'YouTube captions' : 'pasted') + (pack.sourceUrl ? ' \u00b7 ' + String(pack.sourceUrl) : ''), text: String(pack.transcript) });
    return v;
  }
  const meta = formatMeta(pack);
  const out: { label: string; text: string }[] = [];
  const socials: [string, string][] = [['instagram','INSTAGRAM'],['facebook','FACEBOOK'],['linkedin','LINKEDIN']];
  if (meta.key && typeof pack[meta.key] === 'string' && String(pack[meta.key]).trim()) {
    out.push({ label: meta.label, text: String(pack[meta.key]) });
    const socialLabel = String(pack.format) === 'blog' ? 'PROMO POST' : 'SOCIAL TEASER';
    for (const [k, lbl] of socials) {
      if (typeof pack[k] === 'string' && String(pack[k]).trim()) out.push({ label: socialLabel + ' \u00b7 ' + lbl, text: String(pack[k]) });
    }
    return out;
  }
  for (const [k, lbl] of [...socials, ['blog','BLOG']] as [string, string][]) {
    if (typeof pack[k] === 'string' && String(pack[k]).trim()) out.push({ label: lbl, text: String(pack[k]) });
  }
  return out;
}
function formatOutputString(pack: any): string {
  const secs = formatSections(pack);
  if (!secs.length) return '';
  return secs.map((s) => s.label + '\n' + s.text).join('\n\n');
}

function draftBody(d: any): string {
if (!d) return '';
if (typeof d.body === 'string') return d.body;
const pack = d.pack;
if (pack && pack.kind === 'clip') return typeof pack.caption === 'string' ? pack.caption : '';
if (pack && pack.kind === 'image') return (pack._image && typeof pack._image.alt === 'string') ? pack._image.alt : 'AI image';
if (pack && typeof pack === 'object') {
const k = primaryBodyKey(pack);
if (typeof pack[k] === 'string') return pack[k];
}
if (typeof d.text === 'string') return d.text;
return '';
}

function startEditDraft(d: any) {
if (!d) return;
setEditTitle(String(d.topic || d.title || d.name || ''));
setEditBody(draftBody(d));
setEditingDraft(true);
}

async function saveDraftEdits() {
const d = selectedDraft;
if (!d) return;
const id = d.id || d._id;
if (!id) return;
const topic = editTitle.trim();
const basePack = (d.pack && typeof d.pack === 'object') ? { ...d.pack } : {};
const isClip = d.pack && d.pack.kind === 'clip';
const key = isClip ? 'caption' : primaryBodyKey(d.pack);
basePack[key] = editBody;
setSavingEdit(true);
try {
const r = await fetch('/api/drafts', {
method: 'PATCH',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ id, topic: topic || (d.topic || 'Untitled'), pack: basePack }),
});
if (!r.ok) {
// Staying in edit mode with no message looked exactly like "nothing
// happened", so the edits appeared to save and had not.
setActionMsg(await friendlyErrorFromResponse(r, 'We could not save those changes.'));
return;
}
const j = await r.json().catch(() => null);
const updated = (j && j.draft) ? j.draft : { ...d, topic: topic || d.topic, pack: basePack };
setSelectedDraft(updated);
setEditingDraft(false);
setActionMsg(null);
announce('drafts', 'images');
} catch (e) { setActionMsg(friendlyError(e, 'We could not save those changes.')); } finally { setSavingEdit(false); }
}

/** Dropped, picked or pasted pictures: each shrunk in the browser and read on the server, all at once. The idea box is left exactly as typed. */
async function takeIdeaImages(files: File[]) {
const pictures = files.filter((f) => /^image\//i.test(f.type));
if (files.length && !pictures.length) { setErr('Drop pictures (JPEG, PNG, WebP or GIF).'); return; }
const room = MAX_IDEA_PICTURES - ideaImages.length;
if (room <= 0) { setErr('Up to ' + MAX_IDEA_PICTURES + ' pictures for one post. Remove one to add another.'); return; }
const batch = pictures.slice(0, room);
if (pictures.length > room) setErr('Up to ' + MAX_IDEA_PICTURES + ' pictures for one post; the first ' + room + ' were taken.');
else setErr(null);
setIdeaImageBusy((n) => n + batch.length);
await Promise.all(batch.map(async (file) => {
try {
const dataUrl = await downscale(file);
const r = await fetch('/api/generate/see', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ dataUrl }) });
if (!r.ok) throw new Error(await friendlyErrorFromResponse(r, 'The picture could not be read just now.'));
const brief = (await r.json()) as PictureBrief;
setIdeaImages((list) => (list.length < MAX_IDEA_PICTURES ? [...list, { key: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), dataUrl, name: file.name, brief }] : list));
} catch (e) {
setErr(friendlyError(e, 'The picture could not be read just now.'));
} finally { setIdeaImageBusy((n) => Math.max(0, n - 1)); }
}));
}
function onIdeaDrop(e: React.DragEvent) {
e.preventDefault(); setIdeaDrag(false);
void takeIdeaImages(Array.from(e.dataTransfer?.files || []));
}
/** A picture pasted into the idea box (Ctrl+V from a screenshot or a photo) counts too; pasted text is left to the box. */
function onIdeaPaste(e: React.ClipboardEvent) {
const files = Array.from(e.clipboardData?.files || []).filter((f) => /^image\//i.test(f.type));
if (!files.length) return;
e.preventDefault();
void takeIdeaImages(files);
}
/** The first picture is the post's picture; clicking another makes it first. */
function leadIdeaImage(key: string) {
setIdeaImages((list) => { const i = list.findIndex((x) => x.key === key); return i <= 0 ? list : [list[i], ...list.slice(0, i), ...list.slice(i + 1)]; });
}

async function generate() {
const runId = ++genRun.current;
setLoading(true); setErr(null); setOutput(''); setGenPack(null); setGenImage(null); setGenImageFrom(null); setLastDraftId(null);
// Light up the live pipeline: research → draft → save → image → verify.
clearProcTimers();
setProc(stepActive(makeSteps(GEN_STEPS), 'research'));
procAdvanceLater('draft', 4000); // research + drafting happen inside one call; pace the display
// With a picture on the idea box, the topic is the picture: what it shows leads the keywords, the competition and the copy.
const topic = ideaImages.length ? topicFromPicture(prompt, ideaImages.map((i) => i.brief)) : prompt;
try {
const r = await fetch('/api/generate', {
method: 'POST', headers: { 'content-type': 'application/json' },
body: JSON.stringify({ topic, provider, model, type }),
});
const data = await r.json().catch(() => ({}));
// A 504 is the platform cutting the request off, not the writer refusing: said as such, with what to do.
if (!r.ok) throw new Error(data?.error || (r.status === 504 || r.status === 502
  ? 'That took longer than the server allows and was cut off. Try again; a shorter format (a social post, an outline) finishes faster than a full article.'
  : 'Generation failed (' + r.status + ')'));
const pack = data.pack || {};
setKeywordsApplied(Array.isArray(data.keywordsApplied) ? data.keywordsApplied : []);
setKeywordSource(typeof data.keywordSource === 'string' ? data.keywordSource : 'none');
setKeywordReason(typeof data.keywordReason === 'string' ? data.keywordReason : undefined);
setOutput(formatOutputString({ ...pack, format: type }));
setGenPack(pack as Record<string, unknown>);
clearProcTimers();
setProc((p) => (p ? stepActive(p, 'save') : p));
let draftId: string | null = null;
try {
const dr = await fetch('/api/drafts', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ topic: prompt.trim() || ideaImages[0]?.brief.idea || topic, pack: { ...pack, format: type }, provider }),
});
const dj = await dr.json().catch(() => ({}));
draftId = dj?.draft?.id || null;
} catch {}
setLastDraftId(draftId);
announce('drafts', 'stats');
// Visual pack: generate the AI hero image in the background so the text
// shows instantly and the image fills in when ready (fail-soft).
if (draftId) {
setGenImageLoading(true);
setProc((p) => (p ? stepActive(p, 'image') : p));
procAdvanceLater('verify', 20000); // generation ~20s, then the vision check
fetch('/api/drafts/image', {
method: 'POST',
headers: { 'content-type': 'application/json', 'x-cs-progress-scope': 'create' },
// The dropped picture, when there is one: it IS the post's picture, stored like a file dropped on the picker.
// Otherwise auto: the brand's own photograph first (lib/draft-picture.ts), a generated one only when none fits — the same door the Autopilot and the strategy preview use.
body: JSON.stringify(ideaImages.length ? { id: draftId, dataUrl: ideaImages[0].dataUrl, alt: ideaImages[0].brief.description } : { id: draftId, auto: true }),
})
.then(async (ir) => {
const ij = await ir.json().catch(() => ({}));
if (genRun.current !== runId) return; // superseded by a newer Generate
clearProcTimers();
if (ir.ok && ij?.image?.url) {
setGenImage(ij.image);
setGenImageFrom({ source: String(ij.source || ''), notes: Array.isArray(ij.notes) ? ij.notes.map(String) : [] });
setProc((p) => (p ? stepsDone(p) : p));
} else {
// Say why. The text pack is saved and fine; only the picture failed, and
// the reason (out of OpenAI credit, a timeout) decides who needs to act.
const why = friendlyImageError(ij, 'The image could not be generated. Your text is saved — try "New image" in a moment.', {
  provider: 'openai',
  alsoSay: 'Your text is saved and works without a picture.',
});
setProc((p) => (p ? stepError(stepActive(p, 'image'), 'image', why) : p));
}
})
.catch((e) => {
if (genRun.current !== runId) return;
clearProcTimers();
setProc((p) => (p ? stepError(stepActive(p, 'image'), 'image', friendlyImageError(e, 'The image could not be generated. Your text is saved.', { provider: 'openai', alsoSay: 'Your text is saved and works without a picture.' })) : p));
})
.finally(() => {
if (genRun.current === runId) setGenImageLoading(false);
announce('drafts', 'images');
});
} else {
setProc((p) => (p ? stepsDone(stepSkip(p, ['image', 'verify'])) : p));
}
} catch (e: any) {
clearProcTimers();
setProc((p) => (p ? stepError(p) : p));
setErr(friendlyGenError(e?.message || 'Generation failed'));
} finally { setLoading(false); }
}

// Reject the current hero image and get a fresh proposition (the server
// advances the composition variant so every regenerate looks different).
async function regenGenImage() {
if (!lastDraftId || genImageLoading) return;
setGenImageLoading(true);
try {
const ir = await fetch('/api/drafts/image', {
method: 'POST',
headers: { 'content-type': 'application/json', 'x-cs-progress-scope': 'create' },
body: JSON.stringify({ id: lastDraftId, regenerate: true }),
});
const ij = await ir.json().catch(() => ({}));
if (!ir.ok || !ij?.image?.url) { setActionMsg(friendlyError(ij, 'We could not make a new image. The previous one is still here.')); }
else { setGenImage(ij.image); setActionMsg(null); }
} catch (e) { setActionMsg(friendlyError(e, 'We could not make a new image. The previous one is still here.')); } finally { setGenImageLoading(false); announce('drafts', 'images'); }
}

// Same, from the draft detail modal (works for any saved draft).
async function regenDraftImage(d: any) {
const id = d && (d.id || d._id);
if (!id || modalImgBusy) return;
setModalImgBusy(true);
try {
const r = await fetch('/api/drafts/image', {
method: 'POST',
headers: { 'content-type': 'application/json', 'x-cs-progress-scope': 'draft-modal' },
body: JSON.stringify({ id, regenerate: true }),
});
const j = await r.json().catch(() => ({}));
if (!r.ok || !j?.image?.url) { setActionMsg(friendlyError(j, 'We could not make a new image. The previous one is still here.')); }
else {
const updated = { ...d, pack: { ...((d && d.pack) || {}), _image: j.image } };
setSelectedDraft(updated);
setActionMsg(null);
announce('drafts', 'images');
}
} catch (e) { setActionMsg(friendlyError(e, 'We could not make a new image. The previous one is still here.')); } finally { setModalImgBusy(false); }
}

// Load analytics from GET /api/metricool. When silent (mount auto-load), we do
// not surface an error banner if credentials are not configured yet.
async function loadAnalytics(silent = false) {
setMLoading(true); if (!silent) setMStatus(null);
try {
const r = await fetch('/api/metricool?blogId=' + METRICOOL_BLOG_ID);
const data = await r.json().catch(() => ({}));
if (!r.ok) throw new Error(data?.error || ('Metricool fetch failed ('+r.status+')'));
setMAnalytics(data);
} catch (e: any) { if (!silent) setMStatus('Error: ' + (e?.message || 'failed')); } finally { setMLoading(false); }
}


// Is the box holding a filename rather than a title? Decided by the same rule
// the server uses, so the panel and the post never disagree about it.
const mTitleIsInternal = Boolean(mTitle.trim()) && looksInternal(mTitle, {});


/**
 * Write the title from the video, not from the file.
 *
 * "Instead of the keyword search I want to make sure it drafts it with AI
 *  taking into consideration what was said from the copy and the transcription
 *  of the video."
 *
 * Both halves are sent: the copy in the box, and — when this post came from a
 * draft — the transcript excerpt on that draft, which is the part that makes
 * the title about what the speaker actually said. The answer goes through the
 * same rules as a typed title (lib/post-title.ts), so a model naming the
 * presenter has its title refused rather than published.
 */
async function draftTitle() {
  if (mKwBusy) return;
  setMKwBusy(true);
  try {
    const r = await fetch('/api/title', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: mText, draftId: mDraftId || undefined }),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(friendlyError(data, 'The title could not be written just now.'));
    const title = String(data?.title || '').trim();
    if (!title) throw new Error('The writer did not answer with a usable title.');
    setMTitle(title);
    setMStatus(data?.fromTranscript
      ? 'Title written from the video\u2019s transcript and this copy. Edit it if you like.'
      : 'Title written from this copy. Edit it if you like.');
  } catch (e) {
    setMStatus(friendlyError(e, 'The title could not be written just now.'));
  } finally {
    setMKwBusy(false);
  }
}

async function schedulePost() {
if (!mNetworks.length) { setMStatus('Pick at least one network.'); return; }
if (!mDate) { setMStatus('Pick a date & time.'); return; }
if (!mText.trim()) { setMStatus('Write the post text first.'); return; }
setMStatus(null); setMBusy(true);
try {
const results = await Promise.all(
mNetworks.map(async (network) => {
const r = await fetch('/api/metricool/schedule', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({
// The absolute instant the box names on the schedule clock, not its raw digits.
network, text: mText, publishAt: scheduleInstantFromInput(mDate) || mDate, blogId: activeBlogId || METRICOOL_BLOG_ID, mediaUrl: mMedia || undefined,
// The title a person can see and edit above the box — never the filename
// under the video player, which is what this used to send.
title: mTitle.trim() || undefined,
format: mSource?.format || undefined,
// The prepared draft this copy came from, so the route reads its pack for the
// sheet's FORMATO and YouTube settings instead of guessing them from the text.
...(mDraftId ? { draftId: mDraftId } : {}),
// The row this was handed over from, so the queue can name it.
...(mSource ? { sheetTab: mSource.tab, sheetRow: mSource.row, sourceUrl: mSource.link } : {}),
}),
});
const data = await r.json().catch(() => ({}));
return { network, ok: r.ok, status: r.status, data };
})
);
const ok = results.filter((x) => x.ok).map((x) => x.network);
// The copy that actually went out, when the route had to make a better one
// than the link this panel held (a Drive link, which Metricool hands back).
// Shown, so the player above is the video Metricool has, and kept, so the
// next send starts from it.
const rerouted = results.find((x: any) => x.ok && typeof x.data?.mediaUrl === 'string' && x.data.mediaUrl) as any;
if (rerouted) setMMedia(String(rerouted.data.mediaUrl));
// How many of those were drafts already WAITING, continued rather than
// duplicated. Said out loud, because "saved on linkedin" would otherwise
// leave a person wondering whether there are now two of them — which is the
// very anxiety the old refusal was trying to prevent.
const updated = results.filter((x: any) => x.ok && x.data?.updated === true).length;
// The draft that was waiting had already been removed in Metricool, so a
// fresh one was made. Distinct from "updated" on purpose: saying updated
// here would send somebody hunting for a draft that does not exist.
const recreated = results.filter((x: any) => x.ok && x.data?.recreated === true).map((x: any) => x.network);
// THE REASON, NOT JUST THE NAME.
//
// This used to project straight to `.network`, so "failed on linkedin" was the
// whole account a person ever got — while the route had already written a
// perfectly good sentence into `data.message` ("… has already been published on
// linkedin …", "LinkedIn is not connected to this brand …") that nobody read.
// Three different problems with three different fixes all reached the screen as
// the same word. friendlyError prefers our own message and never shows a bare
// machine code, exactly as the Prepare panel already does.
const bad = results.filter((x) => !x.ok).map((x) => ({ network: x.network, why: friendlyError(x.data) }));
const failed = bad.map((x) => x.network);
const reasons = bad.map((x) => x.network + ': ' + x.why).join(' ');
if (failed.length === 0) {
// Kept, not cleared: the text stays where the person can see it, the button
// turns into "Sent", and the green line above it says where the drafts went.
setMStatus([
  updated ? 'Updated ' + updated + ' draft' + (updated === 1 ? '' : 's') + ' already waiting in your queue \u2014 no new ones were made.' : '',
  recreated.length ? 'The ' + recreated.join(' and ') + ' draft' + (recreated.length === 1 ? '' : 's') + ' had already been removed in Metricool, so a fresh one was created.' : '',
  (updated || recreated.length) ? 'Approve in the queue when you are happy.' : '',
].filter(Boolean).join(' ') || null);
setMSent({ key: mKey, networks: ok });
if (updated || recreated.length) refreshPosts();
} else if (ok.length === 0) {
setMStatus('Error: failed on ' + failed.join(', ') + '. ' + reasons);
} else {
setMStatus('Saved on ' + ok.join(', ') + '; failed on ' + failed.join(', ') + '. ' + reasons);
}
announce('posts', 'stats', 'insights');
} catch (e: any) {
setMStatus('Error: ' + (e?.message || 'failed'));
} finally { setMBusy(false); }
}

async function clipVideo() {
setOpStatus(null); setOpBusy(true);
try {
// The server creates the gallery draft itself (keyed by the authoritative
// Opus projectId) and returns it, so there is no separate client draft
// insert to race against the webhook or to save an empty projectId.
const r = await fetch('/api/opus/clip', {
method: 'POST', headers: { 'content-type': 'application/json' },
body: JSON.stringify({ videoUrl: opUrl, title: opTitle.trim() || undefined, language: opLang }),
});
const data = await r.json().catch(() => ({}));
if (!r.ok) throw new Error(data?.error || ('OpusClip failed ('+r.status+')'));
const projectId = (data && (data.projectId || (data.project && (data.project.projectId || data.project.id)))) || '';
setOpStatus(projectId ? 'Clip job started — processing…' : 'Clip job started.');

// Optimistically show the server-created draft immediately; otherwise fall
// back to a refresh so the new tile still appears.
if (data && data.draft) {
setDrafts((prev: any) => [data.draft, ...(Array.isArray(prev) ? prev : [])]);
}
setOpUrl('');
announce('drafts', 'stats');
} catch (e: any) { setOpStatus('Error: ' + (e?.message || 'failed')); } finally { setOpBusy(false); }
}

async function copyOutput() {
try { await navigator.clipboard.writeText(output); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch {}
}

const currentModels = PROVIDERS.find(p => p.id === provider)!.models;
const safeDrafts = Array.isArray(drafts) ? drafts : [];
const safePosts = Array.isArray(posts) ? posts : [];
// The queue as the search leaves it. Only what is SHOWN is filtered — the
// selection, the counts and the duplicate scan all still read safePosts.
const shownPosts = filterQueue(safePosts as any[], queueQ);
// The month view of the queue (lib/queue-calendar.ts). Days are the schedule's
// wall-clock days, as on the calendar page.
const queueToday = scheduleDateKey(new Date().toISOString());
const queueByDay = groupByDay(safePosts as any[], (p: any) => scheduleDateKey(p?.publication_date), (p: any) => Date.parse(p?.publication_date || '') || 0);
const activeQueueDay = queueDay ?? defaultDay(queueByDay.keys(), queueToday);
const activeQueueMonth = queueMonth ?? cursorOf(activeQueueDay) ?? cursorOf(queueToday) ?? { year: new Date().getFullYear(), month: new Date().getMonth() };
// A search, or "Select several", lists every match; otherwise the list under
// the month is the picked day's posts, with every button the queue had.
const queueSearching = Boolean(queueQ.trim()) || selectMode;
const listPosts: any[] = queueSearching ? shownPosts : (queueByDay.get(activeQueueDay) ?? []);
const queueMatchIds = queueQ.trim() ? new Set(shownPosts.map((p: any) => String(p?.id || ''))) : null;
const pendingReviewCount = safePosts.filter((p: any) => postStatusMeta(p?.status).label === 'Waiting for your approval').length;
const activeType = CONTENT_TYPES.find(t => t.id === type)!;

// metricoolMetrics() was computed and thrown away for months while the README
// advertised these as extra counter cards. They are appended, not substituted,
// so the four counts above never move position when analytics arrive.
const statCards = [
{ label: 'Drafts', value: (stats && (stats.drafts ?? stats.draftsCount)) ?? safeDrafts.length ?? 0 },
{ label: 'Scheduled posts', value: (stats && (stats.scheduled ?? stats.scheduledCount)) ?? safePosts.length ?? 0 },
{ label: 'Awaiting approval', value: pendingReviewCount },
{ label: 'Clip jobs', value: (stats && (stats.clips ?? stats.clipJobs)) ?? 0 },
...metricoolMetrics(mAnalytics).map((m) => ({ label: m.label, value: m.value })),
];

const nav = [
{ href: '/', label: 'Dashboard', current: !isDraft },
{ href: '/draft', label: 'Draft', current: isDraft },
{ href: '/templates', label: 'Templates', current: false },
{ href: '/calendar', label: 'Calendar / Publishing', current: false },
{ href: '/brand', label: 'Brand Brain', current: false },
{ href: '/sources/calendar', label: 'Social Calendar', current: false },
{ href: '/sources/videos', label: 'Video Library', current: false },
{ href: '/sources/images', label: 'Image Library', current: false },
] as const;


return (
<div className="glow min-h-screen bg-canvas text-ink">
<div className="relative z-10 mx-auto flex max-w-[2100px] gap-8 px-4 py-5 sm:px-6 sm:py-8 lg:px-10">
{/* Sidebar */}
<aside className="hidden w-60 shrink-0 lg:block">
<div className="sticky top-8">
<div className="mb-8 flex items-center gap-3">
<div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-accent text-white shadow-soft">
<span className="text-lg font-semibold">C</span>
</div>
<div>
<div className="text-[15px] font-semibold leading-tight">Content Studio</div>
<div className="text-xs text-ink-muted">{brandName}</div>
</div>
</div>
<nav className="space-y-1">
{nav.map(n => (
<Link key={n.href} href={n.href}
className={'flex items-center rounded-xl px-3.5 py-2.5 text-[14px] font-medium transition-colors ' + (n.current ? 'bg-white text-ink shadow-soft' : 'text-ink-muted hover:bg-white/60 hover:text-ink')}>
{n.label}
</Link>
))}
</nav>
<div className="mt-8 border-t border-line pt-6">
<a href="/sign-out" className="flex items-center rounded-xl px-3.5 py-2.5 text-[14px] font-medium text-ink-muted transition-colors hover:bg-white/60 hover:text-ink">Sign out</a>
</div>
</div>
</aside>

{/* Main */}
<main className="min-w-0 flex-1 animate-in">
<header className="mb-8 flex flex-wrap items-end justify-between gap-4">
<div>
<h1 className="text-title font-semibold">{isDraft ? 'Draft' : 'Good to see you'}</h1>
<p className="mt-1 text-[15px] text-ink-muted">{isDraft ? 'Create, picture, repurpose and send for review — everything before a post is approved.' : 'What is coming up, what needs your approval, and how the site is doing.'}</p>
</div>
{/* The menu on a phone: one swipeable row of pills (it wrapped into four lines before), with Sign out, which only the desktop sidebar had. */}
<div className="-mx-4 flex w-[calc(100%+2rem)] items-center gap-2 overflow-x-auto px-4 pb-1 lg:hidden [scrollbar-width:none]">
{nav.map(n => (
<Link key={n.href} href={n.href} className={'shrink-0 whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] font-medium ' + (n.current ? 'bg-ink text-white' : 'bg-white text-ink-muted shadow-soft')}>{n.label}</Link>
))}
<a href="/sign-out" className="shrink-0 whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] font-medium text-ink-muted ring-1 ring-line">Sign out</a>
</div>
</header>

{/* THE RIGHT-HAND PANEL. The "How this works" guide and the stat cards sat
    across the top of the page and pushed the work below the fold; they now
    sit in a column on the right, the same width as the menu on the left
    (w-60), that stays in view while the page scrolls.
    It comes FIRST in the markup and the row is reversed, so below 1280px,
    where a side column would squeeze the panels, it stacks on top as before. */}
{/* On a phone the guide and the counts come AFTER the work (flex-col-reverse), not before it: the tour was the first screen and a half of every visit. */}
<div className="flex flex-col-reverse xl:flex-row-reverse xl:items-start xl:gap-8">
<aside aria-label="Guide and counts" className="xl:sticky xl:top-8 xl:w-60 xl:shrink-0">
{/* Onboarding "How this works" strip — dismissible, remembered per browser.

    ON BOTH PAGES, and that is the point of it. This used to sit inside the
    same {!isDraft} wrapper as the stat cards below, because when /draft was
    split out the strip read as overview-page furniture. But the four sections
    it indexes — Create, Images, Repurpose, Schedule — ALL live on Draft, which
    is where their "Step 1 · Create" headings are. The index and the things it
    indexes ended up on opposite pages, so the Draft page numbered its steps
    one to four with nothing on screen saying what the four were. */}
      {(
        <section className="mb-8 overflow-hidden rounded-3xl bg-surface shadow-card ring-1 ring-line/60 xl:mb-6">
          <div className="flex items-center justify-between gap-3 border-b border-line px-6 py-4 sm:px-8 xl:flex-wrap xl:gap-2 xl:px-4 xl:py-3">
            <div>
              <h2 className="text-[15px] font-semibold text-ink">How this works</h2>
              <p className="mt-0.5 text-[12px] text-ink-muted">A quick tour of the create → images → repurpose → schedule flow.</p>
            </div>
            <button type="button" onClick={toggleOnboard} aria-expanded={onboardOpen}
              className="shrink-0 rounded-full px-3 py-1.5 text-[12px] font-medium text-ink-muted ring-1 ring-line transition hover:bg-subtle">
              {onboardOpen ? 'Hide guide' : 'Show guide'}
            </button>
          </div>
          {onboardOpen && (
            <div className="grid gap-3 p-6 sm:grid-cols-2 sm:p-8 lg:grid-cols-5 xl:grid-cols-1 xl:gap-2 xl:p-3">
              {ONBOARD_STEPS.map((s, i) => (
                <button key={s.title} type="button" onClick={() => scrollToStep(i)} className="cursor-pointer rounded-2xl bg-subtle/60 p-4 text-left ring-1 ring-line transition hover:bg-white hover:ring-accent xl:rounded-xl xl:p-3">
                  <div className="text-[13px] font-semibold text-ink">{s.title}</div>
                  <p className="mt-1 text-[12px] leading-relaxed text-ink-muted">{s.body}</p>
                </button>
              ))}
            </div>
          )}
        </section>
      )}

{/* Stat cards — on both pages now, beside the guide in the right-hand panel,
    so Drafts, Scheduled posts and Awaiting approval are in view while drafting too. */}
{(
<section className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4 xl:grid-cols-2 xl:gap-2">
{statCards.map(s => (
<div key={s.label} className="rounded-2xl bg-surface p-5 shadow-card ring-1 ring-line/60 xl:rounded-xl xl:p-3">
<div className="text-[28px] font-semibold leading-none tracking-tight tabular-nums xl:text-[22px]">{s.value}</div>
<div className="mt-2 text-[13px] text-ink-muted xl:mt-1 xl:text-[11px] xl:leading-tight">{s.label}</div>
</div>
))}
</section>
)}
</aside>
<div className="min-w-0 flex-1">

{/* One place that says a load failed, and one that says an action failed.
    Both used to be silence: a 401 or a dropped connection left every panel in
    its empty state, which reads as "you have nothing" rather than "we could
    not check". */}
{loadError && (
<div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-amber-50 px-5 py-4 text-[14px] text-amber-900 ring-1 ring-amber-200" role="status">
<span>{loadError}</span>
<button type="button" onClick={() => { setLoadError(null); refreshStats(); refreshDrafts(0, false); refreshPosts(); }} className="rounded-full bg-amber-900 px-3.5 py-1.5 text-[13px] font-medium text-white">Try again</button>
</div>
)}
{actionMsg && (
<div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-red-50 px-5 py-4 text-[14px] text-red-900 ring-1 ring-red-200" role="alert">
<span>{actionMsg}</span>
<button type="button" onClick={() => setActionMsg(null)} className="rounded-full px-3.5 py-1.5 text-[13px] font-medium text-red-900 underline">Dismiss</button>
</div>
)}

{/* Drop weekly strategy — the team's most important feature, so it sits at
    the top of the overview, full width, above every other panel. A strategy
    PDF becomes Autopilot slots (components/StrategyDrop.tsx). */}
{!isDraft && <StrategyDrop />}

{/* One plain-English line when the app is running degraded, so a blank
    Site Audit dial or a missing keyword note has a stated cause instead of
    looking like three unrelated glitches. Silent when all is well. */}
<SystemStatus />

{/* Generator */}
{/* The panels, two across.
    Stacked one-per-row they were 1048px wide inside a 1400px shell that threw
    away 600px of a 2000px screen. Widened and paired they get ~770px each.
    Two across only from 1536px up (2xl): at 1100px a two-column split
    left each panel 358px, and the Content Generator splits in two again
    inside itself, so its halves would have been ~170px. Below that the
    panels stack full width — still wider than they were, because the shell
    no longer throws away 600px.
    Panels are paired by WEIGHT, not by position in the workflow, because
    four of them are drawers: 91-110px shut, 566-858px open. Pairing a drawer
    with a full panel leaves a void in one state or the other, and pairing
    strictly by workflow order left ~2550px of empty column — 802px beside
    the Content Generator, 1277px beside Long-form to Shorts.

    So the two drawers sit together (110 vs 91 shut, 566 vs 858 open — matched
    either way), Autopilot pairs with Recent Drafts, and the two panels that
    genuinely want width take a full row. The Content Generator loses nothing
    by it: it already splits into input | OUTPUT inside itself, so full width
    gives those halves ~800px each instead of 404px. Publishing is 1368px tall
    shut and 2849 open, with a 3-column and a 5-column row inside.

    Reading order still runs create → images → repurpose → publish →
    autopilot → library, which the browser check enforces. No dense packing:
    The grid is shared by two pages. Draft (/draft) shows create, images,
    repurpose, publish, research, library; the overview shows publish, SEO,
    Autopilot, library. Each drawer that loses its partner in the split
    (SEO on the overview, Research on Draft) takes a full row, and Recent
    Drafts takes a full row on Draft where Autopilot is not there to pair with.
    a full-width panel starts a fresh row by itself once the pair above it is
    complete, and it was dense that previously pulled Autopilot ahead of
    Publishing. */}
<div className="2xl:grid 2xl:grid-cols-2 2xl:items-start 2xl:gap-8">
{isDraft && (<>
<section id="section-create" className="relative mb-8 2xl:mb-0 2xl:col-span-2 overflow-hidden rounded-3xl bg-surface shadow-card ring-1 ring-line/60">
<PanelLoader scope="create" />
<div className="border-b border-line px-6 py-5 sm:px-8">
<div className="flex items-center gap-2">
<span className="rounded-full bg-accent/10 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-accent">Step 1 · Create</span>
<h2 className="text-headline font-semibold">Content Generator</h2>
</div>
<p className="mt-1 text-[13px] text-ink-muted">Describe your idea, pick what you want it to be, then Generate.</p>
</div>
<div className="grid gap-0 lg:grid-cols-2">
{/* Controls */}
<div id="content-generator" className="space-y-5 p-6 sm:p-8">
{/* Which AI wrote it is a preference, not a decision most people need to
    make — and a dropdown of raw model identifiers ("gpt-4o-mini") is not
    something a coordinator can choose between. The good default stays
    selected; anyone who does care opens this. */}
<details className="group">
<summary className="inline-flex cursor-pointer list-none items-center gap-1.5 text-[12px] font-medium text-ink-muted transition hover:text-ink">
<span aria-hidden className="transition-transform group-open:rotate-90">›</span>
Writing with {PROVIDERS.find(p => p.id === provider)?.label.replace(/\s*\(.*\)$/, '')} · change
</summary>
<div className="mt-3">
<label htmlFor="gen-model" className="mb-2 block text-[12px] font-medium uppercase tracking-wide text-ink-muted">Model</label>
<div className="flex flex-wrap items-center gap-2">
{PROVIDERS.map(p => (
<button key={p.id} onClick={() => setProvider(p.id)}
className={'rounded-full px-4 py-2 text-[13px] font-medium transition-all ' + (provider === p.id ? 'bg-ink text-white shadow-soft' : 'bg-subtle text-ink-muted ring-1 ring-line hover:text-ink')}>
{p.label}
</button>
))}
<select id="gen-model" value={model} onChange={e => setModel(e.target.value)}
className="rounded-full bg-subtle px-4 py-2 text-[13px] font-medium text-ink ring-1 ring-line focus:ring-accent">
{currentModels.map(m => <option key={m.id} value={m.id}>{m.label}</option>)}
</select>
</div>
</div>
</details>

<div>
<p id="gen-format-label" className="mb-2 block text-[12px] font-medium uppercase tracking-wide text-ink-muted">Format</p>
<div className="flex flex-wrap gap-2" role="group" aria-labelledby="gen-format-label">
{CONTENT_TYPES.map(t => (
<button key={t.id} onClick={() => setType(t.id)}
className={'rounded-full px-3.5 py-1.5 text-[13px] font-medium transition-all ' + (type === t.id ? 'bg-accent text-white shadow-soft' : 'bg-subtle text-ink-muted ring-1 ring-line hover:text-ink')}>
{t.label}
</button>
))}
</div>
<p className="mt-2 text-[12px] text-ink-faint">{activeType.hint}</p>
</div>

<div>
<div className="mb-2 flex items-center justify-between">
<label htmlFor="trend-input" className="block text-[12px] font-medium uppercase tracking-wide text-ink-muted">Trending topics</label>
<span className="text-[11px] text-ink-faint">Tap one to start · a person always reviews before anything posts</span>
</div>
<div className="flex flex-wrap gap-2">
{trending.slice(0, 12).map((t) => (
<span key={t} className="group inline-flex items-center gap-1 rounded-full bg-subtle px-3 py-1.5 text-[12px] font-medium text-ink ring-1 ring-line">
<button type="button" onClick={() => applyTrend(t)} className="transition hover:text-accent">{t}</button>
<button type="button" aria-label={'Remove ' + t} onClick={() => removeTrend(t)} className="text-ink-faint opacity-0 transition group-hover:opacity-100 hover:text-danger">×</button>
</span>
))}
</div>
<div className="mt-2 flex items-center gap-2">
<input id="trend-input" value={newTrend} onChange={(e) => setNewTrend(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addTrend(); } }}
placeholder="Add a trending topic to track…"
className="min-w-0 flex-1 rounded-full bg-subtle px-3 py-1.5 text-[12px] text-ink ring-1 ring-line placeholder:text-ink-faint focus:ring-accent" />
<button type="button" onClick={addTrend} className="shrink-0 rounded-full bg-ink px-3 py-1.5 text-[12px] font-medium text-white transition-opacity hover:opacity-90">Add</button>
</div>
</div>

<div>
<label htmlFor="gen-idea" className="mb-2 block text-[12px] font-medium uppercase tracking-wide text-ink-muted">Your idea</label>
{/* ONE COMPOSER. The pictures sit inside the same panel as the words, above them; the + and Generate sit along its bottom edge. Drop anywhere on the panel, click +, or paste a picture into it — and keep typing. */}
<div onDragOver={(e) => { e.preventDefault(); setIdeaDrag(true); }} onDragLeave={() => setIdeaDrag(false)} onDrop={onIdeaDrop}
className={'rounded-2xl bg-subtle ring-1 transition-shadow focus-within:ring-accent ' + (ideaDrag ? 'ring-2 ring-accent bg-accent/5' : 'ring-line')}>
{ideaImages.length > 0 && (
<div className="flex flex-wrap gap-2 px-4 pt-4">
{ideaImages.map((im, i) => (
<div key={im.key} className="relative">
<button type="button" onClick={() => leadIdeaImage(im.key)} title={i === 0 ? 'This is the post\u2019s picture' : 'Make this the post\u2019s picture'} className={'block overflow-hidden rounded-xl ring-2 ' + (i === 0 ? 'ring-accent' : 'ring-transparent hover:ring-line')}>
{/* eslint-disable-next-line @next/next/no-img-element */}
<img src={im.dataUrl} alt={im.brief.description || im.name} className="h-24 w-24 object-cover" />
</button>
{i === 0 && <span className="absolute bottom-1 left-1 rounded-md bg-accent px-1.5 py-0.5 text-[10px] font-semibold text-white">Post picture</span>}
<button type="button" onClick={() => setIdeaImages((list) => list.filter((x) => x.key !== im.key))} aria-label="Remove this picture" className="absolute -right-1.5 -top-1.5 h-5 w-5 rounded-full bg-ink text-[12px] leading-none text-white shadow-soft hover:bg-danger">\u00d7</button>
</div>
))}
{ideaImageBusy > 0 && <div className="flex h-24 w-24 items-center justify-center rounded-xl bg-white/60 text-center text-[11px] text-accent ring-1 ring-accent/20"><span className="mr-1 h-1.5 w-1.5 animate-pulse rounded-full bg-accent" />Reading{ideaImageBusy > 1 ? ' ' + ideaImageBusy : ''}\u2026</div>}
</div>
)}
<textarea id="gen-idea" value={prompt} onChange={e => setPrompt(e.target.value)} onBlur={e => publishTopic(e.target.value)} onPaste={onIdeaPaste} rows={ideaImages.length ? 3 : 4}
placeholder={ideaImages.length ? 'Say what the post should do with the picture \u2014 the angle, the channel, the tone. Leave it empty and the picture decides.' : 'e.g. 3 Instagram captions about our newest offering for first-time customers \u2014 or drop a picture here'}
className="block w-full resize-none bg-transparent p-4 text-[14px] text-ink placeholder:text-ink-faint focus:outline-none" />
<div className="flex flex-wrap items-center gap-2 px-3 pb-3">
<label htmlFor="gen-idea-image" title={'Add pictures (up to ' + MAX_IDEA_PICTURES + '). The post is written around what is in them \u2014 keywords, the competition and the brand\u2019s voice as for a typed idea \u2014 and the first becomes the post\u2019s picture.'}
className="inline-flex h-9 w-9 cursor-pointer items-center justify-center rounded-full text-[22px] leading-none text-ink/60 ring-1 ring-line transition-colors hover:bg-white hover:text-ink">
+
<input id="gen-idea-image" type="file" accept="image/*" multiple className="sr-only" onChange={(e) => { void takeIdeaImages(Array.from(e.target.files || [])); e.target.value = ''; }} />
</label>
<span className="text-[11px] text-ink-faint">{ideaImageBusy > 0 ? 'Reading ' + (ideaImageBusy === 1 ? 'the picture' : ideaImageBusy + ' pictures') + '\u2026' : ideaImages.length ? 'Drop or paste more, up to ' + MAX_IDEA_PICTURES : 'Drop, paste or + a picture; the post is written around it'}</span>
<span className="flex-1" />
<button onClick={generate} disabled={loading || ideaImageBusy > 0 || (!prompt.trim() && !ideaImages.length)}
className="inline-flex items-center gap-2 rounded-full bg-accent px-6 py-2.5 text-[14px] font-semibold text-white shadow-soft transition-all hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-40">
{loading ? (<><span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white/40 border-t-white" />Generating\u2026</>) : 'Generate'}
</button>
</div>
</div>
{ideaImages.length > 0 && (
<div className="mt-2 space-y-1 px-1 text-[12px] leading-relaxed text-ink/70">
{ideaImages.map((im, i) => (
<div key={im.key}>
<span className="font-medium text-ink">{ideaImages.length > 1 ? 'Picture ' + (i + 1) + ': ' : ''}</span>{im.brief.description}
{im.brief.caution && <span className="text-amber-800"> {im.brief.caution}</span>}
</div>
))}
{!prompt.trim() && ideaImages[0]?.brief.idea && (
<div className="flex flex-wrap items-center gap-2 pt-1">
<span>Suggested: <span className="text-ink">{ideaImages[0].brief.idea}</span></span>
<button type="button" onClick={() => { setPrompt(ideaImages[0].brief.idea); publishTopic(ideaImages[0].brief.idea); }} className="rounded-full bg-white px-2.5 py-0.5 text-[11px] font-medium text-ink ring-1 ring-line hover:bg-subtle">Use this idea</button>
<span className="text-ink-faint">or type your own in the box \u2014 both go to the writer together.</span>
</div>
)}
</div>
)}
{err && <p className="mt-2 text-[13px] text-danger">{err}</p>}
{/* The "Keyword research" button that sat here is gone: the research is the first step of Generate itself, and the keywords applied are shown under the output. */}
</div>
</div>

{/* Output */}
<div className="border-t border-line bg-subtle/50 p-6 sm:p-8 lg:border-l lg:border-t-0">
<div className="mb-3 flex items-center justify-between">
<span className="text-[12px] font-medium uppercase tracking-wide text-ink-muted">Output</span>
{output && (
<button onClick={copyOutput} className="rounded-full bg-white px-3 py-1 text-[12px] font-medium text-ink ring-1 ring-line transition-colors hover:bg-subtle">
{copied ? 'Copied' : 'Copy'}
</button>
)}
</div>
{proc && (
  <div className="mb-3">
    <ProcessTracker title="Creating your content pack" steps={proc} onClose={() => setProc(null)} />
  </div>
)}
{keywordSource === 'semrush' && keywordsApplied.length > 0 && (
  <div className="mb-3 flex flex-wrap items-center gap-1.5 rounded-xl bg-emerald-50 p-2.5 ring-1 ring-emerald-100">
    <span className="mr-1 inline-flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-emerald-700">🔑 Keywords applied</span>
    {keywordsApplied.map((k, i) => (
      <span key={k + i} className="rounded-full bg-white px-2 py-0.5 text-[11px] text-emerald-800 ring-1 ring-emerald-200">{k}</span>
    ))}
  </div>
)}
{keywordSource === 'none' && output && (
  <p className="mb-3 text-[11px] text-ink-faint">{semrushDraftNote(keywordReason as any)}</p>
)}
{output && lastDraftId && (
  <>
    {/* THE SAME CONTROLS EVERY DRAFT HAS (components/HeroImageControls.tsx): the
        library, the library photo with the brand filter and the post title, the
        Edit image panel (title, notes, suggestions) and a new AI take, last. */}
    <HeroImageControls
      key={lastDraftId}
      draftId={lastDraftId}
      hasImage={Boolean(genImage?.url)}
      note={genImageFrom?.source === 'library'
        ? '📁 From the brand\'s own library' + (genImage?.alt ? ': ' + genImage.alt : '') + ' — with the brand filter, no AI.'
        : genImageFrom?.source === 'generated'
          ? (genImageFrom.notes[0] || 'No library photograph fit this post.') + ' An AI picture was made instead; pick a library photo above to replace it.'
          : 'The picture is chosen from the brand\'s own library first; an AI picture is made only when no photograph fits.'}
      onChanged={(img) => setGenImage((cur: any) => ({ ...(cur || {}), ...img }))}
    />
    {/* And a file from your desk, which only this picker offers. */}
    <HeroImagePicker
      draftId={lastDraftId}
      topic={prompt}
      currentPrompt={genImage?.prompt || null}
      only={['upload']}
      onPicked={(img) => setGenImage({ url: img.url, alt: img.alt, model: img.model, verification: img.verification as never })}
    />
  </>
)}
{output && genPack && (
  <SchedulePack
    pack={genPack}
    draftId={lastDraftId}
    imageUrl={genImage?.url || null}
    avisoNumber={avisoNumber}
    slots={mSlots}
    blogId={activeBlogId || METRICOOL_BLOG_ID}
  />
)}
{output && genImage?.url ? (
  <div className="mb-3 overflow-hidden rounded-2xl ring-1 ring-line">
    <a href={genImage.url} target="_blank" rel="noopener noreferrer" title="Open full size">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={genImage.url} alt={genImage.alt || 'AI hero image'} className={"max-h-96 w-full object-cover transition hover:opacity-95 " + (genImageLoading ? 'opacity-50' : '')} />
    </a>
    <div className="flex flex-wrap items-center gap-2 bg-white px-3 py-1.5">
      {genImage.verification?.textDetected ? (
        <span className="rounded-full bg-red-600/95 px-2 py-0.5 text-[10px] font-semibold text-white" title={(genImage.verification?.issues || []).join(' · ') || 'Text detected — content images must be text-free'}>✗ text in image — reroll</span>
      ) : genImage.verification?.status === 'approved' ? (
        <span className="rounded-full bg-emerald-600/90 px-2 py-0.5 text-[10px] font-semibold text-white" title={'Machine-verified text-free' + (genImage.verification?.score != null ? ' · ' + genImage.verification.score + '/100' : '') + ((genImage.verification?.advisory || []).length ? ' · notes: ' + (genImage.verification?.advisory || []).join(' · ') : '')}>✓ verified{(genImage.verification?.advisory || []).length ? ' · ' + (genImage.verification?.advisory || []).length + ' note' + ((genImage.verification?.advisory || []).length === 1 ? '' : 's') : ''}</span>
      ) : genImage.verification?.status === 'flagged' ? (
        <span className="rounded-full bg-amber-500/95 px-2 py-0.5 text-[10px] font-semibold text-white" title={(genImage.verification?.issues || []).join(' · ')}>⚠ defect found — reroll recommended</span>
      ) : null}
      <span className="text-[11px] text-ink-faint">🖼 AI hero image ({genImage.model || 'OpenAI'}) — saved on the draft, attaches when you schedule. Click to view full size.</span>
      <button type="button" onClick={regenGenImage} disabled={genImageLoading}
        className="ml-auto rounded-full px-3 py-1 text-[12px] font-medium text-accent ring-1 ring-line transition hover:bg-subtle disabled:opacity-50">
        {genImageLoading ? 'Regenerating…' : '↻ New image'}
      </button>
    </div>
  </div>
) : output && genImageLoading ? (
  <div className="mb-3 flex items-center gap-2 rounded-2xl border border-dashed border-line bg-white px-4 py-3 text-[12px] text-ink-muted">
    <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-line border-t-accent" />
    Generating hero image…
  </div>
) : null}
{output ? (
<pre className="max-h-[420px] overflow-auto whitespace-pre-wrap rounded-2xl bg-white p-4 text-[13px] leading-relaxed text-ink-soft ring-1 ring-line">{typeof output === 'string' ? output : JSON.stringify(output, null, 2)}</pre>
) : (
<div className="flex h-[300px] flex-col items-center justify-center rounded-2xl border border-dashed border-line text-center">
<div className="text-[14px] font-medium text-ink-muted">Nothing generated yet</div>
<div className="mt-1 text-[12px] text-ink-faint">Your content pack will appear here.</div>
</div>
)}
</div>
</div>
</section>


{/* Step 2 · Images — every generated + verified visual, right after Create.
    Folded by default: a hero image is already generated and attached with
    every content pack, so opening this is for making EXTRA visuals. */}
<CollapsibleSection
  id="section-images"
  className="2xl:mb-0"
  eyebrow="Step 2 · Images"
  title="AI Image Studio"
  summary="Every pack already comes with a verified hero image. Open this to make more, or to look through the ones you have."
>
<ImageStudio />
</CollapsibleSection>

{/* OpusClip — long-form to Shorts (video repurposing workspace) */}
<CollapsibleSection
  id="section-repurpose"
  className="2xl:mb-0"
  eyebrow="Step 3 · Repurpose"
  title="Long-form to Shorts"
  summary="Turn one long YouTube or Vimeo video into a set of captioned vertical clips."
>
<div>
<div className="border-b border-line px-6 py-5 sm:px-8">
<div className="flex flex-wrap items-center justify-between gap-3">
<div className="flex items-center gap-2">
<span className="rounded-full bg-accent/10 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-accent">Step 3 · Repurpose</span>
<h2 className="text-[18px] font-semibold text-ink">Long-form to Shorts</h2>
</div>
<span className="rounded-full bg-subtle px-2.5 py-1 text-[11px] font-medium text-ink-muted ring-1 ring-line">Powered by OpusClip</span>
</div>
<p className="mt-1.5 text-[13px] text-ink-muted">Drop in one long YouTube or Vimeo video and get back a set of ready-to-post vertical clips — each auto-captioned and cropped for Reels, Shorts and TikTok.</p>
<div className="mt-4 grid gap-3 sm:grid-cols-3">
<div className="rounded-2xl bg-subtle p-3 ring-1 ring-line">
<p className="text-[11px] font-semibold uppercase tracking-wide text-ink-faint">1 · Paste</p>
<p className="mt-1 text-[12px] text-ink-muted">Add a YouTube or Vimeo link and name the project.</p>
</div>
<div className="rounded-2xl bg-subtle p-3 ring-1 ring-line">
<p className="text-[11px] font-semibold uppercase tracking-wide text-ink-faint">2 · Auto-clip</p>
<p className="mt-1 text-[12px] text-ink-muted">Opus finds the best moments and cuts vertical clips with captions.</p>
</div>
<div className="rounded-2xl bg-subtle p-3 ring-1 ring-line">
<p className="text-[11px] font-semibold uppercase tracking-wide text-ink-faint">3 · Review</p>
<p className="mt-1 text-[12px] text-ink-muted">Clips land under Recent Drafts — preview, then send to Metricool.</p>
</div>
</div>
</div>
<div className="grid lg:grid-cols-5">
<div className="p-6 sm:p-8 lg:col-span-3 lg:border-r lg:border-line">
<label htmlFor="opus-source-url" className="mb-2 block text-[11px] font-semibold uppercase tracking-wide text-ink-muted">Source video</label>
<input
id="opus-source-url"
type="url"
value={opUrl}
onChange={e => setOpUrl(e.target.value)}
placeholder="https://youtube.com/watch?v=…  or  https://vimeo.com/…"
aria-invalid={Boolean(opError) || undefined}
aria-describedby="opus-source-help"
className={"w-full rounded-xl bg-white px-4 py-3 text-[14px] text-ink shadow-soft ring-1 transition placeholder:text-ink-faint focus:outline-none focus:ring-2 focus:ring-accent " + (opError ? "ring-danger" : "ring-line")}
/>
<p id="opus-source-help" className="mt-1.5 text-[12px]" role="status">
{opError ? (
<span className="font-medium text-danger">{opError}</span>
) : opParsed.ok ? (
<span className="font-medium text-success">{opParsed.source} video {opParsed.id} — ready to clip.</span>
) : (
<span className="text-ink-muted">Paste a YouTube or Vimeo link. Opus cannot fetch anything else.</span>
)}
</p>
<div className="mt-4 grid gap-3 sm:grid-cols-2">
<div>
<label htmlFor="opus-project-title" className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wide text-ink-muted">Project title <span className="text-ink-muted normal-case">(optional)</span></label>
<input
id="opus-project-title"
type="text"
value={opTitle}
onChange={e => setOpTitle(e.target.value)}
placeholder="e.g. Ben Rothwell — Recovery"
className="w-full rounded-xl bg-white px-3 py-2.5 text-[13px] text-ink shadow-soft ring-1 ring-line transition placeholder:text-ink-faint focus:outline-none focus:ring-2 focus:ring-accent"
/>
</div>
<div>
<label htmlFor="opus-caption-language" className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wide text-ink-muted">Caption language</label>
<select
id="opus-caption-language"
value={opLang}
onChange={e => setOpLang(e.target.value)}
className="w-full rounded-xl bg-white px-3 py-2.5 text-[13px] text-ink shadow-soft ring-1 ring-line transition focus:outline-none focus:ring-2 focus:ring-accent"
>
<option value="en">English</option>
<option value="es">Spanish</option>
<option value="pt">Portuguese</option>
<option value="fr">French</option>
<option value="de">German</option>
<option value="it">Italian</option>
</select>
</div>
</div>
<div className="mt-5 flex flex-wrap items-center gap-3">
<button
type="button"
onClick={clipVideo}
disabled={opBusy || !opValid}
title={opValid ? undefined : 'Paste a valid YouTube or Vimeo link first'}
className="inline-flex items-center gap-2 rounded-full bg-accent px-5 py-2.5 text-[14px] font-semibold text-white shadow-soft transition-all hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-40"
>
{opBusy ? (<><span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white/40 border-t-white" />Sending to Opus…</>) : 'Generate clips'}
</button>
<span className="text-[12px] text-ink-faint">Processing runs in the background — no need to wait here.</span>
</div>
{opStatus && (
<p className="mt-3 rounded-xl bg-subtle px-3 py-2 text-[12px] text-ink-muted ring-1 ring-line">{opStatus}</p>
)}
</div>
<div className="p-6 sm:p-8 lg:col-span-2">
<p className="mb-3 text-[11px] font-semibold uppercase tracking-wide text-ink-faint">What you&apos;ll get</p>
<ul className="space-y-2.5">
<li className="flex items-start gap-2 text-[13px] text-ink-muted"><span className="mt-0.5 text-accent">▸</span>Several short vertical clips from the best moments of your video.</li>
<li className="flex items-start gap-2 text-[13px] text-ink-muted"><span className="mt-0.5 text-accent">▸</span>Auto-generated captions burned in, in your chosen language.</li>
<li className="flex items-start gap-2 text-[13px] text-ink-muted"><span className="mt-0.5 text-accent">▸</span>A virality score and suggested title on each clip.</li>
<li className="flex items-start gap-2 text-[13px] text-ink-muted"><span className="mt-0.5 text-accent">▸</span>Everything saved to Recent Drafts, ready to send to Metricool.</li>
</ul>
<div className="mt-6 rounded-2xl bg-subtle p-4 ring-1 ring-line">
<p className="text-[11px] font-semibold uppercase tracking-wide text-ink-faint">This run</p>
<dl className="mt-2 space-y-1.5 text-[12px]">
<div className="flex items-center justify-between"><dt className="text-ink-muted">Captions</dt><dd className="font-medium text-ink">{({en:'English',es:'Spanish',pt:'Portuguese',fr:'French',de:'German',it:'Italian'})[opLang] || opLang}</dd></div>
<div className="flex items-center justify-between"><dt className="text-ink-muted">Project</dt><dd className="max-w-[150px] truncate font-medium text-ink">{opTitle.trim() || 'Auto from video'}</dd></div>
</dl>
</div>
<div className="mt-4 flex items-start gap-2 rounded-2xl bg-blue-50 p-4 text-[12px] text-blue-700 ring-1 ring-blue-100">
<span className="mt-0.5">ⓘ</span>
<span>Clips can take a few minutes. They appear under <span className="font-medium">Recent Drafts</span> below — hit <span className="font-medium">Refresh clips</span> there to check progress. Format is a hint to Opus; final crop depends on your Opus brand settings.</span>
</div>
</div>
</div>
</div>
</CollapsibleSection>
</>)}

{/* Publishing (Metricool) — compose, review flow, and live queue */}
<section id="section-publish" className="relative mb-8 2xl:mb-0 2xl:col-span-2 overflow-hidden rounded-3xl bg-surface shadow-card ring-1 ring-line/60">
<PanelLoader scope="publish" />
<div className="border-b border-line px-6 py-5 sm:px-8">
<div className="flex flex-wrap items-center justify-between gap-3">
<div className="flex items-center gap-3">
<span aria-hidden className="flex h-9 w-9 items-center justify-center rounded-2xl bg-accent/10 text-accent text-[18px]">📣</span>
<div>
<span className="mb-1 inline-block rounded-full bg-accent/10 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-accent">{isDraft ? 'Step 4 · Schedule' : 'Approvals'}</span><h2 id="publishing-queue" className="text-[18px] font-semibold text-ink">{isDraft ? 'Publishing' : 'Your publishing queue'}</h2>
<p className="text-[13px] text-ink-muted">{isDraft ? 'Plan, schedule, and track your posts across every channel.' : 'Posts waiting for your approval, and the accounts they go to. Write new posts under Draft.'}</p>
</div>
</div>
<div className="flex items-center gap-2">
{(() => {
const brands = mAnalytics && Array.isArray(mAnalytics.data) ? mAnalytics.data.filter((b: any) => b && (b.label || b.title)) : [];
if (brands.length <= 1) return <span className="rounded-full bg-white px-3 py-1 font-medium text-ink ring-1 ring-line text-[12px]">Powered by Metricool</span>;
return (
<label className="flex items-center gap-2 text-[12px] text-ink-muted">Brand
<select value={activeBlogId} onChange={(e) => { setActiveBlogId(e.target.value); loadInsights(e.target.value); }} className="rounded-full bg-white px-3 py-1.5 text-[13px] font-medium text-ink ring-1 ring-line focus:ring-accent">
{brands.map((b: any) => <option key={String(b.id)} value={String(b.id)}>{b.label || b.title}</option>)}
</select>
</label>
);
})()}
</div>
</div>
<div className="mt-4 rounded-2xl bg-emerald-50 px-4 py-3 ring-1 ring-emerald-100">
<p className="text-[13px] text-emerald-900"><span className="font-semibold">Nothing is ever posted automatically.</span> You write it here, send it for review, and press Approve in your queue when you are happy. Metricool publishes it for you — you never have to open it.</p>
</div>
<ol className="mt-4 grid gap-3 sm:grid-cols-3">
<li className="rounded-2xl bg-white p-3 ring-1 ring-line"><div className="text-[12px] font-semibold text-accent">Write</div><div className="mt-0.5 text-[13px] text-ink-muted">Choose your networks and write the post below.</div></li>
<li className="rounded-2xl bg-white p-3 ring-1 ring-line"><div className="text-[12px] font-semibold text-accent">Send for review</div><div className="mt-0.5 text-[13px] text-ink-muted">It lands safely in Metricool as a draft — never live yet.</div></li>
<li className="rounded-2xl bg-white p-3 ring-1 ring-line"><div className="text-[12px] font-semibold text-accent">You approve</div><div className="mt-0.5 text-[13px] text-ink-muted">Take a final look in your queue and press Approve. It goes out at the time you set.</div></li>
</ol>
</div>
<div className="grid gap-0 lg:grid-cols-5">
{isDraft && (
<div className={"p-6 sm:p-8 " + (isDraft ? "lg:col-span-5 border-b border-line" : "border-b border-line lg:col-span-3 lg:border-b-0 lg:border-r")}>
<div className="mb-3 flex items-center justify-between gap-2">
<h3 className="text-[12px] font-medium uppercase tracking-wide text-ink-muted">Schedule a post</h3>
{mBusy && <span className="text-[11px] text-ink-faint">Sending…</span>}
</div>
<div className="mb-2 text-[12px] text-ink-muted">Which channels should this go to?</div>
<div className="flex flex-wrap gap-2" role="group" aria-label="Networks to post to">
{PUBLISH_NETWORKS.map((n) => {
const on = mNetworks.includes(n.id);
return (
<button type="button" key={n.id} onClick={() => toggleNetwork(n.id)} aria-pressed={on}
className={"inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[13px] font-medium ring-1 transition " + (on ? "bg-accent text-white ring-accent" : "bg-white text-ink ring-line hover:ring-accent")}>
<span aria-hidden>{n.emoji}</span>{n.label}
</button>
);
})}
</div>
<p className="mt-1.5 text-[11px] text-ink-faint">{mNetworks.length ? 'Posting to ' + mNetworks.length + ' channel' + (mNetworks.length > 1 ? 's' : '') + '.' : 'Pick at least one channel.'}</p>
<div className="mt-4 flex items-center justify-between gap-2">
<label htmlFor="composer-datetime" className="text-[12px] font-medium text-ink-muted">When should it go out?</label>
<span className="text-[11px] text-ink-faint">All times {scheduleTzLabel()} time</span>
</div>
<div className="mt-1 flex flex-wrap gap-2">
{/* Computed on the schedule clock: setHours() on a browser Date made
    "Tomorrow" mean tomorrow *there*, so an evening press west of the schedule zone
    picked the wrong day. */}
{mSlots.length > 0
? mSlots.map((slot) => (
<button type="button" key={slot} onClick={() => setMDate(scheduleInputValue(slot))} title="The next free slot on the weekly planner"
className={"rounded-full px-3 py-1 text-[12px] font-medium ring-1 transition hover:ring-accent " + (mDate === scheduleInputValue(slot) ? "bg-accent/10 text-accent ring-accent" : "bg-subtle text-ink-muted ring-line")}>{fmtScheduleDateTime(slot)}</button>
))
: [{ label: 'Tomorrow 8 AM', h: 8, d: 1 }, { label: 'Tomorrow 5 PM', h: 17, d: 1 }, { label: 'In 2 days, 8 AM', h: 8, d: 2 }].map((preset) => (
<button type="button" key={preset.label} onClick={() => setMDate(schedulePresetValue(preset.d, preset.h))}
className="rounded-full bg-subtle px-3 py-1 text-[12px] font-medium text-ink-muted ring-1 ring-line transition hover:ring-accent">{preset.label}</button>
))}
</div>
<input
id="composer-datetime"
type="datetime-local"
value={mDate}
min={mMinDateTime}
onChange={(e) => setMDate(e.target.value)}
aria-invalid={mDateInPast || undefined}
className={"mt-2 w-full rounded-xl bg-subtle px-3 py-2 text-[14px] text-ink ring-1 focus:ring-accent " + (mDateInPast ? "ring-danger" : "ring-line")}
/>
{mDateInPast && (
<p className="mt-1.5 text-[12px] font-medium text-danger">That time has already passed. Pick a future time.</p>
)}
{/* THE TITLE, above the copy, where it can be read before it is sent.
    It used to be the media label — the filename — and was never shown. */}
<div className="mt-4 flex flex-wrap items-center justify-between gap-2">
<label htmlFor="composer-title" className="text-[12px] font-medium text-ink-muted">Title <span className="font-normal text-ink-faint">— what YouTube and TikTok show</span></label>
<button type="button" onClick={() => void draftTitle()} disabled={mKwBusy}
  title="Written from the video’s transcript and the post itself — not from the file name"
  className="rounded-full bg-subtle px-2.5 py-1 text-[11px] font-semibold text-ink-muted ring-1 ring-line transition hover:ring-accent disabled:opacity-50">
  {mKwBusy ? 'Writing…' : '✨ Write the title'}
</button>
</div>
<input id="composer-title" value={mTitle} onChange={(e) => setMTitle(e.target.value)}
  placeholder={'e.g. Our spring collection at ' + brandName}
  className="mt-1 w-full rounded-xl bg-subtle px-3 py-2 text-[14px] text-ink ring-1 ring-line placeholder:text-ink-faint focus:ring-accent" />
{mTitleIsInternal && (
  <p className="mt-1.5 text-[12px] font-medium text-amber-700">
    That is the file’s name, not a title. Press <span className="font-semibold">Write the title</span> and it will be written from the video.
  </p>
)}
{mKeyword && (
  <p className="mt-1.5 text-[11px] text-ink-muted">
    🔑 Keyword research: <span className="font-semibold text-ink">{mKeyword.primary}</span>
    {mKeyword.volume ? ' · ' + mKeyword.volume.toLocaleString() + ' searches a month' : ''}
  </p>
)}
<label htmlFor="composer-text" className="mt-4 block text-[12px] font-medium text-ink-muted">What should it say?</label>
<textarea id="composer-text" value={mText} onChange={(e) => setMText(e.target.value)} rows={4} placeholder="Write your post… you can paste anything you generated above." aria-invalid={mTooLong || undefined} className={"mt-1 w-full resize-none rounded-2xl bg-subtle p-4 text-[14px] text-ink ring-1 placeholder:text-ink-faint focus:ring-accent " + (mTooLong ? "ring-danger" : "ring-line")} />
{complianceApplies(mNetworks) && mText.trim() && mCompliance ? (() => {
  // The AVISO is opt-in: with no permit configured it is neither shown nor
  // offered. The REF is waived for a post that makes no health claim
  // (REQUIRE_CITATIONS, lib/compliance.ts), and then it is not listed either.
  const needsAviso = Boolean(avisoNumber);
  const needsRef = !mCompliance.refWaived;
  if (mCompliance.ok) {
    const present = [needsAviso ? 'advertising notice' : '', needsRef ? 'scientific reference' : ''].filter(Boolean).join(' and ');
    return present ? <p className="mt-2 text-[12px] text-emerald-700" role="status">✓ {present.charAt(0).toUpperCase() + present.slice(1)} present.</p> : null;
  }
  return (
    <div className="mt-2 rounded-2xl bg-amber-50 p-3 text-[12px] text-amber-900 ring-1 ring-amber-200" role="status">
      <div className="font-semibold">{needsAviso && needsRef ? 'These posts must carry two lines' : needsAviso ? 'These posts must carry the advertising notice' : 'These posts must carry a scientific reference'}</div>
      <ul className="mt-1 list-disc pl-4">
        {needsAviso ? <li>{!mCompliance.missing.includes('aviso') ? '✓ ' : ''}AVISO DE PUBLICIDAD: {avisoNumber}{mCompliance.missing.includes('aviso') ? (<> — <button type="button" onClick={() => setMText(ensureAviso(mText, avisoNumber))} className="font-semibold underline">add it now</button></>) : null}</li> : null}
        {/* The old wording promised "Drafts from the Content Generator include
            one", which is true for Instagram and Facebook and FALSE for the
            three networks a video hand-off ticks: lib/ai.ts only ever asks for
            and stamps the REF on the instagram and facebook sections of a pack.
            Being told the line was supplied while looking at copy that has none
            is worse than being told nothing. */}
        {needsRef ? <li>
          {!mCompliance.missing.includes('ref') && !mCompliance.missing.includes('doi') ? '✓ ' : ''}
          REF: a scientific study that supports the claim
          {mCompliance.missing.includes('doi') ? ' — your line has no DOI. Add one (10.…/…); it is what lets the citation be checked.' : ''}
          {mCompliance.missing.includes('ref') ? ' — add a line starting with "REF:" (author, year, journal, DOI). Instagram and Facebook drafts come with one; LinkedIn, YouTube and TikTok copy usually needs it added.' : ''}
        </li> : null}
      </ul>
    </div>
  );
})() : null}
{/* Was inline markup that could only DISPLAY media handed over from
    somewhere else — there was no way to attach a video from this screen, which
    is why a video post could not be written here at all. */}
<MediaPicker
  value={mMedia}
  label={mMediaLabel}
  onChange={(url, lbl) => { setMMedia(url); setMMediaLabel(lbl); }}
  hint={mNeedsMedia ? 'YouTube and TikTok will not take a post without one.' : 'Optional — LinkedIn, Facebook, Instagram and X can go out as text.'}
/>
<div className="mt-2 flex flex-wrap items-center justify-between gap-x-3 gap-y-1 text-[11px]">
<span className={mTooLong ? 'font-semibold text-danger' : 'text-ink-muted'}>
{mLimit
? mChars.toLocaleString() + ' / ' + mLimit.limit.toLocaleString() + ' characters · ' + networkLabel(mLimit.network) + ' is the tightest limit'
: mChars.toLocaleString() + ' characters'}
</span>
<span className="text-ink-muted">{mDate ? 'Goes out ' + fmtDateTime(mDate) : 'Pick a date and time — Metricool needs one'}</span>
</div>
{mTooLong && mLimit && (
<p className="mt-1.5 text-[12px] font-medium text-danger">
Too long for {networkLabel(mLimit.network)} by {mOverBy.toLocaleString()} character{mOverBy === 1 ? '' : 's'}. Trim it, or unselect that channel.
</p>
)}
<p className="mt-3 text-[12px] text-ink-muted">Posts arrive in Metricool <strong>scheduled</strong> — in colour on the calendar, going out at the time above on their own. A post whose copy came from a video still will not go without its video.</p>
{/* The only reason the Send button was disabled used to be 12px grey text
    UNDER it, which reads as "the button is broken" rather than "one thing is
    missing". Same sentence, above the button, in a colour, naming the fix. */}
{mProblem && !mBusy && !mAlreadySent && (
<p role="status" className="mt-3 rounded-xl bg-amber-50 px-3 py-2 text-[13px] font-medium text-amber-900 ring-1 ring-amber-200">
{mProblem}{!mDate ? ' The three time chips above set one in a click.' : ''}
</p>
)}
{mAlreadySent && mSent && (
<div role="status" className="mt-3 rounded-xl bg-emerald-50 px-3 py-2 text-[13px] font-medium text-emerald-900 ring-1 ring-emerald-200">
<span>✓ Scheduled on {mSent.networks.map((n) => networkLabel(n)).join(', ')}. {mSent.networks.length === 1 ? 'It goes' : 'They go'} out at the time above on {mSent.networks.length === 1 ? 'its' : 'their'} own — delete or reschedule below before then if you change your mind.</span>
<span className="mt-1.5 flex flex-wrap gap-3">
<button type="button" className="font-semibold text-emerald-900 underline" onClick={() => { const el = typeof document !== 'undefined' ? document.getElementById('publishing-queue') : null; if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }}>Show the queue</button>
<button type="button" className="font-semibold text-emerald-900 underline" onClick={() => { setMText(''); setMTitle(''); setMKeyword(null); setMDraftId(''); setMMedia(''); setMMediaLabel(''); setMSource(null); setMSent(null); setMStatus(null); }}>Write another post</button>
</span>
</div>
)}
<div className="mt-4 flex flex-wrap items-center gap-3">
<button onClick={schedulePost} disabled={!mCanSend} title={mAlreadySent ? 'This exact post was already sent. Change the text, channels or time to send again.' : (mProblem || undefined)} className="inline-flex items-center gap-2 rounded-full bg-accent px-5 py-2.5 text-[14px] font-semibold text-white shadow-soft transition-all hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-40">{mBusy ? 'Sending…' : mAlreadySent ? 'Sent ✓' : 'Send to Metricool for review'}</button>
<a href={metricoolPlannerUrl(activeBlogId)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 rounded-full bg-white px-4 py-2.5 text-[13px] font-medium text-ink ring-1 ring-line transition hover:ring-accent">Open in Metricool ↗</a>
</div>
{mStatus && <p className="mt-3 rounded-xl bg-subtle px-3 py-2 text-[13px] text-ink-muted ring-1 ring-line">{mStatus}</p>}
<p className="mt-3 text-[11px] text-ink-muted">Scheduled on arrival: each post goes out at its own time without another press. Delete or reschedule it here before then if you change your mind.</p>
</div>
)}
<div className="p-6 sm:p-8 lg:col-span-5">
<div className="mb-3 flex items-center justify-between gap-2">
<h3 className="text-[12px] font-medium uppercase tracking-wide text-ink-muted">Connection health</h3>
<button type="button" onClick={() => { loadAnalytics(false); loadInsights(activeBlogId); }} className="text-[12px] font-medium text-accent hover:underline">{(mLoading || insightsLoading) ? 'Checking…' : 'Refresh'}</button>
</div>
{(() => {
const brand = mAnalytics && Array.isArray(mAnalytics.data) ? (mAnalytics.data.find((b: any) => String(b.id) === String(activeBlogId)) || mAnalytics.data[0]) : null;
const channels = [
{ id: 'facebook', label: 'Facebook', emoji: '📘', handle: brand && brand.facebook ? 'Connected' : '' },
{ id: 'instagram', label: 'Instagram', emoji: '📸', handle: brand && brand.instagram ? '@' + brand.instagram : '' },
{ id: 'twitter', label: 'X / Twitter', emoji: '𝕏', handle: brand && brand.twitter ? '@' + brand.twitter : '' },
{ id: 'linkedin', label: 'LinkedIn', emoji: '💼', handle: brand && brand.linkedinCompany ? 'Connected' : '' },
{ id: 'youtube', label: 'YouTube', emoji: '▶️', handle: brand && (brand.youtubeChannelName || brand.youtube) ? (brand.youtubeChannelName || 'Connected') : '' },
{ id: 'tiktok', label: 'TikTok', emoji: '🎵', handle: brand && brand.tiktok ? '@' + brand.tiktok : '' },
];
const connectedCount = channels.filter((c) => c.handle).length;
const ads = brand ? [brand.facebookAds && 'Facebook Ads', brand.adwords && 'Google Ads', brand.tiktokads && 'TikTok Ads'].filter(Boolean) : [];
if (!mAnalytics) {
return <div className="rounded-2xl bg-subtle p-4 text-center ring-1 ring-line"><div className="text-[13px] font-medium text-ink-muted">See which accounts are linked</div><div className="mt-1 text-[12px] text-ink-faint">Tap Refresh to load the accounts connected to your Metricool brand.</div></div>;
}
if (connectedCount === 0) {
return <div className="rounded-2xl bg-amber-50 p-4 text-center ring-1 ring-amber-100"><div className="text-[13px] font-medium text-amber-900">No accounts connected yet</div><div className="mt-1 text-[12px] text-amber-800">Connect the accounts for this brand inside Metricool to start publishing.</div></div>;
}
return (
<div>
<ul className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
{channels.map((c) => (
<li key={c.id} className="flex items-center justify-between rounded-2xl bg-white px-3 py-2 ring-1 ring-line">
<span className="flex items-center gap-2 text-[13px] text-ink"><span aria-hidden className="text-[16px]">{c.emoji}</span><span className="font-medium">{c.label}</span>{c.handle && c.handle !== 'Connected' && <span className="text-[12px] text-ink-faint">{c.handle}</span>}</span>
{c.handle ? <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-medium text-emerald-700 ring-1 ring-emerald-100">Connected</span> : <span className="rounded-full bg-subtle px-2 py-0.5 text-[11px] font-medium text-ink-faint ring-1 ring-line">Not connected</span>}
</li>
))}
</ul>
<p className="mt-2 text-[11px] text-ink-faint">{connectedCount} of {channels.length} channels connected.</p>
{ads.length > 0 && <p className="mt-1 text-[11px] text-ink-faint">Ad accounts linked: {ads.join(', ')}.</p>}
</div>
);
})()}
{/* "How your recent posts did" was removed at the team's request. */}
<div className="mt-6 border-t border-line pt-5">
<div className="flex flex-wrap items-center justify-between gap-2">
<label className="text-[12px] font-medium uppercase tracking-wide text-ink-muted">Your publishing queue</label>
<span className="flex flex-wrap items-center gap-2">
{postsLoading && <span className="text-[11px] text-ink-faint">Refreshing…</span>}
{(() => {
const approvable = safePosts.filter((p: any) => isAwaitingApproval(p?.status) && p?.videoPending !== true);
if (!approvable.length) return null;
const n = approvable.filter((p: any) => selectedPosts.has(String(p?.id || ''))).length;
// Ticked but not on screen, because the search is hiding them. Said out
// loud: "Delete 5" when three are visible is otherwise a nasty surprise.
const hidden = approvable.filter((p: any) => selectedPosts.has(String(p?.id || '')) && !matchesQueueSearch(p, queueQ)).length;
// Duplicates are counted over the WHOLE queue, never the filtered view — a
// search must not change how many duplicates the app thinks it has.
const dupeCount = findDuplicatePosts(safePosts as any[]).extras.length;
return selectMode ? (
<>
<span className="text-[11px] font-semibold text-ink">{n} of {approvable.length} selected{hidden > 0 ? ' (' + hidden + ' hidden by this search)' : ''}</span>
<button type="button" disabled={n === approvable.length || bulkBusy} className="text-[11px] font-medium text-accent hover:underline disabled:opacity-50" onClick={() => setSelectedPosts(new Set(approvable.map((p: any) => String(p.id))))}>All</button>
<button type="button" disabled={!n || bulkBusy} className="text-[11px] font-medium text-accent hover:underline disabled:opacity-50" onClick={() => setSelectedPosts(new Set())}>None</button>
<button type="button" disabled={!n || bulkBusy} onClick={() => void approveSelected(false)} className="rounded-full bg-accent px-2.5 py-0.5 text-[11px] font-semibold text-white shadow-soft transition hover:opacity-90 disabled:opacity-50">{bulkBusy ? 'Approving…' : 'Approve ' + n}</button>
<button type="button" disabled={!n || bulkBusy} onClick={() => void approveSelected(true)} className="text-[11px] font-medium text-accent hover:underline disabled:opacity-50">Publish {n} now</button>
<button type="button" disabled={!n || bulkBusy} onClick={() => void deleteSelected()} title="Removes them from the queue and from Metricool. Nothing is published." className="rounded-full bg-red-50 px-2.5 py-0.5 text-[11px] font-semibold text-danger ring-1 ring-red-200 transition hover:bg-red-100 disabled:opacity-50">{bulkBusy ? 'Working…' : 'Delete ' + n}</button>
<button type="button" disabled={bulkBusy} onClick={() => { setSelectMode(false); setSelectedPosts(new Set()); }} className="text-[11px] text-ink-muted hover:text-ink">Cancel</button>
{dupeCount > 0 && (
<button type="button" disabled={bulkBusy} title="The same draft on the same network more than once. Keeps the earliest of each; removes the rest from Metricool too." className="rounded-full bg-amber-50 px-2.5 py-0.5 text-[11px] font-semibold text-amber-900 ring-1 ring-amber-200 hover:bg-amber-100 disabled:opacity-50" onClick={() => void removeDuplicates()}>{bulkBusy ? 'Removing…' : 'Remove ' + dupeCount + ' duplicate' + (dupeCount === 1 ? '' : 's')}</button>
)}
</>
) : (
<>
{dupeCount > 0 && (
<button type="button" disabled={bulkBusy} title="The same draft on the same network more than once. Keeps the earliest of each; removes the rest from Metricool too." className="rounded-full bg-amber-50 px-2.5 py-0.5 text-[11px] font-semibold text-amber-900 ring-1 ring-amber-200 hover:bg-amber-100 disabled:opacity-50" onClick={() => void removeDuplicates()}>{bulkBusy ? 'Removing…' : 'Remove ' + dupeCount + ' duplicate' + (dupeCount === 1 ? '' : 's')}</button>
)}
<button type="button" className="text-[11px] font-medium text-accent hover:underline" onClick={() => setSelectMode(true)}>Select several…</button>
</>
);
})()}
</span>
</div>
{loadError && (
<div className="mt-2 rounded-2xl bg-amber-50 p-4 text-[12px] text-amber-800 ring-1 ring-amber-200" role="status">{loadError}</div>
)}
{packsWarning && (
<div className="mt-2 rounded-2xl bg-amber-50 p-4 text-[12px] text-amber-800 ring-1 ring-amber-200" role="status">
We could not read the drafts behind these posts just now, so any post waiting on its video is not marked here. Approving is still blocked for those — refresh in a moment to see them.
</div>
)}
{safePosts.length === 0 && !postsLoading && !loadError && (
<div className="mt-2 rounded-2xl bg-subtle p-4 text-center text-[12px] text-ink-faint ring-1 ring-line">Nothing in the queue yet. Anything you schedule here, on the calendar or from a template lands in this list.</div>
)}
{safePosts.length > 0 && (
<div className="mt-2">
<input
type="search"
value={queueQ}
onChange={(e) => setQueueQ(e.target.value)}
placeholder="Search row number, channel or text…"
aria-label="Search the publishing queue"
className="w-full rounded-full bg-white px-4 py-2 text-[12px] text-ink ring-1 ring-line transition placeholder:text-ink-faint focus:outline-none focus:ring-accent"
/>
<p className="mt-1 px-1 text-[11px] text-ink-faint">A number on its own finds that sheet row — 183 finds row 183, not every post mentioning it.</p>
</div>
)}
{safePosts.length > 0 && (
<QueueCalendar
  cursor={activeQueueMonth}
  onCursor={setQueueMonth}
  byDay={queueByDay}
  todayKey={queueToday}
  selectedDay={activeQueueDay}
  onSelectDay={(k) => { setQueueDay(k); const c = cursorOf(k); if (c) setQueueMonth(c); }}
  timeOf={(p: any) => fmtScheduleTime(p?.publication_date)}
  onPreview={(id) => setPreviewPostId(id)}
  onApprove={(p: any) => approvePost(p)}
  approvingId={approvingId}
  matchIds={queueMatchIds}
  plannerUrl={metricoolPlannerUrl(activeBlogId)}
/>
)}
{safePosts.length > 0 && !queueSearching && (
<h3 className="mt-5 text-[13px] font-semibold text-ink">
{new Date(activeQueueDay + 'T12:00:00').toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}
<span className="ml-2 text-[12px] font-normal text-ink-faint">{listPosts.length ? listPosts.length + ' post' + (listPosts.length === 1 ? '' : 's') : 'Nothing scheduled this day — pick another day above'}</span>
</h3>
)}
{safePosts.length > 0 && shownPosts.length === 0 && (
<div className="mt-2 rounded-2xl bg-subtle p-4 text-center text-[12px] text-ink-faint ring-1 ring-line">Nothing in the queue matches “{queueQ.trim()}”. {safePosts.length} draft{safePosts.length === 1 ? '' : 's'} {safePosts.length === 1 ? 'is' : 'are'} waiting behind this search.</div>
)}
{listPosts.length > 0 && (
<ul className="mt-2 space-y-2">
{/* The picked day's posts, or every match of a search or selection — never
    capped: finding row 183 and then hiding it behind "show all" would be
    worse than not finding it. */}
{listPosts.map((p: any, i: number) => {
const meta = postStatusMeta(p?.status);
const tone = meta.tone === 'amber' ? 'bg-amber-50 text-amber-700 ring-amber-100' : meta.tone === 'green' ? 'bg-emerald-50 text-emerald-700 ring-emerald-100' : 'bg-blue-50 text-blue-700 ring-blue-100';
const id = String(p?.id || '');
// Waiting on its video. Computed by the API from the linked draft's pack —
// the only record anywhere that this copy was transcribed from a video —
// and it replaces the status chip rather than sitting beside it, because
// "waiting for your approval" is not what this post is waiting for.
const pending = p?.videoPending === true;
return (
<li key={id || i} className="rounded-2xl bg-white p-3 ring-1 ring-line">
<div className="flex items-center justify-between gap-2">
{selectMode && id && isAwaitingApproval(p?.status) && !pending && (
<input
type="checkbox"
aria-label="Select this post"
checked={selectedPosts.has(id)}
disabled={bulkBusy}
onChange={(e) => setSelectedPosts((prev) => { const next = new Set(prev); if (e.target.checked) next.add(id); else next.delete(id); return next; })}
className="mr-1"
/>
)}
{pending ? (
<button
type="button"
disabled={attachingId === id}
onClick={() => attachVideo(p)}
title="This copy was written from a video and has none attached. Click to attach it."
className="rounded-full bg-rose-50 px-2 py-0.5 text-[11px] font-medium text-rose-700 ring-1 ring-rose-200 transition hover:bg-rose-100 disabled:opacity-50"
>
{attachingId === id ? 'Attaching video…' : 'Pending video'}
</button>
) : (
<span className={'rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ' + tone}>{meta.label}</span>
)}
<span className="text-[11px] tabular-nums text-ink-faint">{fmtDateTime(p?.publication_date)}</span>
</div>
<button type="button" onClick={() => id && setPreviewPostId(id)} title="Preview this post" className="mt-1.5 line-clamp-2 block w-full text-left text-[13px] text-ink hover:text-ink/80">{p?.text || 'Scheduled post'}</button>
{/* Which row of which tab wrote this post. The same link the calendar's
    publishing list carries — a caption truncated to two lines does not
    identify a post in the sheet, and the row number does. */}
{sheetRowUrl(p?.source) && (
<a href={sheetRowUrl(p?.source) as string} target="_blank" rel="noopener noreferrer" title={sheetRowTitle(p?.source)} className="mt-1 inline-flex items-center gap-1 text-[11px] font-medium text-accent hover:underline">
<span aria-hidden>{'\u{1F4C4}'}</span> {sheetRowLabel(p?.source)} {'\u2197'}
</a>
)}
<div className="mt-2 flex flex-wrap items-center gap-2">
{(p?.providers || []).map((n: string) => (
<span key={n} className="rounded-full bg-subtle px-2 py-0.5 text-[11px] text-ink-muted ring-1 ring-line">{n}</span>
))}
{id && rescheduleId !== id && (
<span className="ml-auto flex items-center gap-3">
<button type="button" onClick={() => setPreviewPostId(id)} title="See the whole post — picture, caption and channels — before approving" className="rounded-full px-2.5 py-0.5 text-[11px] font-medium text-ink-muted ring-1 ring-line transition hover:bg-subtle hover:text-ink">Preview</button>
{meta.label === 'Waiting for your approval' && !pending && (
<>
<button type="button" disabled={approvingId === id} onClick={() => approvePost(p)} className="rounded-full bg-accent px-2.5 py-0.5 text-[11px] font-semibold text-white shadow-soft transition hover:opacity-90 disabled:opacity-50">{approvingId === id ? 'Approving…' : 'Approve'}</button>
<button type="button" disabled={approvingId === id} onClick={() => approvePost(p, true)} className="text-[11px] font-medium text-accent hover:underline disabled:opacity-50">Publish now</button>
<button type="button" onClick={() => continueDraft(p)} title="Opens this draft in the panel above. Sending updates this same draft — it does not make a second one." className="text-[11px] font-medium text-accent hover:underline">Continue</button>
</>
)}
<button type="button" onClick={() => { setRescheduleId(id); setRescheduleAt(''); }} className="text-[11px] font-medium text-accent hover:underline">Reschedule</button>
<button type="button" onClick={() => deletePost(id)} className="text-[11px] font-medium text-danger hover:underline">Delete</button>
</span>
)}
</div>
{id && rescheduleId === id && (
<div className="mt-2 flex flex-wrap items-center gap-2">
<input type="datetime-local" value={rescheduleAt} onChange={(e) => setRescheduleAt(e.target.value)} className="rounded-xl bg-subtle px-2.5 py-1.5 text-[12px] text-ink ring-1 ring-line" />
<button type="button" disabled={!rescheduleAt} onClick={() => saveReschedule(id)} className="rounded-full bg-accent px-3 py-1.5 text-[12px] font-medium text-white disabled:opacity-50">Save</button>
<button type="button" onClick={() => { setRescheduleId(null); setRescheduleAt(''); }} className="text-[12px] text-ink-muted hover:text-ink">Cancel</button>
</div>
)}
</li>
);
})}
</ul>
)}
</div>
<div className="mt-6 flex flex-wrap gap-3 border-t border-line pt-5 text-[12px]">
<a href={'https://app.metricool.com/inbox'} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 font-medium text-accent hover:underline">💬 Open Inbox ↗</a>
<a href={'https://app.metricool.com/smartlink?blogId=' + encodeURIComponent(activeBlogId) + (METRICOOL_USER_ID ? '&userId=' + encodeURIComponent(METRICOOL_USER_ID) : '')} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 font-medium text-accent hover:underline">🔗 Smartlinks ↗</a>
<a href={metricoolPlannerUrl(activeBlogId)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 font-medium text-accent hover:underline">📅 Full planner ↗</a>
</div>
</div>
</div>
              {/* The YouTube channel's community numbers (Metricool's Community ·
                  Growth panel), on the main page. */}
{!isDraft && <YouTubeStats />}
              {/* Semrush Intelligence — the full SEO command center (domain
                  overview, rankings, competitors, backlinks, site health) plus
                  the keyword brain that pre-filters every draft */}
{!isDraft && (
<CollapsibleSection
  id="section-semrush"
  className="2xl:mb-0 2xl:col-span-2"
  title="SEO intelligence"
  summary="Rankings, competitors, backlinks and site health for your website. Keyword research already runs on every draft — this is for looking deeper."
>
              <div className="border-t border-line p-6 sm:p-8">
                <SemrushPanel
                  initialTopic={researchTopicText || prompt}
                  onUseTopic={(t) => {
                    setPrompt(t);
                    try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch { /* noop */ }
                  }}
                />
              </div>
</CollapsibleSection>
)}

              {/* AI Research & Draft Copilot — full-width band below the two columns */}
{isDraft && (
<CollapsibleSection
  id="section-research"
  className="2xl:mb-0 2xl:col-span-2"
  title="Research a topic first"
  summary="Angles, keywords, hashtags and hooks for a topic before you write. Open when you want the legwork done for you."
>
              <div className="border-t border-line p-6 sm:p-8">
              <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-50 to-white ring-1 ring-indigo-100">
                <div className="border-b border-indigo-100 px-5 py-4">
                  <div className="flex items-center gap-2">
                    <span aria-hidden className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-600/10 text-indigo-700">&#10024;</span>
                    <div>
                      <h3 className="text-[15px] font-semibold text-ink">AI Research &amp; Draft Copilot</h3>
                      <p className="text-[12px] text-ink-muted">Give it a topic and it does the research legwork &mdash; angles, keywords, hashtags, hooks and a ready draft.</p>
                    </div>
                  </div>
                </div>
                <div className="p-5">
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <input
                      id="research-topic"
                      aria-label="Topic to research"
                      type="text"
                      value={researchTopicText}
                      onChange={(e) => setResearchTopicText(e.target.value)}
                      onBlur={(e) => publishTopic(e.target.value, "research")}
                      onKeyDown={(e) => { if (e.key === "Enter") runResearch(); }}
                      placeholder="e.g. a question your customers keep asking"
                      className="flex-1 rounded-xl bg-white px-3.5 py-2.5 text-[13px] text-ink ring-1 ring-line focus:outline-none focus:ring-2 focus:ring-indigo-400"
                    />
                    <select
                      id="research-network"
                      aria-label="Network to draft for"
                      value={researchNetwork}
                      onChange={(e) => setResearchNetwork(e.target.value)}
                      className="rounded-xl bg-white px-3 py-2.5 text-[13px] text-ink ring-1 ring-line focus:outline-none focus:ring-2 focus:ring-indigo-400"
                    >
                      <option value="instagram">Instagram</option>
                      <option value="facebook">Facebook</option>
                      <option value="linkedin">LinkedIn</option>
                      <option value="x">X / Twitter</option>
                      <option value="blog">Blog</option>
                    </select>
                    <button
                      type="button"
                      onClick={runResearch}
                      disabled={researchLoading || !researchTopicText.trim()}
                      className="shrink-0 rounded-xl bg-indigo-600 px-4 py-2.5 text-[13px] font-medium text-white transition hover:bg-indigo-700 disabled:opacity-50"
                    >
                      {researchLoading ? "Researching\u2026" : "Research this topic"}
                    </button>
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <a
                      href={semrushUrl(researchTopicText)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[12px] font-medium text-indigo-600 transition hover:text-indigo-700">
                      🔑 Research keywords in Semrush
                    </a>
                  </div>

                  {researchError && (
                    <p className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-[12px] text-red-700 ring-1 ring-red-100">{researchError}</p>
                  )}

                  {research && (
                    <div className="mt-4 space-y-4">
                      {research.summary && (
                        <p className="text-[13px] leading-relaxed text-ink">{research.summary}</p>
                      )}

                      <div className="grid gap-3 sm:grid-cols-2">
                        {Array.isArray(research.angles) && research.angles.length > 0 && (
                          <div className="rounded-xl bg-white p-4 ring-1 ring-line">
                            <div className="text-[12px] font-semibold uppercase tracking-wide text-ink-muted">Content angles</div>
                            <ul className="mt-2 space-y-1">
                              {research.angles.map((a: string, i: number) => (
                                <li key={i}>
                                  <button type="button" onClick={() => applyIdea(a)} title="Draft this angle"
                                    className="w-full rounded-lg px-1.5 py-1 text-left text-[13px] text-ink transition hover:bg-indigo-50 hover:text-indigo-900">
                                    &bull; {a}
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        {Array.isArray(research.viralityFactors) && research.viralityFactors.length > 0 && (
                          <div className="rounded-xl bg-white p-4 ring-1 ring-line">
                            <div className="text-[12px] font-semibold uppercase tracking-wide text-ink-muted">Why it can spread</div>
                            <ul className="mt-2 space-y-1">
                              {research.viralityFactors.map((v: string, i: number) => (
                                <li key={i} className="text-[13px] text-ink">&bull; {v}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>

                      {Array.isArray(research.keywords) && research.keywords.length > 0 && (
                        <div className="rounded-xl bg-white p-4 ring-1 ring-line">
                          <div className="text-[12px] font-semibold uppercase tracking-wide text-ink-muted">Suggested keywords</div>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {research.keywords.map((k: any, i: number) => (
                              <button key={i} type="button" onClick={() => applyIdea(String(k?.term || ''), 'research-keyword')}
                                title={(k?.why ? k.why + ' — ' : '') + 'Draft with this keyword'}
                                className="rounded-full bg-indigo-50 px-3 py-1 text-[12px] text-indigo-800 ring-1 ring-indigo-100 transition hover:bg-indigo-100">{k.term}</button>
                            ))}
                          </div>
                        </div>
                      )}

                      {Array.isArray(research.hashtags) && research.hashtags.length > 0 && (
                        <div className="rounded-xl bg-white p-4 ring-1 ring-line">
                          <div className="text-[12px] font-semibold uppercase tracking-wide text-ink-muted">Hashtags</div>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {research.hashtags.map((h: string, i: number) => (
                              <span key={i} className="rounded-full bg-subtle px-3 py-1 text-[12px] text-ink-muted ring-1 ring-line">{h}</span>
                            ))}
                          </div>
                        </div>
                      )}

                      {Array.isArray(research.hooks) && research.hooks.length > 0 && (
                        <div className="rounded-xl bg-white p-4 ring-1 ring-line">
                          <div className="text-[12px] font-semibold uppercase tracking-wide text-ink-muted">Hooks to open with</div>
                          <ul className="mt-2 space-y-1">
                            {research.hooks.map((h: string, i: number) => (
                              <li key={i}>
                                <button type="button" onClick={() => applyIdea(h, 'research-hook')} title="Draft from this hook"
                                  className="w-full rounded-lg px-1.5 py-1 text-left text-[13px] text-ink transition hover:bg-indigo-50 hover:text-indigo-900">
                                  &bull; {h}
                                </button>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {research.trendRead && (
                        <div className="rounded-xl bg-white p-4 ring-1 ring-line">
                          <div className="text-[12px] font-semibold uppercase tracking-wide text-ink-muted">Trend read</div>
                          <p className="mt-2 text-[13px] leading-relaxed text-ink">{research.trendRead}</p>
                        </div>
                      )}

                      {research.draft && (
                        <div className="rounded-xl bg-white p-4 ring-1 ring-line">
                          <div className="flex items-center justify-between">
                            <div className="text-[12px] font-semibold uppercase tracking-wide text-ink-muted">Ready-to-edit draft</div>
                            <button type="button" onClick={() => { try { setMText(String(research.draft || "")); setMStatus(null); scrollToPublisher(); } catch {} }} className="rounded-lg bg-indigo-600 px-2.5 py-1 text-[12px] font-medium text-white transition hover:bg-indigo-700">Use this draft</button> <button type="button" onClick={() => { try { navigator.clipboard.writeText(String(research.draft || "")); } catch {} }} className="rounded-lg px-2.5 py-1 text-[12px] font-medium text-indigo-700 ring-1 ring-indigo-200 transition hover:bg-indigo-50">Copy draft</button>
                          </div>
                          <p className="mt-2 whitespace-pre-wrap text-[13px] leading-relaxed text-ink">{research.draft}</p>
                        </div>
                      )}

                      {research.liveDataNote && (
                        <p className="text-[11px] leading-relaxed text-ink-muted">{research.liveDataNote}</p>
                      )}
                    </div>
                  )}
                </div>
              </div>
              </div>
</CollapsibleSection>
)}

</section>


{/* Autopilot: dynamic-template runs waiting for review — everything but publish */}
{!isDraft && <AutopilotQueue />}

{/* Recent Drafts */}
<section id="section-library" className={"rounded-3xl bg-surface p-6 shadow-card ring-1 ring-line/60 sm:p-7" + (isDraft ? " 2xl:col-span-2" : "")}>
<h2 className="mb-4 text-headline font-semibold">Recent Drafts</h2>
{/* Several at once: tick the drafts, then one Delete. The per-row Delete stays. */}
{safeDrafts.length > 0 && (() => {
const listed = safeDrafts.map((d: any) => String((d && (d.id || d._id)) || '')).filter(Boolean);
const approvedDraftIds = new Set<string>(safeDrafts.filter((d: any) => d && d.approved).map((d: any) => String(d.id || d._id || '')));
const pickedHere = listed.filter((id) => pickedDrafts.has(id));
const allPicked = listed.length > 0 && pickedHere.length === listed.length;
return (
<div className="mb-3 flex flex-wrap items-center gap-3 rounded-xl bg-subtle/60 px-3 py-2 ring-1 ring-line">
<label className="flex cursor-pointer items-center gap-2 text-[12px] font-medium text-ink">
<input type="checkbox" aria-label="Select all drafts shown" checked={allPicked} disabled={bulkDeleting}
onChange={() => setPickedDrafts((prev) => { const next = new Set(prev); if (allPicked) listed.forEach((id) => next.delete(id)); else listed.forEach((id) => next.add(id)); return next; })}
className="h-4 w-4 accent-rose-600" />
{allPicked ? 'All ' + listed.length + ' shown selected' : pickedHere.length ? pickedHere.length + ' selected' : 'Select all shown'}
</label>
{pickedHere.length > 0 && (() => {
const approvedPicked = pickedHere.filter((id) => approvedDraftIds.has(id)).length;
const scope = allPicked ? 'all' : 'selected';
return (
<>
{approvedPicked > 0 ? (
<>
<button type="button" onClick={() => void deleteSelectedDrafts('keep-approved')} disabled={bulkDeleting}
title="Approved posts are the ones a person said yes to; they stay."
className="rounded-lg bg-red-600 px-3 py-1 text-[12px] font-semibold text-white transition hover:opacity-90 disabled:opacity-50">
{bulkDeleting ? 'Deleting…' : 'Delete ' + scope + ' except approved (' + (pickedHere.length - approvedPicked) + ')'}
</button>
<button type="button" onClick={() => void deleteSelectedDrafts('all')} disabled={bulkDeleting}
className="rounded-lg px-3 py-1 text-[12px] font-semibold text-red-700 ring-1 ring-red-300 transition hover:bg-red-50 disabled:opacity-50">
{'Delete ' + scope + ', approved included (' + pickedHere.length + ')'}
</button>
</>
) : (
<button type="button" onClick={() => void deleteSelectedDrafts('all')} disabled={bulkDeleting}
className="rounded-lg bg-red-600 px-3 py-1 text-[12px] font-semibold text-white transition hover:opacity-90 disabled:opacity-50">
{bulkDeleting ? 'Deleting…' : 'Delete ' + scope + ' (' + pickedHere.length + ')'}
</button>
)}
<button type="button" onClick={() => setPickedDrafts(new Set())} disabled={bulkDeleting}
className="rounded-lg px-2.5 py-1 text-[12px] font-medium text-ink-muted ring-1 ring-line transition hover:bg-white disabled:opacity-50">Clear</button>
</>
);
})()}
{draftsMsg && (
// Said HERE, where the buttons are — not at the top of the page, where nobody would know what it was about.
<div className={'basis-full rounded-lg px-3 py-2 text-[12px] ring-1 ' + (draftsMsg.bad ? 'bg-red-50 text-red-900 ring-red-200' : 'bg-emerald-50 text-emerald-900 ring-emerald-200')} role={draftsMsg.bad ? 'alert' : 'status'}>
<span>{draftsMsg.text}</span>
<button type="button" onClick={() => setDraftsMsg(null)} className="ml-3 font-medium underline">Dismiss</button>
</div>
)}
</div>
);
})()}
{/* Clips from Opus — long-form to Shorts */}
{(() => {
const opusClips = safeDrafts.filter((d: any) => d?.pack?.kind === 'clip');
if (opusClips.length === 0) return null;
return (
<div className="mb-6">
<div className="mb-3 flex items-center gap-2">
<h3 className="text-[15px] font-semibold text-ink">Clips from Opus</h3>
<span className="rounded-full bg-subtle px-2 py-0.5 text-[11px] font-medium text-ink-muted ring-1 ring-line">{opusClips.length}</span>
<span className="text-[12px] text-ink-faint">Long-form to Shorts</span>
<button type="button" onClick={refreshClips} disabled={refreshingClips}
className="ml-auto rounded-full bg-subtle px-3 py-1 text-[12px] font-medium text-ink ring-1 ring-line transition hover:bg-white disabled:opacity-40">
{refreshingClips ? 'Refreshing…' : 'Refresh clips'}
</button>
</div>
<div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
{opusClips.map((d: any, i: number) => {
const ready = d?.pack?.status === 'ready' && clipsOf(d).length > 0;
const failed = d?.pack?.status === 'failed';
const count = clipsOf(d).length;
return (
<button key={(d?.id || d?._id || i) + '-opus'} data-ai-target="draft" data-ai-id={String(d?.id || d?._id || '')} data-ai-label={String(d?.topic || d?.title || d?.name || 'Clip')} onClick={() => openDraft(d)}
className="group overflow-hidden rounded-2xl text-left ring-1 ring-line/60 transition hover:ring-black/20">
<div className="relative">
{d?.pack?.thumb ? (
// eslint-disable-next-line @next/next/no-img-element
<img src={d.pack.thumb} alt="Clip still" className="h-28 w-full object-cover" />
) : (
<div className="flex h-28 w-full items-center justify-center bg-subtle text-[12px] text-ink-faint">Clip</div>
)}
<div className="absolute left-2 top-2">
{ready ? (
<span className="rounded-full bg-emerald-600/90 px-2 py-0.5 text-[10px] font-semibold text-white">{count} clip{count === 1 ? '' : 's'}</span>
) : failed ? (
<span className="rounded-full bg-danger/90 px-2 py-0.5 text-[10px] font-semibold text-white">Failed</span>
) : (
<span className="rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-semibold text-white">Processing…</span>
)}
</div>
<div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 transition group-hover:opacity-100">
<span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-ink shadow-card">▶</span>
</div>
</div>
<div className="truncate px-3 py-2 text-[12px] font-medium text-ink">{draftLabel(d?.topic || d?.title, 'Clip')}</div>
</button>
);
})}
</div>
</div>
);
})()}
{safeDrafts.length === 0 ? (
<div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-line py-12 text-center">
{loadError ? (
<>
<div className="text-[14px] font-medium text-ink-muted">We could not load your drafts</div>
<div className="mt-1 max-w-sm text-[12px] text-ink-faint">{loadError}</div>
</>
) : (
<>
<div className="text-[14px] font-medium text-ink-muted">No drafts yet</div>
<div className="mt-1 text-[12px] text-ink-faint">Generate something above to get started.</div>
</>
)}
</div>
) : (
<>
<ul className="divide-y divide-line">
{safeDrafts.map((d, i) => {
const title = draftLabel(d && (d.title || d.topic || d.name));
const body = (d && (d.body || d.instagram || d.text || d.content)) || '';
return (
<li onClick={() => openDraft(d)} role="button" tabIndex={0} key={(d && (d.id || d._id)) || i} data-ai-target="draft" data-ai-id={String((d && (d.id || d._id)) || '')} data-ai-label={String((d && (d.topic || d.title || d.name)) || 'Draft')} className={"cursor-pointer rounded-xl transition hover:bg-subtle/60 flex items-start gap-4 py-4" + (pickedDrafts.has(String((d && (d.id || d._id)) || '')) ? " bg-rose-50/60" : "")}>
<input type="checkbox" aria-label="Select this draft" checked={pickedDrafts.has(String((d && (d.id || d._id)) || ''))} disabled={bulkDeleting}
onClick={(e) => e.stopPropagation()} onChange={() => togglePickedDraft(String((d && (d.id || d._id)) || ''))}
className="mt-3 h-4 w-4 shrink-0 cursor-pointer accent-rose-600" />
{d?.pack?.kind === 'clip' && d?.pack?.thumb ? (
<div className="mb-2 overflow-hidden rounded-lg ring-1 ring-black/10">
{/* eslint-disable-next-line @next/next/no-img-element */}
<img src={d.pack.thumb} alt="Video still" className="h-32 w-full object-cover" />
</div>
) : null}
{d?.pack?._image?.url && d?.pack?.kind !== 'clip' ? (
// eslint-disable-next-line @next/next/no-img-element
<img src={d.pack._image.url} alt={d.pack._image.alt || ''} className="mt-0.5 h-14 w-14 shrink-0 rounded-xl object-cover ring-1 ring-line" />
) : (
<div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-subtle text-[13px] font-semibold text-ink-muted ring-1 ring-line">{i + 1}</div>
)}
<div className="min-w-0">
<div className="flex min-w-0 items-center gap-2">
<span className="truncate text-[14px] font-medium text-ink">{String(title)}</span>
{d?.approved && (
<span title="A person approved this post (or it went out). “Delete … except approved” keeps it." className="inline-flex shrink-0 items-center rounded-full bg-emerald-600 px-2 py-0.5 text-[10px] font-semibold text-white">Approved</span>
)}
{d?.pack?._semrush?.source === 'semrush' && (
<span title={'Semrush keyword research applied — primary: ' + (d.pack._semrush.primary || 'n/a')} className="inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-700 ring-1 ring-emerald-200">🔑 Semrush ✓</span>
)}
</div>
{body && <div className="mt-0.5 line-clamp-2 text-[13px] text-ink-muted">{String(body)}</div>}
</div>
<div className="ml-auto flex shrink-0 items-center gap-1 self-center">
<button type="button" aria-label="Edit draft" onClick={(e) => { e.stopPropagation(); prefillComposerFromDraft(d); }}
className="rounded-lg px-2.5 py-1 text-[12px] font-medium text-ink-muted ring-1 ring-line transition hover:bg-subtle">Edit</button>
<button type="button" aria-label="Delete draft" onClick={(e) => { e.stopPropagation(); deleteDraft((d && (d.id || d._id)) || ''); }}
className="rounded-lg px-2.5 py-1 text-[12px] font-medium text-red-600 ring-1 ring-red-200 transition hover:bg-red-50">Delete</button>
</div>
</li>
);
})}
</ul>
{draftsTotal > safeDrafts.length && (
<div className="mt-5 flex justify-center">
<button type="button" onClick={() => refreshDrafts(draftsOffset + PAGE_SIZE, true)} disabled={loadingMore}
className="rounded-full bg-subtle px-5 py-2 text-[13px] font-medium text-ink ring-1 ring-line transition hover:bg-white disabled:opacity-40">
{loadingMore ? 'Loading…' : 'Load more (' + (draftsTotal - safeDrafts.length) + ' more)'}
</button>
</div>
)}
</>
)}
</section>
</div>


{/* Draft detail modal — click a draft to view / play / edit */}
{(() => {
  // The queue post preview (see previewPostId). Read from the list as it is
  // now, so an approve or delete elsewhere closes it rather than showing a
  // post that is gone.
  const pp: any = previewPostId ? safePosts.find((x: any) => String(x?.id || '') === previewPostId) : null;
  if (!pp || typeof document === 'undefined') return null;
  const ppId = String(pp.id || '');
  const ppMeta = postStatusMeta(pp?.status);
  const ppPending = pp?.videoPending === true;
  const ppWaiting = ppMeta.label === 'Waiting for your approval' && !ppPending;
  // A picture can be edited on a post with a draft behind it and no video.
  const ppCanEdit = Boolean(pp.draft_id) && !pp.mediaUrl;
  const close = () => setPreviewPostId(null);
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4" onClick={close}>
      <div className="relative flex max-h-[90vh] w-full max-w-lg flex-col overflow-hidden rounded-2xl bg-white shadow-2xl ring-1 ring-black/10" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="Post preview">
        <div className="flex items-start justify-between gap-3 border-b border-line px-5 py-4">
          <div className="min-w-0">
            <h3 className="truncate text-base font-semibold text-ink">{pp.packTitle || 'Post preview'}</h3>
            <p className="mt-0.5 text-[12px] text-ink-faint">
              {fmtDateTime(pp.publication_date)} ({scheduleTzLabel()} time){' · '}{(pp.providers || []).map((n: string) => networkLabel(n)).join(', ') || 'no channel'}
            </p>
          </div>
          <button type="button" onClick={close} className="rounded-full px-2 text-lg leading-none text-ink-faint hover:bg-subtle" aria-label="Close preview">×</button>
        </div>
        <div className="overflow-y-auto px-5 py-4">
          {pp.mediaUrl ? (
            <video src={pp.mediaUrl} controls preload="metadata" className="mb-3 max-h-72 w-full rounded-xl bg-black" />
          ) : pp.imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={pp.imageUrl} alt="The picture this post goes out with" className="mb-3 max-h-72 w-full rounded-xl object-contain ring-1 ring-line" />
          ) : (
            <p className="mb-3 rounded-xl bg-subtle px-3 py-2 text-[12px] text-ink-muted ring-1 ring-line">{ppPending ? 'This post is waiting for its video.' : 'No picture or video on this post.'}</p>
          )}
          {ppCanEdit && previewEditing && (
            // EDIT: remake the picture with AI (with notes/prompt for the
            // adjustment), change or remove its title, or use a library photo.
            <div className="mb-3" id="queue-preview-edit">
              <HeroImageControls
                draftId={String(pp.draft_id)}
                hasImage={Boolean(pp.imageUrl)}
                note={pp.metricool_post_id
                  ? 'The new picture is sent to Metricool as soon as it is ready.'
                  : 'This post is not in Metricool yet: the new picture goes with it when it is approved.'}
                beforeChange={() => !pp.metricool_post_id || window.confirm('This replaces the picture and updates the post in Metricool too. Continue?')}
                onChanged={() => afterQueueImageChanged(pp)}
              />
            </div>
          )}
          <div className="whitespace-pre-wrap text-[13px] leading-relaxed text-ink">{pp.text || 'Scheduled post'}</div>
          {sheetRowUrl(pp.source) && (
            <a href={sheetRowUrl(pp.source) as string} target="_blank" rel="noopener noreferrer" title={sheetRowTitle(pp.source)} className="mt-3 inline-flex items-center gap-1 text-[12px] font-medium text-accent hover:underline">
              <span aria-hidden>{'\u{1F4C4}'}</span> {sheetRowLabel(pp.source)} {'\u2197'}
            </a>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2 border-t border-line bg-subtle px-5 py-3">
          <span className={'rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ' + (ppMeta.tone === 'amber' ? 'bg-amber-50 text-amber-700 ring-amber-100' : ppMeta.tone === 'green' ? 'bg-emerald-50 text-emerald-700 ring-emerald-100' : 'bg-blue-50 text-blue-700 ring-blue-100')}>{ppPending ? 'Pending video' : ppMeta.label}</span>
          <span className="flex-1" />
          {ppCanEdit && (
            <button type="button" onClick={() => { setPreviewEditingId(previewEditing ? null : ppId); if (!previewEditing) setTimeout(() => document.getElementById('queue-preview-edit')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 50); }} aria-expanded={previewEditing} title="Remake the picture with AI (with your own notes), change its title, or use a library photo" className={'rounded-full px-3 py-1 text-[12px] font-medium ring-1 ' + (previewEditing ? 'bg-ink text-white ring-ink' : 'text-ink ring-line hover:bg-white')}>{previewEditing ? 'Done editing' : '\u270E Edit'}</button>
          )}
          {ppWaiting && (
            <>
              <button type="button" onClick={() => { close(); continueDraft(pp); }} className="rounded-full px-3 py-1 text-[12px] font-medium text-ink-muted ring-1 ring-line hover:bg-white">Continue</button>
              <button type="button" disabled={approvingId === ppId} onClick={() => void approvePost(pp, true)} className="rounded-full px-3 py-1 text-[12px] font-medium text-accent ring-1 ring-line hover:bg-white disabled:opacity-50">Publish now</button>
              <button type="button" disabled={approvingId === ppId} onClick={() => void approvePost(pp)} className="rounded-full bg-accent px-3 py-1 text-[12px] font-semibold text-white shadow-soft hover:opacity-90 disabled:opacity-50">{approvingId === ppId ? 'Approving…' : 'Approve'}</button>
            </>
          )}
          {!ppWaiting && <button type="button" onClick={close} className="rounded-full px-3 py-1 text-[12px] font-medium text-ink-muted ring-1 ring-line hover:bg-white">Close</button>}
        </div>
      </div>
    </div>,
    document.body,
  );
})()}
{selectedDraft && typeof document !== 'undefined' ? createPortal((
<div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm" onClick={() => { setSelectedDraft(null); setEditingDraft(false); }}>
<div className="relative max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-3xl bg-surface p-6 shadow-card ring-1 ring-line/60 sm:p-7" onClick={(e) => e.stopPropagation()}>
<PanelLoader scope="draft-modal" />
<div className="mb-4 flex items-start justify-between gap-4">
{editingDraft ? (
<input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} aria-label="Draft title" placeholder="Draft title"
className="min-w-0 flex-1 rounded-xl bg-subtle px-3 py-2 text-[16px] font-semibold text-ink ring-1 ring-line focus:ring-accent" />
) : (
<h3 className="text-headline font-semibold text-ink">{draftLabel(selectedDraft?.title || selectedDraft?.topic || selectedDraft?.name, 'Draft')}</h3>
)}
<div className="flex shrink-0 items-center gap-2">
{!editingDraft ? (
<button onClick={() => startEditDraft(selectedDraft)} className="rounded-xl px-3 py-1.5 text-[13px] font-medium text-ink-muted ring-1 ring-line transition hover:bg-subtle">Edit</button>
) : null}
{!editingDraft && !(selectedDraft && selectedDraft.pack && selectedDraft.pack.kind === "clip") ? (<button onClick={() => prefillComposerFromDraft(selectedDraft)} className="rounded-xl bg-accent px-3 py-1.5 text-[13px] font-semibold text-white transition hover:bg-accent-hover">Schedule / Publish</button>) : null}
<button onClick={() => { setSelectedDraft(null); setEditingDraft(false); }} className="rounded-xl px-3 py-1.5 text-[13px] font-medium text-ink-muted ring-1 ring-line transition hover:bg-subtle">Close</button>
</div>
</div>
{/* Semrush provenance: proof that keyword research ran before this draft was written */}
{selectedDraft?.pack?._semrush?.source === 'semrush' && !editingDraft ? (
<div className="mb-4 rounded-2xl bg-emerald-50/70 p-3.5 ring-1 ring-emerald-100">
<div className="flex flex-wrap items-center gap-2">
<span className="inline-flex items-center gap-1 rounded-full bg-emerald-600 px-2.5 py-0.5 text-[11px] font-semibold text-white">🔑 Semrush keyword research applied</span>
{selectedDraft.pack._semrush.fromCache ? <span className="text-[11px] text-emerald-700">cached · 0 units</span> : null}
{selectedDraft.pack._semrush.checkedAt ? <span className="ml-auto text-[11px] text-emerald-700/70">{new Date(selectedDraft.pack._semrush.checkedAt).toLocaleString()}</span> : null}
</div>
<div className="mt-2 flex flex-wrap items-center gap-1.5 text-[12px]">
{selectedDraft.pack._semrush.primary ? (
<span className="rounded-full bg-white px-2.5 py-0.5 font-semibold text-emerald-800 ring-1 ring-emerald-200">
{selectedDraft.pack._semrush.primary}
{selectedDraft.pack._semrush.volume != null ? ' · ' + Number(selectedDraft.pack._semrush.volume).toLocaleString() + '/mo' : ''}
{selectedDraft.pack._semrush.difficulty != null ? ' · KD ' + selectedDraft.pack._semrush.difficulty : ''}
</span>
) : null}
{(Array.isArray(selectedDraft.pack._semrush.keywords) ? selectedDraft.pack._semrush.keywords.slice(1, 7) : []).map((k: string, ki: number) => (
<span key={k + ki} className="rounded-full bg-white px-2 py-0.5 text-emerald-800 ring-1 ring-emerald-200">{k}</span>
))}
{selectedDraft.pack._semrush.intent ? <span className="text-[11px] text-emerald-700">intent: {selectedDraft.pack._semrush.intent}</span> : null}
</div>
</div>
) : null}
{selectedDraft?.pack && selectedDraft.pack.kind !== 'clip' && selectedDraft.pack._semrush && selectedDraft.pack._semrush.source !== 'semrush' && !editingDraft ? (
<p className="mb-4 rounded-xl bg-amber-50 px-3 py-2 text-[12px] text-amber-800 ring-1 ring-amber-200">
{/* Estimated keywords (lib/keyword-fallback.ts) are named; only a draft with none at all reads as written without data. */}
{['model', 'derived'].includes(String(selectedDraft.pack._semrush.source)) ? keywordSourceNote(selectedDraft.pack._semrush) : semrushDraftNote(selectedDraft.pack._semrush.reason)}
</p>
) : null}
{selectedDraft?.pack?._image?.url && selectedDraft?.pack?.kind !== 'clip' && !editingDraft ? (
<div className="mb-4 overflow-hidden rounded-2xl ring-1 ring-line/60">
<a href={selectedDraft.pack._image.url} target="_blank" rel="noopener noreferrer" title="Open full size">
{/* eslint-disable-next-line @next/next/no-img-element */}
<img src={selectedDraft.pack._image.url} alt={selectedDraft.pack._image.alt || 'AI hero image'} className={"w-full object-cover transition hover:opacity-95 " + (modalImgBusy ? 'opacity-50' : '')} />
</a>
<div className="flex flex-wrap items-center gap-2 bg-subtle/60 px-3 py-2">
{selectedDraft.pack._image.verification?.textDetected ? (
<span className="rounded-full bg-red-600/95 px-2 py-0.5 text-[10px] font-semibold text-white" title={(selectedDraft.pack._image.verification?.issues || []).join(' · ') || 'Text detected — content images must be text-free'}>✗ text in image — reroll</span>
) : selectedDraft.pack._image.verification?.status === 'approved' ? (
<span className="rounded-full bg-emerald-600/90 px-2 py-0.5 text-[10px] font-semibold text-white" title={'Machine-verified text-free' + (selectedDraft.pack._image.verification?.score != null ? ' · ' + selectedDraft.pack._image.verification.score + '/100' : '')}>✓ verified</span>
) : selectedDraft.pack._image.verification?.status === 'flagged' ? (
<span className="rounded-full bg-amber-500/95 px-2 py-0.5 text-[10px] font-semibold text-white" title={(selectedDraft.pack._image.verification?.issues || []).join(' · ')}>⚠ flagged: {(selectedDraft.pack._image.verification?.issues || []).slice(0, 2).join('; ')}</span>
) : null}
<span className="text-[11px] text-ink-faint">🖼 AI hero image ({String(selectedDraft.pack._image.model || 'OpenAI')}) — attaches automatically when you schedule or approve. Click to view full size.</span>
<button type="button" onClick={() => regenDraftImage(selectedDraft)} disabled={modalImgBusy}
className="ml-auto rounded-full px-3 py-1 text-[12px] font-medium text-accent ring-1 ring-line transition hover:bg-white disabled:opacity-50">
{modalImgBusy ? 'Regenerating…' : '↻ New image'}
</button>
</div>
</div>
) : null}
{selectedDraft?.pack?.kind === 'clip' ? (
(() => {
const clips = clipsOf(selectedDraft);
if (clips.length > 0) {
return (
<div className="space-y-5">
{clips.map((c: Clip, ci: number) => (
<div key={c.id || ci} className="overflow-hidden rounded-2xl ring-1 ring-line/60">
<video controls autoPlay muted playsInline preload="auto" poster={selectedDraft?.pack?.thumb || undefined} src={c.preview || c.export}
  onError={(e) => { const v = e.currentTarget; const box = v.parentElement; if (box && !box.querySelector('[data-clip-expired]')) { v.style.display = 'none'; const d = document.createElement('div'); d.setAttribute('data-clip-expired', '1'); d.className = 'aspect-video w-full bg-black text-[13px] text-white flex items-center justify-center text-center px-4'; d.textContent = 'Preview link expired — re-sync this clip to play it again.'; box.prepend(d); } }}
className="aspect-video w-full bg-black" />
<div className="p-3">
<div className="flex items-center justify-between gap-3">
<div className="truncate text-[13px] font-semibold text-ink">{c.title || ('Clip ' + (ci + 1))}</div>
<span className="shrink-0 text-[11px] text-ink-faint">{fmtDuration(c.durationMs)}</span>
</div>
{c.description ? <p className="mt-1 line-clamp-2 text-[12px] text-ink-muted">{c.description}</p> : null}
{c.hashtags ? <p className="mt-1 truncate text-[11px] text-accent">{c.hashtags}</p> : null}
<div className="mt-2 flex items-center gap-2">
<button type="button" onClick={() => prefillComposerFromClip(c)} className="rounded-full bg-accent px-3 py-1 text-[12px] font-semibold text-white transition hover:bg-accent-hover">Publish / Schedule</button>
{c.export ? (
<a href={c.export} target="_blank" rel="noopener noreferrer"
className="rounded-full bg-ink px-3 py-1 text-[12px] font-medium text-white transition-opacity hover:opacity-90">Download</a>
) : null}
</div>
</div>
</div>
))}
</div>
);
}
if (selectedDraft?.pack?.status === 'failed') {
return (<div className="rounded-2xl border border-dashed border-line p-6 text-center text-[13px] text-ink-muted">This clip job failed to render. Try submitting the video again.</div>);
}
return (
<div className="rounded-2xl border border-dashed border-line p-8 text-center">
<div className="mx-auto mb-3 h-6 w-6 animate-spin rounded-full border-2 border-line border-t-accent" />
<div className="text-[14px] font-medium text-ink-muted">Clips are still rendering</div>
<div className="mt-1 text-[12px] text-ink-faint">This can take a few minutes. They&apos;ll appear here automatically when ready.</div>
</div>
);
})()
) : editingDraft ? (
<div>
<textarea value={editBody} onChange={(e) => setEditBody(e.target.value)} rows={14} aria-label="Draft content" placeholder="Draft content..."
className="w-full resize-y rounded-2xl bg-subtle/50 p-4 text-[14px] leading-relaxed text-ink ring-1 ring-line/60 focus:ring-accent" />
<div className="mt-4 flex items-center gap-3">
<button onClick={saveDraftEdits} disabled={savingEdit} className="rounded-full bg-accent px-5 py-2 text-[13px] font-semibold text-white shadow-soft transition-colors hover:bg-accent-hover disabled:opacity-40">{savingEdit ? 'Saving...' : 'Save changes'}</button>
<button onClick={() => setEditingDraft(false)} disabled={savingEdit} className="rounded-full px-4 py-2 text-[13px] font-medium text-ink-muted ring-1 ring-line transition hover:bg-subtle disabled:opacity-40">Cancel</button>
</div>
</div>
) : (
(() => {
  const secs = formatSections(selectedDraft?.pack);
  if (secs.length > 0) {
    return (
      <div className="space-y-4">
        {secs.map((s, si) => (
          <div key={si} className="rounded-2xl bg-subtle/50 p-4 ring-1 ring-line/60">
            <div className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-ink-muted">{s.label}</div>
            <div className="whitespace-pre-wrap text-[14px] leading-relaxed text-ink">{s.text}</div>
          </div>
        ))}
      </div>
    );
  }
  if (selectedDraft?.pack?.kind === 'image') {
    return (
      <p className="rounded-2xl bg-subtle/50 p-4 text-[13px] text-ink-muted ring-1 ring-line/60">
        Standalone AI image created in the Image Studio — schedule it, or reroll it with &ldquo;New image&rdquo; above.
      </p>
    );
  }
  return (
    <div className="whitespace-pre-wrap rounded-2xl bg-subtle/50 p-4 text-[14px] leading-relaxed text-ink ring-1 ring-line/60">{String(selectedDraft?.body || selectedDraft?.pack?.instagram || selectedDraft?.pack?.text || selectedDraft?.text || selectedDraft?.pack?.content || JSON.stringify(selectedDraft?.pack ?? {}, null, 2))}</div>
  );
})()
)}
</div>
</div>
), document.body) : null}
</div>
</div>
</main>
</div>
</div>
);
}

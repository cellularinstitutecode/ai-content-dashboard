'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import PageNav from '@/components/PageNav';
import { localDateKey, tightestLimit, networkLabel, PUBLISH_NETWORKS, mediaProblem } from '@/lib/composer';
import MediaPicker from '@/components/MediaPicker';
import { announce, fetchPosts, onRefresh } from '@/components/refreshBus';
import { useWorkspace } from '@/components/workspace';
import { PanelLoader } from '@/components/LoadingScreen';
import { friendlyError, friendlyErrorFromResponse } from '@/lib/friendly-error';
import { METRICOOL_BLOG_ID, metricoolPlannerUrl } from '@/lib/metricool-links';
// The Approve button must agree with the API about what may go out.
import { isAwaitingApproval, postStatusMeta } from '@/lib/post-mode';
import { overduePosts, weeklyPlanByDay, type PlanTemplate } from '@/lib/calendar-plan';
import { fmtClock12 } from '@/lib/clock12';
import { sheetRowUrl, sheetRowLabel, sheetRowTitle, type PostSource } from '@/lib/sheet-link';
import { fmtScheduleTime, fmtScheduleSlot, fmtScheduleDateTime, scheduleDateKey, scheduleWallClock, isoAtScheduleWallClock, scheduleTzLabel, scheduleInputValue, scheduleInstantFromInput } from '@/lib/schedule-clock';
// Autopilot drafts waiting for approval sit in this list too, so the calendar
// is the one place to work from. Same route and same rules as the Dashboard.
import { mergeByDate, reviewRuns, runText } from '@/lib/publishing-list';
import RunPreview, { type ReviewRun } from '@/components/RunPreview';
import { fixButtons, fixPlan, fixRunning, runFixInput, type FixStep } from '@/lib/fix-plan';
import HeroImageControls from '@/components/HeroImageControls';

type Post = {
  id?: string;
  text?: string;
  providers?: string[];
  publication_date?: string;
  status?: string;
  metricool_post_id?: string | null;
  /** Set by GET /api/posts: this copy came from a video and has none attached. */
  videoPending?: boolean;
  /** Set by GET /api/posts: which row of which tab this copy was written from. */
  source?: PostSource | null;
  /** Set by GET /api/posts: the video attached to this post, if any. */
  mediaUrl?: string | null;
  /** Set by GET /api/posts: the linked draft's hero image, if any. */
  imageUrl?: string | null;
  packTitle?: string | null;
  /** The draft this post was written from, whose hero image is the post's picture. */
  draft_id?: string | null;
};

function toArray(x: any): any[] {
  if (Array.isArray(x)) return x;
  if (x && Array.isArray(x.posts)) return x.posts;
  if (x && Array.isArray(x.data)) return x.data;
  return [];
}

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const DOW = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
// The channel list lives in lib/composer.ts. This page held the third hardcoded
// copy of it, which is how YouTube and TikTok stayed unpickable everywhere.
const NETWORKS = PUBLISH_NETWORKS;

// Shared with lib/composer so the rule has one home and one test.
const dateKey = localDateKey;

// Which calendar square a post belongs in, and the time printed on it — both
// on the SCHEDULE clock. Bucketing by the viewer's clock put a late-evening
// post on the following day for anyone east of the schedule zone, and printed a time
// that disagreed with the composer that created it.
function postDayKey(iso?: string) {
  if (!iso) return '';
  return scheduleDateKey(iso);
}

function timeLabel(iso?: string) {
  if (!iso) return '';
  return fmtScheduleTime(iso);
}

// Build a 6-row x 7-col grid of Dates covering the visible month.
function buildGrid(year: number, month: number): Date[] {
  const first = new Date(year, month, 1);
  const start = new Date(first);
  start.setDate(first.getDate() - first.getDay()); // back up to Sunday
  const cells: Date[] = [];
  for (let i = 0; i < 42; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    cells.push(d);
  }
  return cells;
}

export default function CalendarPage() {
  const [posts, setPosts] = useState<Post[]>([]);
  // The weekly planner's slots, shown under each weekday so the calendar reads
  // against the plan. Read-only here; they are edited on Templates.
  const [planTemplates, setPlanTemplates] = useState<PlanTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  // The list could not be read. Kept apart from `err`, which also carries
  // warnings about a list that DID load: "No scheduled posts yet" under a
  // failed load read as "nothing is scheduled", which is the wrong conclusion.
  const [loadFailed, setLoadFailed] = useState(false);
  const [saving, setSaving] = useState<string | null>(null);
  /** "Reschedule": the post whose date-and-time box is open, and what it reads (on the schedule clock). */
  const [rescheduleFor, setRescheduleFor] = useState<{ id: string; value: string; kind: 'post' | 'run' } | null>(null);
  /** What "Verify / fix" concluded about the post it was pressed on (shown in that post's preview only). */
  const [fixNote, setFixNote] = useState<{ id: string; note: string; changed: boolean } | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  // Publishing list: which posts are ticked for bulk delete, which one is open
  // in the preview, and the running bulk delete's progress.
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [bulk, setBulk] = useState<{ done: number; total: number } | null>(null);
  // Autopilot runs, as GET /api/autopilot/runs returns them (the Dashboard's
  // own read). Only the ones waiting for a decision are shown.
  const [runs, setRuns] = useState<ReviewRun[]>([]);
  const [runsFailed, setRunsFailed] = useState(false);
  const [runBusy, setRunBusy] = useState<string | null>(null);
  const [previewRunId, setPreviewRunId] = useState<string | null>(null);

  // Click-a-day scheduling panel state
  const [scheduleDay, setScheduleDay] = useState<Date | null>(null);
  const [pNetworks, setPNetworks] = useState<string[]>(['facebook']);
  const [pMedia, setPMedia] = useState<string>('');
  const [pMediaLabel, setPMediaLabel] = useState<string>('');
  const [pTime, setPTime] = useState('09:00');
  const [pText, setPText] = useState('');
  const [pBusy, setPBusy] = useState(false);
  const [pStatus, setPStatus] = useState<string | null>(null);

  // The "today" marker has to be decided in the browser, never at prerender time.
  // This is a client component, but Next.js still renders its HTML on the server,
  // and React does not reconcile mismatched className attributes during
  // production hydration — so a date captured when the page was built stays
  // baked into the grid and highlights the wrong cell (it marked Aug 20 on
  // Aug 21). `mounted` guarantees one real post-hydration render, which is what
  // actually patches the DOM. Until then no cell claims to be today, which is
  // honest rather than wrong. The interval keeps a tab left open overnight right.
  const [mounted, setMounted] = useState(false);
  const [today, setToday] = useState(() => new Date());
  const [cursor, setCursor] = useState(() => {
    const d = new Date();
    return { year: d.getFullYear(), month: d.getMonth() };
  });

  useEffect(() => {
    setMounted(true);
    const now = new Date();
    setToday(now);
    setCursor({ year: now.getFullYear(), month: now.getMonth() });
    const id = setInterval(() => {
      setToday((prev) => {
        const d = new Date();
        return dateKey(prev) === dateKey(d) ? prev : d;
      });
    }, 60_000);
    return () => clearInterval(id);
  }, []);
  const [aiTopic, setAiTopic] = useState('');
  const [aiProvider, setAiProvider] = useState<'anthropic' | 'openai'>('anthropic');
  const [aiBusy, setAiBusy] = useState(false);
  const workspace = useWorkspace();

  async function draftWithAI() {
    if (!aiTopic.trim()) { setErr('Enter a topic for the AI to draft from.'); return; }
    setErr('');
    setAiBusy(true);
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-cs-progress-scope': 'calendar' },
        body: JSON.stringify({ topic: aiTopic, provider: aiProvider, model: aiProvider === 'anthropic' ? 'claude-sonnet-4-5' : 'gpt-4o', type: 'social' }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to draft');
      const pack = data?.pack || {};
      const drafted = pack.instagram || pack.facebook || pack.linkedin || pack.blog || '';
      setPText(drafted);
      workspace.setTopic(aiTopic, { source: 'calendar' });
      // Persist it like every other generator does, so a draft written on the
      // calendar is not lost when the scheduling panel closes.
      try {
        const saved = await fetch('/api/drafts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ topic: aiTopic, pack }),
        });
        if (saved.ok) announce('drafts', 'stats');
      } catch { /* the draft is still usable in the composer */ }
    } catch (e: any) {
      setErr(e?.message || 'Failed to draft with AI');
    } finally {
      setAiBusy(false);
    }
  }

  useEffect(() => { refresh(); void loadRuns(); lastSyncRef.current = Date.now(); }, []);

  // Keeping the page current. Nothing tells this page when the Autopilot
  // finishes a draft in the background (the hourly engine, or another tab), so
  // the list reloads by itself — when the tab comes back into view after 30
  // seconds away, and every two minutes while it is open and visible — and
  // "↻ Refresh" does it on demand. Posts read from their own rate-limit
  // bucket (posts-read) and the runs read has none, so this is cheap.
  const lastSyncRef = useRef(0);
  const syncingRef = useRef(false);
  const [syncing, setSyncing] = useState(false);
  const [syncedAt, setSyncedAt] = useState<Date | null>(null);
  async function refreshAll() {
    if (syncingRef.current) return;
    syncingRef.current = true;
    setSyncing(true);
    try {
      await Promise.all([refresh(), loadRuns()]);
      lastSyncRef.current = Date.now();
      setSyncedAt(new Date());
    } finally {
      syncingRef.current = false;
      setSyncing(false);
    }
  }
  const refreshAllRef = useRef(refreshAll);
  useEffect(() => { refreshAllRef.current = refreshAll; });
  useEffect(() => {
    const stale = (ms: number) => document.visibilityState === 'visible' && Date.now() - lastSyncRef.current >= ms;
    const onBack = () => { if (stale(30_000)) void refreshAllRef.current(); };
    const tick = window.setInterval(() => { if (stale(120_000)) void refreshAllRef.current(); }, 30_000);
    document.addEventListener('visibilitychange', onBack);
    window.addEventListener('focus', onBack);
    return () => {
      window.clearInterval(tick);
      document.removeEventListener('visibilitychange', onBack);
      window.removeEventListener('focus', onBack);
    };
  }, []);

  // The Autopilot drafts. Best-effort: a failed read says so in the list and
  // never hides the posts.
  async function loadRuns() {
    try {
      const r = await fetch('/api/autopilot/runs');
      if (!r.ok) { setRunsFailed(true); return; }
      const j = await r.json().catch(() => ({}));
      if (Array.isArray(j?.runs)) { setRuns(j.runs); setRunsFailed(false); }
    } catch {
      setRunsFailed(true);
    }
  }

  // Approving, skipping or re-imaging a run anywhere in the app changes this list.
  useEffect(() => onRefresh((scopes) => {
    if (scopes.includes('autopilot') || scopes.includes('images') || scopes.includes('drafts')) void loadRuns();
  }), []);

  // While a FIX works in the background, re-read the runs every few seconds
  // so its progress and result show without a reload. When one finishes, the
  // rest of the app hears about the changed draft.
  const fixingIds = useMemo(() => runs.filter((r) => fixRunning(r.angle)).map((r) => r.id).join(','), [runs]);
  const wasFixing = useRef('');
  useEffect(() => {
    if (wasFixing.current && wasFixing.current !== fixingIds) announce('drafts', 'images', 'autopilot');
    wasFixing.current = fixingIds;
    if (!fixingIds) return;
    const t = window.setInterval(() => { void loadRuns(); }, 5000);
    return () => window.clearInterval(t);
  }, [fixingIds]);

  // The reviewer's decision on an Autopilot draft — the same request the
  // Dashboard sends, so approve logic lives in one place (lib/autopilot.ts).
  async function runAct(run: ReviewRun, action: 'approve' | 'skip' | 'fix', schedule = false, scope?: FixStep) {
    const fallback = action === 'approve' ? 'We could not approve that draft.' : action === 'fix' ? 'We could not fix that draft.' : 'We could not skip that draft.';
    setRunBusy(run.id);
    setErr(null);
    try {
      const r = await fetch('/api/autopilot/runs', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ id: run.id, action, schedule, ...(scope ? { scope } : {}) }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(friendlyError(j, fallback));
      if (action === 'fix') {
        // FIX answers at once and works in the background; the run carries its
        // progress (angle.fix), which the poll below keeps fresh. The card
        // stays open and usable.
        await loadRuns();
        return;
      }
      setPreviewRunId(null);
      // The approved run is now a `posts` row: reload both so it shows as Scheduled.
      await Promise.all([refresh(), loadRuns()]);
      if (action === 'approve') announce('posts', 'stats', 'drafts', 'autopilot', 'insights');
      else announce('drafts', 'autopilot');
    } catch (e: any) {
      setErr(friendlyError(e, fallback));
    } finally {
      setRunBusy(null);
    }
  }

  function approveRunScheduled(run: ReviewRun) {
    if (!window.confirm('Approve and schedule this post?\n\nIt will be published at ' + fmtScheduleSlot(run.scheduled_for) + ' (brand time). Metricool does the publishing; you will not need to open it.')) return;
    void runAct(run, 'approve', true);
  }
  function approveRunDraft(run: ReviewRun) {
    if (!window.confirm('Approve as a draft?\n\nIt goes to Metricool for review, not live. You can approve it from this list afterwards.')) return;
    void runAct(run, 'approve', false);
  }
  function skipRun(run: ReviewRun) {
    if (!window.confirm('Skip this draft? It will not be published.')) return;
    void runAct(run, 'skip');
  }
  /** One repair — the citation, the image or the copy — each its own button and its own AI cost. */
  function fixRun(run: ReviewRun, step: FixStep) {
    void runAct(run, 'fix', false, step);
  }

  useEffect(() => {
    // Best-effort: a failed read just hides the plan row, never the calendar.
    fetch('/api/templates')
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => setPlanTemplates(Array.isArray(j?.templates) ? j.templates : []))
      .catch(() => setPlanTemplates([]));
  }, []);
  const planByDay = useMemo(() => weeklyPlanByDay(planTemplates), [planTemplates]);

  // The calendar grid is the same `posts` table the dashboard's queue and stat
  // cards read, so anything that schedules, approves or reschedules a post
  // anywhere in the app refreshes this grid.
  useEffect(() => onRefresh((scopes) => { if (scopes.includes('posts')) refresh(); }), []);

  // Carry the current topic in from the generator / Semrush.
  useEffect(() => {
    if (workspace.topic && !aiTopic) setAiTopic(workspace.topic);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workspace.topic]);

  async function refresh() {
    setLoading(true);
    setErr(null);
    try {
      const r = await fetchPosts();
      if (!r.ok) {
        // What was already on screen stays there: a refresh that failed is
        // not news that every post was deleted.
        setLoadFailed(true);
        setErr(await friendlyErrorFromResponse(r, 'We could not load your scheduled posts. Reload in a moment.'));
        return;
      }
      const j = await r.json().catch(() => null);
      setPosts(toArray(j));
      setLoadFailed(false);
      // The packs behind these posts could not be read, so nothing can be
      // marked "Pending video" and an absent chip would read as "all fine".
      if (j?.packsUnavailable === true) {
        setErr('We could not read the drafts behind these posts, so any post waiting on its video is not marked here. Approving is still blocked for those — reload in a moment.');
      }
    } catch (e: any) {
      setLoadFailed(true);
      setErr(friendlyError(e, 'We could not reach the server to load your scheduled posts.'));
    } finally {
      setLoading(false);
    }
  }

  const grid = useMemo(() => buildGrid(cursor.year, cursor.month), [cursor.year, cursor.month]);

  const byDay = useMemo(() => {
    const m: Record<string, Post[]> = {};
    for (const p of posts) {
      const k = postDayKey(p.publication_date);
      if (!k) continue;
      (m[k] = m[k] || []).push(p);
    }
    return m;
  }, [posts]);

  function prevMonth() {
    setCursor((c) => {
      const d = new Date(c.year, c.month - 1, 1);
      return { year: d.getFullYear(), month: d.getMonth() };
    });
  }
  function nextMonth() {
    setCursor((c) => {
      const d = new Date(c.year, c.month + 1, 1);
      return { year: d.getFullYear(), month: d.getMonth() };
    });
  }
  function goToday() {
    const n = new Date();
    setCursor({ year: n.getFullYear(), month: n.getMonth() });
  }

  // Reschedule: keep the original time-of-day, move to the dropped calendar day.
  async function reschedule(id: string, targetDay: Date) {
    const post = posts.find((p) => p.id === id);
    if (!post) return;
    // Keep the post's time of day AS THE SCHEDULE CLOCK READS IT, and land it on the
    // dropped square. Reading getHours() off the viewer's clock moved the post
    // by the offset between the two zones every time it was dragged.
    const w = post.publication_date ? scheduleWallClock(post.publication_date) : null;
    const iso = isoAtScheduleWallClock(
      targetDay.getFullYear(), targetDay.getMonth() + 1, targetDay.getDate(),
      w ? w.hh : 9, w ? w.mm : 0
    );
    if (postDayKey(post.publication_date) === dateKey(targetDay)) return; // no-op
    await rescheduleTo(id, iso);
  }

  /** Open the "Reschedule" box for a post, showing the time it has now (or 9:00 tomorrow when it has none). */
  function openReschedule(p: Post) {
    const current = p.publication_date && !isNaN(new Date(p.publication_date).getTime())
      ? scheduleInputValue(p.publication_date)
      : scheduleInputValue(new Date(today.getTime() + 86400000).toISOString()).slice(0, 11) + '09:00';
    setRescheduleFor({ id: String(p.id), value: current, kind: 'post' });
  }

  /** The same box for an Autopilot draft (a missed one, usually): its time moves, its draft and state stay. */
  function openRescheduleRun(r: ReviewRun) {
    const current = r.scheduled_for && !isNaN(new Date(r.scheduled_for).getTime())
      ? scheduleInputValue(r.scheduled_for)
      : scheduleInputValue(new Date(today.getTime() + 86400000).toISOString()).slice(0, 11) + '09:00';
    setRescheduleFor({ id: r.id, value: current, kind: 'run' });
  }

  /** The box's Save: the value read on the schedule clock, sent like a drag. */
  async function saveReschedule() {
    if (!rescheduleFor) return;
    const iso = scheduleInstantFromInput(rescheduleFor.value);
    if (!iso) { setErr('Pick a date and a time first.'); return; }
    const { id, kind } = rescheduleFor;
    setRescheduleFor(null);
    if (kind === 'run') await rescheduleRunTo(id, iso);
    else await rescheduleTo(id, iso);
  }

  /** Move an Autopilot run: POST /api/autopilot/runs { action: 'reschedule' }; the queue reloads, or the refusal is said. */
  async function rescheduleRunTo(id: string, iso: string) {
    setRunBusy(id);
    setErr(null);
    try {
      const r = await fetch('/api/autopilot/runs', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ id, action: 'reschedule', scheduled_for: iso }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(friendlyError(j, 'We could not move that draft.'));
      setPreviewRunId(null);
      await loadRuns();
      announce('autopilot', 'drafts');
    } catch (e: any) {
      setErr(friendlyError(e, 'We could not move that draft.'));
    } finally {
      setRunBusy(null);
    }
  }

  /**
   * Move a post to an instant: the calendar first (optimistic), then the
   * server — which moves it in Metricool too and refuses when it cannot, in
   * which case the chip goes back and the reason is said.
   */
  async function rescheduleTo(id: string, iso: string) {
    // optimistic update
    setPosts((prev) => prev.map((p) => (p.id === id ? { ...p, publication_date: iso } : p)));
    setSaving(id);
    try {
      const r = await fetch('/api/posts', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, publication_date: iso }),
      });
      // The server refuses the local move when it cannot move the post in
      // Metricool, so a failure here means nothing changed anywhere - put the
      // chip back and say why, instead of leaving the calendar disagreeing
      // with the account it is supposed to mirror.
      if (!r.ok) throw new Error(await friendlyErrorFromResponse(r, 'We could not move that post.'));
      announce('posts', 'stats', 'insights');
    } catch (e: any) {
      setErr(friendlyError(e, 'We could not move that post.'));
      refresh(); // revert to server truth
    } finally {
      setSaving(null);
    }
  }

  // The reviewer's yes, from the calendar. Same endpoint and same rules as the
  // dashboard queue: Metricool moves the post to its live queue first, and our
  // row changes only if that succeeded.
  async function approve(post: Post) {
    if (!post.id) return;
    const nets = (post.providers || []).map(networkLabel).join(', ') || 'the selected channels';
    if (!window.confirm('Approve this post?\n\nIt will be published to ' + nets + ' at ' + timeLabel(post.publication_date) + ' on this day (' + scheduleTzLabel() + ' time). Metricool does the publishing.')) return;
    setSaving(post.id);
    try {
      const r = await fetch('/api/posts', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: post.id, action: 'approve' }),
      });
      if (!r.ok) throw new Error(await friendlyErrorFromResponse(r, 'We could not approve that post.'));
      await refresh();
      announce('posts', 'stats', 'insights');
    } catch (e: any) {
      setErr(friendlyError(e, 'We could not approve that post.'));
    } finally {
      setSaving(null);
    }
  }

  // What "Verify / fix" does: checks the study in the REF line against the
  // copy and, when it does not support it, swaps in one that does — here, on
  // the draft, and in Metricool. Never an approval; the post stays where it is.
  async function verifyFix(post: Post) {
    if (!post.id) return;
    setSaving(post.id);
    setFixNote(null);
    try {
      const r = await fetch('/api/posts', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: post.id, action: 'fix_citation' }),
      });
      if (!r.ok) throw new Error(await friendlyErrorFromResponse(r, 'We could not check that post’s citation.'));
      const j = await r.json().catch(() => ({}));
      setErr(null);
      setFixNote({ id: post.id, note: String(j?.note || (j?.fixed ? 'The citation was replaced.' : 'Checked.')), changed: Boolean(j?.fixed) && !j?.metricool });
      if (j?.fixed) {
        // Reloaded whatever Metricool said: the corrected text is on the row.
        await refresh();
        announce('posts', 'drafts');
      }
    } catch (e: any) {
      setErr(friendlyError(e, 'We could not check that post’s citation.'));
    } finally {
      setSaving(null);
    }
  }

  // What the "Pending video" square does.
  //
  // Copy transcribed from a video may not go out without that video, so this
  // makes the world-readable copy and attaches it. It is NOT an approval: the
  // post stays exactly where it is and still needs a person to read it.
  async function attachVideo(post: Post) {
    if (!post.id) return;
    setSaving(post.id);
    try {
      const r = await fetch('/api/posts', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: post.id, action: 'attach_video' }),
      });
      if (!r.ok) throw new Error(await friendlyErrorFromResponse(r, 'We could not attach the video to that post.'));
      setErr(null);
      await refresh();
      announce('posts');
    } catch (e: any) {
      setErr(friendlyError(e, 'We could not attach the video to that post.'));
    } finally {
      setSaving(null);
    }
  }

  // The post's picture changed on its draft (Image section of the preview).
  // If the post is already in Metricool, send the new picture there through
  // the same replace every move and approve use (PATCH sync_media). A post
  // that has its video keeps the video; the picture is not sent in front of it.
  async function afterPostImageChanged(post: Post) {
    try {
      if (post.id && post.metricool_post_id && !post.mediaUrl) {
        const r = await fetch('/api/posts', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: post.id, action: 'sync_media' }),
        });
        if (!r.ok) throw new Error(await friendlyErrorFromResponse(r, 'The new picture is saved here, but Metricool did not take it. It goes with the post the next time it is approved or moved.'));
      }
    } finally {
      await refresh();
      announce('posts', 'images', 'drafts');
    }
  }

  // Open the scheduling panel for a given day.
  function openScheduler(day: Date) {
    setScheduleDay(day);
    setPNetworks(['facebook']);
    setPMedia(''); setPMediaLabel('');
    setPTime('09:00');
    setPText('');
    setPStatus(null);
  }

  function togglePNetwork(id: string) {
    setPNetworks((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  // Schedule a new post on the selected day across all chosen networks.
  async function submitSchedule() {
    if (!scheduleDay) return;
    if (!pNetworks.length) { setPStatus('Pick at least one network.'); return; }
    if (!pText.trim()) { setPStatus('Add some post text.'); return; }
    const missingMedia = mediaProblem(pNetworks, pMedia);
    if (missingMedia) { setPStatus(missingMedia); return; }
    const overBy = pOverBy;
    if (overBy > 0) {
      setPStatus('Too long for ' + networkLabel(pLimit!.network) + ' by ' + overBy.toLocaleString() + ' character' + (overBy === 1 ? '' : 's') + '. Trim it, or unselect that channel.');
      return;
    }
    const [hh, mm] = pTime.split(':').map((x) => parseInt(x, 10));
    // "09:00" means 9 AM on the schedule clock, not 9 AM wherever the browser is.
    const publishAt = isoAtScheduleWallClock(
      scheduleDay.getFullYear(), scheduleDay.getMonth() + 1, scheduleDay.getDate(),
      isNaN(hh) ? 9 : hh, isNaN(mm) ? 0 : mm
    );

    setPBusy(true);
    setPStatus(null);
    try {
      const results = await Promise.all(
        pNetworks.map(async (network) => {
          const r = await fetch('/api/metricool/schedule', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ network, text: pText, publishAt, blogId: METRICOOL_BLOG_ID || undefined, mediaUrl: pMedia || undefined }),
          });
          // The body, not just the verdict: it carries the sentence saying WHY.
          return { network, ok: r.ok, data: await r.json().catch(() => ({})) };
        })
      );
      const ok = results.filter((x) => x.ok).map((x) => x.network);
      // Same fix as the composer's: a network name on its own tells nobody
      // whether to reconnect an account, shorten the text or do nothing at all.
      const bad = results.filter((x) => !x.ok).map((x) => ({ network: x.network, why: friendlyError(x.data) }));
      const failed = bad.map((x) => x.network);
      const reasons = bad.map((x) => x.network + ': ' + x.why).join(' ');
      await refresh();
      if (ok.length) announce('posts', 'stats', 'insights');
      if (failed.length === 0) {
        setPStatus('Scheduled on ' + ok.join(', ') + '.');
        setScheduleDay(null);
      } else if (ok.length === 0) {
        setPStatus('Error: failed on ' + failed.join(', ') + '. ' + reasons);
      } else {
        setPStatus('Scheduled on ' + ok.join(', ') + '; failed on ' + failed.join(', ') + '. ' + reasons);
      }
    } catch (e: any) {
      setPStatus('Error: ' + (e?.message || 'failed'));
    } finally {
      setPBusy(false);
    }
  }

  // The dashboard composer has enforced network character limits for months;
  // this panel did not, so an over-limit post got as far as Metricool before
  // anything said no. Same helper, same rule, both places.
  const pLimit = tightestLimit(pNetworks);
  const pOverBy = pLimit ? Math.max(0, pText.length - pLimit.limit) : 0;

  const monthLabel = `${MONTHS[cursor.month]} ${cursor.year}`;
  // Empty until mount, so the server-rendered grid never marks a stale day.
  const todayKey = mounted ? dateKey(today) : '';

  // Everything from today onward, soonest first — the right-hand list.
  const upcomingList = useMemo(() => {
    const start = new Date(); start.setHours(0, 0, 0, 0);
    return posts
      .filter((p) => p.publication_date && new Date(p.publication_date).getTime() >= start.getTime())
      .sort((a, b) => new Date(a.publication_date || 0).getTime() - new Date(b.publication_date || 0).getTime());
  }, [posts]);

  // Still waiting for a decision after their time. The list above starts at
  // today, so without this these posts disappeared from the page entirely.
  const overdueList = useMemo(() => (mounted ? overduePosts(posts, isAwaitingApproval, today.getTime()) : []), [posts, mounted, today]);

  // Autopilot drafts waiting for a decision, in with the posts by date. Gated
  // on `mounted` like the overdue list, so the server-rendered page never
  // decides "missed" on a stale clock.
  const runLists = useMemo(() => (mounted ? reviewRuns(runs, today.getTime()) : { upcoming: [] as ReviewRun[], missed: [] as ReviewRun[] }), [runs, mounted, today]);
  const upcomingEntries = useMemo(() => mergeByDate(upcomingList, runLists.upcoming), [upcomingList, runLists]);
  const runsByDay = useMemo(() => {
    const m: Record<string, ReviewRun[]> = {};
    for (const r of [...runLists.upcoming, ...runLists.missed]) {
      const k = postDayKey(r.scheduled_for);
      if (k) (m[k] = m[k] || []).push(r);
    }
    return m;
  }, [runLists]);
  const previewRun = previewRunId ? runs.find((r) => r.id === previewRunId) || null : null;

  function jumpTo(p: Post) {
    if (!p.publication_date) return;
    const d = new Date(p.publication_date);
    setCursor({ year: d.getFullYear(), month: d.getMonth() });
  }

  async function removePost(p: Post) {
    if (!p.id) return;
    if (!window.confirm('Delete this post? It is removed from Metricool too. This cannot be undone.')) return;
    setSaving(p.id);
    try {
      const r = await fetch('/api/posts?id=' + encodeURIComponent(p.id), { method: 'DELETE' });
      if (!r.ok) throw new Error(await friendlyErrorFromResponse(r, 'We could not delete that post.'));
      await refresh();
      announce('posts', 'stats', 'insights');
    } catch (e: any) {
      setErr(friendlyError(e, 'We could not delete that post.'));
    } finally {
      setSaving(null);
    }
  }

  // One selection across the whole publishing list — past-due and upcoming.
  // Ticks only ever refer to posts still listed: a post moved, approved or
  // deleted elsewhere drops out of the selection by itself.
  const overdueIds = useMemo(() => overdueList.map((p) => String(p.id || '')).filter(Boolean), [overdueList]);
  const upcomingIds = useMemo(() => upcomingList.map((p) => String(p.id || '')).filter(Boolean), [upcomingList]);
  const listedIds = useMemo(() => Array.from(new Set([...overdueIds, ...upcomingIds])), [overdueIds, upcomingIds]);
  const pickedIds = listedIds.filter((id) => picked.has(id));
  const allPastPicked = overdueIds.length > 0 && overdueIds.every((id) => picked.has(id));
  const allUpcomingPicked = upcomingIds.length > 0 && upcomingIds.every((id) => picked.has(id));
  function togglePick(id: string) {
    setPicked((prev) => { const next = new Set(prev); if (next.has(id)) next.delete(id); else next.add(id); return next; });
  }
  // Ticks (or unticks) a whole group without touching the other group's ticks.
  function toggleGroup(ids: string[], allOn: boolean) {
    setPicked((prev) => { const next = new Set(prev); ids.forEach((id) => (allOn ? next.delete(id) : next.add(id))); return next; });
  }

  // Deletes the ticked posts through the same DELETE the single
  // button uses (Metricool first, then our row), two at a time, and reports
  // exactly which ones failed rather than stopping at the first problem.
  async function removePicked() {
    const ids = pickedIds;
    if (!ids.length || bulk) return;
    // Approved posts are live in Metricool's queue — deleting them cancels a
    // publication, which is a different decision from clearing stale drafts.
    const live = posts.filter((p) => ids.includes(String(p.id)) && !isAwaitingApproval(p.status)).length;
    const warn = live ? '\n\n' + live + ' of them ' + (live === 1 ? 'is' : 'are') + ' already approved and will NOT publish.' : '';
    if (!window.confirm('Delete ' + ids.length + ' post' + (ids.length === 1 ? '' : 's') + '? They are removed from Metricool too. This cannot be undone.' + warn)) return;
    setErr(null);
    setBulk({ done: 0, total: ids.length });
    const failed: string[] = [];
    let firstReason = '';
    const queue = [...ids];
    const worker = async () => {
      while (queue.length) {
        const id = queue.shift() as string;
        try {
          const r = await fetch('/api/posts?id=' + encodeURIComponent(id), { method: 'DELETE', headers: { 'x-cs-progress': 'quiet' } });
          // Already gone counts as deleted.
          if (r.status === 429) {
            // Hourly cap reached: every remaining request would be refused
            // too, so stop and leave the rest ticked for later.
            failed.push(id, ...queue.splice(0));
            if (!firstReason) firstReason = 'The hourly limit for post changes was reached. Try the rest again in a while.';
          } else if (!r.ok && r.status !== 404) {
            failed.push(id);
            if (!firstReason) firstReason = await friendlyErrorFromResponse(r, 'We could not delete that post.');
          }
        } catch (e) {
          failed.push(id);
          if (!firstReason) firstReason = friendlyError(e, 'We could not delete that post.');
        }
        setBulk((b) => (b ? { ...b, done: b.done + 1 } : b));
      }
    };
    await Promise.all([worker(), worker()]);
    setPicked(new Set(failed));
    if (previewId && !failed.includes(previewId) && ids.includes(previewId)) setPreviewId(null);
    if (failed.length) setErr((ids.length - failed.length) + ' of ' + ids.length + ' deleted. ' + failed.length + ' could not be (still ticked): ' + firstReason);
    setBulk(null);
    await refresh();
    announce('posts', 'stats', 'insights');
  }

  const previewPost = previewId ? posts.find((p) => String(p.id) === previewId) || null : null;
  // Escape closes the preview, as it would any dialog.
  useEffect(() => {
    if (!previewId && !previewRunId) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') { setPreviewId(null); setPreviewRunId(null); } };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [previewId, previewRunId]);

  return (
    <main className="min-h-screen bg-canvas text-ink">
      <header className="flex items-center justify-between border-b border-black/5 bg-surface px-8 py-5">
        <div>
          <h1 className="text-xl font-semibold tracking-tight">Calendar / Publishing</h1>
          <p className="mt-1 text-sm text-ink/50">The month on the left, everything coming up in order on the right. Click a day to schedule a post, or drag a post to another day. All times {scheduleTzLabel()} time.</p>
        </div>
        <PageNav current="/calendar" />
      </header>

      <div className="mx-auto grid max-w-[1500px] gap-6 px-4 py-5 sm:px-6 sm:py-8 lg:grid-cols-[minmax(0,1fr)_380px]">
      <div className="min-w-0">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={prevMonth} className="rounded-full border border-black/10 bg-surface px-4 py-2 text-sm text-ink transition hover:bg-black/5">&lsaquo; Prev</button>
            <button onClick={goToday} className="rounded-full border border-black/10 bg-surface px-4 py-2 text-sm text-ink transition hover:bg-black/5">Today</button>
            <button onClick={nextMonth} className="rounded-full border border-black/10 bg-surface px-4 py-2 text-sm text-ink transition hover:bg-black/5">Next &rsaquo;</button>
            <button
              type="button"
              onClick={() => void refreshAll()}
              disabled={syncing}
              title={syncedAt ? 'Last updated ' + syncedAt.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }) + '. It also updates by itself every two minutes.' : 'Reload the posts and the Autopilot drafts'}
              aria-label="Refresh the publishing list"
              className="rounded-full border border-black/10 bg-surface px-4 py-2 text-sm text-ink transition hover:bg-black/5 disabled:opacity-50"
            >
              {syncing ? 'Refreshing…' : '↻ Refresh'}
            </button>
          </div>
          <h2 className="text-lg font-semibold">{monthLabel}</h2>
          <div className="flex items-center gap-3">
            <div className="min-w-[70px] text-right text-xs text-ink/40">
              {saving ? 'Saving…' : loading ? 'Loading…' : ''}
            </div>
            <a
              href={metricoolPlannerUrl()}
              target="_blank"
              rel="noopener noreferrer"
              title="What has been posted and what is waiting for approval, on Metricool's calendar"
              className="inline-flex items-center gap-1 rounded-full border border-accent/40 px-3 py-1.5 text-[12px] font-medium text-accent transition hover:bg-accent/5"
            >
              {'\u{1F4C5}'} Metricool planner ↗
            </a>
          </div>
        </div>

        {err && (
          <div className="mb-3 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-600">Error: {err}</div>
        )}

        {/* cal-month: on a phone the seven columns keep a readable width and the month is swiped sideways (app/globals.css). */}
        <div className="cal-month grid grid-cols-7 gap-2">
          {DOW.map((d, i) => (
            <div key={d} className="py-1 text-center text-xs font-medium text-ink/40">
              {d}
              {planByDay[i]?.length > 0 && (
                <div className="mt-0.5 space-y-[1px] text-left font-normal" title={'Weekly plan (edit on Templates):\n' + planByDay[i].map((e) => (e.time ? e.time + ' ' : '') + e.name).join('\n')}>
                  {planByDay[i].map((e) => (
                    <div key={e.name + e.time} className={'truncate rounded px-1 text-[9px] leading-[14px] ' + (e.fromStrategy ? 'bg-accent/10 text-accent' : 'bg-black/5 text-ink/50')}>
                      {e.time && <span className="tabular-nums">{fmtClock12(e.time, { compact: true })} </span>}{e.name}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
          {grid.map((day) => {
            const k = dateKey(day);
            const inMonth = day.getMonth() === cursor.month;
            const isToday = k === todayKey;
            const dayPosts = byDay[k] || [];
            return (
              <div
                key={k}
                onClick={() => openScheduler(day)}
                onDragOver={(e) => { if (dragId) e.preventDefault(); }}
                onDrop={(e) => { e.preventDefault(); if (dragId) reschedule(dragId, day); }}
                className={
                  'group flex min-h-[104px] cursor-pointer flex-col rounded-xl border p-2 transition ' +
                  (inMonth ? 'bg-surface ' : 'bg-canvas ') +
                  (isToday ? 'border-accent ring-1 ring-accent/40 ' : 'border-black/5 ') +
                  'hover:border-accent/60 hover:bg-accent/5 '
                }
              >
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-[11px] text-accent opacity-0 transition group-hover:opacity-100">+ Add</span>
                  <span className={'text-xs ' + (isToday ? 'font-semibold text-accent ' : inMonth ? 'text-ink/60 ' : 'text-ink/25 ')}>{day.getDate()}</span>
                </div>
                <div className="flex flex-1 flex-col gap-1">
                  {dayPosts.map((p) => (
                    <div
                      key={p.id}
                      data-ai-target="post" data-ai-id={String(p.id)}
                      draggable
                      onClick={(e) => { e.stopPropagation(); setPreviewId(String(p.id)); }}
                      onDragStart={() => setDragId(p.id || null)}
                      onDragEnd={() => setDragId(null)}
                      title={p.text || ''}
                      className={
                        'cursor-pointer rounded-lg border border-accent/20 bg-accent/5 px-2 py-1 text-[11px] leading-tight text-ink transition hover:bg-accent/10 active:cursor-grabbing ' +
                        (saving === p.id ? 'opacity-50 ' : '')
                      }
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-medium text-accent">{timeLabel(p.publication_date)}</span>
                        {p.videoPending === true ? (
                          // Waiting on its video, not on a reviewer. Approve is
                          // refused server-side for this post, so the square
                          // offers the thing that would actually unblock it.
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); void attachVideo(p); }}
                            disabled={saving === p.id}
                            title="This copy was written from a video and has none attached. Click to attach it."
                            className="rounded-full bg-rose-100 px-1.5 py-[1px] text-[9px] font-semibold text-rose-700 hover:bg-rose-200 disabled:opacity-50"
                          >
                            {saving === p.id ? 'Attaching…' : 'Pending video'}
                          </button>
                        ) : isAwaitingApproval(p.status) ? (
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); void approve(p); }}
                            disabled={saving === p.id}
                            title="Approve — Metricool publishes it at this time"
                            className="rounded-full bg-accent px-1.5 py-[1px] text-[9px] font-semibold text-white hover:opacity-90 disabled:opacity-50"
                          >
                            Approve
                          </button>
                        ) : (
                          <span className="text-[9px] font-medium text-emerald-700">{postStatusMeta(p.status).label}</span>
                        )}
                      </div>
                      <div className="truncate">{p.text || 'Untitled post'}</div>
                      {p.providers && p.providers.length > 0 && (
                        <div className="mt-0.5 truncate text-[10px] text-ink/40">{p.providers.join(', ')}</div>
                      )}
                    </div>
                  ))}
                  {/* Autopilot drafts: amber, not draggable (the slot belongs to
                      the template), click to preview and approve. */}
                  {(runsByDay[k] || []).map((r) => (
                    <div
                      key={r.id}
                      data-ai-target="run" data-ai-id={r.id}
                      onClick={(e) => { e.stopPropagation(); setPreviewRunId(r.id); }}
                      title={runText(r.pack) || r.template_name}
                      className={'cursor-pointer rounded-lg border border-amber-300/60 bg-amber-50 px-2 py-1 text-[11px] leading-tight text-ink transition hover:bg-amber-100 ' + (runBusy === r.id ? 'opacity-50 ' : '')}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-medium text-amber-800">{timeLabel(r.scheduled_for)}</span>
                        <span className="rounded-full bg-amber-200/80 px-1.5 py-[1px] text-[9px] font-semibold text-amber-900">{r.missed ? 'Missed' : 'Autopilot · approve'}</span>
                      </div>
                      <div className="truncate">{r.angle?.query || runText(r.pack) || r.template_name}</div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {!loading && !loadFailed && posts.length === 0 && (
          <p className="mt-6 text-sm text-ink/50">No scheduled posts yet. Click any day above to schedule one.</p>
        )}
      </div>

      {/* Publishing list: every upcoming post in date order, with the same
          actions as the calendar. Clicking one jumps the grid to its month. */}
      <aside id="publishing-list" className="min-w-0">
        <div className="sticky top-6 rounded-2xl border border-black/5 bg-surface p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-[13px] font-semibold uppercase tracking-wide text-ink/60">Publishing list</h2>
            <span className="text-xs text-ink/40">{upcomingEntries.length} coming up{runLists.upcoming.length ? ' · ' + runLists.upcoming.length + ' to approve' : ''}</span>
          </div>
          {runsFailed && (
            <p className="mb-3 rounded-xl bg-amber-50 px-3 py-2 text-[11px] text-amber-800">The Autopilot drafts could not be loaded, so none are shown here. <button type="button" onClick={() => void loadRuns()} className="font-semibold underline">Try again</button></p>
          )}
          {/* Bulk bar for the whole list: tick posts below (past or upcoming),
              then delete them together. Always visible so the option is
              obvious even before anything is ticked. */}
          {listedIds.length > 0 && (
            <div className="mb-3 flex flex-wrap items-center gap-2 rounded-xl bg-subtle/70 px-3 py-2 text-[12px] ring-1 ring-line" data-testid="bulk-bar">
              <span className="font-medium text-ink">{pickedIds.length} selected</span>
              <span className="text-[11px] text-ink/50">Tick posts below to delete several at once</span>
              <span className="flex-1" />
              {pickedIds.length > 0 && !bulk && (
                <button type="button" onClick={() => setPicked(new Set())} className="rounded-full px-2 py-[3px] text-[11px] font-medium text-ink/60 hover:bg-black/5">Clear</button>
              )}
              <button
                type="button"
                onClick={() => void removePicked()}
                disabled={pickedIds.length === 0 || Boolean(bulk)}
                className="rounded-full bg-red-600 px-3 py-[4px] text-[11px] font-semibold text-white hover:opacity-90 disabled:opacity-40"
              >
                {bulk ? 'Deleting ' + bulk.done + ' / ' + bulk.total + '…' : 'Delete selected' + (pickedIds.length ? ' (' + pickedIds.length + ')' : '')}
              </button>
            </div>
          )}
          {(overdueList.length > 0 || runLists.missed.length > 0) && (
            <div className="mb-3 rounded-xl border border-rose-200 bg-rose-50/70 p-3 text-[12px]">
              <div className="mb-1 font-semibold text-rose-800">{overdueList.length + runLists.missed.length} past {overdueList.length + runLists.missed.length === 1 ? 'its' : 'their'} time, still waiting</div>
              <p className="mb-2 text-[11px] text-rose-800/80">These were never approved, so they did not go out. Click one to preview it. Tick the ones you don&apos;t need and delete them together, or move one to tomorrow.{runLists.missed.length ? ' A missed Autopilot draft can only be skipped here.' : ''}</p>
              {overdueIds.length > 0 && (
              <label className="mb-2 flex w-fit cursor-pointer items-center gap-1.5 rounded-lg bg-rose-100/90 px-2 py-1 text-[11px] font-medium text-rose-900">
                <input type="checkbox" checked={allPastPicked} onChange={() => toggleGroup(overdueIds, allPastPicked)} disabled={Boolean(bulk)} className="h-3.5 w-3.5 accent-rose-600" aria-label="Select all past posts" />
                Select all past ({overdueIds.length})
              </label>
              )}
              <ul className="max-h-[45vh] space-y-1.5 overflow-y-auto pr-1">
                {runLists.missed.map((r) => (
                  <li key={r.id} className="flex gap-2 rounded-lg bg-amber-50 p-2 ring-1 ring-amber-200">
                    <div className="min-w-0 flex-1">
                      <button type="button" onClick={() => setPreviewRunId(r.id)} className="block w-full text-left" title="Preview this draft">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-semibold text-ink">{fmtScheduleSlot(r.scheduled_for)}</span>
                          <span className="rounded-full bg-amber-200/80 px-2 py-[1px] text-[10px] font-semibold text-amber-900">Autopilot · missed</span>
                        </div>
                        <div className="mt-0.5 line-clamp-1 text-ink/70">{r.angle?.query || runText(r.pack) || r.template_name}</div>
                      </button>
                      <div className="mt-1 flex gap-1.5">
                        <button type="button" onClick={() => setPreviewRunId(r.id)} className="rounded-full px-2 py-[3px] text-[11px] font-medium text-ink/70 ring-1 ring-black/10 hover:bg-black/5">Preview</button>
                        <button type="button" disabled={runBusy === r.id} onClick={() => openRescheduleRun(r)} title="Pick any date and time" className="rounded-full bg-accent px-2.5 py-[3px] text-[11px] font-semibold text-white hover:opacity-90 disabled:opacity-50">Reschedule</button>
                        <button type="button" disabled={runBusy === r.id} onClick={() => skipRun(r)} className="rounded-full px-2 py-[3px] text-[11px] font-medium text-red-600 hover:bg-red-50 disabled:opacity-50">{runBusy === r.id ? 'Working…' : 'Skip'}</button>
                      </div>
                    </div>
                  </li>
                ))}
                {overdueList.map((p) => {
                  const id = String(p.id || '');
                  const d = p.publication_date ? new Date(p.publication_date) : null;
                  const on = picked.has(id);
                  return (
                    <li key={p.id} className={'flex gap-2 rounded-lg p-2 ring-1 transition ' + (on ? 'bg-red-50 ring-red-300' : 'bg-surface/80 ring-transparent')}>
                      <input
                        type="checkbox"
                        checked={on}
                        onChange={() => togglePick(id)}
                        disabled={Boolean(bulk)}
                        className="mt-0.5 h-3.5 w-3.5 shrink-0 accent-rose-600"
                        aria-label="Select this post"
                      />
                      <div className="min-w-0 flex-1">
                        <button type="button" onClick={() => setPreviewId(id)} className="block w-full text-left" title="Preview this post">
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-semibold text-ink">{d ? d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' }) : '—'} · {timeLabel(p.publication_date)}</span>
                            <span className="text-[10px] text-ink/50">{(p.providers || []).map((n) => networkLabel(n)).join(', ')}</span>
                          </div>
                          <div className="mt-0.5 line-clamp-1 text-ink/70">{p.text || 'Untitled post'}</div>
                        </button>
                        <div className="mt-1 flex gap-1.5">
                          <button type="button" onClick={() => setPreviewId(id)} className="rounded-full px-2 py-[3px] text-[11px] font-medium text-ink/70 ring-1 ring-black/10 hover:bg-black/5">Preview</button>
                          <button type="button" disabled={saving === p.id || Boolean(bulk)} onClick={() => { const t = new Date(today.getTime() + 86400000); void reschedule(id, t); }} className="rounded-full bg-accent px-2.5 py-[3px] text-[11px] font-semibold text-white hover:opacity-90 disabled:opacity-50">Move to tomorrow</button>
                          <button type="button" disabled={saving === p.id || Boolean(bulk)} onClick={() => openReschedule(p)} title="Pick any date and time" className="rounded-full px-2 py-[3px] text-[11px] font-medium text-ink/70 ring-1 ring-black/10 hover:bg-black/5 disabled:opacity-50">Reschedule</button>
                          <button type="button" disabled={saving === p.id || Boolean(bulk)} onClick={() => void removePost(p)} className="rounded-full px-2 py-[3px] text-[11px] font-medium text-red-600 hover:bg-red-50 disabled:opacity-50">Delete</button>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
          {loading && posts.length === 0 ? (
            <p className="text-sm text-ink/50">Loading…</p>
          ) : upcomingEntries.length === 0 ? (
            <p className="text-sm text-ink/50">Nothing scheduled from today onward. Write a post under Draft, or click a day on the calendar.</p>
          ) : (
            <>
            {upcomingIds.length > 0 && (
            <label className="mb-2 flex w-fit cursor-pointer items-center gap-1.5 rounded-lg bg-black/5 px-2 py-1 text-[11px] font-medium text-ink/70">
              <input type="checkbox" checked={allUpcomingPicked} onChange={() => toggleGroup(upcomingIds, allUpcomingPicked)} disabled={Boolean(bulk)} className="h-3.5 w-3.5 accent-rose-600" aria-label="Select all upcoming posts" />
              Select all upcoming ({upcomingIds.length})
            </label>
            )}
            <ol className="max-h-[70vh] space-y-2 overflow-y-auto pr-1">
              {upcomingEntries.map((entry) => {
                if (entry.kind === 'run') {
                  // An Autopilot draft: not in Metricool yet, so no tick, no
                  // move, no delete — preview, approve or skip.
                  const r = entry.run;
                  return (
                    <li key={'run-' + r.id} className="flex gap-2 rounded-xl border border-amber-300/70 bg-amber-50 p-3 text-[12px]">
                      <div className="min-w-0 flex-1">
                        <button type="button" onClick={() => setPreviewRunId(r.id)} title="Preview this draft" className="flex w-full items-center justify-between gap-2 text-left">
                          <span className="font-semibold text-ink">{fmtScheduleSlot(r.scheduled_for)}</span>
                          <span className="rounded-full bg-amber-200/80 px-2 py-[2px] text-[10px] font-semibold text-amber-900">Autopilot · needs approval</span>
                        </button>
                        <button type="button" onClick={() => setPreviewRunId(r.id)} className="mt-1 line-clamp-2 block w-full text-left text-ink/80" title="Preview this draft">{r.angle?.query || runText(r.pack) || r.template_name}</button>
                        <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                          <span className="rounded-full bg-black/5 px-2 py-[1px] text-[10px] text-ink/60">{r.template_name}</span>
                          <span className="flex-1" />
                          <button type="button" onClick={() => setPreviewRunId(r.id)} className="rounded-full px-2 py-[3px] text-[11px] font-medium text-ink/70 ring-1 ring-black/10 hover:bg-black/5">Preview</button>
                          {/* One button per repair — citation, image, copy — each its own AI cost. */}
                          {fixRunning(r.angle) ? (
                            <button type="button" disabled className="rounded-full bg-accent px-2.5 py-[3px] text-[11px] font-semibold text-white opacity-50">Fixing…</button>
                          ) : fixButtons(fixPlan(runFixInput(r))).map((b) => (
                            <button key={b.step} type="button" disabled={runBusy === r.id} onClick={() => fixRun(r, b.step)} title={b.title} className="rounded-full bg-accent px-2.5 py-[3px] text-[11px] font-semibold text-white hover:opacity-90 disabled:opacity-50">{b.label}</button>
                          ))}
                          <button type="button" disabled={runBusy === r.id || fixRunning(r.angle)} onClick={() => approveRunScheduled(r)} className="rounded-full bg-accent px-2.5 py-[3px] text-[11px] font-semibold text-white hover:opacity-90 disabled:opacity-50">{runBusy === r.id ? 'Working…' : 'Approve & schedule'}</button>
                          {!r.writes_article && (
                            <button type="button" disabled={runBusy === r.id || fixRunning(r.angle)} onClick={() => approveRunDraft(r)} className="rounded-full px-2 py-[3px] text-[11px] font-medium text-ink/60 ring-1 ring-black/10 hover:bg-black/5 disabled:opacity-50">Approve as draft</button>
                          )}
                          <button type="button" disabled={runBusy === r.id} onClick={() => skipRun(r)} className="rounded-full px-2 py-[3px] text-[11px] font-medium text-red-600 hover:bg-red-50 disabled:opacity-50">Skip</button>
                        </div>
                      </div>
                    </li>
                  );
                }
                const p = entry.post;
                const waiting = isAwaitingApproval(p.status);
                // Waiting on its video rather than on a reviewer. Approve is
                // refused server-side for these, so the list offers the attach
                // instead of a button that cannot work.
                const pending = p.videoPending === true;
                const d = p.publication_date ? new Date(p.publication_date) : null;
                return (
                  <li key={p.id} data-ai-target="post" data-ai-id={String(p.id)} className={'flex gap-2 rounded-xl border p-3 text-[12px] ' + (picked.has(String(p.id)) ? 'border-red-300 bg-red-50' : waiting ? 'border-amber-200 bg-amber-50/60' : 'border-black/5 bg-canvas')}>
                    <input
                      type="checkbox"
                      checked={picked.has(String(p.id))}
                      onChange={() => togglePick(String(p.id))}
                      disabled={Boolean(bulk)}
                      className="mt-0.5 h-3.5 w-3.5 shrink-0 accent-rose-600"
                      aria-label="Select this post"
                    />
                    <div className="min-w-0 flex-1">
                    <button type="button" onClick={() => setPreviewId(String(p.id))} title="Preview this post" className="flex w-full items-center justify-between gap-2 text-left">
                      <span className="font-semibold text-ink">{d ? d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' }) : '—'} · {timeLabel(p.publication_date)}</span>
                      <span className={'rounded-full px-2 py-[2px] text-[10px] font-semibold ' + (pending ? 'bg-rose-100 text-rose-700' : waiting ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800')}>{pending ? 'Pending video' : waiting ? 'Waiting for approval' : postStatusMeta(p.status).label}</span>
                    </button>
                    <button type="button" onClick={() => setPreviewId(String(p.id))} className="mt-1 line-clamp-2 block w-full text-left text-ink/80" title="Preview this post">{p.text || 'Untitled post'}</button>
                    {/* WHICH ROW this post was written from. A two-line caption
                        preview does not identify a post in a forty-row tab; a
                        row number does, and it is the thing somebody needs in
                        order to go and edit the copy. Opens the sheet at that
                        exact cell. Absent for posts with no sheet behind them
                        (hand-written, or from a template). */}
                    {sheetRowUrl(p.source) && (
                      <a
                        href={sheetRowUrl(p.source) as string}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        title={sheetRowTitle(p.source)}
                        className="mt-1 inline-flex items-center gap-1 text-[11px] font-medium text-accent hover:underline"
                      >
                        <span aria-hidden>{'\u{1F4C4}'}</span> {sheetRowLabel(p.source)} {'\u2197'}
                      </a>
                    )}
                    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                      {(p.providers || []).map((n) => <span key={n} className="rounded-full bg-black/5 px-2 py-[1px] text-[10px] text-ink/60">{networkLabel(n)}</span>)}
                      <span className="flex-1" />
                      <button type="button" onClick={() => setPreviewId(String(p.id))} className="rounded-full px-2 py-[3px] text-[11px] font-medium text-ink/70 ring-1 ring-black/10 hover:bg-black/5">Preview</button>
                      {pending ? (
                        <button type="button" disabled={saving === p.id} onClick={() => void attachVideo(p)} title="This copy was written from a video and has none attached. Click to attach it." className="rounded-full bg-rose-600 px-2.5 py-[3px] text-[11px] font-semibold text-white hover:opacity-90 disabled:opacity-50">{saving === p.id ? 'Attaching…' : 'Attach video'}</button>
                      ) : waiting && (
                        <button type="button" disabled={saving === p.id} onClick={() => void approve(p)} className="rounded-full bg-accent px-2.5 py-[3px] text-[11px] font-semibold text-white hover:opacity-90 disabled:opacity-50">Approve</button>
                      )}
                      <button type="button" disabled={saving === p.id} onClick={() => { const day = d ? new Date(d.getTime() + 86400000) : null; if (day) void reschedule(String(p.id), day); }} className="rounded-full px-2 py-[3px] text-[11px] font-medium text-ink/60 hover:bg-black/5" title="Move one day later">+1 day</button>
                      <button type="button" disabled={saving === p.id || Boolean(bulk)} onClick={() => openReschedule(p)} title="Pick any date and time" className="rounded-full px-2 py-[3px] text-[11px] font-medium text-ink/70 ring-1 ring-black/10 hover:bg-black/5 disabled:opacity-50">Reschedule</button>
                      <button type="button" disabled={saving === p.id || Boolean(bulk)} onClick={() => void removePost(p)} className="rounded-full px-2 py-[3px] text-[11px] font-medium text-red-600 hover:bg-red-50 disabled:opacity-50">Delete</button>
                    </div>
                    </div>
                  </li>
                );
              })}
            </ol>
            </>
          )}
        </div>
      </aside>
      </div>

      {/* RESCHEDULE: any date and time, read on the schedule clock (the brand's),
          sent exactly as a drag to another day is — Metricool moves with it. */}
      {rescheduleFor && (() => {
        const post = rescheduleFor.kind === 'post' ? posts.find((p) => String(p.id) === rescheduleFor.id) : null;
        const run = rescheduleFor.kind === 'run' ? runs.find((r) => r.id === rescheduleFor.id) : null;
        const subjectText = post ? (post.text || 'Untitled post') : run ? (run.angle?.query || runText(run.pack) || run.template_name) : '';
        const currentIso = post ? post.publication_date : run ? run.scheduled_for : null;
        const iso = scheduleInstantFromInput(rescheduleFor.value);
        return (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/30 p-4" onClick={() => setRescheduleFor(null)} role="dialog" aria-modal="true" aria-label="Reschedule this post">
            <form className="w-full max-w-sm rounded-2xl bg-surface p-5 shadow-2xl ring-1 ring-black/10" onClick={(e) => e.stopPropagation()} onSubmit={(e) => { e.preventDefault(); void saveReschedule(); }}>
              <div className="text-[15px] font-semibold text-ink">Reschedule</div>
              {subjectText && <p className="mt-1 line-clamp-2 text-[12px] text-ink/60">{subjectText}</p>}
              {run && <p className="mt-1 text-[11px] text-ink/50">An Autopilot draft: its time moves, the draft and its approval status stay. Approve it once it is where you want it.</p>}
              <label className="mt-4 block text-[11px] font-semibold uppercase tracking-wide text-ink/50">New date and time · {scheduleTzLabel()}</label>
              <input
                type="datetime-local"
                autoFocus
                value={rescheduleFor.value}
                onChange={(e) => setRescheduleFor({ ...rescheduleFor, value: e.target.value })}
                className="mt-1 w-full rounded-xl bg-canvas px-3 py-2 text-[14px] text-ink ring-1 ring-black/10 focus:outline-none focus:ring-2 focus:ring-accent"
              />
              <p className="mt-1.5 text-[11px] text-ink/50">
                {currentIso ? 'Now ' + fmtScheduleDateTime(currentIso) + '. ' : ''}
                {iso ? 'Goes out ' + fmtScheduleDateTime(iso) + '.' : 'Pick a date and a time.'}
                {iso && new Date(iso).getTime() < Date.now() ? ' That is in the past.' : ''}
              </p>
              <div className="mt-4 flex items-center justify-end gap-2">
                <button type="button" onClick={() => setRescheduleFor(null)} className="rounded-full px-3 py-1.5 text-[12px] font-medium text-ink/70 ring-1 ring-black/10 hover:bg-black/5">Cancel</button>
                <button type="submit" disabled={!iso || saving === rescheduleFor.id || runBusy === rescheduleFor.id} className="rounded-full bg-accent px-4 py-1.5 text-[12px] font-semibold text-white hover:opacity-90 disabled:opacity-50">{saving === rescheduleFor.id || runBusy === rescheduleFor.id ? 'Moving…' : 'Reschedule'}</button>
              </div>
            </form>
          </div>
        );
      })()}
      {previewPost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4" onClick={() => setPreviewId(null)}>
          <div className="relative flex max-h-[90vh] w-full max-w-lg flex-col overflow-hidden rounded-2xl bg-surface shadow-2xl ring-1 ring-black/10" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="Post preview">
            <div className="flex items-start justify-between gap-3 border-b border-black/5 px-5 py-4">
              <div className="min-w-0">
                <h3 className="truncate text-base font-semibold text-ink">{previewPost.packTitle || 'Post preview'}</h3>
                <p className="mt-0.5 text-[12px] text-ink/50">
                  {previewPost.publication_date ? new Date(previewPost.publication_date).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' }) + ' · ' + timeLabel(previewPost.publication_date) : '—'}
                  {' · '}{(previewPost.providers || []).map((n) => networkLabel(n)).join(', ')}
                </p>
              </div>
              <button type="button" onClick={() => setPreviewId(null)} className="rounded-full px-2 text-lg leading-none text-ink/50 hover:bg-black/5" aria-label="Close preview">×</button>
            </div>
            <div className="overflow-y-auto px-5 py-4">
              {previewPost.mediaUrl ? (
                <video src={previewPost.mediaUrl} controls preload="metadata" className="mb-3 max-h-72 w-full rounded-xl bg-black" />
              ) : previewPost.imageUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={previewPost.imageUrl} alt="Post image" className="mb-3 max-h-72 w-full rounded-xl object-contain ring-1 ring-black/5" />
              ) : null}
              {previewPost.draft_id && !previewPost.mediaUrl && (
                <HeroImageControls
                  draftId={previewPost.draft_id}
                  hasImage={Boolean(previewPost.imageUrl)}
                  note={previewPost.metricool_post_id
                    ? 'The new picture is sent to Metricool as soon as it is ready.'
                    : 'This post is not in Metricool yet: the new picture goes with it when it is next sent.'}
                  beforeChange={() => !previewPost.metricool_post_id || window.confirm('This replaces the picture and updates the post in Metricool too. Continue?')}
                  onChanged={() => afterPostImageChanged(previewPost)}
                />
              )}
              <div className="whitespace-pre-wrap text-[13px] leading-relaxed text-ink">{previewPost.text || 'Untitled post'}</div>
              {fixNote && fixNote.id === String(previewPost.id) && (
                <div className={'mt-3 rounded-xl px-3 py-2 text-[12px] ' + (fixNote.changed ? 'border border-emerald-200 bg-emerald-50 text-emerald-800' : 'border border-black/10 bg-canvas text-ink/70')} role="status">
                  {fixNote.note}
                </div>
              )}
              {sheetRowUrl(previewPost.source) && (
                <a href={sheetRowUrl(previewPost.source) as string} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-1 text-[12px] font-medium text-accent hover:underline">
                  <span aria-hidden>{'\u{1F4C4}'}</span> {sheetRowLabel(previewPost.source)} {'\u2197'}
                </a>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2 border-t border-black/5 bg-canvas px-5 py-3">
              {listedIds.includes(String(previewPost.id)) && (
                <label className="flex cursor-pointer items-center gap-1.5 text-[12px] text-ink/70">
                  <input type="checkbox" checked={picked.has(String(previewPost.id))} onChange={() => togglePick(String(previewPost.id))} disabled={Boolean(bulk)} className="h-3.5 w-3.5 accent-rose-600" />
                  Select for bulk delete
                </label>
              )}
              <span className="flex-1" />
              <button type="button" disabled={saving === previewPost.id} onClick={() => void verifyFix(previewPost)} title="Check that the cited study supports this post; replace it with one that does if not" className="rounded-full px-3 py-1 text-[12px] font-medium text-ink/70 ring-1 ring-black/10 hover:bg-black/5 disabled:opacity-50">{saving === previewPost.id ? 'Checking…' : 'Verify / fix'}</button>
              <button type="button" onClick={() => { jumpTo(previewPost); setPreviewId(null); }} className="rounded-full px-3 py-1 text-[12px] font-medium text-ink/70 ring-1 ring-black/10 hover:bg-black/5">Show on calendar</button>
              {previewPost.videoPending === true ? (
                <button type="button" disabled={saving === previewPost.id} onClick={() => void attachVideo(previewPost)} className="rounded-full bg-rose-600 px-3 py-1 text-[12px] font-semibold text-white hover:opacity-90 disabled:opacity-50">{saving === previewPost.id ? 'Attaching…' : 'Attach video'}</button>
              ) : isAwaitingApproval(previewPost.status) && !overdueIds.includes(String(previewPost.id)) ? (
                <button type="button" disabled={saving === previewPost.id} onClick={() => void approve(previewPost)} className="rounded-full bg-accent px-3 py-1 text-[12px] font-semibold text-white hover:opacity-90 disabled:opacity-50">Approve</button>
              ) : null}
              {overdueIds.includes(String(previewPost.id)) ? (
                <button type="button" disabled={saving === previewPost.id} onClick={() => { const t = new Date(today.getTime() + 86400000); void reschedule(String(previewPost.id), t); setPreviewId(null); }} className="rounded-full bg-accent px-3 py-1 text-[12px] font-semibold text-white hover:opacity-90 disabled:opacity-50">Move to tomorrow</button>
              ) : (
                <button type="button" disabled={saving === previewPost.id} onClick={() => { const d = previewPost.publication_date ? new Date(new Date(previewPost.publication_date).getTime() + 86400000) : null; if (d) void reschedule(String(previewPost.id), d); }} className="rounded-full px-3 py-1 text-[12px] font-medium text-ink/70 ring-1 ring-black/10 hover:bg-black/5">+1 day</button>
              )}
              <button type="button" disabled={saving === previewPost.id || Boolean(bulk)} onClick={() => openReschedule(previewPost)} title="Pick any date and time" className="rounded-full px-3 py-1 text-[12px] font-medium text-ink/70 ring-1 ring-black/10 hover:bg-black/5 disabled:opacity-50">Reschedule</button>
              <button type="button" disabled={saving === previewPost.id || Boolean(bulk)} onClick={() => void removePost(previewPost)} className="rounded-full px-3 py-1 text-[12px] font-medium text-red-600 ring-1 ring-red-200 hover:bg-red-50 disabled:opacity-50">Delete</button>
            </div>
          </div>
        </div>
      )}

      {previewRun && (
        <RunPreview
          run={previewRun}
          busy={runBusy === previewRun.id}
          onClose={() => setPreviewRunId(null)}
          onApprove={() => approveRunScheduled(previewRun)}
          onApproveDraft={() => approveRunDraft(previewRun)}
          onSkip={() => skipRun(previewRun)}
          onReschedule={() => openRescheduleRun(previewRun)}
          onFix={(step) => fixRun(previewRun, step)}
          imageControls={
            <HeroImageControls
              draftId={previewRun.draft_id}
              hasImage={Boolean(previewRun.pack?._image?.url)}
              note="Nothing reaches Metricool until you approve."
              onChanged={async () => { await loadRuns(); announce('images', 'drafts', 'autopilot'); }}
            />
          }
        />
      )}

      {scheduleDay && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4"
          onClick={() => { if (!pBusy) setScheduleDay(null); }}
        >
          <div
            className="relative w-full max-w-md rounded-2xl bg-surface p-5 shadow-2xl ring-1 ring-black/10"
            onClick={(e) => e.stopPropagation()}
          >
            <PanelLoader scope="calendar" rounded="rounded-2xl" />
            <div className="mb-4 flex items-start justify-between">
              <div>
                <h3 className="text-base font-semibold text-ink">Schedule a post</h3>
                <p className="mt-0.5 text-sm text-ink/50">
                  {scheduleDay.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
                </p>
              </div>
              <button onClick={() => setScheduleDay(null)} aria-label="Close" className="rounded-full p-1 text-ink/40 hover:bg-black/5 hover:text-ink">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18M6 6l12 12" /></svg>
              </button>
            </div>

            <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-ink/40">Networks</label>
            <div className="mb-4 flex flex-wrap gap-2">
              {NETWORKS.map((n) => (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => togglePNetwork(n.id)}
                  aria-pressed={pNetworks.includes(n.id)}
                  className={
                    'rounded-full px-3 py-1.5 text-[13px] font-medium ring-1 transition ' +
                    (pNetworks.includes(n.id) ? 'bg-accent text-white ring-accent' : 'bg-canvas text-ink ring-black/10 hover:ring-accent/50')
                  }
                >
                  <span aria-hidden className="mr-1">{n.emoji}</span>{n.label}
                </button>
              ))}
            </div>
            {/* This panel had no way to attach media at all, so picking a video
                channel here could only ever produce a draft Metricool refuses.
                Same picker the composer uses. */}
            <MediaPicker
              value={pMedia}
              label={pMediaLabel}
              onChange={(url, lbl) => { setPMedia(url); setPMediaLabel(lbl); }}
              hint={mediaProblem(pNetworks, '') ? 'YouTube and TikTok will not take a post without one.' : undefined}
            />
            <div className="mb-4" />

            <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-ink/40">Time</label>
            <input
              type="time"
              value={pTime}
              onChange={(e) => setPTime(e.target.value)}
              className="mb-4 w-full rounded-xl bg-canvas px-3 py-2 text-sm text-ink outline-none ring-1 ring-black/10 focus:ring-accent/40"
            />

            <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-ink/40">Draft with AI</label>
            <div className="mb-4 rounded-xl bg-canvas p-3 ring-1 ring-black/10">
              <div className="mb-2 flex items-center gap-2">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M12 2l1.9 5.4L19 9.3l-4.6 2.3L12 17l-2.4-5.4L5 9.3l5.1-1.9L12 2z" fill="#0071e3" />
                </svg>
                <span className="text-xs text-ink/50">Let GPT or Anthropic write this post for you.</span>
              </div>
              <div className="mb-2 flex gap-2">
                {([['anthropic', 'Anthropic'], ['openai', 'GPT']] as const).map(([val, label]) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setAiProvider(val)}
                    className={'rounded-full px-3 py-1 text-xs font-medium transition ring-1 ring-black/10 ' + (aiProvider === val ? 'bg-accent text-white' : 'bg-surface text-ink hover:bg-black/5')}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  value={aiTopic}
                  onChange={(e) => setAiTopic(e.target.value)}
                  placeholder="What should this post be about?"
                  className="w-full rounded-lg bg-surface px-3 py-2 text-sm text-ink outline-none ring-1 ring-black/10 focus:ring-accent/40"
                />
                <button
                  type="button"
                  onClick={draftWithAI}
                  disabled={aiBusy}
                  className="shrink-0 rounded-lg bg-accent px-3 py-2 text-sm font-medium text-white transition hover:opacity-90 disabled:opacity-50"
                >
                  {aiBusy ? 'Drafting…' : 'Draft with AI'}
                </button>
              </div>
            </div>

            <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-ink/40">Post text</label>
            <textarea
              value={pText}
              onChange={(e) => setPText(e.target.value)}
              rows={4}
              placeholder="What should this post say?"
              className="mb-1 w-full resize-none rounded-xl bg-canvas px-3 py-2 text-sm text-ink outline-none ring-1 ring-black/10 focus:ring-accent/40"
            />
            <p className={'mb-4 text-xs ' + (pOverBy > 0 ? 'text-red-600' : 'text-ink/40')}>
              {pOverBy > 0
                ? 'Too long for ' + networkLabel(pLimit!.network) + ' by ' + pOverBy.toLocaleString() + ' character' + (pOverBy === 1 ? '' : 's') + '. Trim it, or unselect that channel.'
                : pLimit
                  ? pText.length.toLocaleString() + ' / ' + pLimit.limit.toLocaleString() + ' characters · ' + networkLabel(pLimit.network) + ' is the tightest limit'
                  : pText.length.toLocaleString() + ' characters'}
            </p>

            {pStatus && (
              <div className={'mb-3 text-sm ' + (pStatus.startsWith('Error') ? 'text-red-600' : 'text-ink/60')}>{pStatus}</div>
            )}

            <div className="flex items-center justify-end gap-2">
              <button onClick={() => setScheduleDay(null)} disabled={pBusy} className="rounded-full border border-black/10 px-4 py-2 text-sm text-ink/70 transition hover:bg-black/5 disabled:opacity-50">Cancel</button>
              <button onClick={submitSchedule} disabled={pBusy || pOverBy > 0} className="rounded-full bg-accent px-4 py-2 text-sm font-medium text-white transition hover:opacity-90 disabled:opacity-50">
                {pBusy ? 'Scheduling…' : 'Schedule'}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

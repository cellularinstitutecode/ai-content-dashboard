# AI Content Dashboard — blank template

An AI content studio for one brand: it writes multi-channel post packs
(Instagram, Facebook, LinkedIn, TikTok, YouTube, blog), makes on-brand images
and cards, turns videos into posts, plans a weekly strategy, and schedules
everything through Metricool — with drafts, auth and history in Supabase.

This copy is **blank**: no API keys, no account ids, no brand. Brand Brain
starts empty, the Google Sheets / Drive connections are empty, and the weekly
strategy is a generic example. Add your keys, fill in Brand Brain, and it is
yours.

**Start here → [SETUP.md](./SETUP.md)**

## Quick start (about 20 minutes, free tiers)

1. **Put this folder on GitHub** (see [SETUP.md](./SETUP.md) step 0). A
   workflow points the button below at your repository on the first push.
2. **Create a Supabase project** (free) and copy its URL and keys.
3. **Click Deploy.** Vercel asks for the keys and builds the app.

   [![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2FYOUR_GITHUB_USER%2FYOUR_REPO&root-directory=web&project-name=ai-content-dashboard&repository-name=ai-content-dashboard&env=NEXT_PUBLIC_SUPABASE_URL,NEXT_PUBLIC_SUPABASE_ANON_KEY,SUPABASE_SERVICE_ROLE_KEY,AI_PROVIDER,OPENAI_API_KEY,ALLOWED_EMAILS,NEXT_PUBLIC_ALLOWED_EMAILS,CRON_SECRET,NEXT_PUBLIC_BRAND_NAME&envDescription=Supabase%20keys%2C%20one%20AI%20key%20(AI_PROVIDER%3Dopenai%20with%20OPENAI_API_KEY)%2C%20who%20may%20sign%20in%2C%20a%20random%20CRON_SECRET%20and%20your%20brand%20name.%20Metricool%20and%20the%20rest%20can%20be%20added%20later.&envLink=https%3A%2F%2Fgithub.com%2FYOUR_GITHUB_USER%2FYOUR_REPO%2Fblob%2Fmain%2FSETUP.md)

4. **Create the database:** in GitHub → Settings → Secrets and variables →
   Actions, add the secret `SUPABASE_DB_URL`, then Actions → **Set up
   database** → Run workflow. (Or paste `web/supabase/setup.sql` into the
   Supabase SQL editor.)
5. **Turn on the background jobs:** in the same place add the variable
   `APP_URL` (your Vercel address) and the secret `CRON_SECRET` (same value as
   in Vercel).
6. **Sign in, fill in Brand Brain**, and add Metricool to post.

Everything after that runs on its own: CI checks every change, GitHub runs
the hourly jobs, Vercel runs the daily ones and redeploys on every push.

## Structure

```
.
├── SETUP.md                     step-by-step setup, cheapest configuration
├── Dockerfile                   self-hosted build (Dokploy / any Docker host)
├── .github/workflows/
│   ├── ci.yml                   lint, typecheck, tests, build on every PR
│   ├── first-run.yml            points the Deploy button at your repo (once)
│   ├── setup-database.yml       creates the Supabase tables (needs SUPABASE_DB_URL)
│   └── scheduled-jobs.yml       hourly background jobs (needs APP_URL + CRON_SECRET)
├── docs/video-autopilot.md      how the video → post pipeline works
├── index.html                   obsolete static prototype (not deployed)
└── web/                         the Next.js app — everything that runs
    ├── .env.example             EVERY setting, documented (copy to .env.local)
    ├── app/                     pages + API routes (/api/*)
    ├── components/              UI components
    ├── lib/                     engine: AI, compliance, strategy, images, video, Metricool…
    │   ├── brand-identity.ts    deployment-wide brand fallbacks (from env)
    │   ├── brand-visual.ts      default (neutral) visual identity
    │   ├── brand-marks.ts       your logo as SVG paths (empty)
    │   └── content-strategy.ts  the EXAMPLE weekly strategy — replace it
    ├── supabase/setup.sql       the whole database in one file (generated)
    ├── supabase/*.sql           its parts
    ├── deploy/                  Dokploy guide + schedules
    ├── vercel.json              Vercel daily crons (free-plan safe)
    ├── e2e/                     end-to-end tests against mock services
    └── test/                    extra unit tests
```

## Local development

```bash
cd web
cp .env.example .env.local   # fill in your values
npm install
npm run dev                  # http://localhost:3000
npm test                     # unit tests
```

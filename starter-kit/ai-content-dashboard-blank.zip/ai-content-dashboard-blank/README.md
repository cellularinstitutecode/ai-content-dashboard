# AI Content Dashboard — blank template

An AI content studio for one brand: it writes multi-channel post packs
(Instagram, Facebook, LinkedIn, TikTok, YouTube, blog), makes on-brand images
and cards, turns videos into posts, plans a weekly strategy, and schedules
everything through Metricool — with drafts, auth and history in Supabase.

This copy is **blank**: no API keys, no account ids, no brand. Brand Brain
starts empty, the Google Sheets / Drive connections are empty, and the weekly
strategy is a generic example. Add your keys, fill in Brand Brain, and it is
yours.

**Start here → [SETUP.md](./SETUP.md)**

## Structure

```
.
├── SETUP.md                     step-by-step setup, cheapest configuration
├── Dockerfile                   self-hosted build (Dokploy / any Docker host)
├── .github/workflows/
│   ├── ci.yml                   lint, typecheck, tests, build on every PR
│   └── scheduled-jobs.yml       OPTIONAL free cron runner (off until configured)
├── docs/video-autopilot.md      how the video → post pipeline works
├── index.html                   obsolete static prototype (not deployed)
└── web/                         the Next.js app — everything that runs
    ├── .env.example             EVERY setting, documented (copy to .env.local)
    ├── app/                     pages + API routes (/api/*)
    ├── components/              UI components
    ├── lib/                     engine: AI, compliance, strategy, images, video, Metricool…
    │   ├── brand-identity.ts    deployment-wide brand fallbacks (from env)
    │   ├── brand-visual.ts      default (neutral) visual identity
    │   ├── brand-marks.ts       your logo as SVG paths (empty)
    │   └── content-strategy.ts  the EXAMPLE weekly strategy — replace it
    ├── supabase/*.sql           database schema (run in the Supabase SQL editor)
    ├── deploy/                  Dokploy guide + schedules
    ├── vercel.json              Vercel crons
    ├── e2e/                     end-to-end tests against mock services
    └── test/                    extra unit tests
```

## Local development

```bash
cd web
cp .env.example .env.local   # fill in your values
npm install
npm run dev                  # http://localhost:3000
npm test                     # unit tests
```

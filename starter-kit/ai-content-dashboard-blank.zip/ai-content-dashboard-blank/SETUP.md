# Setup

Everything in this repository is already in place: the app, the database
schema, the deploy configs and the tests. What is missing is only what
belongs to you — your API keys and your brand. Work through the steps in
order; the whole thing takes about an hour.

> **Never commit a real key.** Keys go in `web/.env.local` (git-ignored) for
> local use and in your host's environment settings for production.

---

## 0. Put it on GitHub

```bash
unzip ai-content-dashboard-blank.zip
cd ai-content-dashboard-blank
git init -b main
git add -A
git commit -m "Initial commit from the blank template"
# create an EMPTY repository on github.com (no README), then:
git remote add origin https://github.com/YOUR_GITHUB_USER/YOUR_REPO.git
git push -u origin main
```

The template starts with fresh history, so nothing from any earlier
deployment comes along. CI (`.github/workflows/ci.yml`) runs lint, typecheck,
tests and a build on every pull request; it needs no secrets.

## 1. Accounts you need

| Service | Required? | What it does here | Cost-saving note |
|---|---|---|---|
| **Supabase** | yes | database, sign-in, image storage | the free plan is enough to start |
| **Anthropic _or_ OpenAI** | yes (one) | writes the posts | one key is enough; see step 4 |
| **Metricool** | yes | schedules and publishes to the networks | API access depends on your Metricool plan |
| Hosting: **Vercel** or **Dokploy** | yes (one) | runs the app | see step 6 |
| OpusClip | optional | cuts long videos into clips | leave `OPUS_*` blank to switch off |
| Semrush | optional | keyword / SEO research | leave `SEMRUSH_*` blank; the app falls back to AI keyword ideas |
| WordPress | optional | publishes the weekly article | leave `WORDPRESS_*` blank |
| Google Cloud service account | optional | reads your content Sheets / Drive photos & videos | leave `GOOGLE_*` and `SOURCES_*` blank |

Everything optional degrades cleanly: its panel says it is not set up instead
of failing.

## 2. Supabase (database + sign-in)

1. Create a project at <https://supabase.com>.
2. **SQL editor** → run these files from `web/supabase/`, in this order (each
   is safe to re-run):
   1. `schema.sql` — core tables (drafts, posts, Brand Brain, templates…)
   2. `autopilot.sql` — the content engine
   3. `video-autopilot.sql`, `video-register.sql`, `metricool-uploads.sql` — video pipeline
   4. `library-photos.sql` — photo library
   5. `semrush.sql`, `semrush-domain.sql` — only if you will use Semrush

   `maintenance.sql` is **not** a setup file: it is a clean-up script for
   later, when the database grows.
3. **Authentication → Providers**: enable **Email**.
4. **Project Settings → API**: copy the Project URL, the `anon` key and the
   `service_role` key into `NEXT_PUBLIC_SUPABASE_URL`,
   `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`.

The storage buckets (`content-images`, `content-videos`, `brand-assets`) are
created by the app on first use.

## 3. Who may sign in

```
ALLOWED_EMAILS=you@yourbrand.com,teammate@yourbrand.com
NEXT_PUBLIC_ALLOWED_EMAILS=you@yourbrand.com,teammate@yourbrand.com
```

Empty means **nobody** can sign in (deliberately: a missing setting must
never open the app to everyone). Then either add the user(s) in Supabase →
Authentication → Users (email + password), or use the sign-in page's
emailed magic link. In Supabase → Authentication → URL Configuration, set the
Site URL to your deployment's address so the magic link comes back to it.

## 4. AI provider

- **Cheapest single key: OpenAI.** One `OPENAI_API_KEY` covers writing,
  images, video transcription and the image check. Set `AI_PROVIDER=openai`
  and keep the economical models suggested in `.env.example`
  (`OPENAI_MODEL=gpt-4o-mini`, `OPENAI_IMAGE_MODEL=gpt-image-1-mini`).
- **Anthropic only:** set `ANTHROPIC_API_KEY` (`AI_PROVIDER=anthropic` is the
  default). Copy is written by Claude; AI image generation stays off.
- **Both:** Claude writes, OpenAI makes pictures and transcripts. The
  dashboard has a per-request toggle.

More savings, all in `.env.example`:
- `IMAGE_VERIFY=off` skips the vision check on every generated image.
- `IMAGE_GEN=off` stops AI pictures entirely (the photo library and brand
  cards still work).
- Leave Semrush blank: keyword research falls back to the AI.
- Autopilot only spends when templates are active; nothing runs on its own
  until you create them.

## 5. Metricool

In Metricool → account settings → API, copy your **user token**, and note the
**userId** and **blogId** (they appear in Metricool's own URLs as
`?blogId=…&userId=…`).

```
METRICOOL_USER_TOKEN=…
METRICOOL_USER_ID=…
METRICOOL_BLOG_ID=…
NEXT_PUBLIC_METRICOOL_USER_ID=…   # same values, for the browser
NEXT_PUBLIC_METRICOOL_BLOG_ID=…
SCHEDULE_TIMEZONE=America/New_York   # your IANA zone; default is UTC
```

By default posts arrive in Metricool **scheduled**. Set `PUBLISH_MODE=review`
to have them arrive as drafts you approve first.

## 6. Deploy — pick one host

Generate the two app secrets first:

```bash
openssl rand -hex 32   # → CRON_SECRET
openssl rand -hex 32   # → MEDIA_URL_SECRET
```

### Option A — Dokploy on your own small server (lowest running cost)

One fixed monthly server bill, no per-request limits, and the long video jobs
never hit a serverless timeout. Follow `web/deploy/DOKPLOY.md`; the
repository `Dockerfile` builds the app and `web/deploy/dokploy-schedules.json`
lists the background jobs to add as Dokploy Schedule Jobs.

### Option B — Vercel

1. Import your GitHub repository in Vercel. **Root directory: `web`.**
2. Paste your environment variables (Project → Settings → Environment Variables).
3. Deploy.

The background jobs in `web/vercel.json` run more often than once a day.
Vercel's Hobby plan only allows daily cron jobs, so **on Hobby**:
1. delete the three sub-daily entries (`/api/autopilot/tick`,
   `/api/videos/watch`, `/api/library/index`) from `web/vercel.json`, and
2. turn on `.github/workflows/scheduled-jobs.yml` instead: in GitHub →
   Settings → Secrets and variables → Actions, add the variable `APP_URL`
   (your deployment's https address) and the secret `CRON_SECRET` (the same
   value as in Vercel). It is free on public repositories; on private ones it
   uses your included Actions minutes.

On Vercel Pro, leave `vercel.json` as it is and do not enable the workflow —
run the jobs on one scheduler only.

## 7. Make it your brand

1. Set the brand basics in the environment (all optional, used before Brand
   Brain is filled in):

   ```
   NEXT_PUBLIC_BRAND_NAME=Your Brand
   BRAND_DESCRIPTION=a family-run bakery
   BRAND_LOCATION=Austin, Texas
   BRAND_HASHTAG=#yourbrand
   BRAND_WEBSITE=https://yourbrand.com
   CONTACT_EMAIL=hello@yourbrand.com
   ```

2. Sign in and open **Brand Brain** (`/brand`). It starts empty. Fill in the
   name, mission, voice, audience, keywords, guidelines, your palette, and
   upload your licensed headline/body font files. Until you do, the app uses
   a neutral grey palette and open-licence stand-in fonts.
3. Optional logo: paste your logo's SVG path data into `web/lib/brand-marks.ts`
   (empty by default — cards simply carry no logo).
4. **Weekly strategy:** `web/lib/content-strategy.ts` is a generic example
   (14 posts a week across pillars like how-to, behind the scenes, customer
   stories). On the **Templates** page you can upload your own strategy
   document instead, or edit that file.
5. Optional settings that only some brands need:
   - `AVISO_PUBLICIDAD` — a regulatory advertising permit number that must
     appear on every post (some jurisdictions require one for health
     advertising). Blank = no notice.
   - `REQUIRE_CITATIONS` — `health-claims` (default: a post making a health
     claim must cite a study), `always`, or `off`.

## 8. Optional connections (blank by default)

- **Google Sheets / Drive** (content calendar sheet, video sheet, photo
  folder): create a Google Cloud service account, paste its JSON key into
  `GOOGLE_SERVICE_ACCOUNT_JSON`, share your sheets/folders with the service
  account's email, then set `SOURCES_CALENDAR_SHEET_ID`,
  `SOURCES_VIDEOS_SHEET_ID`, `SOURCES_IMAGES_FOLDER_ID` and `DRIVE_FOLDER_ID`.
  How the video sheet becomes posts: `docs/video-autopilot.md`.
- **OpusClip:** `OPUS_API_KEY`, `OPUS_WEBHOOK_URL`, `OPUS_WEBHOOK_SECRET`.
- **Semrush:** `SEMRUSH_API_KEY` (a Standard API v3 key) and `SEMRUSH_DOMAIN`.
- **WordPress:** `WORDPRESS_BASE_URL`, `WORDPRESS_USER`, `WORDPRESS_APP_PASSWORD`
  (an application password, not your login password).

## 9. Check it

Open the dashboard: the **System status** panel lists every integration and
says exactly which setting is missing. `GET /api/health` returns the same as
JSON.

Locally, before pushing changes:

```bash
cd web
npm run lint && npx tsc --noEmit && npm test && npm run build
```
